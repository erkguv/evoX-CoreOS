#include "url_codec.h"
/*
 * BFpilot - tiny single-purpose HTTP server.
 */

#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <sys/time.h>

#include "asset.h"
#include "appinst_direct.h"
#include "diag.h"
#include "fs.h"
#include "path_ops.h"
#include "pkg_install.h"
#include "tile_bootstrap.h"
#include "transfer.h"
#include "version.h"
#include "websrv.h"


#define HEADER_MAX 65536
#define CONTROL_TOKEN "bs5fm-local-reload"

#ifndef BFPILOT_WEB_PORT
#define BFPILOT_WEB_PORT 5905
#endif

/* Inherit large windows: Orbis often caps post-accept setsockopt. */
#ifndef BFPILOT_LISTEN_RCVBUF
#define BFPILOT_LISTEN_RCVBUF (4 * 1024 * 1024)
#endif
#ifndef BFPILOT_CONN_SNDBUF
#define BFPILOT_CONN_SNDBUF (4 * 1024 * 1024)
#endif
#ifndef BFPILOT_HTTP_KEEPALIVE_MAX
#define BFPILOT_HTTP_KEEPALIVE_MAX 64
#endif
#ifndef BFPILOT_LISTEN_BACKLOG
#define BFPILOT_LISTEN_BACKLOG 32
#endif

static __thread int g_tls_keep_alive = 0;

static int             g_websrv_srvfd = -1;
static pthread_mutex_t g_websrv_lock = PTHREAD_MUTEX_INITIALIZER;
static atomic_int g_websrv_exit_requested;
static unsigned short  g_websrv_port = BFPILOT_WEB_PORT;
static pthread_mutex_t g_launcher_lock = PTHREAD_MUTEX_INITIALIZER;
static bfpilot_launcher_diag_t g_launcher_diag = {
  .launcher_enabled = 1,
  .launcher_attempted = 0,
  .appinst_init_rc = -1,
  .title_dir_resolved = 0,
  .install_title_dir_resolved = 0,
  .install_title_rc = BFPILOT_DIAG_SKIPPED,
  .uninstall_resolved = 0,
  .uninstall_rc = BFPILOT_DIAG_SKIPPED,
  .install_all_resolved = 0,
  .install_all_rc = BFPILOT_DIAG_SKIPPED,
  .user_app_writable = -1,
  .launcher_install_rc = -1,
  .launcher_final_state = "skipped",
};


void
websrv_set_launcher_diag(const bfpilot_launcher_diag_t *diag) {
  if(!diag) return;
  pthread_mutex_lock(&g_launcher_lock);
  g_launcher_diag = *diag;
  g_launcher_diag.launcher_enabled = diag->launcher_enabled;
  pthread_mutex_unlock(&g_launcher_lock);
}


void
websrv_set_runtime_port(unsigned short port) {
  if(port != 0) {
    g_websrv_port = port;
  }
}


static const char *
status_text(int status) {
  switch(status) {
  case 200: return "OK";
  case 201: return "Created";
  case 202: return "Accepted";
  case 204: return "No Content";
  case 400: return "Bad Request";
  case 403: return "Forbidden";
  case 404: return "Not Found";
  case 405: return "Method Not Allowed";
  case 409: return "Conflict";
  case 413: return "Payload Too Large";
  case 500: return "Internal Server Error";
  case 503: return "Service Unavailable";
  case 507: return "Insufficient Storage";
  default:  return "OK";
  }
}


int
websrv_write_all(int fd, const void *data, size_t size) {
  const char *p = data;
  while(size > 0) {
    ssize_t n = send(fd, p, size, 0);
    if(n < 0) {
      if(errno == EINTR) continue;
      return -1;
    }
    if(n == 0) return -1;
    p += n;
    size -= (size_t)n;
  }
  return 0;
}


void
websrv_conn_set_keep_alive(int on) {
  g_tls_keep_alive = on ? 1 : 0;
}


int
websrv_conn_get_keep_alive(void) {
  return g_tls_keep_alive ? 1 : 0;
}


int
websrv_send_headers(int fd, int status, const char *mime, size_t size,
                    const char *extra) {
  char header[1024];
  const char *conn = g_tls_keep_alive ? "keep-alive" : "close";
  char clean_extra[512] = {0};
  if(extra && *extra) {
    size_t elen = strlen(extra);
    if(elen >= sizeof(clean_extra) - 2) elen = sizeof(clean_extra) - 3;
    memcpy(clean_extra, extra, elen);
    if(clean_extra[elen - 1] != '\n') {
      clean_extra[elen++] = '\r';
      clean_extra[elen++] = '\n';
    }
    clean_extra[elen] = '\0';
  }
  int n = snprintf(header, sizeof(header),
                   "HTTP/1.1 %d %s\r\n"
                   "Connection: %s\r\n"
                   "X-Content-Type-Options: nosniff\r\n"
                   "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n"
                   "Pragma: no-cache\r\n"
                   "Expires: 0\r\n"
                   "Content-Type: %s\r\n"
                   "Content-Length: %lu\r\n"
                   "%s"
                   "\r\n",
                   status, status_text(status),
                   conn,
                   mime ? mime : "application/octet-stream",
                   (unsigned long)size,
                   clean_extra);
  if(n < 0 || (size_t)n >= sizeof(header)) return -1;
  return websrv_write_all(fd, header, (size_t)n);
}


int
websrv_send_chunked_headers(int fd, int status, const char *mime,
                            const char *extra) {
  char header[4096];
  const char *conn = g_tls_keep_alive ? "keep-alive" : "close";
  char clean_extra[512] = {0};
  if(extra && *extra) {
    size_t elen = strlen(extra);
    if(elen >= sizeof(clean_extra) - 2) elen = sizeof(clean_extra) - 3;
    memcpy(clean_extra, extra, elen);
    if(clean_extra[elen - 1] != '\n') {
      clean_extra[elen++] = '\r';
      clean_extra[elen++] = '\n';
    }
    clean_extra[elen] = '\0';
  }
  int n = snprintf(header, sizeof(header),
                   "HTTP/1.1 %d %s\r\n"
                   "Connection: %s\r\n"
                   "X-Content-Type-Options: nosniff\r\n"
                   "Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n"
                   "Pragma: no-cache\r\n"
                   "Expires: 0\r\n"
                   "Content-Type: %s\r\n"
                   "Transfer-Encoding: chunked\r\n"
                   "%s"
                   "\r\n",
                   status, status_text(status), conn,
                   mime ? mime : "application/octet-stream",
                   clean_extra);
  if(n < 0 || (size_t)n >= sizeof(header)) return -1;
  return websrv_write_all(fd, header, (size_t)n);
}


int
websrv_write_chunk(int fd, const void *data, size_t size) {
  char prefix[32];
  int n;

  if(size == 0) return 0;
  n = snprintf(prefix, sizeof(prefix), "%lx\r\n", (unsigned long)size);
  if(n < 0 || (size_t)n >= sizeof(prefix)) return -1;
  if(websrv_write_all(fd, prefix, (size_t)n) != 0 ||
     websrv_write_all(fd, data, size) != 0 ||
     websrv_write_all(fd, "\r\n", 2) != 0) {
    return -1;
  }
  return 0;
}


int
websrv_write_chunk_end(int fd) {
  return websrv_write_all(fd, "0\r\n\r\n", 5);
}


int
websrv_send(int fd, int status, const char *mime,
            const void *data, size_t size) {
  if(websrv_send_headers(fd, status, mime, size, NULL) != 0) return -1;
  if(size == 0) return 0;
  return websrv_write_all(fd, data, size);
}


int
websrv_send_text(int fd, int status, const char *mime, const char *body) {
  return websrv_send(fd, status, mime, body ? body : "",
                     body ? strlen(body) : 0);
}


void
websrv_request_exit(void) {
  pthread_mutex_lock(&g_websrv_lock);
  atomic_store(&g_websrv_exit_requested, 1);
  int srvfd = g_websrv_srvfd;
  g_websrv_srvfd = -1;
  unsigned short port = g_websrv_port;
  pthread_mutex_unlock(&g_websrv_lock);

  if(srvfd >= 0) {
    shutdown(srvfd, SHUT_RDWR);
    close(srvfd);
  }

  if(port > 0) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if(fd >= 0) {
      struct sockaddr_in addr = {0};
      addr.sin_len = sizeof(addr);
      addr.sin_family = AF_INET;
      addr.sin_port = htons(port);
      addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
      int flags = fcntl(fd, F_GETFL, 0);
      if(flags >= 0) fcntl(fd, F_SETFL, flags | O_NONBLOCK);
      connect(fd, (struct sockaddr *)&addr, sizeof(addr));
      close(fd);
    }
  }
}


int
websrv_exit_requested(void) {
  return atomic_load(&g_websrv_exit_requested) ? 1 : 0;
}


static int
json_error_escape(char *out, size_t out_size, const char *message) {
  size_t pos = 0;
  const unsigned char *p = (const unsigned char *)(message ? message : "error");

  if(out_size == 0) return -1;
  for(; *p && pos + 7 < out_size; p++) {
    if(*p == '\\' || *p == '"') {
      out[pos++] = '\\';
      out[pos++] = (char)*p;
    } else if(*p == '\n') {
      out[pos++] = '\\';
      out[pos++] = 'n';
    } else if(*p == '\r') {
      out[pos++] = '\\';
      out[pos++] = 'r';
    } else if(*p == '\t') {
      out[pos++] = '\\';
      out[pos++] = 't';
    } else if(*p < 0x20) {
      int n = snprintf(out + pos, out_size - pos, "\\u%04x", *p);
      if(n < 0) return -1;
      pos += (size_t)n;
    } else {
      out[pos++] = (char)*p;
    }
  }
  out[pos] = 0;
  return 0;
}


int
websrv_send_error_json(int fd, int status, const char *message) {
  char escaped[512];
  char body[640];
  json_error_escape(escaped, sizeof(escaped), message);
  snprintf(body, sizeof(body), "{\"ok\":false,\"error\":\"%s\"}", escaped);
  return websrv_send_text(fd, status, "application/json", body);
}


void websrv_url_decode(char *out, size_t out_size, const char *in) {
  (void)bfpilot_url_decode(out, out_size, in ? in : "", in ? strlen(in) : 0);
}
int websrv_get_query_arg(const http_request_t *req, const char *name,
                           char *out, size_t out_size) {
  return bfpilot_form_arg(req ? req->query : "", name, out, out_size);
}

static int
find_header_end(const char *buf, size_t size) {
  for(size_t i = 3; i < size; i++) {
    if(buf[i - 3] == '\r' && buf[i - 2] == '\n' &&
       buf[i - 1] == '\r' && buf[i] == '\n') {
      return (int)(i + 1);
    }
  }
  return -1;
}


static size_t
content_length_from_headers(const char *headers) {
  const char *line = strstr(headers, "\r\n");
  if(!line) return 0;
  line += 2;
  while(*line) {
    const char *next = strstr(line, "\r\n");
    size_t len = next ? (size_t)(next - line) : strlen(line);
    if(len == 0) break;
    if(len > 15 && !strncasecmp(line, "Content-Length:", 15)) {
      return (size_t)strtoull(line + 15, NULL, 10);
    }
    if(!next) break;
    line = next + 2;
  }
  return 0;
}


/* HTTP/1.1 defaults to keep-alive unless client sends Connection: close. */
static int
client_wants_close(const char *headers) {
  const char *line = strstr(headers, "\r\n");
  if(!line) return 0;
  line += 2;
  while(*line) {
    const char *next = strstr(line, "\r\n");
    size_t len = next ? (size_t)(next - line) : strlen(line);
    if(len == 0) break;
    if(len > 11 && !strncasecmp(line, "Connection:", 11)) {
      const char *v = line + 11;
      while(*v == ' ' || *v == '\t') v++;
      if(!strncasecmp(v, "close", 5)) return 1;
    }
    if(!next) break;
    line = next + 2;
  }
  return 0;
}


static int
header_value(const char *headers, const char *name, char *out,
             size_t out_size) {
  size_t name_len;
  const char *line;
  if(!headers || !name || !out || out_size == 0) return 0;
  out[0] = 0;
  name_len = strlen(name);
  line = strstr(headers, "\r\n");
  if(!line) return 0;
  line += 2;
  while(*line) {
    const char *next = strstr(line, "\r\n");
    size_t line_len = next ? (size_t)(next - line) : strlen(line);
    if(line_len == 0) break;
    if(line_len > name_len && line[name_len] == ':' &&
       !strncasecmp(line, name, name_len)) {
      const char *value = line + name_len + 1;
      const char *end = line + line_len;
      while(value < end && (*value == ' ' || *value == '\t')) value++;
      while(end > value && (end[-1] == ' ' || end[-1] == '\t')) end--;
      size_t value_len = (size_t)(end - value);
      if(value_len == 0 || value_len >= out_size) return 0;
      memcpy(out, value, value_len);
      out[value_len] = 0;
      return 1;
    }
    if(!next) break;
    line = next + 2;
  }
  return 0;
}


static const char *
json_bool(int value) {
  return value ? "true" : "false";
}


static const char *
json_tristate(int value) {
  if(value < 0) return "null";
  return value ? "true" : "false";
}


static int
status_request(const http_request_t *req) {
  char body[768];
  time_t now = time(NULL);
  int n = snprintf(body, sizeof(body),
                   "{\"ok\":true,"
                   "\"name\":\"BFpilot\","
                   "\"tag\":\"%s\","
                   "\"version\":\"%s\","
                   "\"mode\":\"%s\","
                   "\"pid\":%ld,"
                   "\"now\":%ld,"
                   "\"services\":[\"web\",\"file-manager\",\"archive\","
                   "\"tile-installer\",\"pkg-installer\"],"
                   "\"diagReadOnly\":true,"
                   "\"allInOne\":true,"
                   "\"launcherCompiled\":%s,"
                   "\"launcherDisabled\":%s,"
                   "\"tileBusy\":%s,"
                   "\"pkgBusy\":%s,"
                   "\"fileJobBusy\":%s,"
                   "\"port\":%u}",
                   VERSION_TAG, BUILD_VERSION, BFPILOT_BUILD_MODE,
                   (long)getpid(), (long)now,
                   "true",
                   "false",
                   bfpilot_tile_bootstrap_busy() ? "true" : "false",
                   bfpilot_pkg_is_busy() ? "true" : "false",
                   transfer_job_busy() ? "true" : "false",
                   (unsigned int)g_websrv_port);
  if(n < 0) return -1;
  if((size_t)n >= sizeof(body)) n = (int)sizeof(body) - 1;
  return websrv_send(req->fd, 200, "application/json", body, (size_t)n);
}


static int
diag_request(const http_request_t *req) {
  char body[6144];
  char cwd[256];
  char launcher_status[64];
  char checkpoint[128];
  char cwd_json[512];
  char launcher_status_json[128];
  char launcher_final_json[64];
  char checkpoint_json[192];
  time_t now = time(NULL);
  int can_stat_root = bfpilot_diag_can_stat_root();
  int can_opendir_data = bfpilot_diag_can_opendir_data();
  int can_opendir_data_homebrew = bfpilot_diag_can_opendir_data_homebrew();
  int can_opendir_usb0 = bfpilot_diag_can_opendir_usb0();
  int can_opendir_ext0 = bfpilot_diag_can_opendir_ext0();
  int can_opendir_ext0_homebrew = bfpilot_diag_can_opendir_ext0_homebrew();
  int can_write_data = bfpilot_diag_can_write_data_bfpilot();
  int can_write_user_app = bfpilot_diag_can_write_user_app();
  int core_server_started =
      bfpilot_diag_bind_rc() == 0 && bfpilot_diag_listen_rc() == 0;
  bfpilot_launcher_diag_t launcher_diag;
  pthread_mutex_lock(&g_launcher_lock);
  launcher_diag = g_launcher_diag;
  pthread_mutex_unlock(&g_launcher_lock);

  bfpilot_diag_get_cwd(cwd, sizeof(cwd));
  bfpilot_diag_get_launcher_status(launcher_status,
                                   sizeof(launcher_status));
  bfpilot_diag_get_checkpoint(checkpoint, sizeof(checkpoint));
  int last_errno = bfpilot_diag_last_errno();
  json_error_escape(cwd_json, sizeof(cwd_json), cwd);
  json_error_escape(launcher_status_json, sizeof(launcher_status_json),
                    launcher_status);
  json_error_escape(launcher_final_json, sizeof(launcher_final_json),
                    launcher_diag.launcher_final_state);
  json_error_escape(checkpoint_json, sizeof(checkpoint_json), checkpoint);

  unsigned long long free_ram = 0, total_ram = 0;
  int memory_available = bfpilot_diag_get_memory_info(&free_ram, &total_ram);
  char free_ram_json[32] = "null", total_ram_json[32] = "null";
  if(memory_available & BFPILOT_MEMORY_FREE_VALID)
    snprintf(free_ram_json, sizeof(free_ram_json), "%llu", free_ram / (1024ULL * 1024ULL));
  if(memory_available & BFPILOT_MEMORY_TOTAL_VALID)
    snprintf(total_ram_json, sizeof(total_ram_json), "%llu", total_ram / (1024ULL * 1024ULL));

  int n = snprintf(body, sizeof(body),
                   "{\"ok\":true,"
                   "\"name\":\"BFpilot\","
                   "\"tag\":\"%s\","
                   "\"version\":\"%s\","
                   "\"mode\":\"%s\","
                   "\"pid\":%ld,"
                   "\"now\":%ld,"
                   "\"uptime\":%ld,"
                   "\"port\":%u,"
                   "\"firmwareMajor\":%d,"
                   "\"free_ram_mb\":%s,"
                   "\"total_ram_mb\":%s,"
                   "\"memory_source\":\"%s\","
                   "\"cwd\":\"%s\","
                   "\"can_stat_root\":%s,"
                   "\"can_opendir_data\":%s,"
                   "\"can_opendir_data_homebrew\":%s,"
                   "\"can_opendir_usb0\":%s,"
                   "\"can_opendir_ext0\":%s,"
                   "\"can_opendir_ext0_homebrew\":%s,"
                   "\"can_write_data_bfpilot\":%s,"
                   "\"can_write_user_app\":%s,"
                   "\"write_probe_policy\":\"skipped-read-only\","
                   "\"launcher_status\":\"%s\","
                   "\"last_errno\":%d,"
                   "\"checkpoint\":\"%s\","
                   "\"core_server_started\":%s,"
                   "\"launcher_attempted\":%s,"
                   "\"appinst_init_rc\":%d,"
                   "\"title_dir_resolved\":%s,"
                   "\"install_title_rc\":%d,"
                   "\"install_all_rc\":%d,"
                   "\"uninstall_rc\":%d,"
                   "\"launcher_final_state\":\"%s\","
                   "\"rcs\":{"
                   "\"sceNetCtlInit\":%d,"
                   "\"sceUserServiceInitialize\":%d,"
                   "\"notification_test\":%d,"
                   "\"bind_port\":%u,"
                   "\"listen_port\":%u,"
                   "\"bind_5905\":%d,"
                   "\"listen_5905\":%d},"
                   "\"launcher\":{"
                   "\"status\":\"%s\","
                   "\"status_rc\":%d,"
                   "\"compiled\":%s,"
                   "\"disabled\":%s,"
                   "\"launcher_enabled\":%s,"
                   "\"launcher_attempted\":%s,"
                   "\"appinst_init_rc\":%d,"
                   "\"title_dir_resolved\":%s,"
                   "\"install_title_dir_resolved\":%s,"
                   "\"install_title_rc\":%d,"
                   "\"uninstall_resolved\":%s,"
                   "\"uninstall_rc\":%d,"
                   "\"install_all_resolved\":%s,"
                   "\"install_all_rc\":%d,"
                   "\"user_app_writable\":%s,"
                   "\"launcher_install_rc\":%d,"
                   "\"launcher_final_state\":\"%s\"},"
                   "\"notifications\":{\"mode\":\"optional-raw-debug\"},"
                   "\"routes\":[\"/\",\"/api/status\",\"/api/diag\","
                   "\"/fs\",\"/api/fs/*\",\"/api/fs/places\","
                   "\"/api/fs/shortcut/add\",\"/api/fs/shortcut/delete\","
                   "\"/api/fs/shortcut/rename\","
                   "\"/api/fs/search\",\"/api/fs/search/status\","
                   "\"/api/fs/search/rebuild\",\"/api/fs/search/cancel\","
                   "\"/api/fs/transfer/stats\","
                   "\"/api/fs/archive/support\","
                   "\"/api/fs/archive/status\","
                   "\"/api/fs/archive/prepare\","
                   "\"/api/fs/download/prepare\","
                   "\"/api/fs/download\","
                   "\"/api/fs/pkg/install\","
                   "\"/api/fs/pkg/status\","
                   "\"/api/fs/launch\","
                   "\"/api/fs/chmod\","
                   "\"/api/fs/pkg/info\","
                   "\"/api/fs/pkg/icon\","
                   "\"/api/diag/logs\"]}",
                   VERSION_TAG, BUILD_VERSION, BFPILOT_BUILD_MODE,
                   (long)getpid(), (long)now,
                   bfpilot_diag_uptime(),
                   (unsigned int)g_websrv_port,
                   bfpilot_appinst_firmware_major(),
                   free_ram_json, total_ram_json,
                   memory_available ? "sysctl" : "unavailable",
                   cwd_json,
                   json_bool(can_stat_root),
                   json_bool(can_opendir_data),
                   json_bool(can_opendir_data_homebrew),
                   json_bool(can_opendir_usb0),
                   json_bool(can_opendir_ext0),
                   json_bool(can_opendir_ext0_homebrew),
                   json_tristate(can_write_data),
                   json_tristate(can_write_user_app),
                   launcher_status_json,
                   last_errno,
                   checkpoint_json,
                   json_bool(core_server_started),
                   json_bool(launcher_diag.launcher_attempted),
                   launcher_diag.appinst_init_rc,
                   json_bool(launcher_diag.title_dir_resolved),
                   launcher_diag.install_title_rc,
                   launcher_diag.install_all_rc,
                   launcher_diag.uninstall_rc,
                   launcher_final_json,
                   bfpilot_diag_netctl_rc(),
                   bfpilot_diag_user_service_rc(),
                   bfpilot_diag_notification_rc(),
                   (unsigned int)g_websrv_port,
                   (unsigned int)g_websrv_port,
                   bfpilot_diag_bind_rc(),
                   bfpilot_diag_listen_rc(),
                   launcher_status_json,
                   bfpilot_diag_launcher_rc(),
                   "true",
                   "false",
                   json_bool(launcher_diag.launcher_enabled),
                   json_bool(launcher_diag.launcher_attempted),
                   launcher_diag.appinst_init_rc,
                   json_bool(launcher_diag.title_dir_resolved),
                   json_bool(launcher_diag.install_title_dir_resolved),
                   launcher_diag.install_title_rc,
                   json_bool(launcher_diag.uninstall_resolved),
                   launcher_diag.uninstall_rc,
                   json_bool(launcher_diag.install_all_resolved),
                   launcher_diag.install_all_rc,
                   json_tristate(launcher_diag.user_app_writable),
                   launcher_diag.launcher_install_rc,
                   launcher_final_json);
  if(n < 0) return -1;
  if((size_t)n >= sizeof(body)) n = (int)sizeof(body) - 1;
  return websrv_send(req->fd, 200, "application/json", body, (size_t)n);
}


static int
diag_log_udp_request(const http_request_t *req) {
  char ip[64] = {0};
  char port_str[16] = {0};
  (void)websrv_get_query_arg(req, "ip", ip, sizeof(ip));
  (void)websrv_get_query_arg(req, "port", port_str, sizeof(port_str));

  unsigned short port = 5906;
  if(port_str[0]) {
    port = (unsigned short)strtol(port_str, NULL, 10);
  }

  bfpilot_diag_set_log_udp_target(ip, port);

  char body[256];
  int n = snprintf(body, sizeof(body), "{\"ok\":true,\"ip\":\"%s\",\"port\":%u}", ip, port);
  if(n < 0) return -1;
  if((size_t)n >= sizeof(body)) n = (int)sizeof(body) - 1;
  return websrv_send(req->fd, 200, "application/json", body, (size_t)n);
}


static int
diag_logs_request(const http_request_t *req) {
  char tail_str[32] = {0};
  char fmt_str[32] = {0};
  char clear_str[32] = {0};
  char level_str[32] = {0};

  (void)websrv_get_query_arg(req, "tail", tail_str, sizeof(tail_str));
  (void)websrv_get_query_arg(req, "fmt", fmt_str, sizeof(fmt_str));
  (void)websrv_get_query_arg(req, "clear", clear_str, sizeof(clear_str));
  (void)websrv_get_query_arg(req, "level", level_str, sizeof(level_str));

  if(clear_str[0] && strcmp(clear_str, "0") != 0) {
    bfpilot_diag_clear_logs();
    const char clear_msg[] = "{\"ok\":true,\"cleared\":true}";
    return websrv_send(req->fd, 200, "application/json", clear_msg, sizeof(clear_msg) - 1);
  }

  size_t tail_count = 200;
  if(tail_str[0]) {
    long t = strtol(tail_str, NULL, 10);
    if(t > 0) tail_count = (size_t)t;
  }

  const char *fmt = fmt_str[0] ? fmt_str : "text";
  char *log_data = NULL;
  size_t log_size = 0;
  if(bfpilot_diag_dump_logs(&log_data, &log_size, tail_count, fmt, level_str) != 0 || !log_data) {
    return websrv_send_error_json(req->fd, 500, "failed to read log buffer");
  }

  const char *mime = (!strcmp(fmt, "json")) ? "application/json" : "text/plain; charset=utf-8";
  int rc = websrv_send(req->fd, 200, mime, log_data, log_size);
  free(log_data);
  return rc;
}


static int
shutdown_request(const http_request_t *req) {
  char token[64];
  if(!websrv_get_query_arg(req, "token", token, sizeof(token)) ||
     strcmp(token, CONTROL_TOKEN) != 0) {
    return websrv_send_error_json(req->fd, 403, "forbidden");
  }
  char force[8] = {0};
  int is_force = websrv_get_query_arg(req, "force", force, sizeof(force)) && strcmp(force, "1") == 0;
  if(!is_force && transfer_job_busy()) {
    return websrv_send_error_json(req->fd, 409,
                                  "file-manager job is still running");
  }
  if(!is_force && bfpilot_tile_bootstrap_busy()) {
    return websrv_send_error_json(req->fd, 409,
                                  "Media tile installation is still running");
  }
  if(!is_force && bfpilot_pkg_is_busy()) {
    return websrv_send_error_json(req->fd, 409,
                                  "PKG submission is still running");
  }

  const char body[] = "{\"ok\":true,\"shutdown\":true}";
  int rc = websrv_send(req->fd, 200, "application/json",
                       body, sizeof(body) - 1);
  websrv_request_exit();
  return rc;
}


static int
dispatch_request(const http_request_t *req, const char *initial_body,
                 size_t initial_size, size_t content_size) {
  if(!strcmp(req->method, "GET") || !strcmp(req->method, "HEAD")) {
    if(!strcmp(req->path, "/") || !strcmp(req->path, "/files") ||
       !strcmp(req->path, "/index.html")) {
      return asset_request(req, "/files.html");
    }
    if(!strcmp(req->path, "/api/status") || !strcmp(req->path, "/api/version")) {
      return status_request(req);
    }
    if(!strcmp(req->path, "/api/diag")) {
      return diag_request(req);
    }
    if(!strcmp(req->path, "/api/diag/log_udp")) {
      return diag_log_udp_request(req);
    }
    if(!strcmp(req->path, "/api/diag/logs")) {
      return diag_logs_request(req);
    }
    if(!strcmp(req->path, "/api/control/shutdown")) {
      return shutdown_request(req);
    }
    if(!strcmp(req->path, "/fs") || !strncmp(req->path, "/fs/", 4)) {
      return fs_request(req, req->path);
    }
    if(!strncmp(req->path, "/api/fs/", 8) || !strcmp(req->path, "/api/launch-elf")) {
      return transfer_request(req, req->path);
    }
    return asset_request(req, req->path);
  }

  if(!strcmp(req->method, "POST")) {
    if(!strcmp(req->path, "/api/control/shutdown") || !strncmp(req->path, "/api/control/shutdown?", 22)) {
      return shutdown_request(req);
    }
    if(!strcmp(req->path, "/api/diag/logs")) {
      return diag_logs_request(req);
    }
    if(!strcmp(req->path, "/api/fs/upload")) {
      return transfer_upload_request(req, initial_body, initial_size,
                                     content_size);
    }
    if(!strcmp(req->path, "/api/fs/text/save")) {
      return transfer_text_save_request(req, initial_body, initial_size,
                                        content_size);
    }
    if(!strcmp(req->path, "/api/fs/text/create")) {
      return transfer_text_create_request(req, initial_body, initial_size,
                                          content_size);
    }
    if(!strcmp(req->path, "/api/fs/copy") ||
       !strcmp(req->path, "/api/fs/smb/save") ||
       !strcmp(req->path, "/api/fs/smb/remove") ||
       !strcmp(req->path, "/api/fs/move") ||
       !strcmp(req->path, "/api/fs/delete") ||
       !strcmp(req->path, "/api/fs/chmod") ||
       !strcmp(req->path, "/api/fs/launch") ||
       !strcmp(req->path, "/api/fs/launch-elf") ||
       !strcmp(req->path, "/api/launch-elf")) {
      return transfer_action_post_request(req, req->path, initial_body,
                                          initial_size, content_size);
    }
    if(!strcmp(req->path, "/api/fs/archive/prepare")) {
      return transfer_archive_prepare_request(req, initial_body, initial_size,
                                              content_size);
    }
    if(!strcmp(req->path, "/api/fs/archive/batch")) {
      return transfer_archive_batch_request(req, initial_body, initial_size,
                                            content_size);
    }
    if(!strcmp(req->path, "/api/fs/download/prepare")) {
      return transfer_download_prepare_request(req, initial_body, initial_size,
                                               content_size);
    }
    if(!strcmp(req->path, "/api/fs/pkg/install")) {
      if(strcmp(req->action, "install-pkg") != 0) {
        return websrv_send_error_json(req->fd, 403,
                                      "missing PKG install confirmation header");
      }
      return transfer_pkg_install_request(req, initial_body, initial_size,
                                          content_size);
    }
    return websrv_send_error_json(req->fd, 404, "not found");
  }

  return websrv_send_error_json(req->fd, 405, "method not allowed");
}


typedef struct client_arg {
  int fd;
} client_arg_t;


static void *
client_thread(void *arg) {
  client_arg_t *client = arg;
  int fd = client->fd;
  char *buf = malloc(HEADER_MAX + 1);
  size_t used = 0;
  int req_count = 0;

  free(client);
  if(!buf) {
    close(fd);
    return NULL;
  }

  /*
   * HTTP/1.1 keep-alive loop: multi-file PC→PS5 upload reuses one TCP
   * session (saves handshake + slow-start per file). Cap request count so
   * a sticky client cannot pin a worker forever.
   */
  while(!atomic_load(&g_websrv_exit_requested) &&
        req_count < BFPILOT_HTTP_KEEPALIVE_MAX) {
    int header_end = -1;

    while(used < HEADER_MAX) {
      header_end = find_header_end(buf, used);
      if(header_end >= 0) break;
      ssize_t n = recv(fd, buf + used, HEADER_MAX - used, 0);
      if(n < 0) {
        if(errno == EINTR) continue;
        goto done;
      }
      if(n == 0) goto done;
      used += (size_t)n;
    }

    if(header_end < 0) {
      websrv_conn_set_keep_alive(0);
      websrv_send_error_json(fd, 400, "bad request");
      goto done;
    }

    char first_body_byte = buf[header_end];
    buf[header_end] = 0;

    char method[8];
    char target[16384], protocol[16];
    if(sscanf(buf, "%7s %16383s %15s", method, target, protocol) != 3 ||
       (strcmp(protocol, "HTTP/1.0") && strcmp(protocol, "HTTP/1.1"))) {
      websrv_conn_set_keep_alive(0);
      websrv_send_error_json(fd, 400, "bad request");
      goto done;
    }

    int want_close = client_wants_close(buf);
    int keep = !want_close;
    websrv_conn_set_keep_alive(keep);

    http_request_t req;
    memset(&req, 0, sizeof(req));
    req.fd = fd;
    req.keep_alive = keep;
    snprintf(req.method, sizeof(req.method), "%s", method);
    (void)header_value(buf, "X-BFpilot-Action", req.action,
                       sizeof(req.action));

    char *query = strchr(target, '?');
    if(query) {
      *query++ = 0;
      snprintf(req.query, sizeof(req.query), "%s", query);
    }
    char decoded_path[4097];
    if(bfpilot_url_decode(decoded_path, sizeof(decoded_path), target, strlen(target)) != 0) {
      websrv_conn_set_keep_alive(0);
      websrv_send_error_json(fd, 400, "invalid or overlong URL path");
      goto done;
    }
    (void)bfpilot_path_decode_byte_tokens(decoded_path);
    if(strlen(decoded_path) >= sizeof(req.path)) {
      websrv_conn_set_keep_alive(0);
      websrv_send_error_json(fd, 400, "URL path too long");
      goto done;
    }
    memcpy(req.path, decoded_path, strlen(decoded_path) + 1);

    size_t content_size = content_length_from_headers(buf);
    size_t body_in_buf = used - (size_t)header_end;
    size_t initial_size =
        body_in_buf > content_size ? content_size : body_in_buf;
    buf[header_end] = first_body_byte;
    const char *initial = buf + header_end;

    int dispatch_rc = dispatch_request(&req, initial, initial_size, content_size);
    if(dispatch_rc == 0) {
      bfpilot_diag_mark_first_http(req.method, req.path);
    }

    /*
     * Body bytes that were already in the header buffer beyond Content-Length
     * (next request on a pipelined/keep-alive socket) must be preserved.
     * Upload path consumes full Content-Length from the socket; only excess
     * prefetched bytes remain for the next headers.
     */
    size_t consumed_from_buf = (size_t)header_end + initial_size;
    if(consumed_from_buf < used) {
      size_t leftover = used - consumed_from_buf;
      memmove(buf, buf + consumed_from_buf, leftover);
      used = leftover;
    } else {
      used = 0;
    }

    req_count++;
    if(!websrv_conn_get_keep_alive() || want_close || dispatch_rc != 0) {
      break;
    }
  }

done:
  websrv_conn_set_keep_alive(0);
  free(buf);
  shutdown(fd, SHUT_RDWR);
  close(fd);
  return NULL;
}


int
websrv_listen(unsigned short port, websrv_ready_cb_t ready_cb,
              void *ready_arg) {
  struct sockaddr_in server_addr;
  int srvfd;

  websrv_set_runtime_port(port);

  signal(SIGPIPE, SIG_IGN);

  srvfd = socket(AF_INET, SOCK_STREAM, 0);
  if(srvfd < 0) {
    int err = errno;
    bfpilot_diag_set_last_errno(err);
    bfpilot_log("socket port %u failed errno=%d", (unsigned int)port, err);
    perror("socket");
    return -err;
  }

  int on = 1;
  if(setsockopt(srvfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
    int err = errno;
    bfpilot_diag_set_last_errno(err);
    bfpilot_log("setsockopt SO_REUSEADDR port %u failed errno=%d",
                (unsigned int)port, err);
    perror("setsockopt");
    close(srvfd);
    return -err;
  }

#ifdef SO_REUSEPORT
  setsockopt(srvfd, SOL_SOCKET, SO_REUSEPORT, &on, sizeof(on));
#endif

  /*
   * SO_RCVBUF on the LISTENING socket (before bind/listen).
   * On FreeBSD/Orbis the accepted socket inherits this; post-accept
   * setsockopt(SO_RCVBUF) is often silently capped to ~256–512 KB, which is
   * too small to absorb PFS write latency during large uploads (zftpd).
   * SO_SNDBUF on listen helps downloads inherit a larger send window.
   */
  {
    int rcvbuf = BFPILOT_LISTEN_RCVBUF;
    int sndbuf = BFPILOT_CONN_SNDBUF;
    if(setsockopt(srvfd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf)) != 0) {
      bfpilot_log("setsockopt SO_RCVBUF listen port %u failed errno=%d",
                  (unsigned int)port, errno);
    } else {
      int got = 0;
      socklen_t gl = sizeof(got);
      if(getsockopt(srvfd, SOL_SOCKET, SO_RCVBUF, &got, &gl) == 0) {
        bfpilot_log("listen SO_RCVBUF requested=%d effective=%d port=%u",
                    rcvbuf, got, (unsigned int)port);
      }
    }
    if(setsockopt(srvfd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf)) != 0) {
      bfpilot_log("setsockopt SO_SNDBUF listen port %u failed errno=%d",
                  (unsigned int)port, errno);
    } else {
      int got = 0;
      socklen_t gl = sizeof(got);
      if(getsockopt(srvfd, SOL_SOCKET, SO_SNDBUF, &got, &gl) == 0) {
        bfpilot_log("listen SO_SNDBUF requested=%d effective=%d port=%u",
                    sndbuf, got, (unsigned int)port);
      }
    }
  }

  memset(&server_addr, 0, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  server_addr.sin_port = htons(port);

  if(bind(srvfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) != 0) {
    int err = errno;
    bfpilot_diag_set_last_errno(err);
    bfpilot_diag_set_bind_rc(-err);
    bfpilot_log("bind port %u rc=%d errno=%d",
                (unsigned int)port, -err, err);
    perror("bind");
    close(srvfd);
    return -err;
  }
  bfpilot_diag_set_bind_rc(0);
  bfpilot_log("bind port %u rc=0", (unsigned int)port);

  if(listen(srvfd, BFPILOT_LISTEN_BACKLOG) != 0) {
    int err = errno;
    bfpilot_diag_set_last_errno(err);
    bfpilot_diag_set_listen_rc(-err);
    bfpilot_log("listen port %u rc=%d errno=%d",
                (unsigned int)port, -err, err);
    perror("listen");
    close(srvfd);
    return -err;
  }
  bfpilot_diag_set_listen_rc(0);
  bfpilot_log("listen port %u rc=0 backlog=%d",
              (unsigned int)port, BFPILOT_LISTEN_BACKLOG);

  pthread_mutex_lock(&g_websrv_lock);
  g_websrv_srvfd = srvfd;
  g_websrv_port = port;
  pthread_mutex_unlock(&g_websrv_lock);

  if(ready_cb) ready_cb(port, ready_arg);

  while(!atomic_load(&g_websrv_exit_requested)) {
    struct sockaddr_in client_addr;
    socklen_t client_len = sizeof(client_addr);
    int connfd = accept(srvfd, (struct sockaddr *)&client_addr, &client_len);
    if(connfd < 0) {
      if(atomic_load(&g_websrv_exit_requested)) {
        return -ECANCELED;
      }
      if(errno == EINTR || errno == ECONNABORTED || errno == ECONNRESET) {
        continue;
      }
      int err = errno;
      bfpilot_diag_set_last_errno(err);
      bfpilot_log("accept failed errno=%d", err);
      perror("accept");

      pthread_mutex_lock(&g_websrv_lock);
      int active = g_websrv_srvfd == srvfd;
      if(active) g_websrv_srvfd = -1;
      pthread_mutex_unlock(&g_websrv_lock);

      if(active) close(srvfd);
      return -err;
    }

    if(client_addr.sin_family == AF_INET && client_addr.sin_addr.s_addr != htonl(INADDR_LOOPBACK)) {
      bfpilot_diag_set_log_udp_target(inet_ntoa(client_addr.sin_addr), 5906);
    }

    /*
     * zftpd: SO_RCVBUF is set on the *listen* socket (above); post-accept
     * setsockopt is often silently capped on Orbis. Still request large
     * windows so firmwares that honor them get better bulk transfer.
     * Never TCP_NODELAY on bulk HTTP — tiny segments thrash PFS writes.
     */
    {
      static int logged_effective_buffers = 0;
      int rcvbuf = BFPILOT_LISTEN_RCVBUF;
      int sndbuf = BFPILOT_CONN_SNDBUF;
      struct timeval io_timeout = {.tv_sec = 120, .tv_usec = 0};
      (void)setsockopt(connfd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
      (void)setsockopt(connfd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));
      (void)setsockopt(connfd, SOL_SOCKET, SO_RCVTIMEO, &io_timeout,
                       sizeof(io_timeout));
      (void)setsockopt(connfd, SOL_SOCKET, SO_SNDTIMEO, &io_timeout,
                       sizeof(io_timeout));
      if(!logged_effective_buffers) {
        int actual_rcv = 0, actual_snd = 0;
        socklen_t rlen = sizeof(actual_rcv), slen = sizeof(actual_snd);
        int have_rcv = getsockopt(connfd, SOL_SOCKET, SO_RCVBUF,
                                  &actual_rcv, &rlen) == 0;
        int have_snd = getsockopt(connfd, SOL_SOCKET, SO_SNDBUF,
                                  &actual_snd, &slen) == 0;
        if(have_rcv || have_snd) {
          bfpilot_log("accepted socket buffers requested_rcv=%d effective_rcv=%d "
                      "requested_snd=%d effective_snd=%d",
                      rcvbuf, have_rcv ? actual_rcv : -1, sndbuf,
                      have_snd ? actual_snd : -1);
        }
        logged_effective_buffers = 1;
      }
    }

    client_arg_t *client = calloc(1, sizeof(*client));
    if(!client) {
      close(connfd);
      continue;
    }
    client->fd = connfd;

    pthread_t thread;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    (void)pthread_attr_setstacksize(&attr, 512U * 1024U);
    if(pthread_create(&thread, &attr, client_thread, client) != 0) {
      close(connfd);
      free(client);
    }
    pthread_attr_destroy(&attr);
  }

  pthread_mutex_lock(&g_websrv_lock);
  g_websrv_srvfd = -1;
  pthread_mutex_unlock(&g_websrv_lock);

  return close(srvfd);
}
