#include "url_codec.h"
#include "fs_at.h"
/*
 * BFpilot - file-manager copy/move/delete primitives and API.
 */

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/statvfs.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "diag.h"
#include "notify.h"
#include "archive_worker.h"
#include "fs.h"
#include "mime.h"
#include "smb.h"
#include "remote_io.h"
#include "path_ops.h"
#include "tree_chmod.h"
#include "tree_walk.h"
#include "staging.h"
#include "paths.h"
#include "payload_launch.h"
#include "pkg_file.h"
#include "pkg_install.h"
#include "search.h"
#include "text_format.h"
#include "transfer.h"
#include "websrv.h"

#ifndef BFPILOT_TRANSFER_BUF_SIZE
#define BFPILOT_TRANSFER_BUF_SIZE (8 * 1024 * 1024)
#endif

/*
 * Upload buffer — single-buffer STOR only (no double-buffer writer on PS4/PS5;
 * zftpd/ftpsrv lessons: double-buffer + small RCVBUF stalls TCP).
 *
 * 2 MiB (was 1 MiB): fewer write()s into PFS crypto on write-bound firmwares
 * while keeping the same recv→write cadence that reopens the TCP window after
 * each disk write. Still far below multi-GB fallocate stalls.
 */
#ifndef BFPILOT_UPLOAD_BUF_SIZE
#define BFPILOT_UPLOAD_BUF_SIZE (2 * 1024 * 1024)
#endif

#define COPY_BUF_SIZE   BFPILOT_TRANSFER_BUF_SIZE
#define UPLOAD_BUF_SIZE BFPILOT_UPLOAD_BUF_SIZE
#define BFPILOT_IO_ALIGNMENT 0x4000U
#define BFPILOT_COPY_PIPELINE_MIN_SIZE (256ULL * 1024ULL * 1024ULL)
#define BFPILOT_WRITEBACK_SYNC_BYTES (256ULL * 1024ULL * 1024ULL)
#define BFPILOT_SPACE_MARGIN_BYTES (256ULL * 1024ULL * 1024ULL)
#define BFPILOT_TEXT_MAX_SIZE (5U * 1024U * 1024U)
#define BFPILOT_ACTION_FORM_MAX_SIZE (64U * 1024U)
#define BFPILOT_DOWNLOAD_FORM_MAX_SIZE (4U * 1024U * 1024U)
#define BFPILOT_DOWNLOAD_MAX_PATHS 2048U
#define BFPILOT_DOWNLOAD_BUF_SIZE (2U * 1024U * 1024U)
#define BFPILOT_DOWNLOAD_PREPARE_TTL 120
#define BFPILOT_FS_MAX_DEPTH 64U

#define BFPILOT_MAX_SHORTCUTS 32

#ifndef BFPILOT_ENABLE_INTEGRATED_ARCHIVE
#define BFPILOT_ENABLE_INTEGRATED_ARCHIVE 0
#endif

#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
#define BFPILOT_ARCHIVE_DIR BFPILOT_ARCHIVE_INTEGRATED_DIR
#else
#define BFPILOT_ARCHIVE_DIR BFPILOT_ARCHIVE_STANDALONE_DIR
#endif
#define BFPILOT_ARCHIVE_JOB BFPILOT_ARCHIVE_DIR "/job.ini"
#define BFPILOT_ARCHIVE_JOB_TMP BFPILOT_ARCHIVE_DIR "/job.tmp"
#define BFPILOT_ARCHIVE_STATUS BFPILOT_ARCHIVE_DIR "/status.json"
#define BFPILOT_ARCHIVE_STATUS_TMP BFPILOT_ARCHIVE_DIR "/status.tmp"

static void
apply_fchmod_0777(int fd) {
  (void)fchmod(fd, 0777);
}

static void
apply_chmod_0777(const char *path) {
  (void)chmod(path, 0777);
}
#define BFPILOT_ARCHIVE_DEFAULT_NICE 4
#define BFPILOT_ARCHIVE_MIN_NICE -20
#define BFPILOT_ARCHIVE_MAX_NICE 20

typedef struct json_buf {
  char  *data;
  size_t len;
  size_t cap;
} json_buf_t;


static int
json_grow(json_buf_t *b, size_t add) {
  if(b->len + add + 1 <= b->cap) return 0;
  size_t next = b->cap ? b->cap : 1024;
  while(next < b->len + add + 1) next *= 2;
  char *p = realloc(b->data, next);
  if(!p) return -1;
  b->data = p;
  b->cap = next;
  return 0;
}


static int
json_append(json_buf_t *b, const char *s) {
  size_t n = strlen(s);
  if(json_grow(b, n) != 0) return -1;
  memcpy(b->data + b->len, s, n);
  b->len += n;
  b->data[b->len] = 0;
  return 0;
}


static int
json_appendf(json_buf_t *b, const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  va_list cp;
  va_copy(cp, ap);
  int n = vsnprintf(NULL, 0, fmt, cp);
  va_end(cp);
  if(n < 0) {
    va_end(ap);
    return -1;
  }
  if(json_grow(b, (size_t)n) != 0) {
    va_end(ap);
    return -1;
  }
  vsnprintf(b->data + b->len, b->cap - b->len, fmt, ap);
  va_end(ap);
  b->len += (size_t)n;
  return 0;
}


static int
json_string(json_buf_t *b, const char *s) {
  if(json_append(b, "\"") != 0) return -1;
  for(const unsigned char *p = (const unsigned char *)(s ? s : ""); *p; p++) {
    switch(*p) {
    case '\\': if(json_append(b, "\\\\") != 0) return -1; break;
    case '"':  if(json_append(b, "\\\"") != 0) return -1; break;
    case '\b': if(json_append(b, "\\b") != 0) return -1; break;
    case '\f': if(json_append(b, "\\f") != 0) return -1; break;
    case '\n': if(json_append(b, "\\n") != 0) return -1; break;
    case '\r': if(json_append(b, "\\r") != 0) return -1; break;
    case '\t': if(json_append(b, "\\t") != 0) return -1; break;
    default:
      if(*p < 0x20) {
        if(json_appendf(b, "\\u%04x", *p) != 0) return -1;
      } else if(*p >= 0x80) {
        size_t utf8_length = bfpilot_utf8_sequence_length(p);
        if(utf8_length > 0) {
          if(json_grow(b, utf8_length) != 0) return -1;
          memcpy(b->data + b->len, p, utf8_length);
          b->len += utf8_length;
          b->data[b->len] = 0;
          p += utf8_length - 1;
        } else if(json_appendf(b, "\\udb80\\udc%02x", *p) != 0) {
          return -1;
        }
      } else {
        if(json_grow(b, 1) != 0) return -1;
        b->data[b->len++] = (char)*p;
        b->data[b->len] = 0;
      }
      break;
    }
  }
  return json_append(b, "\"");
}


static int
serve_owned(const http_request_t *req, int status, char *data, size_t size) {
  int rc = websrv_send(req->fd, status, "application/json", data, size);
  free(data);
  return rc;
}


static int
serve_error(const http_request_t *req, int status, const char *msg) {
  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":false,\"error\":") != 0 ||
     json_string(&b, msg ? msg : "error") != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, status, b.data, b.len);
}


static int write_all_fd(int fd, const void *data, size_t size);
static int check_free_space_for_bytes(const char *path, unsigned long long required,
                                      unsigned long long *available_out,
                                      unsigned long long *needed_out);
static void drain_body(int fd, size_t already_read, size_t content_size);
static int upload_segment_safe(const char *seg);


static int
path_is_safe(const char *p) {
  return bfpilot_path_is_safe(p);
}

/* Resolve path; on ENOENT try case-insensitive segments (#8). */
static int
path_for_list(const char *in, char *out, size_t out_sz) {
  struct stat st;
  if(!bfpilot_path_is_safe(in)) return -EINVAL;
  if(lstat(in, &st) == 0) {
    if(strlen(in) >= out_sz) return -ENAMETOOLONG;
    memcpy(out, in, strlen(in) + 1);
    return 0;
  }
  return bfpilot_path_resolve_ci(in, out, out_sz);
}


static int
mkdirs(const char *path) {
  char buf[1024];
  size_t n = strlen(path);
  if(n >= sizeof(buf)) {
    errno = ENAMETOOLONG;
    return -1;
  }
  memcpy(buf, path, n + 1);
  for(size_t i = 1; i <= n; i++) {
    if(buf[i] == '/' || buf[i] == 0) {
      char saved = buf[i];
      buf[i] = 0;
      if(mkdir(buf, 0777) != 0 && errno != EEXIST) return -1;
      apply_chmod_0777(buf);
      buf[i] = saved;
    }
  }
  return 0;
}


static void
ensure_bfpilot_dir(void) {
  (void)mkdir(BFPILOT_DATA_ROOT, 0755);
  (void)mkdir(BFPILOT_DATA_DIR, 0755);
}


static void
join_path(char *out, size_t out_sz, const char *dir, const char *name) {
  size_t n = strlen(dir);
  snprintf(out, out_sz, "%s%s%s", dir, (n > 1 && dir[n - 1] != '/') ? "/" : "",
           name);
}


static int
join_path_checked(char *out, size_t out_sz, const char *dir,
                  const char *name) {
  size_t n = strlen(dir);
  int written = snprintf(out, out_sz, "%s%s%s", dir,
                         (n > 1 && dir[n - 1] != '/') ? "/" : "", name);
  if(written < 0 || (size_t)written >= out_sz) {
    errno = ENAMETOOLONG;
    return -1;
  }
  return 0;
}


static const char *
path_basename(const char *path) {
  const char *base = strrchr(path ? path : "", '/');
  return base && base[1] ? base + 1 : path;
}


static const char *
safe_basename_label(const char *path) {
  const char *base = path_basename(path);
  return base && base[0] ? base : path;
}


static int
path_is_same_or_child(const char *base, const char *path) {
  size_t n = strlen(base);
  while(n > 1 && base[n - 1] == '/') n--;
  return strncmp(base, path, n) == 0 && (path[n] == 0 || path[n] == '/');
}


static int
path_has_dotdot_segment(const char *path) {
  const char *p = path ? path : "";
  while(*p) {
    while(*p == '/') p++;
    const char *start = p;
    while(*p && *p != '/') p++;
    if((size_t)(p - start) == 2 && start[0] == '.' && start[1] == '.') {
      return 1;
    }
  }
  return 0;
}


static int
path_starts_with_root(const char *path, const char *root) {
  size_t n = strlen(root);
  return strncmp(path, root, n) == 0 && (path[n] == 0 || path[n] == '/');
}


static int
archive_path_allowed(const char *path) {
  if(!path_is_safe(path) || path_has_dotdot_segment(path)) return 0;
  if(path_starts_with_root(path, "/data")) return 1;
  for(int i = 0; i < 8; i++) {
    char root[32];
    snprintf(root, sizeof(root), "/mnt/usb%d", i);
    if(path_starts_with_root(path, root)) return 1;
    snprintf(root, sizeof(root), "/mnt/ext%d", i);
    if(path_starts_with_root(path, root)) return 1;
  }
  return 0;
}


static int
config_value_safe(const char *value, int allow_empty) {
  if(!value || (!allow_empty && !*value)) return 0;
  for(const unsigned char *p = (const unsigned char *)value; *p; p++) {
    if(*p < 0x20 || *p == 0x7f) return 0;
  }
  return 1;
}


struct job_state {
  pthread_mutex_t lock;
  atomic_int      busy;
  atomic_int      cancel;
  atomic_int      total_known;
  atomic_long     total_bytes;
  atomic_long     copied_bytes;
  atomic_int      total_files;
  atomic_int      done_files;
  atomic_int      failed_files;
  atomic_long     elapsed_ms;
  atomic_long     read_bytes;
  atomic_long     written_bytes;
  atomic_int      last_errno;
  atomic_int      pipeline_files;
  atomic_int      serial_files;
  atomic_int      writeback_syncs;
  char            current[1024];
  char            source[1024];
  char            destination[1024];
  char            verb[16];
  char            error[256];
  unsigned long   source_dev;
  unsigned long   destination_dev;
  time_t          started_at;
  time_t          ended_at;
  long            started_ms;
  long            window_sample_ms;
  long            window_sample_bytes;
  double          last_instant_bps;
};


static atomic_int g_du_cancel;

static struct job_state g_job = {
  .lock = PTHREAD_MUTEX_INITIALIZER,
};

struct upload_state {
  pthread_mutex_t lock;
  long            elapsed_ms;
  unsigned long   bytes;
  unsigned long   destination_dev;
  int             error_code;
  long            recv_ms;
  long            write_ms;
  long            sync_ms;
  unsigned int    sync_count;
  int             buffer_aligned;
  char            path[1024];
};

static struct upload_state g_upload = {
  .lock = PTHREAD_MUTEX_INITIALIZER,
};

/* Serializes optimistic-version checks with atomic text replacements. */
static pthread_mutex_t g_text_lock = PTHREAD_MUTEX_INITIALIZER;

struct download_request_state {
  pthread_mutex_t lock;
  char          **paths;
  size_t          path_count;
  unsigned long   id;
  unsigned long   next_id;
  int             started;
  time_t          prepared_at;
};

static struct download_request_state g_download = {
  .lock = PTHREAD_MUTEX_INITIALIZER,
  .next_id = 1,
};

static void download_free_paths(char **paths, size_t count);

atomic_int g_archive_busy = 0;
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
extern int g_archive_cancel;
#else
/* Defined here when archive objects are not linked (ENABLE_ARCHIVE=0). */
int g_archive_cancel = 0;
#endif


int
transfer_archive_busy(void) {
  return atomic_load(&g_archive_busy) != 0
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
      || bfpilot_archive_batch_busy()
#endif
      ;
}


int
transfer_job_busy(void) {
  return atomic_load(&g_job.busy) != 0 || transfer_archive_busy();
}


static long
monotonic_ms(void) {
  struct timespec ts;
  if(clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return 0;
  return (long)ts.tv_sec * 1000L + (long)(ts.tv_nsec / 1000000L);
}

static void
job_set_current(const char *path) {
  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.current, sizeof(g_job.current), "%s", path ? path : "");
  pthread_mutex_unlock(&g_job.lock);
}


static void
job_set_error(const char *fmt, ...) {
  pthread_mutex_lock(&g_job.lock);
  if(!g_job.error[0]) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_job.error, sizeof(g_job.error), fmt, ap);
    va_end(ap);
  }
  pthread_mutex_unlock(&g_job.lock);
}


static int
job_cancelled(void) {
  return atomic_load(&g_job.cancel);
}


static int
job_begin(const char *verb) {
  if(transfer_archive_busy()) return 0;
  int expected = 0;
  if(!atomic_compare_exchange_strong(&g_job.busy, &expected, 1)) return 0;
  /* Close the race with archive_prepare claiming its own busy flag. */
  if(transfer_archive_busy()) {
    atomic_store(&g_job.busy, 0);
    return 0;
  }
  atomic_store(&g_du_cancel, 1);
  pthread_mutex_lock(&g_job.lock);
  atomic_store(&g_job.cancel, 0);
  atomic_store(&g_job.total_known, 1);
  atomic_store(&g_job.total_bytes, 0);
  atomic_store(&g_job.copied_bytes, 0);
  atomic_store(&g_job.total_files, 0);
  atomic_store(&g_job.done_files, 0);
  atomic_store(&g_job.failed_files, 0);
  atomic_store(&g_job.elapsed_ms, 0);
  atomic_store(&g_job.read_bytes, 0);
  atomic_store(&g_job.written_bytes, 0);
  atomic_store(&g_job.last_errno, 0);
  atomic_store(&g_job.pipeline_files, 0);
  atomic_store(&g_job.serial_files, 0);
  atomic_store(&g_job.writeback_syncs, 0);
  g_job.current[0] = 0;
  g_job.source[0] = 0;
  g_job.destination[0] = 0;
  g_job.error[0] = 0;
  g_job.source_dev = 0;
  g_job.destination_dev = 0;
  snprintf(g_job.verb, sizeof(g_job.verb), "%s", verb);
  g_job.started_at = time(NULL);
  g_job.ended_at = 0;
  g_job.started_ms = monotonic_ms();
  g_job.window_sample_ms = g_job.started_ms;
  g_job.window_sample_bytes = 0;
  g_job.last_instant_bps = 0.0;
  pthread_mutex_unlock(&g_job.lock);
  return 1;
}


static void
job_end(int rc, const char *err) {
  int saved_errno = errno;
  pthread_mutex_lock(&g_job.lock);
  g_job.ended_at = time(NULL);
  if(rc == 0) atomic_store(&g_job.total_known, 1);
  long ended_ms = monotonic_ms();
  atomic_store(&g_job.elapsed_ms,
               ended_ms > g_job.started_ms ? ended_ms - g_job.started_ms : 0);
  atomic_store(&g_job.last_errno, rc == 0 ? 0 : saved_errno);
  if(rc != 0 && err && !g_job.error[0]) {
    snprintf(g_job.error, sizeof(g_job.error), "%s", err);
  }
  pthread_mutex_unlock(&g_job.lock);
  long elapsed_ms = atomic_load(&g_job.elapsed_ms);
  long written = atomic_load(&g_job.written_bytes);
  double mbps = elapsed_ms > 0 ?
      ((double)written * 1000.0 / (double)elapsed_ms) / (1024.0 * 1024.0) : 0.0;
  bfpilot_log("transfer job end verb=%s rc=%d errno=%d bytes_read=%ld "
              "bytes_written=%ld elapsed_ms=%ld average_mbps=%.2f "
              "src_dev=%lu dst_dev=%lu current=%s error=%s",
              g_job.verb, rc, atomic_load(&g_job.last_errno),
              atomic_load(&g_job.read_bytes), written, elapsed_ms, mbps,
              g_job.source_dev, g_job.destination_dev, g_job.current,
              err ? err : "");
  atomic_store(&g_job.busy, 0);
}


static int
download_expire_pending(void) {
  char **paths = NULL;
  size_t count = 0;
  time_t now = time(NULL);

  pthread_mutex_lock(&g_download.lock);
  if(g_download.paths && !g_download.started &&
     g_download.prepared_at > 0 && now >= g_download.prepared_at &&
     now - g_download.prepared_at >= BFPILOT_DOWNLOAD_PREPARE_TTL) {
    paths = g_download.paths;
    count = g_download.path_count;
    g_download.paths = NULL;
    g_download.path_count = 0;
    g_download.id = 0;
    g_download.prepared_at = 0;
  }
  pthread_mutex_unlock(&g_download.lock);
  if(!paths) return 0;

  download_free_paths(paths, count);
  errno = ETIMEDOUT;
  job_end(-1, "download was not started within 120 seconds");
  return 1;
}


struct size_context { long *items, *bytes; int count_dirs; };
static int walk_job_cancelled(void *context) {
  (void)context;
  return job_cancelled();
}
static int size_entry(const char *path, const char *relative,
                       const struct stat *st, void *context) {
  (void)relative;
  struct size_context *scan = context;
  job_set_current(path);
  if(S_ISREG(st->st_mode) || scan->count_dirs) {
    if(*scan->items == INT_MAX || st->st_size > LONG_MAX - *scan->bytes)
      return -EOVERFLOW;
    (*scan->items)++;
    if(st->st_size > 0) *scan->bytes += (long)st->st_size;
  }
  atomic_store(&g_job.total_files, (int)*scan->items);
  atomic_store(&g_job.total_bytes, *scan->bytes);
  return 0;
}
static int size_walker(const char *path, dev_t root_dev, long *items,
                        long *bytes, int count_dirs) {
  struct size_context scan = {items, bytes, count_dirs};
  int rc = bfpilot_tree_walk(path, root_dev, size_entry, walk_job_cancelled, &scan);
  if(rc != 0) errno = -rc;
  return rc == 0 ? 0 : -1;
}

static void *
alloc_aligned_io_buffer(size_t size, int *aligned_out) {
  if(aligned_out) *aligned_out = 0;
  if(!size) return NULL;
  void *buffer = NULL;
  if(posix_memalign(&buffer, BFPILOT_IO_ALIGNMENT, size) == 0) {
    if(aligned_out) *aligned_out = 1;
    return buffer;
  }
  return malloc(size);
}

static void
free_aligned_io_buffer(void *ptr, size_t size, int aligned) {
  (void)size;
  (void)aligned;
  free(ptr);
}


struct copy_pipeline {
  pthread_mutex_t lock;
  pthread_cond_t  ready;
  pthread_cond_t  empty;
  int             out;
  const char     *dst;
  unsigned char  *buffers[2];
  size_t          lengths[2];
  int             slots_ready[2];
  int             eof[2];
  int             shutdown;
  int             writer_errno;
  int             is_mmap[2];
};


static void
copy_pipeline_fail(struct copy_pipeline *pipe, int slot, int error_code,
                   const char *operation) {
  int saved_errno = error_code ? error_code : EIO;
  job_set_error("%s(%s): %s", operation, pipe->dst,
                strerror(saved_errno));
  pthread_mutex_lock(&pipe->lock);
  if(!pipe->writer_errno) pipe->writer_errno = saved_errno;
  pipe->slots_ready[slot] = 0;
  pthread_cond_broadcast(&pipe->empty);
  pthread_cond_broadcast(&pipe->ready);
  pthread_mutex_unlock(&pipe->lock);
}


static void *
copy_pipeline_writer(void *arg) {
  struct copy_pipeline *pipe = arg;
  int slot = 0;

  for(;;) {
    pthread_mutex_lock(&pipe->lock);
    while(!pipe->slots_ready[slot] && !pipe->shutdown) {
      pthread_cond_wait(&pipe->ready, &pipe->lock);
    }
    if(pipe->shutdown) {
      pthread_mutex_unlock(&pipe->lock);
      return NULL;
    }
    size_t length = pipe->lengths[slot];
    int eof = pipe->eof[slot];
    pthread_mutex_unlock(&pipe->lock);

    size_t written = 0;
    while(written < length) {
      ssize_t n = write(pipe->out, pipe->buffers[slot] + written,
                        length - written);
      if(n < 0) {
        if(errno == EINTR) continue;
        copy_pipeline_fail(pipe, slot, errno, "write");
        return NULL;
      }
      if(n == 0) {
        copy_pipeline_fail(pipe, slot, ENOSPC, "write");
        return NULL;
      }
      written += (size_t)n;
      atomic_fetch_add(&g_job.copied_bytes, (long)n);
      atomic_fetch_add(&g_job.written_bytes, (long)n);
    }

    pthread_mutex_lock(&pipe->lock);
    pipe->slots_ready[slot] = 0;
    pthread_cond_signal(&pipe->empty);
    pthread_mutex_unlock(&pipe->lock);
    if(eof) return NULL;
    slot = 1 - slot;
  }
}


/*
 * Read and write large files concurrently with exactly two fixed-size slots.
 * Returns 1 only when the optional pipeline cannot be initialized; callers
 * then use the serial path without losing the copy operation.
 */
static int
copy_file_pipelined(int in, int out, const char *src, const char *dst,
                    unsigned long long expected_size) {
  struct copy_pipeline pipe;
  memset(&pipe, 0, sizeof(pipe));
  pipe.out = out;
  pipe.dst = dst;

  if(pthread_mutex_init(&pipe.lock, NULL) != 0) return 1;
  if(pthread_cond_init(&pipe.ready, NULL) != 0) {
    pthread_mutex_destroy(&pipe.lock);
    return 1;
  }
  if(pthread_cond_init(&pipe.empty, NULL) != 0) {
    pthread_cond_destroy(&pipe.ready);
    pthread_mutex_destroy(&pipe.lock);
    return 1;
  }

  pipe.buffers[0] = alloc_aligned_io_buffer(COPY_BUF_SIZE, &pipe.is_mmap[0]);
  pipe.buffers[1] = alloc_aligned_io_buffer(COPY_BUF_SIZE, &pipe.is_mmap[1]);
  if(!pipe.buffers[0] || !pipe.buffers[1]) {
    free_aligned_io_buffer(pipe.buffers[0], COPY_BUF_SIZE, pipe.is_mmap[0]);
    free_aligned_io_buffer(pipe.buffers[1], COPY_BUF_SIZE, pipe.is_mmap[1]);
    pthread_cond_destroy(&pipe.empty);
    pthread_cond_destroy(&pipe.ready);
    pthread_mutex_destroy(&pipe.lock);
    return 1;
  }

  pthread_t writer;
  if(pthread_create(&writer, NULL, copy_pipeline_writer, &pipe) != 0) {
    free_aligned_io_buffer(pipe.buffers[0], COPY_BUF_SIZE, pipe.is_mmap[0]);
    free_aligned_io_buffer(pipe.buffers[1], COPY_BUF_SIZE, pipe.is_mmap[1]);
    pthread_cond_destroy(&pipe.empty);
    pthread_cond_destroy(&pipe.ready);
    pthread_mutex_destroy(&pipe.lock);
    return 1;
  }
  atomic_fetch_add(&g_job.pipeline_files, 1);
  bfpilot_log("copy pipeline start src=%s dst=%s size=%llu slot=%u mmap=%d",
              src, dst, expected_size, (unsigned int)COPY_BUF_SIZE,
              pipe.is_mmap[0] && pipe.is_mmap[1]);

  int rc = 0;
  int saved_errno = 0;
  int slot = 0;
  unsigned long long remaining = expected_size;
  while(remaining > 0 && !job_cancelled()) {
    pthread_mutex_lock(&pipe.lock);
    while(pipe.slots_ready[slot] && !pipe.writer_errno) {
      pthread_cond_wait(&pipe.empty, &pipe.lock);
    }
    if(pipe.writer_errno) {
      saved_errno = pipe.writer_errno;
      pthread_mutex_unlock(&pipe.lock);
      rc = -1;
      break;
    }
    pthread_mutex_unlock(&pipe.lock);

    size_t want = remaining < COPY_BUF_SIZE ? (size_t)remaining : COPY_BUF_SIZE;
    ssize_t n = read(in, pipe.buffers[slot], want);
    if(n < 0) {
      if(errno == EINTR) continue;
      saved_errno = errno;
      job_set_error("read(%s): %s", src, strerror(saved_errno));
      rc = -1;
      break;
    }
    if(n == 0) {
      saved_errno = EIO;
      job_set_error("read(%s): source became shorter during copy", src);
      rc = -1;
      break;
    }
    atomic_fetch_add(&g_job.read_bytes, (long)n);
    remaining -= (unsigned long long)n;
#ifdef POSIX_FADV_DONTNEED
    (void)posix_fadvise(in, (off_t)(expected_size - remaining - n), (off_t)n,
                        POSIX_FADV_DONTNEED);
#endif

    pthread_mutex_lock(&pipe.lock);
    if(pipe.writer_errno) {
      saved_errno = pipe.writer_errno;
      pthread_mutex_unlock(&pipe.lock);
      rc = -1;
      break;
    }
    pipe.lengths[slot] = (size_t)n;
    pipe.slots_ready[slot] = 1;
    pthread_cond_signal(&pipe.ready);
    pthread_mutex_unlock(&pipe.lock);
    slot = 1 - slot;
  }

  if(job_cancelled() && rc == 0) {
    saved_errno = ECANCELED;
    rc = -1;
  }

  if(rc == 0) {
    pthread_mutex_lock(&pipe.lock);
    while(pipe.slots_ready[slot] && !pipe.writer_errno) {
      pthread_cond_wait(&pipe.empty, &pipe.lock);
    }
    if(pipe.writer_errno) {
      saved_errno = pipe.writer_errno;
      rc = -1;
    } else {
      pipe.lengths[slot] = 0;
      pipe.eof[slot] = 1;
      pipe.slots_ready[slot] = 1;
      pthread_cond_signal(&pipe.ready);
    }
    pthread_mutex_unlock(&pipe.lock);
  }

  if(rc != 0) {
    pthread_mutex_lock(&pipe.lock);
    pipe.shutdown = 1;
    pthread_cond_broadcast(&pipe.ready);
    pthread_cond_broadcast(&pipe.empty);
    pthread_mutex_unlock(&pipe.lock);
  }
  pthread_join(writer, NULL);
  if(rc == 0 && pipe.writer_errno) {
    saved_errno = pipe.writer_errno;
    rc = -1;
  }

  free_aligned_io_buffer(pipe.buffers[0], COPY_BUF_SIZE, pipe.is_mmap[0]);
  free_aligned_io_buffer(pipe.buffers[1], COPY_BUF_SIZE, pipe.is_mmap[1]);
  pthread_cond_destroy(&pipe.empty);
  pthread_cond_destroy(&pipe.ready);
  pthread_mutex_destroy(&pipe.lock);
  if(rc != 0) errno = saved_errno ? saved_errno : EIO;
  return rc;
}


static int
copy_file_serial(int in, int out, const char *src, const char *dst,
                 unsigned long long expected_size) {
  if(expected_size == 0) {
    atomic_fetch_add(&g_job.serial_files, 1);
    return 0;
  }
  size_t buf_size = expected_size < COPY_BUF_SIZE ? (size_t)expected_size : COPY_BUF_SIZE;
  if(buf_size < 64 * 1024) buf_size = 64 * 1024;
  int is_mmap = 0;
  void *buffer = alloc_aligned_io_buffer(buf_size, &is_mmap);
  if(!buffer) {
    errno = ENOMEM;
    return -1;
  }
  atomic_fetch_add(&g_job.serial_files, 1);
  bfpilot_log("copy serial start src=%s dst=%s size=%llu buf=%u mmap=%d",
              src, dst, expected_size, (unsigned int)buf_size, is_mmap);

  int rc = 0;
  int saved_errno = 0;
  unsigned long long remaining = expected_size;
  while(remaining > 0 && !job_cancelled()) {
    size_t want = remaining < buf_size ? (size_t)remaining : buf_size;
    ssize_t n = read(in, buffer, want);
    if(n < 0) {
      if(errno == EINTR) continue;
      saved_errno = errno;
      job_set_error("read(%s): %s", src, strerror(saved_errno));
      rc = -1;
      break;
    }
    if(n == 0) {
      saved_errno = EIO;
      job_set_error("read(%s): source became shorter during copy", src);
      rc = -1;
      break;
    }
    atomic_fetch_add(&g_job.read_bytes, (long)n);
    remaining -= (unsigned long long)n;

    unsigned char *cursor = buffer;
    size_t left = (size_t)n;
    while(left > 0) {
      ssize_t written = write(out, cursor, left);
      if(written < 0) {
        if(errno == EINTR) continue;
        saved_errno = errno;
        job_set_error("write(%s): %s", dst, strerror(saved_errno));
        rc = -1;
        break;
      }
      if(written == 0) {
        saved_errno = ENOSPC;
        job_set_error("write(%s): no space or short write", dst);
        rc = -1;
        break;
      }
      cursor += written;
      left -= (size_t)written;
      atomic_fetch_add(&g_job.copied_bytes, (long)written);
      atomic_fetch_add(&g_job.written_bytes, (long)written);
    }
    if(rc != 0) break;
#ifdef POSIX_FADV_DONTNEED
    (void)posix_fadvise(in, (off_t)(expected_size - remaining - n), (off_t)n,
                        POSIX_FADV_DONTNEED);
#endif
  }
  if(job_cancelled() && rc == 0) {
    saved_errno = ECANCELED;
    rc = -1;
  }
  free_aligned_io_buffer(buffer, buf_size, is_mmap);
  if(rc != 0) errno = saved_errno ? saved_errno : EIO;
  return rc;
}


static int
copy_file(const char *src, const char *dst, const struct stat *expected) {
  int flags = O_RDONLY;
#ifdef O_NOFOLLOW
  flags |= O_NOFOLLOW;
#endif
  int in = open(src, flags);
  if(in < 0) {
    job_set_error("open(%s): %s", src, strerror(errno));
    return -1;
  }
  struct stat opened;
  int stat_rc = fstat(in, &opened);
  if(stat_rc != 0 || !S_ISREG(opened.st_mode) ||
     opened.st_dev != expected->st_dev || opened.st_ino != expected->st_ino) {
    int saved_errno = stat_rc != 0 ? errno : EAGAIN;
    job_set_error("source changed before copy: %s", src);
    close(in);
    errno = saved_errno;
    return -1;
  }
  int out = open(dst, O_WRONLY | O_CREAT | O_EXCL, 0777);
  if(out < 0) {
    int saved_errno = errno;
    job_set_error("open(%s): %s", dst, strerror(errno));
    close(in);
    errno = saved_errno;
    return -1;
  }
  apply_fchmod_0777(out);

#ifdef F_RDAHEAD
  (void)fcntl(in, F_RDAHEAD, 1);
#endif
#ifdef POSIX_FADV_SEQUENTIAL
  (void)posix_fadvise(in, 0, 0, POSIX_FADV_SEQUENTIAL);
  (void)posix_fadvise(out, 0, 0, POSIX_FADV_SEQUENTIAL);
#endif
#ifdef POSIX_FADV_NOREUSE
  (void)posix_fadvise(in, 0, 0, POSIX_FADV_NOREUSE);
#endif

  job_set_current(src);
  unsigned long long expected_size =
      expected->st_size > 0 ? (unsigned long long)expected->st_size : 0;
  int rc = 1;
  if(expected_size > 0) {
    int allocation_rc = posix_fallocate(out, 0, (off_t)expected_size);
    if(allocation_rc != 0 && allocation_rc != EOPNOTSUPP &&
       allocation_rc != ENOSYS && allocation_rc != EINVAL) {
      job_set_error("preallocate(%s): %s", dst, strerror(allocation_rc));
      errno = allocation_rc;
      rc = -1;
    }
  }
  if(rc == 1 && expected_size >= BFPILOT_COPY_PIPELINE_MIN_SIZE) {
    rc = copy_file_pipelined(in, out, src, dst, expected_size);
  }
  if(rc == 1) {
    rc = copy_file_serial(in, out, src, dst, expected_size);
  }

  /* Do not publish a staging file while delayed storage errors can still be
   * hidden in buffered writes. Unsupported preallocation retains this gate. */
  if(rc == 0) {
    if(fsync(out) != 0) {
      job_set_error("fsync(%s): %s", dst, strerror(errno));
      rc = -1;
    } else atomic_fetch_add(&g_job.writeback_syncs, 1);
  }

  int saved_errno = errno;
  struct stat final_source;
  if(rc == 0) {
    int verify_rc = fstat(in, &final_source);
    if(verify_rc != 0 || final_source.st_dev != expected->st_dev ||
       final_source.st_ino != expected->st_ino ||
       final_source.st_size != expected->st_size) {
      saved_errno = verify_rc != 0 ? errno : EAGAIN;
      job_set_error("source changed during copy: %s", src);
      rc = -1;
    }
  }
#ifdef POSIX_FADV_DONTNEED
  (void)posix_fadvise(in, 0, 0, POSIX_FADV_DONTNEED);
#endif
  if(close(in) != 0 && rc == 0) {
    saved_errno = errno;
    job_set_error("close(%s): %s", src, strerror(errno));
    rc = -1;
  }
  if(close(out) != 0 && rc == 0) {
    saved_errno = errno;
    job_set_error("close(%s): %s", dst, strerror(errno));
    rc = -1;
  }
  if(rc != 0) {
    (void)unlink(dst);
    errno = saved_errno ? saved_errno : EIO;
  }
  return rc;
}


struct copy_walk_context { const char *destination; };
static int copy_entry(const char *src, const char *relative,
                       const struct stat *st, void *context) {
  struct copy_walk_context *copy = context;
  char dst[1024];
  if(*relative) {
    if(join_path_checked(dst, sizeof(dst), copy->destination, relative) != 0)
      return -errno;
  } else snprintf(dst, sizeof(dst), "%s", copy->destination);
  job_set_current(src);
  if(S_ISDIR(st->st_mode)) {
    if(mkdir(dst, 0777) != 0 || chmod(dst, 0777) != 0) return -errno;
    return 0;
  }
  if(!S_ISREG(st->st_mode)) {
    job_set_error("unsupported source type: %s", src);
    return -EOPNOTSUPP;
  }
  long total = atomic_load(&g_job.total_bytes);
  if(st->st_size < 0 || st->st_size > LONG_MAX - total ||
     atomic_load(&g_job.total_files) == INT_MAX) return -EOVERFLOW;
  atomic_fetch_add(&g_job.total_files, 1);
  atomic_fetch_add(&g_job.total_bytes, (long)st->st_size);
  /* Space is checked as each file is discovered. There is no second complete
   * directory pass before the first write. The file's allocation/write/fsync
   * gates still protect against delayed ENOSPC and storage failures. */
  char parent[1024];
  snprintf(parent, sizeof(parent), "%s", dst);
  char *slash = strrchr(parent, '/');
  if(slash == parent) slash[1] = 0;
  else if(slash) *slash = 0;
  unsigned long long available, needed;
  int space = check_free_space_for_bytes(parent, (unsigned long long)st->st_size,
                                        &available, &needed);
  if(space != 0) return space > 0 ? -ENOSPC : -errno;
  if(copy_file(src, dst, st) != 0) {
    atomic_fetch_add(&g_job.failed_files, 1);
    return -errno;
  }
  atomic_fetch_add(&g_job.done_files, 1);
  return 0;
}
static int copy_recursive(const char *src, const char *dst, dev_t root_dev) {
  struct copy_walk_context copy = {dst};
  int rc = bfpilot_tree_walk(src, root_dev, copy_entry, walk_job_cancelled, &copy);
  if(rc != 0) errno = -rc;
  return rc == 0 ? 0 : -1;
}

struct delete_context { int progress; };
static int delete_entry(const char *path, const char *relative,
                         const struct stat *st, void *context) {
  (void)relative;
  struct delete_context *remove = context;
  struct stat current;
  if(lstat(path, &current) != 0) return -errno;
  if(current.st_dev != st->st_dev || current.st_ino != st->st_ino ||
     (current.st_mode & S_IFMT) != (st->st_mode & S_IFMT)) return -EAGAIN;
  if(remove->progress) job_set_current(path);
  if((S_ISDIR(st->st_mode) ? rmdir(path) : unlink(path)) != 0) return -errno;
  if(remove->progress) {
    if(st->st_size > 0) atomic_fetch_add(&g_job.copied_bytes, (long)st->st_size);
    atomic_fetch_add(&g_job.done_files, 1);
  }
  return 0;
}
static int delete_recursive(const char *path, dev_t root_dev, int count_progress) {
  struct delete_context remove = {count_progress};
  int rc = bfpilot_tree_walk_post(path, root_dev, delete_entry,
                                 walk_job_cancelled, &remove);
  if(rc != 0) errno = -rc;
  return rc == 0 ? 0 : -1;
}
static int delete_recursive_force(const char *path) {
  struct stat st;
  if(lstat(path, &st) != 0) return errno == ENOENT ? 0 : -1;
  struct delete_context remove = {0};
  int rc = bfpilot_tree_walk_post(path, st.st_dev, delete_entry, NULL, &remove);
  if(rc != 0) errno = -rc;
  return rc == 0 ? 0 : -1;
}

/*
 * Validate an existing-directory merge before changing the destination. Both
 * trees must remain on the destination filesystem and directory/file type
 * conflicts are rejected up front. Symlinks are never followed.
 */
static int
validate_staged_merge_inner(const char *staged, const char *destination,
                            dev_t destination_dev, unsigned depth) {
  if(depth > BFPILOT_FS_MAX_DEPTH) {
    errno = ELOOP;
    return -1;
  }
  struct stat staged_st, destination_st;
  if(lstat(staged, &staged_st) != 0) return -1;
  if(staged_st.st_dev != destination_dev) {
    errno = EXDEV;
    return -1;
  }
  if(lstat(destination, &destination_st) != 0) {
    return errno == ENOENT ? 0 : -1;
  }
  if(destination_st.st_dev != destination_dev) {
    errno = EXDEV;
    return -1;
  }
  if(S_ISDIR(staged_st.st_mode) != S_ISDIR(destination_st.st_mode)) {
    errno = EEXIST;
    return -1;
  }
  if(!S_ISDIR(staged_st.st_mode)) return 0;

  DIR *dir = opendir(staged);
  if(!dir) return -1;
  int rc = 0;
  int saved_errno = 0;
  struct dirent *entry;
  for(;;) {
    errno = 0;
    entry = readdir(dir);
    if(!entry) {
      if(errno != 0) {
        saved_errno = errno;
        rc = -1;
      }
      break;
    }
    if(!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
    char staged_child[1024], destination_child[1024];
    if(join_path_checked(staged_child, sizeof(staged_child), staged,
                         entry->d_name) != 0 ||
       join_path_checked(destination_child, sizeof(destination_child),
                         destination, entry->d_name) != 0 ||
       validate_staged_merge_inner(staged_child, destination_child,
                                   destination_dev, depth + 1) != 0) {
      saved_errno = errno;
      rc = -1;
      break;
    }
  }
  if(closedir(dir) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc != 0) errno = saved_errno;
  return rc;
}


static int
validate_staged_merge(const char *staged, const char *destination,
                      dev_t destination_dev) {
  return validate_staged_merge_inner(staged, destination, destination_dev, 0);
}


/* Move a fully-written staging tree into an existing directory. */
static int
merge_staged_tree_inner(const char *staged, const char *destination,
                        dev_t destination_dev, unsigned depth) {
  if(depth > BFPILOT_FS_MAX_DEPTH) {
    errno = ELOOP;
    return -1;
  }
  if(job_cancelled()) {
    errno = ECANCELED;
    return -1;
  }
  struct stat staged_st, destination_st;
  if(lstat(staged, &staged_st) != 0) return -1;
  if(staged_st.st_dev != destination_dev) {
    errno = EXDEV;
    return -1;
  }
  if(lstat(destination, &destination_st) != 0) {
    if(errno != ENOENT) return -1;
    return rename(staged, destination);
  }
  if(destination_st.st_dev != destination_dev) {
    errno = EXDEV;
    return -1;
  }

  if(!S_ISDIR(staged_st.st_mode)) {
    if(S_ISDIR(destination_st.st_mode)) {
      errno = EISDIR;
      return -1;
    }
    return rename(staged, destination);
  }
  if(!S_ISDIR(destination_st.st_mode)) {
    errno = ENOTDIR;
    return -1;
  }

  DIR *dir = opendir(staged);
  if(!dir) return -1;
  int rc = 0;
  int saved_errno = 0;
  struct dirent *entry;
  for(;;) {
    errno = 0;
    entry = readdir(dir);
    if(!entry) {
      if(errno != 0) {
        saved_errno = errno;
        rc = -1;
      }
      break;
    }
    if(!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
    char staged_child[1024], destination_child[1024];
    if(join_path_checked(staged_child, sizeof(staged_child), staged,
                         entry->d_name) != 0 ||
       join_path_checked(destination_child, sizeof(destination_child),
                         destination, entry->d_name) != 0 ||
       merge_staged_tree_inner(staged_child, destination_child,
                               destination_dev, depth + 1) != 0) {
      saved_errno = errno;
      rc = -1;
      break;
    }
  }
  if(closedir(dir) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc == 0 && rmdir(staged) != 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc != 0) errno = saved_errno;
  return rc;
}


static int
merge_staged_tree(const char *staged, const char *destination,
                  dev_t destination_dev) {
  return merge_staged_tree_inner(staged, destination, destination_dev, 0);
}


struct copy_arg {
  char src[1024];
  char dst[1024];
  int  is_move;
  int  overwrite;
};

#include "remote_jobs.inc"


static void *
copy_worker(void *arg) {
  struct copy_arg *a = arg;
  if(bfpilot_smb_path(a->src)||bfpilot_smb_path(a->dst))return remote_copy_worker(arg);
  struct stat src_st, dst_st, final_st;
  char final_dst[1024];
  char staging_dst[1024];
  int final_exists = 0;
  int merge_existing_dir = 0;

  bfpilot_log("transfer worker start verb=%s src=%s dst=%s",
              a->is_move ? "move" : "copy", a->src, a->dst);
  if(lstat(a->src, &src_st) != 0) {
    job_end(-1, "source not found");
    free(a);
    return NULL;
  }
  if(!S_ISREG(src_st.st_mode) && !S_ISDIR(src_st.st_mode)) {
    errno = EOPNOTSUPP;
    job_end(-1, "source type is not supported");
    free(a);
    return NULL;
  }
  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.source, sizeof(g_job.source), "%s", a->src);
  snprintf(g_job.destination, sizeof(g_job.destination), "%s", a->dst);
  g_job.source_dev = (unsigned long)src_st.st_dev;
  pthread_mutex_unlock(&g_job.lock);

  atomic_store(&g_job.total_known, 0);
  job_set_current(a->src);

  if(stat(a->dst, &dst_st) == 0) {
    if(!S_ISDIR(dst_st.st_mode)) {
      job_end(-1, "target exists and is not a folder");
      free(a);
      return NULL;
    }
  } else {
    if(errno != ENOENT) {
      char err[160];
      snprintf(err, sizeof(err), "target: %s", strerror(errno));
      job_end(-1, err);
      free(a);
      return NULL;
    }
    if(mkdirs(a->dst) != 0) {
      char err[160];
      snprintf(err, sizeof(err), "mkdir target: %s", strerror(errno));
      job_end(-1, err);
      free(a);
      return NULL;
    }
  }
  if(stat(a->dst, &dst_st) == 0) {
    pthread_mutex_lock(&g_job.lock);
    g_job.destination_dev = (unsigned long)dst_st.st_dev;
    pthread_mutex_unlock(&g_job.lock);
  }

  const char *base = path_basename(a->src);
  if(strlen(a->dst) + strlen(base) + 2 >= sizeof(final_dst)) {
    job_end(-1, "target path too long");
    free(a);
    return NULL;
  }
  join_path(final_dst, sizeof(final_dst), a->dst, base);

  /*
   * Keep an existing regular destination intact until its replacement has been
   * fully written and closed. The final same-directory rename replaces it.
   */
  if(lstat(final_dst, &final_st) == 0) {
    final_exists = 1;
    if(!a->overwrite) {
      job_end(-1, "destination already exists");
      free(a);
      return NULL;
    }
    if(S_ISDIR(src_st.st_mode) != S_ISDIR(final_st.st_mode)) {
      job_end(-1, "source and destination types conflict");
      free(a);
      return NULL;
    }
    merge_existing_dir = S_ISDIR(final_st.st_mode);
  } else if(errno != ENOENT) {
    char err[160];
    snprintf(err, sizeof(err), "destination: %s", strerror(errno));
    job_end(-1, err);
    free(a);
    return NULL;
  }

  if(!strcmp(a->src, final_dst)) {
    job_end(-1, "source and destination are the same");
    free(a);
    return NULL;
  }
  if(S_ISDIR(src_st.st_mode) &&
     path_is_same_or_child(a->src, final_dst)) {
    job_end(-1, "refusing to place a folder inside itself");
    free(a);
    return NULL;
  }

  if(a->is_move && !merge_existing_dir) {
    job_set_current(a->src);
    if(job_cancelled()) {
      job_end(-1, "cancelled");
      free(a);
      return NULL;
    }
    if(rename(a->src, final_dst) == 0) {
      /* A same-device rename does not read/copy the tree or invent counts. */
      job_set_current("Moved by atomic rename");
      bfpilot_search_mark_stale(a->is_move ? "move" : "copy");
      job_end(0, NULL);
      free(a);
      return NULL;
    }
    if(errno != EXDEV) {
      char err[160];
      snprintf(err, sizeof(err), "rename: %s", strerror(errno));
      job_end(-1, err);
      free(a);
      return NULL;
    }
    bfpilot_log("transfer move cross-device fallback src=%s final=%s", a->src, final_dst);
  }

  if(bfpilot_stage_path_avoiding(a->dst, "copy",
      S_ISDIR(src_st.st_mode) ? a->src : NULL, staging_dst, sizeof(staging_dst)) != 0) {
    char error[192];
    snprintf(error, sizeof(error), "private staging: %s", strerror(errno));
    job_end(-1, error); free(a); return NULL;
  }
  int rc = copy_recursive(a->src, staging_dst, src_st.st_dev);
  if(rc != 0) {
    int saved_errno = errno;
    char err[160];
    snprintf(err, sizeof(err), "copy: %s",
             job_cancelled() ? "cancelled" : strerror(saved_errno));
    (void)delete_recursive_force(staging_dst);
    errno = saved_errno;
    job_end(-1, err);
    free(a);
    return NULL;
  }
  if(job_cancelled()) {
    (void)delete_recursive_force(staging_dst);
    job_end(-1, "cancelled");
    free(a);
    return NULL;
  }
  job_set_current("Finalizing destination");
  int finalize_rc;
  if(merge_existing_dir) {
    finalize_rc = validate_staged_merge(staging_dst, final_dst,
                                        (dev_t)dst_st.st_dev);
    if(finalize_rc == 0) {
      finalize_rc = merge_staged_tree(staging_dst, final_dst,
                                      (dev_t)dst_st.st_dev);
    }
  } else {
    finalize_rc = rename(staging_dst, final_dst);
  }
  if(finalize_rc != 0) {
    int saved_errno = errno;
    char err[160];
    snprintf(err, sizeof(err), "finalize: %s", strerror(saved_errno));
    (void)delete_recursive_force(staging_dst);
    errno = saved_errno;
    job_end(-1, err);
    free(a);
    return NULL;
  }
  bfpilot_log("transfer finalized staging=%s final=%s merge=%d existed=%d",
              staging_dst, final_dst, merge_existing_dir, final_exists);
  if(a->is_move && delete_recursive(a->src, src_st.st_dev, 0) != 0) {
    char err[160];
    snprintf(err, sizeof(err), "post-move cleanup: %s",
             job_cancelled() ? "cancelled" : strerror(errno));
    job_end(-1, err);
    free(a);
    return NULL;
  }
  if(a->is_move) {
    bfpilot_log("transfer source cleanup complete src=%s", a->src);
  }

  bfpilot_search_mark_stale(a->is_move ? "move" : "copy");
  job_end(0, NULL);
  free(a);
  return NULL;
}


struct delete_arg {
  char path[1024];
};


static void *
delete_worker(void *arg) {
  struct delete_arg *a = arg;
  if(bfpilot_smb_path(a->path)) {
    bfpilot_io_t *endpoint=NULL;int rc=bfpilot_io_endpoint(a->path,&endpoint);
    if(!rc&&(!strcmp(a->path,bfpilot_io_root(endpoint))))rc=-EPERM;
    if(!rc){atomic_store(&g_job.total_known,0);rc=remote_remove_tree(endpoint,a->path,1,NULL);}
    bfpilot_io_end(endpoint);if(rc)errno=-rc;job_end(rc,rc?strerror(-rc):NULL);free(a);return NULL;
  }
  long items = 0, bytes = 0;
  struct stat root_st;
  if(lstat(a->path, &root_st) != 0) {
    job_end(-1, "source not found");
    free(a);
    return NULL;
  }
  job_set_current("Scanning folder");
  if(size_walker(a->path, root_st.st_dev, &items, &bytes, 1) != 0) {
    int saved_errno = errno;
    char err[192];
    snprintf(err, sizeof(err), "delete scan: %s",
             job_cancelled() ? "cancelled" : strerror(saved_errno));
    errno = saved_errno;
    job_end(-1, err);
    free(a);
    return NULL;
  }
  atomic_store(&g_job.total_files, (int)(items > 0 ? items : 1));
  atomic_store(&g_job.total_bytes, bytes);

  if(delete_recursive(a->path, root_st.st_dev, 1) != 0) {
    char err[160];
    snprintf(err, sizeof(err), "delete: %s",
             job_cancelled() ? "cancelled" : strerror(errno));
    job_end(-1, err);
    free(a);
    return NULL;
  }
  bfpilot_search_mark_stale("delete");
  job_end(0, NULL);
  free(a);
  return NULL;
}


static int
chmod_cancelled(void *context) {
  (void)context;
  return job_cancelled();
}

static int
chmod_recursive_dir(const char *dir_path, mode_t mode) {
  if(!job_begin("chmod")) return -EBUSY;
  job_set_current(dir_path);
  int rc = bfpilot_tree_chmod(dir_path, mode, chmod_cancelled, NULL);
  if(rc != 0) errno = -rc;
  job_end(rc, rc ? strerror(-rc) : NULL);
  return rc;
}

static int
chmod_request(const http_request_t *req) {
  char path[1024];
  char mode_s[16];
  char recursive_s[16];
  char resolved[1024];
  mode_t mode = 0;
  int rc;
  struct stat st;
  char body[256];

  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !websrv_get_query_arg(req, "mode", mode_s, sizeof(mode_s))) {
    return serve_error(req, 400, "missing path or mode");
  }
  if(bfpilot_parse_mode_octal(mode_s, &mode) != 0) {
    return serve_error(req, 400, "bad mode (use octal like 444 or 755)");
  }
  if(path_for_list(path, resolved, sizeof(resolved)) != 0) {
    return serve_error(req, 404, "path not found");
  }
  if(lstat(resolved, &st) != 0) {
    return serve_error(req, 404, "path not found");
  }
  int recursive = websrv_get_query_arg(req, "recursive", recursive_s, sizeof(recursive_s)) &&
                  (strcmp(recursive_s, "0") != 0 && strcasecmp(recursive_s, "false") != 0);

  if(recursive && S_ISDIR(st.st_mode)) {
    rc = chmod_recursive_dir(resolved, mode);
  } else {
    rc = bfpilot_path_chmod(resolved, mode);
  }
  if(rc != 0) {
    snprintf(body, sizeof(body),
             "{\"ok\":false,\"error\":\"chmod failed\",\"errno\":%d}", -rc);
    return websrv_send_text(req->fd, rc == -EBUSY ? 409 : 500, "application/json", body);
  }
  if(lstat(resolved, &st) != 0) {
    return serve_error(req, 500, "chmod ok but stat failed");
  }
  snprintf(body, sizeof(body),
           "{\"ok\":true,\"path_ok\":true,\"mode\":%o,\"mode_bits\":%u}",
           (unsigned)(st.st_mode & 07777), (unsigned)(st.st_mode & 07777));
  return websrv_send_text(req->fd, 200, "application/json", body);
}

static int
pkg_info_request(const http_request_t *req) {
  char path_in[1024];
  char resolved[1024];

  if(!websrv_get_query_arg(req, "path", path_in, sizeof(path_in)) ||
     !path_is_safe(path_in)) {
    return serve_error(req, 400, "missing or unsafe path");
  }
  if(bfpilot_smb_path(path_in)) {
    if(bfpilot_smb_validate_path(path_in))return serve_error(req,400,"unsafe SMB package path");
    snprintf(resolved,sizeof(resolved),"%s",path_in);
  } else if(path_for_list(path_in, resolved, sizeof(resolved)) != 0) {
    return serve_error(req, 404, "path not found");
  }

  bfpilot_pkg_details_t details;
  int rc = bfpilot_pkg_parse_details(resolved, &details);
  if(rc != 0) {
    return serve_error(req, 400, "could not read package information");
  }

  json_buf_t b = {0};
  if(json_grow(&b, 16384) != 0 ||
     json_append(&b, "{\"ok\":true") != 0 ||
     json_appendf(&b, ",\"size\":%llu", (unsigned long long)details.size) != 0 ||
     json_append(&b, ",\"content_id\":") != 0 ||
     json_string(&b, details.content_id) != 0 ||
     json_append(&b, ",\"title_id\":") != 0 ||
     json_string(&b, details.title_id) != 0 ||
     json_append(&b, ",\"title_name\":") != 0 ||
     json_string(&b, details.title_name) != 0 ||
     json_append(&b, ",\"app_ver\":") != 0 ||
     json_string(&b, details.app_ver) != 0 ||
     json_append(&b, ",\"min_fw\":") != 0 ||
     json_string(&b, details.min_fw) != 0 ||
     json_append(&b, ",\"category\":") != 0 ||
     json_string(&b, details.category) != 0 ||
     json_append(&b, ",\"platform\":") != 0 ||
     json_string(&b, details.platform) != 0 ||
     json_appendf(&b, ",\"content_type\":%u,\"content_flags\":%u,\"has_icon\":%s",
                  details.content_type, details.content_flags,
                  details.has_icon ? "true" : "false") != 0 ||
     json_append(&b, ",\"fields\":[") != 0) {
    free(b.data);
    return serve_error(req, 500, "out of memory");
  }

  for(size_t i = 0; i < details.field_count; i++) {
    if(i > 0 && json_append(&b, ",") != 0) break;
    if(json_append(&b, "{\"name\":") != 0 ||
       json_string(&b, details.fields[i].name) != 0 ||
       json_append(&b, ",\"value\":") != 0 ||
       json_string(&b, details.fields[i].value) != 0 ||
       json_append(&b, "}") != 0) break;
  }
  if(json_append(&b, "]}") != 0) {
    free(b.data);
    return serve_error(req, 500, "out of memory");
  }

  return serve_owned(req, 200, b.data, b.len);
}

static int
pkg_icon_request(const http_request_t *req) {
  char path_in[1024];
  char resolved[1024];

  if(!websrv_get_query_arg(req, "path", path_in, sizeof(path_in)) ||
     !path_is_safe(path_in)) {
    return serve_error(req, 400, "missing or unsafe path");
  }
  if(bfpilot_smb_path(path_in)) {
    if(bfpilot_smb_validate_path(path_in))return serve_error(req,400,"unsafe SMB package path");
    snprintf(resolved,sizeof(resolved),"%s",path_in);
  } else if(path_for_list(path_in, resolved, sizeof(resolved)) != 0) {
    return serve_error(req, 404, "path not found");
  }

  void *icon_buf = NULL;
  size_t icon_size = 0;
  int rc = bfpilot_pkg_read_icon(resolved, &icon_buf, &icon_size);
  if(rc != 0 || !icon_buf || icon_size == 0) {
    return serve_error(req, 404, "package icon not found");
  }

  int send_rc = websrv_send_headers(req->fd, 200, "image/png", icon_size,
                                    "Cache-Control: public, max-age=86400\r\n");
  if(send_rc == 0) {
    send_rc = websrv_write_all(req->fd, icon_buf, icon_size);
  }
  free(icon_buf);
  return send_rc;
}

struct smb_json_entries {json_buf_t *buffer;int first,virtual_entries;};
static int smb_json_record(const bfpilot_smb_record_t *record,void *context) {
  struct smb_json_entries *list=context;json_buf_t *b=list->buffer;
  if(!list->first&&json_append(b,",")!=0)return -ENOMEM;
  list->first=0;
  if(json_append(b,"{\"id\":")!=0||json_string(b,record->id)!=0||
     json_append(b,",\"label\":")!=0||json_string(b,record->label)!=0||
     json_append(b,",\"server\":")!=0||json_string(b,record->server)!=0||
     json_append(b,",\"user\":")!=0||json_string(b,record->user)!=0||
     json_append(b,",\"domain\":")!=0||json_string(b,record->domain)!=0||
     json_appendf(b,",\"dialect\":%u,\"encrypt\":%s,\"allowUnsigned\":%s}",
                  record->dialect,record->encrypt==1?"true":"false",
                  record->encrypt==2?"true":"false")!=0)return -ENOMEM;
  return 0;
}
static int smb_records_request(const http_request_t *req) {
  json_buf_t b={0};
  if(json_append(&b,"{\"ok\":true,\"connections\":[")!=0)return -1;
  struct smb_json_entries list={&b,1,0};int rc=bfpilot_smb_records(smb_json_record,&list);
  if(rc){free(b.data);return serve_error(req,500,"cannot read SMB connections; preserve the existing configuration for inspection");}
  if(json_append(&b,"]}")!=0){free(b.data);return -1;}
  return serve_owned(req,200,b.data,b.len);
}
static int smb_json_entry(const bfpilot_smb_entry_t *entry,void *context) {
  struct smb_json_entries *list=context;json_buf_t *b=list->buffer;
  if(b->len>32U*1024U*1024U)return -E2BIG;
  if(!list->first && json_append(b,",")!=0)return -ENOMEM;
  list->first=0;
  if(json_append(b,"{\"name\":")!=0 || json_string(b,entry->name)!=0 ||
     (entry->display_name && (json_append(b,",\"displayName\":")!=0 || json_string(b,entry->display_name)!=0)) ||
     json_appendf(b,",\"dir\":%s,\"link\":%s,\"remote\":true,\"virtual\":%s,\"mode\":0,\"size\":%llu,\"mtime\":%llu}",
       entry->directory?"true":"false",entry->link?"true":"false",
       list->virtual_entries?"true":"false",
       (unsigned long long)entry->size,(unsigned long long)entry->mtime)!=0)return -ENOMEM;
  return 0;
}
static int smb_list_request(const http_request_t *req,const char *path) {
  json_buf_t b={0};
  if(json_append(&b,"{\"ok\":true,\"remote\":true,\"path\":")!=0 ||
     json_string(&b,path)!=0 || json_append(&b,",\"entries\":[")!=0){free(b.data);return -1;}
  struct smb_json_entries list={&b,1,!strcmp(path,"/smb")||!strcmp(path,"/smb/")};int rc=bfpilot_smb_list(path,smb_json_entry,&list);
  if(rc){free(b.data);return serve_error(req,rc==-EINVAL?400:rc==-ENOENT?404:rc==-EACCES?403:rc==-EBUSY?409:502,strerror(-rc));}
  if(json_append(&b,"]}")!=0){free(b.data);return -1;}
  return serve_owned(req,200,b.data,b.len);
}
static int
list_request(const http_request_t *req) {
  char path_in[1024];
  char path[1024];
  char fast[32];
  int fast_mode = websrv_get_query_arg(req, "fast", fast, sizeof(fast)) &&
                  strcmp(fast, "0") != 0;
  if(!websrv_get_query_arg(req, "path", path_in, sizeof(path_in)) ||
     !path_is_safe(path_in)) {
    return serve_error(req, 400, "missing or unsafe path");
  }
  if(bfpilot_smb_path(path_in))return smb_list_request(req,path_in);
  if(path_for_list(path_in, path, sizeof(path)) != 0) {
    return serve_error(req, 404, "path not found");
  }

  DIR *d = opendir(path);
  if(!d) return serve_error(req, 404, strerror(errno));

  json_buf_t b = {0};
  if(json_grow(&b, 64U * 1024U) != 0 ||
     json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_appendf(&b, ",\"fast\":%s,\"entries\":[",
                  fast_mode ? "true" : "false") != 0) {
    closedir(d);
    free(b.data);
    return -1;
  }

  int first = 1;
  struct dirent *ent;
  while((ent = readdir(d))) {
    if(!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, "..")) continue;
    char full[1024];
    if(join_path_checked(full, sizeof(full), path, ent->d_name) != 0) continue;
    struct stat st;
    if(bfpilot_fs_fstatat(dirfd(d), ent->d_name, &st, AT_SYMLINK_NOFOLLOW) != 0) {
      continue;
    }
    if(!first && json_append(&b, ",") != 0) break;
    first = 0;
    if(json_append(&b, "{\"name\":") != 0 ||
       json_string(&b, ent->d_name) != 0 ||
       json_appendf(&b, ",\"dir\":%s,\"mode\":%u",
                    S_ISDIR(st.st_mode) ? "true" : "false",
                    (unsigned)(st.st_mode & 07777)) != 0) break;
    if(!fast_mode &&
       json_appendf(&b, ",\"size\":%ld,\"mtime\":%ld",
                    (long)st.st_size, (long)st.st_mtime) != 0) break;
    if(json_append(&b, "}") != 0) break;
  }
  closedir(d);
  if(json_append(&b, "]}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


typedef struct fs_total_info {
  int ok;
  unsigned long long total;
  unsigned long long free_bytes;
  unsigned long long available;
  unsigned long long reserved;
  unsigned long long used;
  unsigned long long usable_total;
  unsigned long long usable_used;
  double used_pct;
  double usable_used_pct;
} fs_total_info_t;

static void
fs_totals(const char *path, fs_total_info_t *info);
static void fs_total_values(fs_total_info_t *info, unsigned long long total,
                             unsigned long long free_bytes,
                             unsigned long long available) {
  memset(info,0,sizeof(*info));
  info->total=total;info->free_bytes=free_bytes;info->available=available;
  info->reserved=free_bytes>available?free_bytes-available:0;
  info->used=total>free_bytes?total-free_bytes:0;
  info->usable_total=total>info->reserved?total-info->reserved:total;
  info->usable_used=info->usable_total>available?info->usable_total-available:0;
  info->used_pct=total?((double)info->used*100)/total:0;
  info->usable_used_pct=info->usable_total?((double)info->usable_used*100)/info->usable_total:0;
  info->ok=1;
}


static int
stat_request(const http_request_t *req) {
  char path[1024];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path)) {
    return serve_error(req, 400, "missing or unsafe path");
  }
  struct stat st;
  fs_total_info_t fs = {0};
  if(bfpilot_smb_path(path)) {
    bfpilot_io_t *endpoint=NULL;int rc=bfpilot_io_endpoint(path,&endpoint);
    if(!rc)rc=bfpilot_io_lstat(endpoint,path,&st);
    if(!rc) {
      bfpilot_io_space_t space;
      if(!bfpilot_io_space(endpoint,path,&space))
        fs_total_values(&fs,space.total,space.free_bytes,space.available);
    }
    bfpilot_io_end(endpoint);
    if(rc)return serve_error(req,rc==-ENOENT?404:502,strerror(-rc));
  } else if(lstat(path, &st) != 0) return serve_error(req, 404, strerror(errno));

  json_buf_t b = {0};
  if(!bfpilot_smb_path(path))fs_totals(path, &fs);
  if(json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_appendf(&b,
                  ",\"remote\":%s,\"dir\":%s,\"mode\":%u,\"size\":%ld,\"mtime\":%ld,\"dev\":%lu,"
                  "\"statvfs\":%s,\"totalBytes\":%llu,\"freeBytes\":%llu,"
                  "\"availableBytes\":%llu,\"reservedBytes\":%llu,"
                  "\"usedBytes\":%llu,\"usedPercent\":%.2f,"
                  "\"usableTotalBytes\":%llu,\"usableUsedBytes\":%llu,"
                  "\"usableUsedPercent\":%.2f}",
                  bfpilot_smb_path(path)?"true":"false",S_ISDIR(st.st_mode) ? "true" : "false",
                  bfpilot_smb_path(path)?0:(unsigned)(st.st_mode & 07777),
                  (long)st.st_size, (long)st.st_mtime,
                  bfpilot_smb_path(path)?0:(unsigned long)st.st_dev, fs.ok ? "true" : "false",
                  fs.total, fs.free_bytes, fs.available, fs.reserved,
                  fs.used, fs.used_pct, fs.usable_total, fs.usable_used,
                  fs.usable_used_pct) != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


/* One read-only size worker, independent of the transfer slot. Selecting a new
 * folder cancels the old walk; a lease stops abandoned browser requests. */
typedef struct du_counts {
  atomic_ulong bytes;
  atomic_long entries, files, dirs;
  int background;
  long deadline;
} du_counts_t;
static struct {
  pthread_mutex_t lock;
  atomic_int busy;
  atomic_long lease_ms;
  unsigned long id;
  char path[1024];
  int error;
  du_counts_t counts;
} g_du = {.lock = PTHREAD_MUTEX_INITIALIZER};
struct du_arg { char path[1024]; dev_t device; };

static int du_cancelled(void *context) {
  du_counts_t *du = context;
  return du->background ? transfer_job_busy() || atomic_load(&g_du_cancel) ||
      monotonic_ms() - atomic_load(&g_du.lease_ms) > 30000 :
      monotonic_ms() > du->deadline;
}
static int du_entry(const char *path, const char *relative,
                     const struct stat *st, void *context) {
  (void)path; (void)relative;
  du_counts_t *du = context;
  unsigned long size = st->st_size > 0 ? (unsigned long)st->st_size : 0;
  if(size > ULONG_MAX - atomic_load(&du->bytes) ||
     atomic_load(&du->entries) == LONG_MAX) return -EOVERFLOW;
  atomic_fetch_add(&du->entries, 1);
  atomic_fetch_add(&du->bytes, size);
  atomic_fetch_add(S_ISDIR(st->st_mode) ? &du->dirs : &du->files, 1);
  return 0;
}
static void *du_worker(void *context) {
  struct du_arg *arg = context;
  int rc;
  if(bfpilot_smb_path(arg->path)) {
    bfpilot_io_t *endpoint=NULL;rc=bfpilot_io_endpoint(arg->path,&endpoint);
    if(!rc)rc=bfpilot_io_walk(endpoint,arg->path,0,du_entry,du_cancelled,&g_du.counts);
    bfpilot_io_end(endpoint);
  } else rc = bfpilot_tree_walk(arg->path, arg->device, du_entry, du_cancelled,&g_du.counts);
  pthread_mutex_lock(&g_du.lock);
  g_du.error = rc ? -rc : 0;
  atomic_store(&g_du.busy, 0);
  pthread_mutex_unlock(&g_du.lock);
  free(arg);
  return NULL;
}
static int du_response(const http_request_t *req, const char *path,
                        du_counts_t *du, int busy, unsigned long id, int error) {
  json_buf_t b = {0};
  if(json_appendf(&b, "{\"ok\":%s,\"busy\":%s,\"id\":%lu,\"path\":",
      error ? "false" : "true", busy ? "true" : "false", id) != 0 ||
     json_string(&b, path) != 0 ||
     json_appendf(&b, ",\"size\":%lu,\"entries\":%ld,\"files\":%ld,"
      "\"dirs\":%ld,\"truncated\":%s,\"errno\":%d,\"error\":",
      atomic_load(&du->bytes), atomic_load(&du->entries),
      atomic_load(&du->files), atomic_load(&du->dirs),
      busy || error ? "true" : "false", error) != 0 ||
     json_string(&b, error ? strerror(error) : "") != 0 ||
     json_append(&b, "}") != 0) { free(b.data); return -1; }
  return serve_owned(req, error ? 500 : 200, b.data, b.len);
}
static int du_request(const http_request_t *req) {
  char path[1024], async_s[16], id_s[32], cancel_s[16];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) || !path_is_safe(path))
    return serve_error(req, 400, "missing or unsafe path");
  int asynchronous = websrv_get_query_arg(req, "async", async_s, sizeof(async_s)) &&
                     !strcmp(async_s, "1");
  if(!asynchronous) {
    if(bfpilot_smb_path(path))return serve_error(req,400,"remote folder size requires async=1");
    /* Preserve quick legacy queries, but never monopolize an HTTP thread for
     * an unbounded crawl. Large callers must use the background/poll API. */
    struct stat st;
    if(lstat(path, &st) != 0) return serve_error(req, 404, strerror(errno));
    du_counts_t counts = {.deadline = monotonic_ms() + 200};
    int rc = bfpilot_tree_walk(path, st.st_dev, du_entry, du_cancelled, &counts);
    return du_response(req, path, &counts, 0, 0, rc == -ECANCELED ? ETIMEDOUT : -rc);
  }
  int has_id = websrv_get_query_arg(req, "id", id_s, sizeof(id_s));
  unsigned long id = has_id ? strtoul(id_s, NULL, 10) : 0;
  int cancel = websrv_get_query_arg(req, "cancel", cancel_s, sizeof(cancel_s)) &&
               !strcmp(cancel_s, "1");
  pthread_mutex_lock(&g_du.lock);
  if(has_id && (id != g_du.id || strcmp(path, g_du.path))) {
    pthread_mutex_unlock(&g_du.lock);
    return serve_error(req, 404, "size request expired");
  }
  if(cancel) {
    atomic_store(&g_du_cancel, 1);
  } else if(!has_id) {
    if(atomic_load(&g_du.busy)) {
      atomic_store(&g_du_cancel, 1);
      pthread_mutex_unlock(&g_du.lock);
      return serve_error(req, 409, "previous size request is cancelling");
    }
    if(transfer_job_busy()) {
      pthread_mutex_unlock(&g_du.lock);
      return serve_error(req, 409, "folder size is unavailable during a transfer");
    }
    struct du_arg *arg = calloc(1, sizeof(*arg));
    struct stat st={0};
    if(!arg || (!bfpilot_smb_path(path)&&lstat(path, &st) != 0)) {
      int error = arg ? errno : ENOMEM;
      free(arg); pthread_mutex_unlock(&g_du.lock);
      return serve_error(req, 500, strerror(error));
    }
    snprintf(arg->path, sizeof(arg->path), "%s", path);
    arg->device = st.st_dev;
    snprintf(g_du.path, sizeof(g_du.path), "%s", path);
    g_du.id++;
    g_du.error = 0;
    atomic_store(&g_du.counts.bytes, 0);
    atomic_store(&g_du.counts.entries, 0);
    atomic_store(&g_du.counts.files, 0);
    atomic_store(&g_du.counts.dirs, 0);
    g_du.counts.background = 1;
    atomic_store(&g_du_cancel, 0);
    atomic_store(&g_du.lease_ms, monotonic_ms());
    atomic_store(&g_du.busy, 1);
    pthread_attr_t attr;
    pthread_t thread;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    int rc = pthread_create(&thread, &attr, du_worker, arg);
    pthread_attr_destroy(&attr);
    if(rc) { free(arg); g_du.error = rc; atomic_store(&g_du.busy, 0); }
  }
  atomic_store(&g_du.lease_ms, monotonic_ms());
  int result = du_response(req, g_du.path, &g_du.counts,
                           atomic_load(&g_du.busy), g_du.id, g_du.error);
  pthread_mutex_unlock(&g_du.lock);
  return result;
}

typedef struct shortcut_entry {
  char label[64];
  char path[512];
} shortcut_entry_t;


static void
sanitize_shortcut_label(char *out, size_t out_size, const char *label,
                        const char *path) {
  const char *src = label && label[0] ? label : safe_basename_label(path);
  size_t pos = 0;
  if(out_size == 0) return;
  for(const unsigned char *p = (const unsigned char *)src;
      *p && pos + 1 < out_size; p++) {
    if(*p < 0x20 || *p == '\t') {
      if(pos > 0 && out[pos - 1] != ' ') out[pos++] = ' ';
    } else {
      out[pos++] = (char)*p;
    }
  }
  while(pos > 0 && out[pos - 1] == ' ') pos--;
  out[pos] = 0;
  if(!out[0]) snprintf(out, out_size, "%s", safe_basename_label(path));
}


static int
read_shortcuts(shortcut_entry_t *items, int max_items) {
  FILE *file = fopen(BFPILOT_SHORTCUTS_PATH, "r");
  if(!file) return 0;

  int count = 0;
  char line[700];
  while(count < max_items && fgets(line, sizeof(line), file)) {
    char *nl = strpbrk(line, "\r\n");
    if(nl) *nl = 0;
    char *tab = strchr(line, '\t');
    if(!tab) continue;
    *tab++ = 0;
    if(!path_is_safe(tab)) continue;
    sanitize_shortcut_label(items[count].label, sizeof(items[count].label),
                            line, tab);
    snprintf(items[count].path, sizeof(items[count].path), "%s", tab);
    count++;
  }
  fclose(file);
  return count;
}


static int
write_shortcuts(const shortcut_entry_t *items, int count) {
  ensure_bfpilot_dir();
  FILE *file = fopen(BFPILOT_SHORTCUTS_TMP, "w");
  if(!file) return -1;
  for(int i = 0; i < count; i++) {
    if(fprintf(file, "%s\t%s\n", items[i].label, items[i].path) < 0) {
      fclose(file);
      return -1;
    }
  }
  if(fclose(file) != 0) return -1;
  if(rename(BFPILOT_SHORTCUTS_TMP, BFPILOT_SHORTCUTS_PATH) != 0) return -1;
  return 0;
}


static void
fs_totals(const char *path, fs_total_info_t *info) {
  struct statvfs vfs;
  memset(info, 0, sizeof(*info));
  if(statvfs(path, &vfs) != 0) return;

  unsigned long long block = vfs.f_frsize ? vfs.f_frsize : vfs.f_bsize;
  info->total = (unsigned long long)vfs.f_blocks * block;
  info->free_bytes = (unsigned long long)vfs.f_bfree * block;
  info->available = (unsigned long long)vfs.f_bavail * block;
  info->reserved = info->free_bytes > info->available
                       ? info->free_bytes - info->available
                       : 0;
  info->used = info->total > info->free_bytes
                   ? info->total - info->free_bytes
                   : 0;
  info->usable_total = info->total > info->reserved
                           ? info->total - info->reserved
                           : info->total;
  info->usable_used = info->usable_total > info->available
                          ? info->usable_total - info->available
                          : 0;
  info->used_pct = info->total > 0
                       ? ((double)info->used * 100.0) / (double)info->total
                       : 0.0;
  info->usable_used_pct =
      info->usable_total > 0
          ? ((double)info->usable_used * 100.0) / (double)info->usable_total
          : 0.0;
  info->ok = 1;
}


static int
append_fs_place(json_buf_t *b, int *first, const char *label,
                const char *path, const char *kind, int custom,
                int mounted) {
  struct stat st;
  int network=bfpilot_smb_path(path);
  memset(&st,0,sizeof(st));
  if(!network && (stat(path, &st) != 0 || !S_ISDIR(st.st_mode))) return 0;

  if(!*first && json_append(b, ",") != 0) return -1;
  *first = 0;

  fs_total_info_t fs = {0};
  if(!network)fs_totals(path, &fs);

  if(json_append(b, "{\"label\":") != 0 ||
     json_string(b, label && label[0] ? label : safe_basename_label(path)) != 0 ||
     json_append(b, ",\"path\":") != 0 ||
     json_string(b, path) != 0 ||
     json_append(b, ",\"kind\":") != 0 ||
     json_string(b, kind ? kind : "path") != 0 ||
     json_appendf(b,
                  ",\"custom\":%s,\"mounted\":%s,\"dev\":%lu,"
                  "\"statvfs\":%s,\"totalBytes\":%llu,\"freeBytes\":%llu,"
                  "\"availableBytes\":%llu,\"reservedBytes\":%llu,"
                  "\"usedBytes\":%llu,\"usedPercent\":%.2f,"
                  "\"usableTotalBytes\":%llu,\"usableUsedBytes\":%llu,"
                  "\"usableUsedPercent\":%.2f,"
                  "\"writable\":null,\"writeProbe\":\"skipped-read-only\"}",
                  custom ? "true" : "false", mounted ? "true" : "false",
                  (unsigned long)st.st_dev, fs.ok ? "true" : "false",
                  fs.total, fs.free_bytes, fs.available, fs.reserved,
                  fs.used, fs.used_pct, fs.usable_total, fs.usable_used,
                  fs.usable_used_pct) != 0) {
    return -1;
  }
  return 0;
}


static int
append_mount_candidate(json_buf_t *b, int *first, const char *path,
                       const char *kind, dev_t mnt_dev) {
  struct stat st;
  if(stat(path, &st) != 0 || !S_ISDIR(st.st_mode)) return 0;

  if(st.st_dev == mnt_dev) {
    return 0;
  }

  char label[64];
  if(!strcmp(path, "/mnt/ext1")) {
    snprintf(label, sizeof(label), "M.2 SSD");
  } else if(!strcmp(path, "/mnt/ext0")) {
    snprintf(label, sizeof(label), "USB Extended");
  } else if(!strncmp(path, "/mnt/usb", 8)) {
    snprintf(label, sizeof(label), "USB Drive %s", path + strlen("/mnt/usb"));
  } else {
    snprintf(label, sizeof(label), "%s", path + strlen("/mnt/"));
    for(char *p = label; *p; p++) *p = (char)toupper((unsigned char)*p);
  }
  return append_fs_place(b, first, label, path, kind, 0, 1);
}


struct smb_places {json_buf_t *buffer;int *first;};
static int append_smb_place(const bfpilot_smb_record_t *record,void *context) {
  struct smb_places *places=context;char path[64];snprintf(path,sizeof(path),"/smb/%s",record->id);
  return append_fs_place(places->buffer,places->first,record->label,path,"network",0,1);
}
static int
places_request(const http_request_t *req) {
  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"places\":[") != 0) return -1;
  int first = 1;

  if(append_fs_place(&b, &first, "Root", "/", "root", 0, 1) != 0 ||
     append_fs_place(&b, &first, "Homebrew", "/data/homebrew", "homebrew", 0, 1) != 0 ||
     append_fs_place(&b, &first, "Mounts", "/mnt", "mounts", 0, 1) != 0 ||
     append_fs_place(&b, &first, "User", "/user", "user", 0, 1) != 0 ||
     append_fs_place(&b, &first, "Data", "/data", "internal", 0, 1) != 0) {
    free(b.data);
    return -1;
  }

  struct stat mnt_st;
  dev_t mnt_dev = 0;
  if(stat("/mnt", &mnt_st) == 0) mnt_dev = mnt_st.st_dev;

  for(int i = 0; i < 8; i++) {
    char path[24];
    snprintf(path, sizeof(path), "/mnt/usb%d", i);
    if(append_mount_candidate(&b, &first, path, "usb", mnt_dev) != 0) {
      free(b.data);
      return -1;
    }
  }
  for(int i = 0; i < 8; i++) {
    char path[24];
    snprintf(path, sizeof(path), "/mnt/ext%d", i);
    if(append_mount_candidate(&b, &first, path, "ext", mnt_dev) != 0) {
      free(b.data);
      return -1;
    }
  }

  struct smb_places network={&b,&first};
  if(append_fs_place(&b,&first,"Network","/smb","network",0,1)!=0||
     bfpilot_smb_records(append_smb_place,&network)!=0){free(b.data);return serve_error(req,500,"cannot read saved SMB connections");}

  shortcut_entry_t shortcuts[BFPILOT_MAX_SHORTCUTS];
  int shortcut_count = read_shortcuts(shortcuts, BFPILOT_MAX_SHORTCUTS);
  for(int i = 0; i < shortcut_count; i++) {
    if(append_fs_place(&b, &first, shortcuts[i].label, shortcuts[i].path,
                       "custom", 1, 1) != 0) {
      free(b.data);
      return -1;
    }
  }

  if(json_append(&b, "],\"mounts\":[") != 0) {
    free(b.data);
    return -1;
  }

  int mount_first = 1;
  for(int i = 0; i < 8; i++) {
    char path[24];
    snprintf(path, sizeof(path), "/mnt/usb%d", i);
    if(append_mount_candidate(&b, &mount_first, path, "usb", mnt_dev) != 0) {
      free(b.data);
      return -1;
    }
  }
  for(int i = 0; i < 8; i++) {
    char path[24];
    snprintf(path, sizeof(path), "/mnt/ext%d", i);
    if(append_mount_candidate(&b, &mount_first, path, "ext", mnt_dev) != 0) {
      free(b.data);
      return -1;
    }
  }

  if(json_append(&b, "]}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
shortcut_add_request(const http_request_t *req) {
  char label[128], path[512];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path)) {
    return serve_error(req, 400, "bad shortcut path");
  }
  (void)websrv_get_query_arg(req, "label", label, sizeof(label));

  struct stat st;
  if(stat(path, &st) != 0 || !S_ISDIR(st.st_mode)) {
    return serve_error(req, 404, "shortcut target is not a folder");
  }

  shortcut_entry_t shortcuts[BFPILOT_MAX_SHORTCUTS];
  int count = read_shortcuts(shortcuts, BFPILOT_MAX_SHORTCUTS);
  int index = -1;
  for(int i = 0; i < count; i++) {
    if(!strcmp(shortcuts[i].path, path)) {
      index = i;
      break;
    }
  }
  if(index < 0) {
    if(count >= BFPILOT_MAX_SHORTCUTS) {
      return serve_error(req, 409, "shortcut limit reached");
    }
    index = count++;
  }
  sanitize_shortcut_label(shortcuts[index].label,
                          sizeof(shortcuts[index].label), label, path);
  snprintf(shortcuts[index].path, sizeof(shortcuts[index].path), "%s", path);

  if(write_shortcuts(shortcuts, count) != 0) {
    return serve_error(req, 500, strerror(errno));
  }
  bfpilot_log("shortcut add label=%s path=%s", shortcuts[index].label, path);

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"label\":") != 0 ||
     json_string(&b, shortcuts[index].label) != 0 ||
     json_append(&b, ",\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
shortcut_delete_request(const http_request_t *req) {
  char path[512];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path)) {
    return serve_error(req, 400, "bad shortcut path");
  }

  shortcut_entry_t shortcuts[BFPILOT_MAX_SHORTCUTS];
  int count = read_shortcuts(shortcuts, BFPILOT_MAX_SHORTCUTS);
  int out = 0;
  int removed = 0;
  for(int i = 0; i < count; i++) {
    if(!strcmp(shortcuts[i].path, path)) {
      removed = 1;
      continue;
    }
    if(out != i) shortcuts[out] = shortcuts[i];
    out++;
  }
  if(!removed) return serve_error(req, 404, "shortcut not found");
  if(write_shortcuts(shortcuts, out) != 0) {
    return serve_error(req, 500, strerror(errno));
  }
  bfpilot_log("shortcut delete path=%s", path);

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
shortcut_rename_request(const http_request_t *req) {
  char label[128], path[512];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path)) {
    return serve_error(req, 400, "bad shortcut path");
  }
  if(!websrv_get_query_arg(req, "label", label, sizeof(label))) {
    return serve_error(req, 400, "missing shortcut label");
  }

  shortcut_entry_t shortcuts[BFPILOT_MAX_SHORTCUTS];
  int count = read_shortcuts(shortcuts, BFPILOT_MAX_SHORTCUTS);
  int index = -1;
  for(int i = 0; i < count; i++) {
    if(!strcmp(shortcuts[i].path, path)) {
      index = i;
      break;
    }
  }
  if(index < 0) return serve_error(req, 404, "shortcut not found");

  sanitize_shortcut_label(shortcuts[index].label,
                          sizeof(shortcuts[index].label), label, path);
  if(write_shortcuts(shortcuts, count) != 0) {
    return serve_error(req, 500, strerror(errno));
  }
  bfpilot_log("shortcut rename label=%s path=%s", shortcuts[index].label, path);

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"label\":") != 0 ||
     json_string(&b, shortcuts[index].label) != 0 ||
     json_append(&b, ",\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
spawn_copy_or_move_values(const http_request_t *req, int is_move,
                          const char *src, const char *dst, int overwrite) {
  if(!path_is_safe(src) || !path_is_safe(dst)) {
    return serve_error(req, 400, "bad src/dst");
  }
  if(!strcmp(src, dst)) return serve_error(req, 400, "src == dst");

  const char *base = path_basename(src);
  char final_dst[1024];
  if(join_path_checked(final_dst, sizeof(final_dst), dst, base) != 0) {
    return serve_error(req, 400, "target path too long");
  }

  struct stat final_st;
  if(!overwrite && lstat(final_dst, &final_st) == 0) {
    return serve_error(req, 409, "destination already exists");
  }

  if(!job_begin(is_move ? "move" : "copy")) {
    return serve_error(req, 409, "another file-manager job is already running");
  }
  bfpilot_log("transfer job begin verb=%s src=%s dst=%s",
              is_move ? "move" : "copy", src, dst);

  struct copy_arg *a = calloc(1, sizeof(*a));
  if(!a) {
    job_end(-1, "alloc");
    return serve_error(req, 500, "alloc");
  }
  snprintf(a->src, sizeof(a->src), "%s", src);
  snprintf(a->dst, sizeof(a->dst), "%s", dst);
  a->is_move = is_move;
  a->overwrite = overwrite;

  pthread_t t;
  pthread_attr_t at;
  pthread_attr_init(&at);
  pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
  /* Existing destination-merge validation remains depth-bounded; provision
   * its worst-case path frames explicitly instead of relying on libc defaults. */
  int stack_rc = pthread_attr_setstacksize(&at, 512 * 1024);
  if(stack_rc != 0) {
    pthread_attr_destroy(&at);
    free(a); errno = stack_rc; job_end(-1, "worker stack");
    return serve_error(req, 500, "worker stack");
  }
  int trc = pthread_create(&t, &at, copy_worker, a);
  pthread_attr_destroy(&at);
  if(trc != 0) {
    free(a);
    job_end(-1, "pthread_create");
    return serve_error(req, 500, "could not start job");
  }

  json_buf_t b = {0};
  if(json_appendf(&b, "{\"ok\":true,\"verb\":\"%s\",\"src\":",
                  is_move ? "move" : "copy") != 0 ||
     json_string(&b, src) != 0 ||
     json_append(&b, ",\"dst\":") != 0 ||
     json_string(&b, dst) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
spawn_copy_or_move(const http_request_t *req, int is_move) {
  char src[1024], dst[1024], overwrite_text[16];
  if(!websrv_get_query_arg(req, "src", src, sizeof(src)) ||
     !websrv_get_query_arg(req, "dst", dst, sizeof(dst))) {
    return serve_error(req, 400, "bad src/dst");
  }
  int overwrite = websrv_get_query_arg(req, "overwrite", overwrite_text,
                                       sizeof(overwrite_text))
                      ? atoi(overwrite_text)
                      : 0;
  return spawn_copy_or_move_values(req, is_move, src, dst, overwrite);
}


static int
delete_handler_values(const http_request_t *req, const char *path,
                      int recursive) {
  if(!path_is_safe(path)) {
    return serve_error(req, 400, "bad path");
  }
  if(!strcmp(path, "/") || !strcmp(path, "/data") ||
     !strcmp(path, "/system_data") || !strcmp(path, "/user")) {
    return serve_error(req, 403, "refusing to delete root path");
  }

  struct stat st;
  if(bfpilot_smb_path(path)) {
    bfpilot_io_t *endpoint=NULL;int rc=bfpilot_io_endpoint(path,&endpoint);
    if(!rc&&!strcmp(path,bfpilot_io_root(endpoint)))rc=-EPERM;
    if(!rc)rc=bfpilot_io_lstat(endpoint,path,&st);
    bfpilot_io_end(endpoint);if(rc)return serve_error(req,rc==-EPERM?403:404,strerror(-rc));
  } else if(lstat(path, &st) != 0) return serve_error(req, 404, strerror(errno));
  if(S_ISDIR(st.st_mode) && !recursive) {
    return serve_error(req, 400, "directory delete needs recursive=1");
  }
  if(!job_begin("delete")) {
    return serve_error(req, 409, "another file-manager job is already running");
  }

  struct delete_arg *a = calloc(1, sizeof(*a));
  if(!a) {
    job_end(-1, "alloc");
    return serve_error(req, 500, "alloc");
  }
  snprintf(a->path, sizeof(a->path), "%s", path);

  pthread_t t;
  pthread_attr_t at;
  pthread_attr_init(&at);
  pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
  /* Existing destination-merge validation remains depth-bounded; provision
   * its worst-case path frames explicitly instead of relying on libc defaults. */
  int stack_rc = pthread_attr_setstacksize(&at, 512 * 1024);
  if(stack_rc != 0) {
    pthread_attr_destroy(&at);
    free(a); errno = stack_rc; job_end(-1, "worker stack");
    return serve_error(req, 500, "worker stack");
  }
  int trc = pthread_create(&t, &at, delete_worker, a);
  pthread_attr_destroy(&at);
  if(trc != 0) {
    free(a);
    job_end(-1, "pthread_create");
    return serve_error(req, 500, "could not start job");
  }

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"verb\":\"delete\",\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
mkdir_handler(const http_request_t *req) {
  char path[1024];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path)) {
    return serve_error(req, 400, "bad path");
  }
  if(bfpilot_smb_path(path)) {
    bfpilot_io_t *endpoint=NULL;int rc=bfpilot_io_endpoint(path,&endpoint);
    if(!rc)rc=bfpilot_io_mkdirs(endpoint,path,0777);bfpilot_io_end(endpoint);
    if(rc)return serve_error(req,500,strerror(-rc));
  } else if(mkdirs(path) != 0) return serve_error(req, 500, strerror(errno));
  bfpilot_search_mark_stale("mkdir");

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
rename_handler(const http_request_t *req) {
  char src[1024], dst[1024];
  if(!websrv_get_query_arg(req, "src", src, sizeof(src)) ||
     !websrv_get_query_arg(req, "dst", dst, sizeof(dst)) ||
     !path_is_safe(src) || !path_is_safe(dst)) {
    return serve_error(req, 400, "bad src/dst");
  }
  if(bfpilot_smb_path(src)||bfpilot_smb_path(dst)) {
    if(!bfpilot_smb_path(src)||!bfpilot_smb_path(dst))return serve_error(req,400,"use Move for transfers between filesystems");
    bfpilot_io_t *endpoint=NULL;int rc=bfpilot_io_endpoint(src,&endpoint);
    if(!rc)rc=bfpilot_io_rename(endpoint,src,dst,0);bfpilot_io_end(endpoint);
    if(rc)return serve_error(req,rc==-EEXIST?409:500,strerror(-rc));
  } else if(rename(src, dst) != 0) return serve_error(req, 500, strerror(errno));
  bfpilot_search_mark_stale("rename");

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"src\":") != 0 ||
     json_string(&b, src) != 0 ||
     json_append(&b, ",\"dst\":") != 0 ||
     json_string(&b, dst) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
status_handler(const http_request_t *req) {
  (void)download_expire_pending();
  int busy = atomic_load(&g_job.busy);
  long tb = atomic_load(&g_job.total_bytes);
  long cb = atomic_load(&g_job.copied_bytes);
  int tf = atomic_load(&g_job.total_files);
  int df = atomic_load(&g_job.done_files);
  int ff = atomic_load(&g_job.failed_files);
  long elapsed_ms = atomic_load(&g_job.elapsed_ms);
  long read_bytes = atomic_load(&g_job.read_bytes);
  long written_bytes = atomic_load(&g_job.written_bytes);
  int last_errno = atomic_load(&g_job.last_errno);
  int pipeline_files = atomic_load(&g_job.pipeline_files);
  int serial_files = atomic_load(&g_job.serial_files);
  int writeback_syncs = atomic_load(&g_job.writeback_syncs);
  int cancel = atomic_load(&g_job.cancel);
  char verb[16], current[sizeof(g_job.current)], source[sizeof(g_job.source)],
       destination[sizeof(g_job.destination)], err[256];
  unsigned long source_dev, destination_dev;
  long started_ms;
  time_t started_at;
  time_t ended_at;

  pthread_mutex_lock(&g_job.lock);
  snprintf(verb, sizeof(verb), "%s", g_job.verb);
  snprintf(current, sizeof(current), "%s", g_job.current);
  snprintf(source, sizeof(source), "%s", g_job.source);
  snprintf(destination, sizeof(destination), "%s", g_job.destination);
  snprintf(err, sizeof(err), "%s", g_job.error);
  source_dev = g_job.source_dev;
  destination_dev = g_job.destination_dev;
  started_ms = g_job.started_ms;
  started_at = g_job.started_at;
  ended_at = g_job.ended_at;
  pthread_mutex_unlock(&g_job.lock);

  pthread_mutex_lock(&g_download.lock);
  unsigned long download_id = g_download.id;
  pthread_mutex_unlock(&g_download.lock);

  time_t now = time(NULL);
  time_t ref_at = busy ? now : (ended_at ? ended_at : now);
  long elapsed = started_at > 0 && ref_at > started_at
                     ? (long)(ref_at - started_at)
                     : 0;
  if(busy) {
    long now_ms = monotonic_ms();
    elapsed_ms = now_ms > started_ms ? now_ms - started_ms : 0;
  }
  double speed_bps = elapsed_ms > 0 && cb > 0
                         ? ((double)cb * 1000.0) / (double)elapsed_ms
                         : 0.0;
  long speed = speed_bps > 0.0 ? (long)speed_bps : 0;
  double avg_mbps = speed_bps / (1024.0 * 1024.0);

  double instant_bps = 0.0;
  if(busy) {
    long now_ms = monotonic_ms();
    pthread_mutex_lock(&g_job.lock);
    long w_dt = now_ms - g_job.window_sample_ms;
    long w_db = cb - g_job.window_sample_bytes;
    if(w_dt >= 600 && w_db >= 0) {
      instant_bps = ((double)w_db * 1000.0) / (double)w_dt;
      g_job.last_instant_bps = instant_bps;
      g_job.window_sample_ms = now_ms;
      g_job.window_sample_bytes = cb;
    } else {
      instant_bps = g_job.last_instant_bps;
    }
    pthread_mutex_unlock(&g_job.lock);
  }
  if(instant_bps <= 0.0 && speed_bps > 0.0) {
    instant_bps = speed_bps;
  }
  long instant_speed = instant_bps > 0.0 ? (long)instant_bps : 0;
  double instant_mbps = instant_bps / (1024.0 * 1024.0);

  long eta = busy && instant_bps > 0.0 && tb > cb
                 ? (long)(((double)(tb - cb) / instant_bps) + 0.999)
                 : (busy && speed > 0 && tb > cb
                        ? (long)(((double)(tb - cb) / speed_bps) + 0.999)
                        : 0);

  json_buf_t b = {0};
  if(json_appendf(&b,
      "{\"ok\":true,\"busy\":%s,\"cancelling\":%s,\"verb\":",
      busy ? "true" : "false", cancel ? "true" : "false") != 0 ||
     json_string(&b, verb) != 0 ||
     json_append(&b, ",\"current\":") != 0 ||
     json_string(&b, current) != 0 ||
     json_append(&b, ",\"error\":") != 0 ||
     json_string(&b, err) != 0 ||
     json_append(&b, ",\"source\":") != 0 ||
     json_string(&b, source) != 0 ||
     json_append(&b, ",\"destination\":") != 0 ||
     json_string(&b, destination) != 0 ||
     json_appendf(&b,
      ",\"downloadId\":%lu,\"totalBytes\":%ld,\"copiedBytes\":%ld,"
      "\"totalKnown\":%s,\"totalFiles\":%d,\"doneFiles\":%d,\"failedFiles\":%d,"
      "\"startedAt\":%ld,\"endedAt\":%ld,"
      "\"elapsedSeconds\":%ld,\"elapsedMs\":%ld,"
      "\"bytesRead\":%ld,\"bytesWritten\":%ld,"
      "\"pipelineFiles\":%d,\"serialFiles\":%d,"
      "\"writebackSyncs\":%d,\"copyBufferSize\":%u,"
      "\"sourceDev\":%lu,\"destinationDev\":%lu,\"errno\":%d,"
      "\"speedBytesPerSec\":%ld,\"averageMBps\":%.2f,"
      "\"instantSpeedBytesPerSec\":%ld,\"instantMBps\":%.2f,"
      "\"etaSeconds\":%ld}",
      download_id, tb, cb, atomic_load(&g_job.total_known) ? "true" : "false", tf, df, ff, (long)started_at, (long)ended_at,
      elapsed, elapsed_ms, read_bytes, written_bytes, pipeline_files,
      serial_files, writeback_syncs, (unsigned int)COPY_BUF_SIZE, source_dev,
      destination_dev, last_errno, speed, avg_mbps, instant_speed, instant_mbps, eta) != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}

static int
transfer_stats_handler(const http_request_t *req) {
  long elapsed_ms, recv_ms, write_ms, sync_ms;
  unsigned long bytes, destination_dev;
  unsigned int sync_count;
  int error_code, buffer_aligned;
  char path[sizeof(g_upload.path)];
  bfpilot_download_stats_t download;

  pthread_mutex_lock(&g_upload.lock);
  elapsed_ms = g_upload.elapsed_ms;
  bytes = g_upload.bytes;
  destination_dev = g_upload.destination_dev;
  error_code = g_upload.error_code;
  recv_ms = g_upload.recv_ms;
  write_ms = g_upload.write_ms;
  sync_ms = g_upload.sync_ms;
  sync_count = g_upload.sync_count;
  buffer_aligned = g_upload.buffer_aligned;
  snprintf(path, sizeof(path), "%s", g_upload.path);
  pthread_mutex_unlock(&g_upload.lock);
  memset(&download, 0, sizeof(download));
  bfpilot_fs_get_download_stats(&download);

  json_buf_t b = {0};
  double mbps = elapsed_ms > 0 ?
      ((double)bytes * 1000.0 / (double)elapsed_ms) / (1024.0 * 1024.0) : 0.0;
  if(json_append(&b, "{\"ok\":true,\"bufferSize\":") != 0 ||
     json_appendf(&b, "%u,\"lastUpload\":{\"path\":",
                  (unsigned int)UPLOAD_BUF_SIZE) != 0 ||
     json_string(&b, path) != 0 ||
     json_appendf(&b,
                  ",\"bytes\":%lu,\"elapsedMs\":%ld,\"averageMBps\":%.2f,"
                  "\"recvMs\":%ld,\"writeMs\":%ld,\"syncMs\":%ld,"
                  "\"syncCount\":%u,\"bufferAligned\":%s,"
                  "\"destinationDev\":%lu,\"errno\":%d},"
                  "\"lastDownload\":{\"path\":",
                  bytes, elapsed_ms, mbps, recv_ms, write_ms, sync_ms,
                  sync_count, buffer_aligned ? "true" : "false",
                  destination_dev, error_code) != 0 ||
     json_string(&b, download.path) != 0 ||
     json_appendf(&b,
                  ",\"bytes\":%lu,\"elapsedMs\":%ld,"
                  "\"averageMBps\":%.2f,\"readMs\":%ld,\"sendMs\":%ld,"
                  "\"sourceDev\":%lu,\"bufferSize\":%u,"
                  "\"bufferAligned\":%s,\"mode\":\"buffered-sequential\","
                  "\"errno\":%d}}",
                  download.bytes, download.elapsed_ms,
                  download.elapsed_ms > 0
                      ? ((double)download.bytes * 1000.0 /
                         (double)download.elapsed_ms) / (1024.0 * 1024.0)
                      : 0.0,
                  download.read_ms, download.send_ms, download.source_dev,
                  download.buffer_size,
                  download.buffer_aligned ? "true" : "false",
                  download.error_code) != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
read_request_body(const http_request_t *req, const char *initial_data,
                  size_t initial_size, size_t content_size,
                  size_t max_size, char **out) {
  if(content_size > max_size) {
    drain_body(req->fd, initial_size, content_size);
    errno = EFBIG;
    return -1;
  }
  char *body = calloc(1, content_size + 1);
  if(!body) {
    drain_body(req->fd, initial_size, content_size);
    return -1;
  }
  if(initial_size > content_size) initial_size = content_size;
  if(initial_size > 0) memcpy(body, initial_data, initial_size);

  size_t used = initial_size;
  while(used < content_size) {
    ssize_t n = recv(req->fd, body + used, content_size - used, 0);
    if(n < 0) {
      if(errno == EINTR) continue;
      free(body);
      return -1;
    }
    if(n == 0) {
      free(body);
      errno = ECONNRESET;
      return -1;
    }
    used += (size_t)n;
  }
  body[content_size] = 0;
  *out = body;
  return 0;
}


static int form_get_arg(const char *body, const char *name, char *out, size_t out_size) {
  return bfpilot_form_arg(body, name, out, out_size);
}


static void
download_free_paths(char **paths, size_t count) {
  if(!paths) return;
  for(size_t i = 0; i < count; i++) free(paths[i]);
  free(paths);
}


static int
hex_digit_value(unsigned char c) {
  if(c >= '0' && c <= '9') return (int)(c - '0');
  if(c >= 'a' && c <= 'f') return (int)(c - 'a') + 10;
  if(c >= 'A' && c <= 'F') return (int)(c - 'A') + 10;
  return -1;
}


static int
form_component_decode(const char *input, size_t input_size,
                      char *output, size_t output_size) {
  size_t used = 0;
  if(!output || output_size == 0) return -1;
  for(size_t i = 0; i < input_size; i++) {
    unsigned char c = (unsigned char)input[i];
    if(c == '+') {
      c = ' ';
    } else if(c == '%') {
      if(i + 2 >= input_size) return -1;
      int high = hex_digit_value((unsigned char)input[i + 1]);
      int low = hex_digit_value((unsigned char)input[i + 2]);
      if(high < 0 || low < 0) return -1;
      c = (unsigned char)((high << 4) | low);
      i += 2;
    }
    if(c == 0 || used + 1 >= output_size) return -1;
    output[used++] = (char)c;
  }
  output[used] = 0;
  return 0;
}


static int
download_collect_paths(const char *body, char ***paths_out,
                       size_t *count_out) {
  char **paths = NULL;
  size_t count = 0;
  const char *cursor = body ? body : "";

  while(*cursor) {
    const char *amp = strchr(cursor, '&');
    size_t pair_size = amp ? (size_t)(amp - cursor) : strlen(cursor);
    const char *eq = memchr(cursor, '=', pair_size);
    size_t key_size = eq ? (size_t)(eq - cursor) : pair_size;
    size_t value_size = eq ? pair_size - key_size - 1 : 0;
    char key[32];

    if(form_component_decode(cursor, key_size, key, sizeof(key)) != 0) {
      download_free_paths(paths, count);
      errno = EINVAL;
      return -1;
    }
    if(!strcmp(key, "path")) {
      char decoded[1024];
      char resolved[1024];
      struct stat st;
      int duplicate = 0;

       if(count >= BFPILOT_DOWNLOAD_MAX_PATHS || !eq || value_size == 0 ||
          form_component_decode(eq + 1, value_size, decoded,
                                sizeof(decoded)) != 0) {
         download_free_paths(paths, count);
         errno = count >= BFPILOT_DOWNLOAD_MAX_PATHS ? E2BIG : EINVAL;
         return -1;
       }
       (void)bfpilot_path_decode_byte_tokens(decoded);
       bfpilot_io_t *endpoint = NULL;
       int path_rc = -EINVAL;
       /* SMB paths are virtual and cannot be resolved with local lstat/CI. */
       int resolved_rc = -EINVAL;
       if(path_is_safe(decoded)) {
         if(bfpilot_smb_path(decoded)) {
           resolved_rc = bfpilot_smb_validate_path(decoded);
           if(!resolved_rc) snprintf(resolved, sizeof(resolved), "%s", decoded);
         } else resolved_rc = path_for_list(decoded, resolved, sizeof(resolved));
       }
       if(!resolved_rc) {
         path_rc = bfpilot_io_endpoint(resolved, &endpoint);
         if(!path_rc) path_rc = bfpilot_io_lstat(endpoint, resolved, &st);
         bfpilot_io_end(endpoint);
       }
       if(path_rc ||
         (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode))) {
        download_free_paths(paths, count);
        errno = count >= BFPILOT_DOWNLOAD_MAX_PATHS ? E2BIG : EINVAL;
        return -1;
      }
      for(size_t i = 0; i < count; i++) {
        if(!strcmp(paths[i], resolved)) {
          duplicate = 1;
          break;
        }
      }
      if(!duplicate) {
        char **next = realloc(paths, (count + 1) * sizeof(*paths));
        if(!next) {
          download_free_paths(paths, count);
          errno = ENOMEM;
          return -1;
        }
        paths = next;
        paths[count] = strdup(resolved);
        if(!paths[count]) {
          download_free_paths(paths, count);
          errno = ENOMEM;
          return -1;
        }
        count++;
      }
    }
    if(!amp) break;
    cursor = amp + 1;
  }

  if(count == 0) {
    download_free_paths(paths, count);
    errno = EINVAL;
    return -1;
  }
  *paths_out = paths;
  *count_out = count;
  return 0;
}


int
transfer_pkg_install_request(const http_request_t *req,
                             const char *initial_data, size_t initial_size,
                             size_t content_size) {
  char *body = NULL;
  char **paths = NULL;
  size_t count = 0;
  char error[512];

  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_DOWNLOAD_FORM_MAX_SIZE, &body) != 0) {
    return serve_error(req, errno == EFBIG ? 413 : 500,
                       errno == EFBIG ? "PKG request is too large"
                                      : strerror(errno));
  }
  if(download_collect_paths(body, &paths, &count) != 0) {
    int saved_errno = errno;
    free(body);
    return serve_error(req, saved_errno == E2BIG ? 413 : 400,
                       saved_errno == E2BIG ? "too many selected paths"
                                            : "invalid PKG selection");
  }
  free(body);

  int rc = bfpilot_pkg_install_start((const char *const *)paths, count,
                                     error, sizeof(error));
  download_free_paths(paths, count);
  if(rc != 0) {
    int status = rc == -EINVAL || rc == -ENAMETOOLONG || rc == -ENOTSUP ? 400 :
                 rc == -EBUSY ? 409 :
                 rc == -ENOENT ? 404 :
                 rc == -ECONNREFUSED || rc == -ENETUNREACH ||
                 rc == -ETIMEDOUT ? 503 : 500;
    return serve_error(req, status, error[0] ? error : "PKG install failed");
  }

  char response[160];
  int length = snprintf(response, sizeof(response),
                        "{\"ok\":true,\"state\":\"queued\","
                        "\"packageCount\":%lu}", (unsigned long)count);
  return length < 0 || (size_t)length >= sizeof(response) ? -1 :
      websrv_send(req->fd, 202, "application/json", response,
                  (size_t)length);
}


int
transfer_download_prepare_request(const http_request_t *req,
                                  const char *initial_data,
                                  size_t initial_size,
                                  size_t content_size) {
  char *body = NULL;
  char **paths = NULL;
  size_t count = 0;
  unsigned long id;

  (void)download_expire_pending();

  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_DOWNLOAD_FORM_MAX_SIZE, &body) != 0) {
    return serve_error(req, errno == EFBIG ? 413 : 500,
                       errno == EFBIG ? "download request is too large"
                                      : strerror(errno));
  }
  if(download_collect_paths(body, &paths, &count) != 0) {
    int saved_errno = errno;
    free(body);
    return serve_error(req, saved_errno == E2BIG ? 413 : 400,
                       saved_errno == E2BIG ? "too many selected paths"
                                            : "invalid download selection");
  }
  free(body);

  if(!job_begin("download")) {
    download_free_paths(paths, count);
    return serve_error(req, 409,
                       "another file-manager job is already running");
  }

  pthread_mutex_lock(&g_download.lock);
  download_free_paths(g_download.paths, g_download.path_count);
  g_download.paths = paths;
  g_download.path_count = count;
  g_download.id = g_download.next_id++;
  if(g_download.next_id == 0) g_download.next_id = 1;
  g_download.started = 0;
  g_download.prepared_at = time(NULL);
  id = g_download.id;
  pthread_mutex_unlock(&g_download.lock);

  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.source, sizeof(g_job.source), "%s%s",
           paths[0], count > 1 ? " ..." : "");
  snprintf(g_job.current, sizeof(g_job.current), "%s", "waiting for browser");
  pthread_mutex_unlock(&g_job.lock);

  bfpilot_log("download prepared id=%lu selections=%lu first=%s",
              id, (unsigned long)count, paths[0]);
  char response[160];
  int n = snprintf(response, sizeof(response),
                   "{\"ok\":true,\"id\":%lu,\"count\":%lu}",
                   id, (unsigned long)count);
  if(n < 0 || (size_t)n >= sizeof(response)) {
    errno = EOVERFLOW;
    job_end(-1, "download response overflow");
    return -1;
  }
  return websrv_send(req->fd, 200, "application/json", response, (size_t)n);
}


static int
download_take_request(unsigned long id, char ***paths_out,
                      size_t *count_out) {
  int ok = 0;
  (void)download_expire_pending();
  pthread_mutex_lock(&g_download.lock);
  if(g_download.paths && g_download.id == id && !g_download.started) {
    g_download.started = 1;
    *paths_out = g_download.paths;
    *count_out = g_download.path_count;
    g_download.paths = NULL;
    g_download.path_count = 0;
    g_download.prepared_at = 0;
    ok = 1;
  }
  pthread_mutex_unlock(&g_download.lock);
  return ok;
}


static int
download_cancel_pending(void) {
  char **paths = NULL;
  size_t count = 0;

  pthread_mutex_lock(&g_download.lock);
  if(g_download.paths && !g_download.started) {
    paths = g_download.paths;
    count = g_download.path_count;
    g_download.paths = NULL;
    g_download.path_count = 0;
    g_download.id = 0;
    g_download.prepared_at = 0;
  }
  pthread_mutex_unlock(&g_download.lock);
  if(!paths) return 0;

  download_free_paths(paths, count);
  errno = ECANCELED;
  job_end(-1, "cancelled before download started");
  return 1;
}


struct tar_seen_entry {
  dev_t dev;
  ino_t ino;
};

struct tar_seen_set {
  struct tar_seen_entry *items;
  size_t count;
  size_t capacity;
};

static int
tar_seen_add(struct tar_seen_set *seen, const struct stat *st) {
  for(size_t i = 0; i < seen->count; i++) {
    if(seen->items[i].dev == st->st_dev &&
       seen->items[i].ino == st->st_ino) return 0;
  }
  if(seen->count == seen->capacity) {
    size_t next_capacity = seen->capacity ? seen->capacity * 2 : 128;
    struct tar_seen_entry *next = realloc(
        seen->items, next_capacity * sizeof(*next));
    if(!next) return -1;
    seen->items = next;
    seen->capacity = next_capacity;
  }
  seen->items[seen->count].dev = st->st_dev;
  seen->items[seen->count].ino = st->st_ino;
  seen->count++;
  return 1;
}


static int
download_count_path(const char *path, dev_t root_dev, unsigned depth,
                    struct tar_seen_set *seen, unsigned long long *bytes,
                    long *items) {
  struct stat st;
  if(depth > BFPILOT_FS_MAX_DEPTH) {
    errno = ELOOP;
    return -1;
  }
  if(job_cancelled()) {
    errno = ECANCELED;
    return -1;
  }
  if(lstat(path, &st) != 0) return -1;
  if(st.st_dev != root_dev) {
    bfpilot_log("download scan stopped at mount boundary path=%s root_dev=%lu child_dev=%lu",
                path, (unsigned long)root_dev, (unsigned long)st.st_dev);
    return 0;
  }
  if(S_ISREG(st.st_mode)) {
    if(st.st_size < 0 ||
       *bytes > ULLONG_MAX - (unsigned long long)st.st_size) {
      errno = EOVERFLOW;
      return -1;
    }
    *bytes += (unsigned long long)st.st_size;
    (*items)++;
    return 0;
  }
  if(!S_ISDIR(st.st_mode)) {
    if(depth == 0) {
      errno = ESTALE;
      return -1;
    }
    return 0;
  }

  int added = tar_seen_add(seen, &st);
  if(added < 0) {
    errno = ENOMEM;
    return -1;
  }
  if(added == 0) return 0;
  (*items)++;
  DIR *dir = opendir(path);
  if(!dir) return -1;
  struct stat opened;
  int dir_fd = dirfd(dir);
  if(dir_fd < 0 || fstat(dir_fd, &opened) != 0) {
    int saved_errno = errno;
    closedir(dir);
    errno = saved_errno;
    return -1;
  }
  if(opened.st_dev != st.st_dev || opened.st_ino != st.st_ino) {
    closedir(dir);
    errno = ESTALE;
    return -1;
  }

  int rc = 0;
  int saved_errno = 0;
  for(;;) {
    errno = 0;
    struct dirent *entry = readdir(dir);
    if(!entry) {
      if(errno) {
        saved_errno = errno;
        rc = -1;
      }
      break;
    }
    if(!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
    size_t need = strlen(path) + strlen(entry->d_name) + 2;
    char *child = malloc(need);
    if(!child) {
      saved_errno = ENOMEM;
      rc = -1;
      break;
    }
    snprintf(child, need, "%s%s%s", path,
             path[strlen(path) - 1] == '/' ? "" : "/", entry->d_name);
    if(download_count_path(child, root_dev, depth + 1, seen, bytes,
                           items) != 0) {
      saved_errno = errno;
      free(child);
      rc = -1;
      break;
    }
    free(child);
  }
  if(closedir(dir) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc != 0) errno = saved_errno;
  return rc;
}


static int
tar_put_number(unsigned char *field, size_t size, unsigned long long value) {
  unsigned long long max_octal = 0;
  if(size < 2) return -1;
  for(size_t i = 0; i < size - 1; i++) {
    if(max_octal > (ULLONG_MAX - 7) / 8) {
      max_octal = ULLONG_MAX;
      break;
    }
    max_octal = max_octal * 8 + 7;
  }
  memset(field, 0, size);
  if(value <= max_octal) {
    char format[20];
    snprintf(format, sizeof(format), "%%0%zullo", size - 1);
    snprintf((char *)field, size, format, value);
    return 0;
  }
  for(size_t i = 0; i < size; i++) {
    field[size - 1 - i] = (unsigned char)(value & 0xff);
    value >>= 8;
  }
  if(value != 0) return -1;
  field[0] |= 0x80;
  return 0;
}


static int
tar_split_ustar_name(const char *path, char name[100], char prefix[155]) {
  size_t length = strlen(path);
  memset(name, 0, 100);
  memset(prefix, 0, 155);
  if(length <= 100) {
    memcpy(name, path, length);
    return 0;
  }
  for(const char *slash = path + length; slash > path; slash--) {
    if(slash[-1] != '/') continue;
    size_t prefix_length = (size_t)(slash - 1 - path);
    size_t name_length = length - prefix_length - 1;
    if(prefix_length <= 155 && name_length > 0 && name_length <= 100) {
      memcpy(prefix, path, prefix_length);
      memcpy(name, slash, name_length);
      return 0;
    }
  }
  return -1;
}


static int
tar_make_header(unsigned char header[512], const char *name,
                const struct stat *st, char type, unsigned long long size) {
  char tar_name[100];
  char prefix[155];
  if(tar_split_ustar_name(name, tar_name, prefix) != 0) {
    const char *base = path_basename(name);
    size_t base_size = strlen(base);
    memset(tar_name, 0, sizeof(tar_name));
    memcpy(tar_name, base,
           base_size < sizeof(tar_name) ? base_size : sizeof(tar_name));
    memset(prefix, 0, sizeof(prefix));
  }

  memset(header, 0, 512);
  memcpy(header, tar_name, sizeof(tar_name));
  if(tar_put_number(header + 100, 8,
                    (unsigned long long)(st->st_mode & 07777)) != 0 ||
     tar_put_number(header + 108, 8, 0) != 0 ||
     tar_put_number(header + 116, 8, 0) != 0 ||
     tar_put_number(header + 124, 12, size) != 0 ||
     tar_put_number(header + 136, 12,
                    st->st_mtime > 0 ? (unsigned long long)st->st_mtime : 0) != 0) {
    errno = EOVERFLOW;
    return -1;
  }
  memset(header + 148, ' ', 8);
  header[156] = (unsigned char)type;
  memcpy(header + 257, "ustar", 5);
  header[262] = 0;
  memcpy(header + 263, "00", 2);
  memcpy(header + 345, prefix, sizeof(prefix));

  unsigned int checksum = 0;
  for(size_t i = 0; i < 512; i++) checksum += header[i];
  snprintf((char *)header + 148, 8, "%06o", checksum);
  header[154] = 0;
  header[155] = ' ';
  return 0;
}


static int
tar_send_chunk(const http_request_t *req, const void *data, size_t size) {
  if(job_cancelled()) {
    errno = ECANCELED;
    return -1;
  }
  return websrv_write_chunk(req->fd, data, size);
}


static int
tar_send_zeros(const http_request_t *req, size_t size) {
  static const unsigned char zeros[512] = {0};
  while(size > 0) {
    size_t part = size < sizeof(zeros) ? size : sizeof(zeros);
    if(tar_send_chunk(req, zeros, part) != 0) return -1;
    size -= part;
  }
  return 0;
}


static int
tar_send_header(const http_request_t *req, const char *name,
                const struct stat *st, char type, unsigned long long size) {
  unsigned char header[512];
  char fit_name[100];
  char fit_prefix[155];
  if(tar_split_ustar_name(name, fit_name, fit_prefix) != 0) {
    struct stat long_st = *st;
    const char longlink_name[] = "././@LongLink";
    size_t long_size = strlen(name) + 1;
    if(tar_make_header(header, longlink_name, &long_st, 'L',
                       (unsigned long long)long_size) != 0 ||
       tar_send_chunk(req, header, sizeof(header)) != 0 ||
       tar_send_chunk(req, name, long_size) != 0 ||
       tar_send_zeros(req, (512 - (long_size % 512)) % 512) != 0) {
      return -1;
    }
  }
  if(tar_make_header(header, name, st, type, size) != 0) return -1;
  return tar_send_chunk(req, header, sizeof(header));
}


static int
download_open_regular(const char *path, const struct stat *expected) {
  int flags = O_RDONLY;
#ifdef O_NOFOLLOW
  flags |= O_NOFOLLOW;
#endif
  int fd = open(path, flags);
  if(fd < 0) return -1;
  struct stat opened;
  if(fstat(fd, &opened) != 0) {
    int saved_errno = errno;
    close(fd);
    errno = saved_errno;
    return -1;
  }
  if(!S_ISREG(opened.st_mode) || opened.st_dev != expected->st_dev ||
     opened.st_ino != expected->st_ino) {
    close(fd);
    errno = ESTALE;
    return -1;
  }
  return fd;
}


static int
tar_stream_path(const http_request_t *req, const char *path,
                const char *archive_name, dev_t root_dev, unsigned depth,
                struct tar_seen_set *seen, unsigned char *buffer,
                size_t buffer_size) {
  struct stat st;
  if(depth > BFPILOT_FS_MAX_DEPTH) {
    errno = ELOOP;
    return -1;
  }
  if(job_cancelled()) {
    errno = ECANCELED;
    return -1;
  }
  if(lstat(path, &st) != 0) return -1;
  if(st.st_dev != root_dev) return 0;
  if(S_ISREG(st.st_mode)) {
    if(st.st_size < 0) {
      errno = EOVERFLOW;
      return -1;
    }
    if(tar_send_header(req, archive_name, &st, '0',
                       (unsigned long long)st.st_size) != 0) return -1;
    int fd = download_open_regular(path, &st);
    if(fd < 0) return -1;
    job_set_current(path);
    unsigned long long remaining = (unsigned long long)st.st_size;
    int rc = 0;
    int saved_errno = 0;
    while(remaining > 0) {
      size_t wanted = remaining < buffer_size ? (size_t)remaining : buffer_size;
      ssize_t got = read(fd, buffer, wanted);
      if(got < 0) {
        if(errno == EINTR) continue;
        saved_errno = errno;
        rc = -1;
        break;
      }
      if(got == 0) {
        saved_errno = EIO;
        rc = -1;
        break;
      }
      atomic_fetch_add(&g_job.read_bytes, (long)got);
      if(tar_send_chunk(req, buffer, (size_t)got) != 0) {
        saved_errno = errno ? errno : EPIPE;
        rc = -1;
        break;
      }
      remaining -= (unsigned long long)got;
      atomic_fetch_add(&g_job.copied_bytes, (long)got);
      atomic_fetch_add(&g_job.written_bytes, (long)got);
    }
    if(close(fd) != 0 && rc == 0) {
      saved_errno = errno;
      rc = -1;
    }
    if(rc == 0 && tar_send_zeros(req,
        (size_t)((512 - ((unsigned long long)st.st_size % 512)) % 512)) != 0) {
      saved_errno = errno ? errno : EPIPE;
      rc = -1;
    }
    if(rc == 0) atomic_fetch_add(&g_job.done_files, 1);
    if(rc != 0) errno = saved_errno;
    return rc;
  }
  if(!S_ISDIR(st.st_mode)) {
    if(depth == 0) {
      errno = ESTALE;
      return -1;
    }
    return 0;
  }

  int added = tar_seen_add(seen, &st);
  if(added < 0) {
    errno = ENOMEM;
    return -1;
  }
  if(added == 0) return 0;

  size_t name_length = strlen(archive_name);
  char *dir_name = malloc(name_length + 2);
  if(!dir_name) return -1;
  memcpy(dir_name, archive_name, name_length);
  if(name_length == 0 || archive_name[name_length - 1] != '/') {
    dir_name[name_length++] = '/';
  }
  dir_name[name_length] = 0;
  if(tar_send_header(req, dir_name, &st, '5', 0) != 0) {
    free(dir_name);
    return -1;
  }
  atomic_fetch_add(&g_job.done_files, 1);
  free(dir_name);

  DIR *dir = opendir(path);
  if(!dir) return -1;
  struct stat opened;
  int dir_fd = dirfd(dir);
  if(dir_fd < 0 || fstat(dir_fd, &opened) != 0) {
    int saved_errno = errno;
    closedir(dir);
    errno = saved_errno;
    return -1;
  }
  if(opened.st_dev != st.st_dev || opened.st_ino != st.st_ino) {
    closedir(dir);
    errno = ESTALE;
    return -1;
  }

  int rc = 0;
  int saved_errno = 0;
  for(;;) {
    errno = 0;
    struct dirent *entry = readdir(dir);
    if(!entry) {
      if(errno) {
        saved_errno = errno;
        rc = -1;
      }
      break;
    }
    if(!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
    size_t child_size = strlen(path) + strlen(entry->d_name) + 2;
    size_t name_size = strlen(archive_name) + strlen(entry->d_name) + 2;
    char *child = malloc(child_size);
    char *child_name = malloc(name_size);
    if(!child || !child_name) {
      free(child);
      free(child_name);
      saved_errno = ENOMEM;
      rc = -1;
      break;
    }
    snprintf(child, child_size, "%s%s%s", path,
             path[strlen(path) - 1] == '/' ? "" : "/", entry->d_name);
    snprintf(child_name, name_size, "%s%s%s", archive_name,
             archive_name[strlen(archive_name) - 1] == '/' ? "" : "/",
             entry->d_name);
    if(tar_stream_path(req, child, child_name, root_dev, depth + 1,
                       seen, buffer, buffer_size) != 0) {
      saved_errno = errno;
      free(child);
      free(child_name);
      rc = -1;
      break;
    }
    free(child);
    free(child_name);
  }
  if(closedir(dir) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc != 0) errno = saved_errno;
  return rc;
}


static void
download_header_filename(const char *name, char *extra, size_t extra_size) {
  static const char hex[] = "0123456789ABCDEF";
  char quoted[260];
  char encoded[780];
  size_t q = 0, e = 0;
  const unsigned char *p = (const unsigned char *)(name ? name : "download");
  while(*p && q + 1 < sizeof(quoted) && e + 3 < sizeof(encoded)) {
    unsigned char c = *p++;
    quoted[q++] = (c < 0x20 || c == 0x7f || c == '"' || c == '\\')
                    ? '_' : (char)c;
    if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
       (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_') {
      encoded[e++] = (char)c;
    } else {
      encoded[e++] = '%';
      encoded[e++] = hex[c >> 4];
      encoded[e++] = hex[c & 15];
    }
  }
  quoted[q] = 0;
  encoded[e] = 0;
  snprintf(extra, extra_size,
           "Content-Disposition: attachment; filename=\"%s\"; "
           "filename*=UTF-8''%s\r\n",
           quoted, encoded);
}


static char **
download_root_names(char **paths, size_t count) {
  char **names = calloc(count, sizeof(*names));
  if(!names) return NULL;
  for(size_t i = 0; i < count; i++) {
    const char *base = path_basename(paths[i]);
    if(!base || !base[0] || !strcmp(base, "/")) base = "root";
    size_t suffix = 1;
    char candidate[1024];
    snprintf(candidate, sizeof(candidate), "%s", base);
    for(;;) {
      int unique = 1;
      for(size_t j = 0; j < i; j++) {
        if(!strcmp(names[j], candidate)) {
          unique = 0;
          break;
        }
      }
      if(unique) break;
      suffix++;
      snprintf(candidate, sizeof(candidate), "%.*s-%lu",
               980, base, (unsigned long)suffix);
    }
    names[i] = strdup(candidate);
    if(!names[i]) {
      download_free_paths(names, i);
      return NULL;
    }
  }
  return names;
}


static int
download_stream_regular(const http_request_t *req, const char *path,
                        const struct stat *st, unsigned char *buffer,
                        size_t buffer_size) {
  char extra[1200];
  download_header_filename(path_basename(path), extra, sizeof(extra));
  websrv_conn_set_keep_alive(0);
  if(websrv_send_headers(req->fd, 200, "application/octet-stream",
                         (size_t)st->st_size, extra) != 0) return -1;
  int fd = download_open_regular(path, st);
  if(fd < 0) return -1;
  job_set_current(path);
  unsigned long long remaining = (unsigned long long)st->st_size;
  int rc = 0;
  int saved_errno = 0;
  while(remaining > 0) {
    if(job_cancelled()) {
      saved_errno = ECANCELED;
      rc = -1;
      break;
    }
    size_t wanted = remaining < buffer_size ? (size_t)remaining : buffer_size;
    ssize_t got = read(fd, buffer, wanted);
    if(got < 0) {
      if(errno == EINTR) continue;
      saved_errno = errno;
      rc = -1;
      break;
    }
    if(got == 0) {
      saved_errno = EIO;
      rc = -1;
      break;
    }
    atomic_fetch_add(&g_job.read_bytes, (long)got);
    if(websrv_write_all(req->fd, buffer, (size_t)got) != 0) {
      saved_errno = errno ? errno : EPIPE;
      rc = -1;
      break;
    }
    remaining -= (unsigned long long)got;
    atomic_fetch_add(&g_job.copied_bytes, (long)got);
    atomic_fetch_add(&g_job.written_bytes, (long)got);
  }
  if(close(fd) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc == 0) atomic_store(&g_job.done_files, 1);
  if(rc != 0) errno = saved_errno;
  return rc;
}


#include "remote_download.inc"

static int
download_stream_request(const http_request_t *req) {
  char id_text[32];
  char *end = NULL;
  char **paths = NULL;
  char **root_names = NULL;
  size_t count = 0;
  unsigned long id;
  struct stat first;
  int aligned = 0;
  unsigned char *buffer = NULL;
  int rc = -1;
  int saved_errno = 0;

  if(strcmp(req->method, "GET") != 0) {
    return serve_error(req, 405, "download requires GET");
  }
  if(!websrv_get_query_arg(req, "id", id_text, sizeof(id_text))) {
    return serve_error(req, 400, "missing download id");
  }
  errno = 0;
  id = strtoul(id_text, &end, 10);
  if(errno || !end || *end || id == 0 ||
     !download_take_request(id, &paths, &count)) {
    return serve_error(req, 404, "download request not found or already used");
  }

  buffer = alloc_aligned_io_buffer(BFPILOT_DOWNLOAD_BUF_SIZE, &aligned);
  if(!buffer) {
    saved_errno = ENOMEM;
    goto done;
  }

  for(size_t i = 0; i < count; i++) {
    if(bfpilot_smb_path(paths[i])) {
      rc = remote_download_request(req, paths, count, buffer);
      saved_errno = rc ? (errno ? errno : EIO) : 0;
      goto done;
    }
  }

  if(count == 1 && lstat(paths[0], &first) == 0 && S_ISREG(first.st_mode)) {
    if(first.st_size < 0 || (uintmax_t)first.st_size > (uintmax_t)SIZE_MAX) {
      saved_errno = EOVERFLOW;
      goto done;
    }
    atomic_store(&g_job.total_bytes, (long)first.st_size);
    atomic_store(&g_job.total_files, 1);
    rc = download_stream_regular(req, paths[0], &first, buffer,
                                 BFPILOT_DOWNLOAD_BUF_SIZE);
    saved_errno = rc == 0 ? 0 : (errno ? errno : EIO);
    goto done;
  }

  root_names = download_root_names(paths, count);
  if(!root_names) {
    saved_errno = ENOMEM;
    goto done;
  }

  {
    struct tar_seen_set count_seen = {0};
    unsigned long long total_bytes = 0;
    long total_items = 0;
    job_set_current("preparing download");
    for(size_t i = 0; i < count; i++) {
      struct stat root_st;
      if(lstat(paths[i], &root_st) != 0 ||
         download_count_path(paths[i], root_st.st_dev, 0, &count_seen,
                             &total_bytes, &total_items) != 0) {
        saved_errno = errno ? errno : EIO;
        free(count_seen.items);
        goto done;
      }
    }
    free(count_seen.items);
    if(total_bytes > (unsigned long long)LONG_MAX || total_items > INT_MAX) {
      saved_errno = EOVERFLOW;
      goto done;
    }
    atomic_store(&g_job.total_bytes, (long)total_bytes);
    atomic_store(&g_job.total_files, (int)total_items);
  }

  {
    char archive_name[320];
    char extra[1200];
    if(count == 1) {
      snprintf(archive_name, sizeof(archive_name), "%.*s.tar",
               280, root_names[0]);
    } else {
      snprintf(archive_name, sizeof(archive_name), "%s", "bfpilot-download.tar");
    }
    download_header_filename(archive_name, extra, sizeof(extra));
    websrv_conn_set_keep_alive(0);
    if(websrv_send_chunked_headers(req->fd, 200, "application/x-tar",
                                   extra) != 0) {
      saved_errno = errno ? errno : EPIPE;
      goto done;
    }

    struct tar_seen_set stream_seen = {0};
    rc = 0;
    for(size_t i = 0; i < count; i++) {
      struct stat root_st;
      if(lstat(paths[i], &root_st) != 0 ||
         tar_stream_path(req, paths[i], root_names[i], root_st.st_dev, 0,
                         &stream_seen, buffer,
                         BFPILOT_DOWNLOAD_BUF_SIZE) != 0) {
        saved_errno = errno ? errno : EIO;
        rc = -1;
        break;
      }
    }
    free(stream_seen.items);
    if(rc == 0 &&
       (tar_send_zeros(req, 1024) != 0 ||
        websrv_write_chunk_end(req->fd) != 0)) {
      saved_errno = errno ? errno : EPIPE;
      rc = -1;
    }
  }

done:
  free(buffer);
  download_free_paths(root_names, count);
  download_free_paths(paths, count);
  if(rc == 0) {
    bfpilot_log("download completed id=%lu selections=%lu aligned=%d",
                id, (unsigned long)count, aligned);
    job_end(0, NULL);
    return 0;
  }
  errno = saved_errno ? saved_errno : EIO;
  bfpilot_log("download failed id=%lu selections=%lu errno=%d aligned=%d",
              id, (unsigned long)count, errno, aligned);
  job_end(-1, errno == ECANCELED ? "download cancelled" : strerror(errno));
  return -1;
}


int
transfer_action_post_request(const http_request_t *req, const char *url,
                             const char *initial_data, size_t initial_size,
                             size_t content_size) {
  char *body = NULL;
  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_ACTION_FORM_MAX_SIZE, &body) != 0) {
    return serve_error(req, errno == EFBIG ? 413 : 500,
                       errno == EFBIG ? "action request is too large"
                                       : strerror(errno));
  }

  int rc;
  if(!strcmp(url,"/api/fs/smb/save") || !strcmp(url,"/api/fs/smb/remove")) {
    bfpilot_smb_record_t record={0};
    int valid=form_get_arg(body,"id",record.id,sizeof(record.id));
    if(!strcmp(url,"/api/fs/smb/remove"))rc=valid?bfpilot_smb_remove(record.id):-EINVAL;
    else {
      char dialect[8],encrypt[8],replace[8],allow_unsigned[8]="0";
      errno=0;
      int have_unsigned=form_get_arg(body,"allowUnsigned",allow_unsigned,sizeof(allow_unsigned));
      int optional_valid=have_unsigned||!errno;
      if(!have_unsigned)snprintf(allow_unsigned,sizeof(allow_unsigned),"0");
      valid=valid && optional_valid && form_get_arg(body,"label",record.label,sizeof(record.label)) &&
          form_get_arg(body,"server",record.server,sizeof(record.server)) &&
          form_get_arg(body,"user",record.user,sizeof(record.user)) &&
          form_get_arg(body,"domain",record.domain,sizeof(record.domain)) &&
          form_get_arg(body,"password",record.password,sizeof(record.password)) &&
          form_get_arg(body,"dialect",dialect,sizeof(dialect)) &&
          form_get_arg(body,"encrypt",encrypt,sizeof(encrypt)) &&
          form_get_arg(body,"replacePassword",replace,sizeof(replace));
      if(valid)valid=(!strcmp(dialect,"0")||!strcmp(dialect,"2")||!strcmp(dialect,"3")) &&
          (!strcmp(encrypt,"0")||!strcmp(encrypt,"1")) && (!strcmp(replace,"0")||!strcmp(replace,"1")) &&
          (!strcmp(allow_unsigned,"0")||!strcmp(allow_unsigned,"1")) &&
          !(atoi(encrypt)&&atoi(allow_unsigned));
      if(valid){record.dialect=atoi(dialect);record.encrypt=atoi(allow_unsigned)?2:atoi(encrypt);}
      rc=valid?bfpilot_smb_save(&record,atoi(replace)):-EINVAL;
    }
    free(body);memset(record.password,0,sizeof(record.password));
    if(rc)return serve_error(req,rc==-EINVAL?400:rc==-ENOENT?404:500,strerror(-rc));
    json_buf_t b={0};
    if(json_append(&b,"{\"ok\":true,\"id\":")!=0||json_string(&b,record.id)!=0||json_append(&b,"}")!=0){free(b.data);return -1;}
    return serve_owned(req,200,b.data,b.len);
  } else if(!strcmp(url, "/api/fs/copy") || !strcmp(url, "/api/fs/move")) {
    char src[1024], dst[1024], overwrite_text[16];
    if(!form_get_arg(body, "src", src, sizeof(src)) ||
       !form_get_arg(body, "dst", dst, sizeof(dst))) {
      free(body);
      return serve_error(req, 400, "bad src/dst");
    }
    int overwrite = form_get_arg(body, "overwrite", overwrite_text,
                                 sizeof(overwrite_text))
                        ? atoi(overwrite_text)
                        : 0;
    rc = spawn_copy_or_move_values(req, !strcmp(url, "/api/fs/move"),
                                   src, dst, overwrite);
  } else if(!strcmp(url, "/api/fs/delete")) {
    char path[1024], recursive_text[16];
    if(!form_get_arg(body, "path", path, sizeof(path))) {
      free(body);
      return serve_error(req, 400, "bad path");
    }
    int recursive = form_get_arg(body, "recursive", recursive_text,
                                 sizeof(recursive_text)) &&
                    strcmp(recursive_text, "0");
    rc = delete_handler_values(req, path, recursive);
  } else if(!strcmp(url, "/api/fs/chmod")) {
    char path[1024], mode_s[16], recursive_text[16];
    if(!form_get_arg(body, "path", path, sizeof(path)) ||
       !form_get_arg(body, "mode", mode_s, sizeof(mode_s))) {
      free(body);
      return serve_error(req, 400, "missing path or mode");
    }
    mode_t mode = 0;
    if(bfpilot_parse_mode_octal(mode_s, &mode) != 0) {
      free(body);
      return serve_error(req, 400, "bad mode (use octal like 444 or 755)");
    }
    char resolved[1024];
    if(path_for_list(path, resolved, sizeof(resolved)) != 0) {
      free(body);
      return serve_error(req, 404, "path not found");
    }
    int recursive = form_get_arg(body, "recursive", recursive_text, sizeof(recursive_text)) &&
                    strcmp(recursive_text, "0") != 0;
    struct stat st;
    if(lstat(resolved, &st) != 0) {
      free(body);
      return serve_error(req, 404, "path not found");
    }
    if(recursive && S_ISDIR(st.st_mode)) {
      rc = chmod_recursive_dir(resolved, mode);
    } else {
      rc = bfpilot_path_chmod(resolved, mode);
    }
    if(rc != 0) {
      char resp[256];
      snprintf(resp, sizeof(resp), "{\"ok\":false,\"error\":\"chmod failed\",\"errno\":%d}", -rc);
      free(body);
      return websrv_send_text(req->fd, rc == -EBUSY ? 409 : 500, "application/json", resp);
    }
    free(body);
    return websrv_send_text(req->fd, 200, "application/json", "{\"ok\":true}");
  } else if(!strcmp(url, "/api/fs/launch") ||
             !strcmp(url, "/api/fs/launch-elf") ||
             !strcmp(url, "/api/launch-elf")) {
    char path[1024];
    if(!form_get_arg(body, "path", path, sizeof(path))) {
      free(body);
      return serve_error(req, 400, "missing path");
    }
    rc = bfpilot_launch_payload_path(path);
    if(rc != 0) {
      char resp[256];
      snprintf(resp, sizeof(resp), "{\"ok\":false,\"error\":\"launch failed\",\"errno\":%d}", -rc);
      free(body);
      return websrv_send_text(req->fd, 500, "application/json", resp);
    }
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    char note[160];
    snprintf(note, sizeof(note), "sent %s to elfldr", base);
    bfpilot_notify("BFpilot", note);
    json_buf_t response = {0};
    int response_rc = json_appendf(&response, "{\"ok\":true,\"port\":%d,\"path\":", BFPILOT_ELFLDR_PORT);
    if(response_rc == 0) response_rc = json_string(&response, path);
    if(response_rc == 0) response_rc = json_append(&response, "}");
    free(body);
    if(response_rc != 0) {
      free(response.data);
      return serve_error(req, 500, "could not format launch response");
    }
    return serve_owned(req, 200, response.data, response.len);
  } else {
    rc = serve_error(req, 404, "no such action endpoint");
  }
  free(body);
  return rc;
}


static int
text_extension_allowed(const char *path) {
  static const char *const extensions[] = {
    ".txt", ".ini", ".json", ".xml", ".cfg", ".log", ".sh", ".bat",
    ".py", ".c", ".cpp", ".h", ".hpp", ".html", ".htm", ".css",
    ".js", ".lua", ".md", ".csv", ".yaml", ".yml", ".conf", ".sql",
    ".shn"
  };
  const char *dot = strrchr(path ? path : "", '.');
  if(!dot) return 0;
  for(size_t i = 0; i < sizeof(extensions) / sizeof(extensions[0]); i++) {
    if(!strcasecmp(dot, extensions[i])) return 1;
  }
  return 0;
}


static int
valid_utf8_text(const unsigned char *data, size_t size) {
  size_t i = 0;
  while(i < size) {
    unsigned char c = data[i];
    if(c == 0) return 0; /* The JSON encoder and textarea are text-only. */
    if(c <= 0x7f) {
      i++;
      continue;
    }

    size_t continuation;
    unsigned int value;
    unsigned int minimum;
    if((c & 0xe0) == 0xc0) {
      continuation = 1;
      value = c & 0x1f;
      minimum = 0x80;
    } else if((c & 0xf0) == 0xe0) {
      continuation = 2;
      value = c & 0x0f;
      minimum = 0x800;
    } else if((c & 0xf8) == 0xf0) {
      continuation = 3;
      value = c & 0x07;
      minimum = 0x10000;
    } else {
      return 0;
    }
    if(i + continuation >= size) return 0;
    for(size_t j = 1; j <= continuation; j++) {
      unsigned char next = data[i + j];
      if((next & 0xc0) != 0x80) return 0;
      value = (value << 6) | (next & 0x3f);
    }
    if(value < minimum || value > 0x10ffff ||
       (value >= 0xd800 && value <= 0xdfff)) {
      return 0;
    }
    i += continuation + 1;
  }
  return 1;
}


static uint64_t
text_version_hash(const unsigned char *data, size_t size) {
  uint64_t hash = UINT64_C(14695981039346656037);
  for(size_t i = 0; i < size; i++) {
    hash ^= data[i];
    hash *= UINT64_C(1099511628211);
  }
  return hash;
}


#include "remote_text.inc"

static int
read_edit_text(const char *path, char **data_out, size_t *size_out,
               mode_t *mode_out, struct stat *identity_out) {
  if(bfpilot_smb_path(path))
    return remote_text_read(path, data_out, size_out, mode_out, identity_out);
  struct stat path_st, st;
  if(lstat(path, &path_st) != 0) return -1;
  if(!S_ISREG(path_st.st_mode)) {
    errno = EINVAL;
    return -1;
  }
  int flags = O_RDONLY;
#ifdef O_NOFOLLOW
  flags |= O_NOFOLLOW;
#endif
  int fd = open(path, flags);
  if(fd < 0) return -1;
  if(fstat(fd, &st) != 0) {
    int saved_errno = errno;
    close(fd);
    errno = saved_errno;
    return -1;
  }
  if(!S_ISREG(st.st_mode)) {
    close(fd);
    errno = EINVAL;
    return -1;
  }
  if(st.st_dev != path_st.st_dev || st.st_ino != path_st.st_ino) {
    close(fd);
    errno = EAGAIN;
    return -1;
  }
  if(st.st_size < 0 || (uintmax_t)st.st_size > BFPILOT_TEXT_MAX_SIZE) {
    close(fd);
    errno = EFBIG;
    return -1;
  }

  size_t capacity = (size_t)st.st_size;
  char *data = malloc(capacity + 1);
  if(!data) {
    close(fd);
    return -1;
  }
  size_t used = 0;
  while(used < capacity) {
    ssize_t count = read(fd, data + used, capacity - used);
    if(count < 0) {
      if(errno == EINTR) continue;
      int saved_errno = errno;
      free(data);
      close(fd);
      errno = saved_errno;
      return -1;
    }
    if(count == 0) break;
    used += (size_t)count;
  }
  if(used == capacity) {
    char extra;
    ssize_t count;
    do {
      count = read(fd, &extra, 1);
    } while(count < 0 && errno == EINTR);
    if(count > 0) {
      free(data);
      close(fd);
      errno = EAGAIN;
      return -1;
    }
    if(count < 0) {
      int saved_errno = errno;
      free(data);
      close(fd);
      errno = saved_errno;
      return -1;
    }
  }
  if(close(fd) != 0) {
    int saved_errno = errno;
    free(data);
    errno = saved_errno;
    return -1;
  }
  data[used] = 0;
  *data_out = data;
  *size_out = used;
  if(mode_out) *mode_out = st.st_mode;
  if(identity_out) *identity_out = st;
  return 0;
}


static int
write_edit_text_atomic(const char *path, const char *data, size_t size,
                       mode_t mode) {
  struct timespec now;
  char temp[1152];
  if(clock_gettime(CLOCK_MONOTONIC, &now) != 0) {
    now.tv_sec = time(NULL);
    now.tv_nsec = 0;
  }
  int written = snprintf(temp, sizeof(temp), "%s.bfpilot-edit-%ld-%ld-%ld",
                         path, (long)getpid(), (long)now.tv_sec,
                         (long)now.tv_nsec);
  if(written < 0 || (size_t)written >= sizeof(temp)) {
    errno = ENAMETOOLONG;
    return -1;
  }

  int fd = open(temp, O_WRONLY | O_CREAT | O_EXCL, 0600);
  if(fd < 0) return -1;
  int rc = write_all_fd(fd, data, size);
  if(rc == 0 && fchmod(fd, mode & 07777) != 0 &&
     errno != EOPNOTSUPP && errno != EPERM && errno != EINVAL &&
     errno != EROFS) {
    rc = -1;
  }
  if(rc == 0 && fsync(fd) != 0) rc = -1;
  int saved_errno = errno;
  if(close(fd) != 0 && rc == 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc == 0 && rename(temp, path) != 0) {
    saved_errno = errno;
    rc = -1;
  }
  if(rc != 0) {
    (void)unlink(temp);
    errno = saved_errno ? saved_errno : EIO;
  }
  return rc;
}


static int
text_read_request(const http_request_t *req) {
  char path[1024];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !path_is_safe(path) || !text_extension_allowed(path)) {
    return serve_error(req, 400, "file type is not editable");
  }
  if(atomic_load(&g_job.busy) || transfer_archive_busy()) {
    return serve_error(req, 409, "another file-manager job is running");
  }

  char *data = NULL;
  size_t size = 0;
  if(read_edit_text(path, &data, &size, NULL, NULL) != 0) {
    int saved_errno = errno;
    if(saved_errno == EFBIG) return serve_error(req, 413, "text file is too large");
    if(saved_errno == ENOENT) return serve_error(req, 404, "file not found");
    if(saved_errno == EAGAIN) return serve_error(req, 409, "file changed while it was read");
    if(saved_errno == EINVAL) return serve_error(req, 400, "file type is not editable");
    return serve_error(req, 500, strerror(saved_errno));
  }
  if(!valid_utf8_text((const unsigned char *)data, size)) {
    free(data);
    return serve_error(req, 415, "file is not valid UTF-8");
  }

  char version[24];
  snprintf(version, sizeof(version), "%016llx",
           (unsigned long long)text_version_hash((const unsigned char *)data,
                                                 size));
  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"version\":") != 0 ||
     json_string(&b, version) != 0 ||
     json_appendf(&b, ",\"size\":%llu,\"text\":",
                  (unsigned long long)size) != 0 ||
     json_string(&b, data) != 0 || json_append(&b, "}") != 0) {
    free(data);
    free(b.data);
    return -1;
  }
  free(data);
  return serve_owned(req, 200, b.data, b.len);
}


int
transfer_text_create_request(const http_request_t *req,
                             const char *initial_data, size_t initial_size,
                             size_t content_size) {
  char *body = NULL;
  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_ACTION_FORM_MAX_SIZE, &body) != 0) {
    int saved_errno = errno;
    return serve_error(req, saved_errno == EFBIG ? 413 : 500,
                       saved_errno == EFBIG ? "text create request is too large"
                                            : strerror(saved_errno));
  }

  char parent[1024], name[1024], path[1024];
  if(!form_get_arg(body, "path", parent, sizeof(parent)) ||
     !form_get_arg(body, "name", name, sizeof(name)) ||
     !path_is_safe(parent) || !upload_segment_safe(name) ||
     !text_extension_allowed(name) ||
     join_path_checked(path, sizeof(path), parent, name) != 0) {
    free(body);
    return serve_error(req, 400, "bad text file path or unsupported extension");
  }
  free(body);

  if(!job_begin("edit")) {
    return serve_error(req, 409, "another file-manager job is running");
  }
  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.source, sizeof(g_job.source), "%s", path);
  snprintf(g_job.destination, sizeof(g_job.destination), "%s", path);
  pthread_mutex_unlock(&g_job.lock);

  if(bfpilot_smb_path(path)) {
    int remote_rc = remote_text_write(path, "", 0, NULL);
    if(remote_rc) {
      int error = errno;
      job_end(-1, "text create failed");
      return serve_error(req, error == EEXIST ? 409 : error == ENOENT ? 404 :
                         error == EACCES || error == EPERM || error == EROFS ? 403 : 500,
                         error == EEXIST ? "file already exists" : strerror(error));
    }
    goto text_created;
  }

  int dir_flags = O_RDONLY | O_DIRECTORY;
#ifdef O_NOFOLLOW
  dir_flags |= O_NOFOLLOW;
#endif
  int dir_fd = open(parent, dir_flags);
  if(dir_fd < 0) {
    int saved_errno = errno;
    job_end(-1, "text create parent open failed");
    errno = saved_errno;
    if(saved_errno == ENOENT) return serve_error(req, 404, "folder not found");
    if(saved_errno == EACCES || saved_errno == EPERM || saved_errno == EROFS) {
      return serve_error(req, 403, strerror(saved_errno));
    }
    return serve_error(req, 500, strerror(saved_errno));
  }

  struct stat parent_st;
  int fd = -1;
  int rc = fstat(dir_fd, &parent_st);
  if(rc == 0 && !S_ISDIR(parent_st.st_mode)) {
    errno = ENOTDIR;
    rc = -1;
  }
  if(rc == 0) {
    pthread_mutex_lock(&g_text_lock);
    fd = bfpilot_fs_openat(dir_fd, name, O_WRONLY | O_CREAT | O_EXCL, 0777);
    if(fd < 0) {
      rc = -1;
    } else {
      apply_fchmod_0777(fd);
      if(fsync(fd) != 0) rc = -1;
      if(close(fd) != 0 && rc == 0) rc = -1;
      fd = -1;
      if(rc != 0) (void)unlinkat(dir_fd, name, 0);
    }
    pthread_mutex_unlock(&g_text_lock);
  }
  int saved_errno = errno;
  if(fd >= 0) close(fd);
  close(dir_fd);

  if(rc != 0) {
    errno = saved_errno ? saved_errno : EIO;
    job_end(-1, "text create failed");
    if(errno == EEXIST) return serve_error(req, 409, "file already exists");
    if(errno == ENOENT) return serve_error(req, 404, "folder not found");
    if(errno == EACCES || errno == EPERM || errno == EROFS) {
      return serve_error(req, 403, strerror(errno));
    }
    return serve_error(req, 500, strerror(errno));
  }

text_created:;
  char version[24];
  snprintf(version, sizeof(version), "%016llx",
           (unsigned long long)text_version_hash(NULL, 0));
  bfpilot_search_mark_stale("text create");
  job_end(0, NULL);
  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, path) != 0 ||
     json_append(&b, ",\"version\":") != 0 ||
     json_string(&b, version) != 0 || json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 201, b.data, b.len);
}


static int
delete_handler(const http_request_t *req) {
  char path[1024], recursive_text[32];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path))) {
    return serve_error(req, 400, "bad path");
  }
  int recursive = websrv_get_query_arg(req, "recursive", recursive_text,
                                       sizeof(recursive_text)) &&
                  strcmp(recursive_text, "0");
  return delete_handler_values(req, path, recursive);
}


int
transfer_text_save_request(const http_request_t *req,
                           const char *initial_data, size_t initial_size,
                           size_t content_size) {
  char path[1024], expected[32];
  if(!websrv_get_query_arg(req, "path", path, sizeof(path)) ||
     !websrv_get_query_arg(req, "version", expected, sizeof(expected)) ||
     !path_is_safe(path) || !text_extension_allowed(path)) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 400, "bad text save request");
  }
  if(!job_begin("edit")) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }
  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.source, sizeof(g_job.source), "%s", path);
  snprintf(g_job.destination, sizeof(g_job.destination), "%s", path);
  pthread_mutex_unlock(&g_job.lock);

  char *body = NULL;
  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_TEXT_MAX_SIZE, &body) != 0) {
    int saved_errno = errno;
    job_end(-1, saved_errno == EFBIG ? "text file is too large"
                                     : "text request read failed");
    errno = saved_errno;
    return serve_error(req, saved_errno == EFBIG ? 413 : 500,
                       saved_errno == EFBIG ? "text file is too large"
                                            : strerror(saved_errno));
  }
  if(!valid_utf8_text((const unsigned char *)body, content_size)) {
    free(body);
    errno = EILSEQ;
    job_end(-1, "text file is not valid UTF-8");
    return serve_error(req, 415, "text file is not valid UTF-8");
  }

  pthread_mutex_lock(&g_text_lock);
  char *current = NULL;
  char *formatted = NULL;
  size_t current_size = 0;
  size_t formatted_size = 0;
  mode_t current_mode = 0;
  struct stat current_identity;
  int rc = read_edit_text(path, &current, &current_size, &current_mode, &current_identity);
  int saved_errno = errno;
  if(rc == 0) {
    char actual[24];
    snprintf(actual, sizeof(actual), "%016llx",
             (unsigned long long)text_version_hash(
                 (const unsigned char *)current, current_size));
    if(strcmp(expected, actual)) {
      rc = -2;
    } else if(bfpilot_text_prepare_save(
                  (const unsigned char *)body, content_size,
                  (const unsigned char *)current, current_size,
                  BFPILOT_TEXT_MAX_SIZE, &formatted, &formatted_size) != 0) {
      saved_errno = errno;
      rc = -1;
    } else {
      rc = bfpilot_smb_path(path)
          ? remote_text_write(path, formatted, formatted_size, &current_identity)
          : write_edit_text_atomic(path, formatted, formatted_size, current_mode);
      saved_errno = errno;
    }
  }
  free(current);
  pthread_mutex_unlock(&g_text_lock);

  if(rc == -2) {
    free(body);
    free(formatted);
    errno = EAGAIN;
    job_end(-1, "file changed since it was opened");
    return serve_error(req, 409, "file changed since it was opened; reload before saving");
  }
  if(rc != 0) {
    free(body);
    free(formatted);
    errno = saved_errno;
    job_end(-1, "text save failed");
    if(saved_errno == EFBIG) {
      return serve_error(req, 413,
                         "text file is too large after newline conversion");
    }
    if(saved_errno == ENOENT) return serve_error(req, 404, "file not found");
    if(saved_errno == EAGAIN) return serve_error(req, 409, "file changed during save; reload before saving");
    return serve_error(req, 500, strerror(saved_errno));
  }

  char version[24];
  snprintf(version, sizeof(version), "%016llx",
           (unsigned long long)text_version_hash(
               (const unsigned char *)formatted, formatted_size));
  free(body);
  free(formatted);
  bfpilot_search_mark_stale("text save");
  job_end(0, NULL);
  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"version\":") != 0 ||
     json_string(&b, version) != 0 || json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}


static int
write_text_atomic(const char *tmp_path, const char *final_path,
                  const char *data, size_t size, mode_t mode) {
  int fd = open(tmp_path, O_WRONLY | O_CREAT | O_TRUNC, mode);
  if(fd < 0) return -1;
  apply_fchmod_0777(fd);
  int rc = write_all_fd(fd, data, size);
  if(rc == 0 && fsync(fd) != 0) rc = -1;
  if(close(fd) != 0 && rc == 0) rc = -1;
  if(rc != 0) {
    unlink(tmp_path);
    return -1;
  }
  if(rename(tmp_path, final_path) != 0) {
    unlink(tmp_path);
    return -1;
  }
  return 0;
}


static unsigned
archive_normalize_threads_text(const char *threads) {
  if(!threads || !*threads) return 0;
  for(const unsigned char *p = (const unsigned char *)threads; *p; p++) {
    if(*p < '0' || *p > '9') return 0;
  }
  unsigned long value = strtoul(threads, NULL, 10);
  if(value > BFPILOT_ARCHIVE_MAX_THREADS) value = BFPILOT_ARCHIVE_MAX_THREADS;
  return (unsigned)value;
}

static int
archive_normalize_nice_text(const char *nice) {
  if(!nice || !*nice) return BFPILOT_ARCHIVE_DEFAULT_NICE;
  char *end = NULL;
  errno = 0;
  long value = strtol(nice, &end, 10);
  if(errno != 0 || end == nice || (end && *end)) {
    return BFPILOT_ARCHIVE_DEFAULT_NICE;
  }
  if(value < BFPILOT_ARCHIVE_MIN_NICE) value = BFPILOT_ARCHIVE_MIN_NICE;
  if(value > BFPILOT_ARCHIVE_MAX_NICE) value = BFPILOT_ARCHIVE_MAX_NICE;
  return (int)value;
}


static int
archive_bool_text_true(const char *value) {
  if(!value) return 0;
  return !strcmp(value, "1") ||
         !strcmp(value, "true") ||
         !strcmp(value, "yes") ||
         !strcmp(value, "on");
}


static int
archive_write_status_prepared(const char *src, const char *dst,
                              unsigned threads, int priority_nice,
                              int cleanup_partial) {
  json_buf_t b = {0};
  const char *worker = "bfpilot-integrated-archive";
  const char *current = "starting integrated archive extractor";
  const char *requires_injection = "false";
  if(json_append(&b,
                 "{\"ok\":true,\"worker\":\"") != 0 ||
     json_append(&b, worker) != 0 ||
     json_append(&b,
                 "\",\"state\":\"prepared\",\"archiveType\":\"pending\","
                 "\"source\":") != 0 ||
     json_string(&b, src) != 0 ||
     json_append(&b, ",\"destination\":") != 0 ||
     json_string(&b, dst) != 0 ||
     json_append(&b, ",\"stage\":\"\",\"current\":") != 0 ||
     json_string(&b, current) != 0 ||
     json_append(&b,
                 ",\"error\":\"\",\"percent\":0,\"totalBytes\":0,"
                 "\"bytesWritten\":0,\"filesDone\":0,\"totalFiles\":0,"
                 "\"elapsedMs\":0,\"averageMBps\":0,\"errno\":0,"
                 "\"threads\":") != 0 ||
     json_appendf(&b, "%u", threads) != 0 ||
     json_append(&b, ",\"threadMode\":\"") != 0 ||
     json_append(&b, threads == 0 ? "auto" : "manual") != 0 ||
     json_appendf(&b, "\",\"priorityNice\":%d", priority_nice) != 0 ||
     json_append(&b, ",\"cleanupPartial\":") != 0 ||
     json_append(&b, cleanup_partial ? "true" : "false") != 0 ||
     json_append(&b, ","
                 "\"requiresInjection\":") != 0 ||
     json_append(&b, requires_injection) != 0 ||
     json_append(&b, "}") != 0) {
    free(b.data);
    return -1;
  }
  int rc = write_text_atomic(BFPILOT_ARCHIVE_STATUS_TMP,
                             BFPILOT_ARCHIVE_STATUS, b.data, b.len, 0666);
  free(b.data);
  return rc;
}


static int
archive_status_handler(const http_request_t *req) {
  const char *idle_body =
      "{\"ok\":true,\"worker\":\"bfpilot-integrated-archive\","
      "\"state\":\"idle\",\"requiresInjection\":false}";
  int fd = open(BFPILOT_ARCHIVE_STATUS, O_RDONLY);
  if(fd < 0) {
    return websrv_send(req->fd, 200, "application/json",
                       idle_body, strlen(idle_body));
  }
  struct stat status_st;
  if(fstat(fd, &status_st) != 0 || !S_ISREG(status_st.st_mode) ||
     status_st.st_size < 0 || status_st.st_size > 1024 * 1024) {
    close(fd); return serve_error(req, 500, "invalid archive status file");
  }
  size_t length = (size_t)status_st.st_size;
  char *buf = malloc(length + 1);
  if(!buf) { close(fd); return serve_error(req, 500, "out of memory"); }
  size_t used = 0;
  int error = 0;
  while(used < length) {
    ssize_t got = read(fd, buf + used, length - used);
    if(got < 0 && errno == EINTR) continue;
    if(got <= 0) { error = got < 0 ? errno : EIO; break; }
    used += (size_t)got;
  }
  if(close(fd) != 0 && !error) error = errno;
  if(error) { free(buf); return serve_error(req, 500, strerror(error)); }
  ssize_t n = (ssize_t)used;
  if(n == 0) {
    free(buf);
    return websrv_send(req->fd, 200, "application/json",
                       idle_body, strlen(idle_body));
  }
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  buf[n] = 0;
  if(!strstr(buf, "\"ok\":") || !strstr(buf, "\"state\":")) {
    free(buf);
    return websrv_send(req->fd, 200, "application/json",
                       idle_body, strlen(idle_body));
  }
  /* Only the producer releases archive ownership, after it has stopped. */
#endif
  return serve_owned(req, 200, buf, (size_t)n);
}


static int
archive_support_handler(const http_request_t *req) {
  char body[4096];
  int length = snprintf(body, sizeof(body),
      "{\"ok\":true,\"worker\":\"bfpilot-integrated-archive\","
      "\"requiresInjection\":false,"
      "\"jobPath\":\"" BFPILOT_ARCHIVE_JOB "\","
      "\"statusPath\":\"" BFPILOT_ARCHIVE_STATUS "\","
      "\"supported\":[\"rar\",\"7z\",\"7z.001\",\"zip\",\"zipx\",\"tar\",\"gz\",\"bz2\",\"xz\",\"zst\",\"z\",\"lzma\",\"pmd\",\"arj\",\"cpio\",\"lzh\",\"cab\",\"xar\",\"xip\",\"001\"],"
      "\"passwords\":{\"rar\":true,\"7z\":true,"
      "\"zip\":\"ZipCrypto and AES\"},"
      "\"multipart\":{\"rar\":true,\"7z.001\":true,"
      "\"zip\":true},"
      "\"threading\":{\"default\":\"auto\",\"autoStrategy\":\"decoder-default\","
      "\"manualStrategy\":\"integrated\",\"autoMax\":0,\"integratedAutoMax\":%u,"
      "\"manualMax\":%u,\"statusField\":\"effectiveThreads\","
      "\"formats\":{\"rar\":{\"autoMax\":0,\"integratedAutoMax\":%u,\"manualMax\":%u},"
      "\"7z\":{\"autoMax\":0,\"integratedAutoMax\":%u,\"manualMax\":%u},"
      "\"zip\":{\"autoMax\":1,\"manualMax\":1}}},"
      "\"scheduling\":{\"defaultNice\":4,\"minNice\":-20,"
      "\"maxNice\":20,\"bestEffort\":true},"
      "\"options\":{\"cleanupPartial\":true},"
      "\"telemetry\":[\"inputWaitMBps\",\"outputWaitMBps\","
      "\"cpuUtilPercent\",\"rarMtThreadedBlocks\","
      "\"rarMtLargeBlocks\"],"
      "\"allowedRoots\":[\"/data\",\"/mnt/usb0-7\",\"/mnt/ext0-7\"]}",
      BFPILOT_ARCHIVE_AUTO_MAX_THREADS, BFPILOT_ARCHIVE_MAX_THREADS,
      BFPILOT_ARCHIVE_AUTO_MAX_THREADS, BFPILOT_ARCHIVE_RAR_MAX_THREADS,
      BFPILOT_ARCHIVE_AUTO_MAX_THREADS, BFPILOT_ARCHIVE_MAX_THREADS);
  if(length < 0 || (size_t)length >= sizeof(body)) return -1;
  return websrv_send(req->fd, 200, "application/json",
                     body, (size_t)length);
}


int
transfer_archive_prepare_request(const http_request_t *req,
                                 const char *initial_data,
                                 size_t initial_size,
                                 size_t content_size) {
  char *body = NULL;
  char src[1024] = {0};
  char dst[1024] = {0};
  char password[512] = {0};
  char threads[32] = {0};
  char nice[32] = {0};
  char cleanup_partial[16] = {0};
  char merge[16] = {0};

  if(atomic_load(&g_job.busy)
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
     || bfpilot_archive_batch_busy()
#endif
     ) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }

#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  int expected = 0;
  if(!atomic_compare_exchange_strong(&g_archive_busy, &expected, 1)) {
    bfpilot_log("archive prepare conflict: extraction still owns the transfer slot");
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "archive extraction is already running");
  }
  /* Close the race with job_begin claiming the regular transfer flag. */
  if(atomic_load(&g_job.busy)) {
    atomic_store(&g_archive_busy, 0);
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }
  __atomic_store_n(&g_archive_cancel, 0, __ATOMIC_RELAXED);
#endif

  if(read_request_body(req, initial_data, initial_size, content_size,
                       BFPILOT_ACTION_FORM_MAX_SIZE, &body) != 0) {
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return serve_error(req, 400, "archive prepare body is too large or invalid");
  }

  int have_src = form_get_arg(body, "src", src, sizeof(src));
  int have_dst = form_get_arg(body, "dst", dst, sizeof(dst));
  int ok = have_src && have_dst;
  if(!form_get_arg(body, "password", password, sizeof(password))) {
    password[0] = 0;
  }
  if(!form_get_arg(body, "threads", threads, sizeof(threads))) {
    snprintf(threads, sizeof(threads), "%s", "0");
  }
  if(!form_get_arg(body, "nice", nice, sizeof(nice))) {
    snprintf(nice, sizeof(nice), "%d", BFPILOT_ARCHIVE_DEFAULT_NICE);
  }
  if(!form_get_arg(body, "cleanupPartial", cleanup_partial,
                   sizeof(cleanup_partial))) {
    snprintf(cleanup_partial, sizeof(cleanup_partial), "%s", "0");
  }
  (void)form_get_arg(body,"merge",merge,sizeof(merge));
  free(body);

  if(bfpilot_smb_path(src) || bfpilot_smb_path(dst)) {
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return serve_error(req,400,bfpilot_smb_path(src)
        ? "copy the archive to local storage before extracting"
        : "extract to local storage, then copy the completed folder to SMB");
  }

  int src_allowed = archive_path_allowed(src);
  int dst_allowed = archive_path_allowed(dst);
  int src_text_ok = config_value_safe(src, 0);
  int dst_text_ok = config_value_safe(dst, 0);
  int password_text_ok = config_value_safe(password, 1);
  int threads_text_ok = config_value_safe(threads, 1);
  int nice_text_ok = config_value_safe(nice, 1);
  int cleanup_text_ok = config_value_safe(cleanup_partial, 1);
  if(!ok || !src_allowed || !dst_allowed || !src_text_ok || !dst_text_ok ||
     !password_text_ok || !threads_text_ok || !nice_text_ok ||
     !cleanup_text_ok) {
    char err[256];
    snprintf(err, sizeof(err),
             "bad archive request fields ok=%d src_allowed=%d "
             "dst_allowed=%d src_text=%d dst_text=%d password_text=%d "
             "threads_text=%d nice_text=%d cleanup_text=%d",
             ok, src_allowed, dst_allowed, src_text_ok, dst_text_ok,
             password_text_ok, threads_text_ok, nice_text_ok,
             cleanup_text_ok);
    int rc = serve_error(req, 400, err);
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }

  struct stat st;
  if(stat(src, &st) != 0 || !S_ISREG(st.st_mode)) {
    int rc = serve_error(req, 404, "archive source is not a file");
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }
  int destination_exists = lstat(dst, &st) == 0;
  int merge_enabled = archive_bool_text_true(merge);
  if(destination_exists && !(merge_enabled && S_ISDIR(st.st_mode))) {
    int rc = serve_error(req, 409, "archive destination already exists");
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }
  if(!destination_exists && errno != ENOENT) {
    int rc = serve_error(req, 500, strerror(errno));
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }

  if(mkdirs(BFPILOT_ARCHIVE_DIR) != 0) {
    int rc = serve_error(req, 500, strerror(errno));
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }

  unsigned normalized_threads = archive_normalize_threads_text(threads);
  int normalized_nice = archive_normalize_nice_text(nice);
  int cleanup_partial_enabled = archive_bool_text_true(cleanup_partial);

  /* Identical paths/options can represent a new request immediately after a
     completed extraction. Keep the daemon's durable-job deduplication unique. */
  static atomic_ullong archive_request_sequence;
  struct timespec request_time = {0};
  (void)clock_gettime(CLOCK_MONOTONIC, &request_time);
  unsigned long long request_sequence = atomic_fetch_add(&archive_request_sequence, 1);
  json_buf_t job = {0};
  if(json_append(&job, "source=") != 0 ||
     json_append(&job, src) != 0 ||
     json_append(&job, "\ndestination=") != 0 ||
     json_append(&job, dst) != 0 ||
     json_append(&job, "\npassword=") != 0 ||
     json_append(&job, password) != 0 ||
     json_append(&job, "\nthreads=") != 0 ||
     json_appendf(&job, "%u", normalized_threads) != 0 ||
     json_append(&job, "\nnice=") != 0 ||
     json_appendf(&job, "%d", normalized_nice) != 0 ||
     json_append(&job, "\ncleanupPartial=") != 0 ||
     json_append(&job, cleanup_partial_enabled ? "1" : "0") != 0 ||
     json_appendf(&job, "\nmerge=%u",merge_enabled?1:0) != 0 ||
     json_appendf(&job, "\nrequestId=%ld-%lld-%ld-%llu\n", (long)getpid(),
                  (long long)request_time.tv_sec, request_time.tv_nsec,
                  request_sequence) != 0) {
    free(job.data);
    int rc = serve_error(req, 500, "out of memory");
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }
  if(write_text_atomic(BFPILOT_ARCHIVE_JOB_TMP, BFPILOT_ARCHIVE_JOB,
                       job.data, job.len, 0600) != 0) {
    free(job.data);
    int rc = serve_error(req, 500, strerror(errno));
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }
  free(job.data);

  if(archive_write_status_prepared(src, dst, normalized_threads,
                                   normalized_nice,
                                   cleanup_partial_enabled) != 0) {
    int rc = serve_error(req, 500, strerror(errno));
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return rc;
  }

  bfpilot_log("archive prepare source=%s destination=%s password=%s threads=%u mode=%s nice=%d",
              src, dst, password[0] ? "provided" : "empty",
              normalized_threads, normalized_threads == 0 ? "auto" : "manual",
              normalized_nice);
  bfpilot_search_mark_stale("archive");

#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  bfpilot_archive_notify_prepared();
  bfpilot_log("archive integrated worker job queued");
#endif

  json_buf_t res = {0};
  if(json_append(&res,
                 "{\"ok\":true,\"worker\":\"bfpilot-integrated-archive\","
                 "\"requiresInjection\":false,\"jobPath\":") != 0 ||
     json_string(&res, BFPILOT_ARCHIVE_JOB) != 0 ||
     json_append(&res, ",\"statusPath\":") != 0 ||
     json_string(&res, BFPILOT_ARCHIVE_STATUS) != 0 ||
     json_append(&res, ",\"source\":") != 0 ||
     json_string(&res, src) != 0 ||
     json_append(&res, ",\"destination\":") != 0 ||
     json_string(&res, dst) != 0 ||
     json_appendf(&res, ",\"threads\":%u,\"threadMode\":\"%s\"",
                  normalized_threads,
                  normalized_threads == 0 ? "auto" : "manual") != 0 ||
     json_appendf(&res, ",\"priorityNice\":%d", normalized_nice) != 0 ||
     json_append(&res, ",\"cleanupPartial\":") != 0 ||
     json_append(&res, cleanup_partial_enabled ? "true" : "false") != 0 ||
     json_append(&res, ",\"next\":") != 0 ||
     json_string(&res, "archive extraction started") != 0 ||
     json_append(&res, "}") != 0) {
    free(res.data);
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
    atomic_store(&g_archive_busy, 0);
#endif
    return -1;
  }
  return serve_owned(req, 200, res.data, res.len);
}


int
transfer_archive_batch_request(const http_request_t *req, const char *initial,
                                size_t initial_size, size_t content_size) {
#if !BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  drain_body(req->fd, initial_size, content_size);
  return serve_error(req, 400, "integrated archive support is disabled");
#else
  int expected = 0;
  if(bfpilot_archive_batch_busy() || atomic_load(&g_job.busy) ||
     !atomic_compare_exchange_strong(&g_archive_busy, &expected, 1)) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }
  if(atomic_load(&g_job.busy) || bfpilot_archive_batch_busy()) {
    atomic_store(&g_archive_busy, 0);
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }
  /* Each raw FS byte can use a four-byte UTF8 private byte token, then percent
     encoding expands that token threefold. Two max-length paths per item. */
  const size_t form_limit = BFAB_MAX_ITEMS * (24U * BFAB_PATH_SIZE + 32U) + 4096U;
  char *body = NULL;
  int rc = read_request_body(req, initial, initial_size, content_size, form_limit, &body);
  int http = 400;
  const char *error = "invalid archive batch fields";
  bfab_job_t batch = {0};
  bfab_item_t *items = NULL;
  if(rc || memchr(body, 0, content_size)) goto fail;
  items = calloc(BFAB_MAX_ITEMS, sizeof(*items));
  if(!items) { error = "out of memory"; http = 500; goto fail; }
  batch.items = items; batch.state = BFAB_PREPARED; batch.revision = 1;
  batch.nice = BFPILOT_ARCHIVE_DEFAULT_NICE;
  unsigned options = 0;
  int need_destination = 0;
  for(const char *p = body; *p;) {
    const char *amp = strchr(p, '&');
    size_t length = amp ? (size_t)(amp - p) : strlen(p);
    const char *eq = memchr(p, '=', length);
    size_t key_size = eq ? (size_t)(eq - p) : length;
    char key[32], value[4097];
    if(!eq || form_component_decode(p, key_size, key, sizeof(key)) ||
       form_component_decode(eq + 1, length - key_size - 1, value, sizeof(value))) goto fail;
    if(!strcmp(key, "src") || !strcmp(key, "dst")) {
      int source = !strcmp(key, "src");
      if(batch.count >= BFAB_MAX_ITEMS || (source ? need_destination : !need_destination)) goto fail;
      (void)bfpilot_path_decode_byte_tokens(value);
      if(strlen(value) >= BFAB_PATH_SIZE || !archive_path_allowed(value) ||
         !config_value_safe(value, 0)) {
        error = bfpilot_smb_path(value) ? "copy archives to local storage before extracting" :
                "archive batch paths must be within local allowed roots";
        goto fail;
      }
      strcpy(source ? items[batch.count].source : items[batch.count].destination, value);
      need_destination = source;
      if(!source) batch.count++;
    } else {
      unsigned bit = !strcmp(key, "password") ? 1U : !strcmp(key, "threads") ? 2U :
        !strcmp(key, "nice") ? 4U : !strcmp(key, "cleanupPartial") ? 8U :
        !strcmp(key, "merge") ? 16U : 0U;
      if(!bit || (options & bit) || !config_value_safe(value, 1)) goto fail;
      options |= bit;
      if(bit == 1) {
        if(strlen(value) >= sizeof(batch.password)) goto fail;
        strcpy(batch.password, value);
      } else if(bit == 2) batch.threads = archive_normalize_threads_text(value);
      else if(bit == 4) batch.nice = archive_normalize_nice_text(value);
      else if(bit == 8 && archive_bool_text_true(value)) batch.flags |= BFAB_CLEANUP;
      else if(bit == 16 && archive_bool_text_true(value)) batch.flags |= BFAB_MERGE;
    }
    if(!amp) break;
    p = amp + 1;
  }
  if(need_destination || !batch.count) goto fail;
  struct timespec stamp;
  static atomic_ullong batch_sequence;
  if(clock_gettime(CLOCK_REALTIME, &stamp)) { http = 500; error = strerror(errno); goto fail; }
  snprintf(batch.id, sizeof(batch.id), "b%lx-%llx-%lx-%llx", (unsigned long)getpid(),
           (unsigned long long)stamp.tv_sec, (unsigned long)stamp.tv_nsec,
           atomic_fetch_add(&batch_sequence, 1));
  batch.created = (uint64_t)stamp.tv_sec;
  if(bfab_validate(&batch)) goto fail;
  for(unsigned i = 0; i < batch.count; i++) {
    struct stat st;
    if(lstat(items[i].source, &st) || !S_ISREG(st.st_mode)) {
      error = "archive source is not a regular local file"; http = 404; goto fail;
    }
    int exists=lstat(items[i].destination, &st)==0;
    if(exists && !((batch.flags&BFAB_MERGE) && S_ISDIR(st.st_mode))) {
      error = "archive destination already exists"; http = 409; goto fail;
    }
    if(!exists && errno != ENOENT) { error = strerror(errno); http = 500; goto fail; }
    for(unsigned k = 0; k < i; k++) if(!(batch.flags&BFAB_MERGE) && !strcmp(items[k].destination, items[i].destination)) {
      error = "archive batch contains duplicate destinations"; http = 409; goto fail;
    }
  }
  rc = bfpilot_archive_batch_start(&batch);
  if(rc) { error = strerror(-rc); http = rc == -EBUSY || rc == -EAGAIN ? 409 : 500; goto fail; }
  free(items); free(body);
  bfpilot_search_mark_stale("archive batch");
  char response[256];
  int n = snprintf(response, sizeof(response), "{\"ok\":true,\"id\":\"%s\",\"count\":%u}", batch.id, batch.count);
  // Acceptance is already durable; a disconnected browser cannot release it.
  return websrv_send(req->fd, 200, "application/json", response, (size_t)n);
fail:
  free(items); free(body);
  atomic_store(&g_archive_busy, 0);
  return serve_error(req, http, error);
#endif
}

static int
cancel_handler(const http_request_t *req) {
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  int batch_rc = bfpilot_archive_batch_cancel();
  if(batch_rc) return serve_error(req, 500, "archive batch cancellation could not be journaled; current extraction asked to stop");
#endif
  __atomic_store_n(&g_archive_cancel, 1, __ATOMIC_RELAXED);
  if(download_cancel_pending()) return status_handler(req);
  if(atomic_load(&g_job.busy)) {
    atomic_store(&g_job.cancel, 1);
  }
  return status_handler(req);
}


int
transfer_request(const http_request_t *req, const char *url) {
  if(!strcmp(url,"/api/fs/smb/connections"))return smb_records_request(req);
  if(!strcmp(url, "/api/fs/list")) return list_request(req);
  if(!strncmp(url, "/api/fs/search", 14) &&
     (url[14] == 0 || url[14] == '/')) {
    return bfpilot_search_request(req, url);
  }
  if(!strcmp(url, "/api/fs/stat")) return stat_request(req);
  if(!strcmp(url, "/api/fs/du")) return du_request(req);
  if(!strcmp(url, "/api/fs/places")) return places_request(req);
  if(!strcmp(url, "/api/fs/usb")) return places_request(req);
  if(!strcmp(url, "/api/fs/shortcut/add")) return shortcut_add_request(req);
  if(!strcmp(url, "/api/fs/shortcut/delete")) return shortcut_delete_request(req);
  if(!strcmp(url, "/api/fs/shortcut/rename")) return shortcut_rename_request(req);
  if(!strcmp(url, "/api/fs/copy")) return spawn_copy_or_move(req, 0);
  if(!strcmp(url, "/api/fs/move")) return spawn_copy_or_move(req, 1);
  if(!strcmp(url, "/api/fs/delete")) return delete_handler(req);
  if(!strcmp(url, "/api/fs/mkdir")) return mkdir_handler(req);
  if(!strcmp(url, "/api/fs/rename")) return rename_handler(req);
  if(!strcmp(url, "/api/fs/job/status")) return status_handler(req);
  if(!strcmp(url, "/api/fs/transfer/stats")) return transfer_stats_handler(req);
  if(!strcmp(url, "/api/fs/download")) return download_stream_request(req);
  if(!strcmp(url, "/api/fs/pkg/status")) return bfpilot_pkg_status_request(req);
  if(!strcmp(url, "/api/fs/text")) return text_read_request(req);
  if(!strcmp(url, "/api/fs/archive/status")) return archive_status_handler(req);
#if BFPILOT_ENABLE_INTEGRATED_ARCHIVE
  if(!strcmp(url, "/api/fs/archive/batch/status")) {
    char *body = NULL; size_t size = 0;
    char summary[8]={0};websrv_get_query_arg(req,"summary",summary,sizeof(summary));
    int rc = !strcmp(summary,"1") ? bfpilot_archive_batch_summary(&body,&size) :
                                   bfpilot_archive_batch_status(&body, &size);
    return rc ? serve_error(req, 500, strerror(-rc)) : serve_owned(req, 200, body, size);
  }
#endif
  if(!strcmp(url, "/api/fs/archive/support")) return archive_support_handler(req);
  if(!strcmp(url, "/api/fs/job/cancel")) return cancel_handler(req);
  if(!strcmp(url, "/api/fs/launch") ||
     !strcmp(url, "/api/fs/launch-elf") ||
     !strcmp(url, "/api/launch-elf")) return bfpilot_launch_request(req);
  if(!strcmp(url, "/api/fs/chmod")) return chmod_request(req);
  if(!strcmp(url, "/api/fs/pkg/info")) return pkg_info_request(req);
  if(!strcmp(url, "/api/fs/pkg/icon")) return pkg_icon_request(req);
  return serve_error(req, 404, "no such endpoint");
}


static int
upload_segment_safe(const char *seg) {
  if(!seg || !*seg) return 0;
  if(!strcmp(seg, ".") || !strcmp(seg, "..")) return 0;
  for(const unsigned char *p = (const unsigned char *)seg; *p; p++) {
    if(*p == '/' || *p == '\\' || *p < 0x20 || *p == 0x7f) return 0;
  }
  return 1;
}


static int
write_all_fd(int fd, const void *data, size_t size) {
  const char *p = data;
  while(size > 0) {
    ssize_t n = write(fd, p, size);
    if(n < 0) {
      if(errno == EINTR) continue;
      return -1;
    }
    if(n == 0) {
      errno = ENOSPC;
      return -1;
    }
    p += n;
    size -= (size_t)n;
  }
  return 0;
}

static int
check_free_space_for_bytes(const char *path, unsigned long long required,
                           unsigned long long *available_out,
                           unsigned long long *needed_out) {
  struct statvfs vfs;
  if(available_out) *available_out = 0;
  if(needed_out) *needed_out = 0;
  if(required == 0) return 0;
  if(statvfs(path, &vfs) != 0) return -1;

  unsigned long long block =
      vfs.f_frsize ? (unsigned long long)vfs.f_frsize
                   : (unsigned long long)vfs.f_bsize;
  unsigned long long available =
      block != 0 && vfs.f_bavail > ULLONG_MAX / block
          ? ULLONG_MAX
          : (unsigned long long)vfs.f_bavail * block;
  unsigned long long needed =
      required > ULLONG_MAX - BFPILOT_SPACE_MARGIN_BYTES
          ? ULLONG_MAX
          : required + BFPILOT_SPACE_MARGIN_BYTES;

  if(available_out) *available_out = available;
  if(needed_out) *needed_out = needed;
  return available >= needed ? 0 : 1;
}


static void
drain_body(int fd, size_t already_read, size_t content_size) {
  char buf[8192];
  size_t remaining = content_size > already_read ? content_size - already_read : 0;
  while(remaining > 0) {
    size_t want = remaining < sizeof(buf) ? remaining : sizeof(buf);
    ssize_t n = recv(fd, buf, want, 0);
    if(n < 0) {
      if(errno == EINTR) continue;
      break;
    }
    if(n == 0) break;
    remaining -= (size_t)n;
  }
}


static int
sync_writeback_checkpoint(int fd, unsigned long long *bytes_since_sync,
                          long *sync_ms, unsigned int *sync_count) {
  if(!bytes_since_sync || *bytes_since_sync < BFPILOT_WRITEBACK_SYNC_BYTES) {
    return 0;
  }
  long started = monotonic_ms();
  if(fsync(fd) != 0) return -1;
  long ended = monotonic_ms();
  if(sync_ms && ended > started) *sync_ms += ended - started;
  if(sync_count) (*sync_count)++;
  *bytes_since_sync = 0;
  atomic_fetch_add(&g_job.writeback_syncs, 1);
  return 0;
}


#include "remote_upload.inc"

int
transfer_upload_request(const http_request_t *req, const char *initial_data,
                        size_t initial_size, size_t content_size) {
  char dest[1024], fname[256], relpath[768];
  char dir[1024], final_path[1024], staging_path[1152];
  int has_relpath = 0;

  if(!websrv_get_query_arg(req, "path", dest, sizeof(dest)) ||
     !path_is_safe(dest) ||
     !websrv_get_query_arg(req, "filename", fname, sizeof(fname)) ||
     !upload_segment_safe(fname)) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 400, "bad upload target");
  }

  has_relpath = websrv_get_query_arg(req, "relpath", relpath, sizeof(relpath));
  snprintf(dir, sizeof(dir), "%s", dest);
  size_t dlen = strlen(dir);
  while(dlen > 1 && dir[dlen - 1] == '/') dir[--dlen] = 0;

  if(has_relpath && relpath[0]) {
    char tmp[768];
    snprintf(tmp, sizeof(tmp), "%s", relpath);
    char *seg = tmp;
    while(seg && *seg) {
      char *slash = strchr(seg, '/');
      if(slash) *slash = 0;
      if(*seg) {
        if(!upload_segment_safe(seg)) {
          drain_body(req->fd, initial_size, content_size);
          return serve_error(req, 400, "bad relative path");
        }
        size_t used = strlen(dir);
        if(used + strlen(seg) + 2 >= sizeof(dir)) {
          drain_body(req->fd, initial_size, content_size);
          return serve_error(req, 400, "upload path too long");
        }
        snprintf(dir + used, sizeof(dir) - used, "/%s", seg);
      }
      if(!slash) break;
      seg = slash + 1;
    }
  }

  if(join_path_checked(final_path, sizeof(final_path), dir, fname) != 0) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 400, "upload path too long");
  }
  if(bfpilot_smb_path(final_path))
    return remote_upload_request(req, dir, final_path, initial_data,
                                  initial_size, content_size);
  if(!job_begin("upload")) {
    drain_body(req->fd, initial_size, content_size);
    return serve_error(req, 409, "another file-manager job is running");
  }
  pthread_mutex_lock(&g_job.lock);
  snprintf(g_job.source, sizeof(g_job.source), "%s", fname);
  snprintf(g_job.destination, sizeof(g_job.destination), "%s", final_path);
  pthread_mutex_unlock(&g_job.lock);
  atomic_store(&g_job.total_files, 1);
  atomic_store(&g_job.total_bytes, (long)content_size);
  job_set_current(final_path);

  if(mkdirs(dir) != 0) {
    int saved_errno = errno;
    drain_body(req->fd, initial_size, content_size);
    errno = saved_errno;
    job_end(-1, "upload target creation failed");
    return serve_error(req, 500, strerror(saved_errno));
  }
  unsigned long long upload_available = 0;
  unsigned long long upload_needed = 0;
  int space_rc = check_free_space_for_bytes(
      dir, (unsigned long long)content_size, &upload_available,
      &upload_needed);
  if(space_rc != 0) {
    int saved_errno = space_rc < 0 ? errno : ENOSPC;
    drain_body(req->fd, initial_size, content_size);
    errno = saved_errno;
    job_end(-1, space_rc < 0 ? "upload statvfs failed"
                             : "not enough free space for upload");
    if(space_rc < 0) {
      return serve_error(req, 500, strerror(saved_errno));
    }
    char msg[192];
    snprintf(msg, sizeof(msg),
             "not enough free space for upload: need %llu bytes, "
             "available %llu bytes",
             upload_needed, upload_available);
    return serve_error(req, 507, msg);
  }

  if(bfpilot_stage_path(dir, "upload", staging_path, sizeof(staging_path)) != 0) {
    int error = errno;
    drain_body(req->fd, initial_size, content_size);
    errno = error; job_end(-1, "upload private staging failed");
    return serve_error(req, 500, strerror(error));
  }
  int out = open(staging_path, O_WRONLY | O_CREAT | O_EXCL, 0777);
  if(out < 0) {
    int saved_errno = errno;
    drain_body(req->fd, initial_size, content_size);
    errno = saved_errno;
    job_end(-1, "upload staging open failed");
    return serve_error(req, 500, strerror(saved_errno));
  }
  apply_fchmod_0777(out);

  /*
   * No posix_fallocate on the upload path.
   *
   * For multi‑GB bodies, fallocate on PFS can take a long time while the
   * browser is already streaming the POST body. Kernel RCVBUF fills, the
   * TCP window closes, and measured rates collapse to 1–2 MB/s (or stall).
   * Free space is already preflighted via statvfs; free-space mid-write
   * still fails cleanly. Matches v0.3.1-test6-perf8 and zftpd STOR.
   */

  int upload_buffer_aligned = 0;
  char *buf = alloc_aligned_io_buffer(UPLOAD_BUF_SIZE,
                                      &upload_buffer_aligned);
  if(!buf) {
    int saved_errno = errno ? errno : ENOMEM;
    close(out);
    drain_body(req->fd, initial_size, content_size);
    unlink(staging_path);
    errno = saved_errno;
    job_end(-1, "upload buffer allocation failed");
    return serve_error(req, 500, "out of memory");
  }

  int failed = 0;
  int failure_errno = 0;
  char err[200] = {0};
  size_t bytes = 0;
  size_t remaining = content_size;
  long started_ms = monotonic_ms();
  long recv_ms = 0;
  long write_ms = 0;
  long sync_ms = 0;
  unsigned int sync_count = 0;
  unsigned long long bytes_since_sync = 0;

  if(initial_size > remaining) initial_size = remaining;
  if(initial_size > 0) {
    long w0 = monotonic_ms();
    if(write_all_fd(out, initial_data, initial_size) != 0) {
      failed = 1;
      failure_errno = errno ? errno : EIO;
      snprintf(err, sizeof(err), "write: %s", strerror(failure_errno));
    } else {
      write_ms += monotonic_ms() - w0;
      bytes += initial_size;
      bytes_since_sync += initial_size;
      atomic_fetch_add(&g_job.read_bytes, (long)initial_size);
      atomic_fetch_add(&g_job.written_bytes, (long)initial_size);
      atomic_fetch_add(&g_job.copied_bytes, (long)initial_size);
      if(sync_writeback_checkpoint(out, &bytes_since_sync, &sync_ms,
                                   &sync_count) != 0) {
        failed = 1;
        failure_errno = errno ? errno : EIO;
        snprintf(err, sizeof(err), "fsync: %s", strerror(failure_errno));
      }
    }
    remaining -= initial_size;
  }

  /*
   * Exact zftpd PS5 STOR / ftpsrv STOR / perf8 pattern:
   *   recv(up to the configured 2 MiB) → write those bytes → recv again.
   * Do NOT use MSG_WAITALL to fill the whole buffer before writing: that
   * lengthens the no-recv window during PFS crypto and can zero-window the sender
   * (zftpd: double-buffer + small RCVBUF stalls; single-buffer after each
   * write reopens the window within one write cycle).
   */
  struct timeval tv;
  tv.tv_sec = 8;
  tv.tv_usec = 0;
  (void)setsockopt(req->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

  while(!failed && remaining > 0) {
    if(job_cancelled()) {
      failed = 1;
      failure_errno = ECANCELED;
      snprintf(err, sizeof(err), "upload cancelled");
      break;
    }
    size_t want = remaining < UPLOAD_BUF_SIZE ? remaining : UPLOAD_BUF_SIZE;
    long r0 = monotonic_ms();
    ssize_t n = recv(req->fd, buf, want, 0);
    int recv_errno = n < 0 ? errno : 0;
    long r1 = monotonic_ms();
    if(n < 0) {
      if(recv_errno == EINTR) continue;
      if((recv_errno == EAGAIN || recv_errno == EWOULDBLOCK)) {
        if(job_cancelled()) {
          failed = 1;
          failure_errno = ECANCELED;
          snprintf(err, sizeof(err), "upload cancelled");
          break;
        }
        continue;
      }
      failed = 1;
      failure_errno = recv_errno;
      snprintf(err, sizeof(err), "recv: %s", strerror(recv_errno));
      break;
    }
    if(n == 0) {
      failed = 1;
      errno = ECONNRESET;
      failure_errno = errno;
      snprintf(err, sizeof(err), "short upload");
      break;
    }
    recv_ms += r1 - r0;
    remaining -= (size_t)n;
    atomic_fetch_add(&g_job.read_bytes, (long)n);

    long w0 = monotonic_ms();
    if(write_all_fd(out, buf, (size_t)n) != 0) {
      failed = 1;
      failure_errno = errno ? errno : EIO;
      snprintf(err, sizeof(err), "write: %s", strerror(errno));
      break;
    }
    write_ms += monotonic_ms() - w0;
    bytes += (size_t)n;
    bytes_since_sync += (unsigned long long)n;
    atomic_fetch_add(&g_job.written_bytes, (long)n);
    atomic_fetch_add(&g_job.copied_bytes, (long)n);
    if(sync_writeback_checkpoint(out, &bytes_since_sync, &sync_ms,
                                 &sync_count) != 0) {
      failed = 1;
      failure_errno = errno ? errno : EIO;
      snprintf(err, sizeof(err), "fsync: %s", strerror(failure_errno));
      break;
    }
  }

  free(buf);
  if(!failed) {
    long sync_started = monotonic_ms();
    if(fsync(out) != 0) {
      failed = 1;
      failure_errno = errno ? errno : EIO;
      snprintf(err, sizeof(err), "fsync: %s", strerror(failure_errno));
    } else sync_count++;
    sync_ms += monotonic_ms() - sync_started;
  }
  int close_rc = close(out);
  if(close_rc != 0 && !failed) {
    failed = 1;
    failure_errno = errno;
    snprintf(err, sizeof(err), "close: %s", strerror(errno));
  }
  if(!failed && rename(staging_path, final_path) != 0) {
    failed = 1;
    failure_errno = errno;
    snprintf(err, sizeof(err), "rename: %s", strerror(errno));
  }
  int saved_errno = failed ? (failure_errno ? failure_errno : EIO) : 0;
  long ended_ms = monotonic_ms();
  long elapsed_ms = ended_ms > started_ms ? ended_ms - started_ms : 0;
  struct stat upload_st;
  unsigned long destination_dev =
      stat(dir, &upload_st) == 0 ? (unsigned long)upload_st.st_dev : 0;
  pthread_mutex_lock(&g_job.lock);
  g_job.destination_dev = destination_dev;
  pthread_mutex_unlock(&g_job.lock);
  pthread_mutex_lock(&g_upload.lock);
  g_upload.elapsed_ms = elapsed_ms;
  g_upload.bytes = (unsigned long)bytes;
  g_upload.destination_dev = destination_dev;
  g_upload.error_code = saved_errno;
  g_upload.recv_ms = recv_ms;
  g_upload.write_ms = write_ms;
  g_upload.sync_ms = sync_ms;
  g_upload.sync_count = sync_count;
  g_upload.buffer_aligned = upload_buffer_aligned;
  snprintf(g_upload.path, sizeof(g_upload.path), "%s", final_path);
  pthread_mutex_unlock(&g_upload.lock);
  double mbps = elapsed_ms > 0 ?
      ((double)bytes * 1000.0 / (double)elapsed_ms) / (1024.0 * 1024.0) : 0.0;
  bfpilot_log("upload end rc=%d errno=%d bytes_read=%lu bytes_written=%lu "
              "elapsed_ms=%ld average_mbps=%.2f recv_ms=%ld write_ms=%ld "
              "sync_ms=%ld sync_count=%u dst_dev=%lu buf_size=%u aligned=%d "
              "path=%s",
              failed ? -1 : 0, saved_errno, (unsigned long)bytes,
              (unsigned long)bytes, elapsed_ms, mbps, recv_ms, write_ms,
              sync_ms, sync_count, destination_dev,
              (unsigned int)UPLOAD_BUF_SIZE, upload_buffer_aligned, final_path);

  if(failed) {
    drain_body(req->fd, 0, remaining);
    unlink(staging_path);
    errno = saved_errno;
    job_end(-1, err[0] ? err : "upload failed");
    return serve_error(req, 500, err[0] ? err : "upload failed");
  }
  atomic_store(&g_job.done_files, 1);
  bfpilot_search_mark_stale("upload");
  job_end(0, NULL);

  json_buf_t b = {0};
  if(json_append(&b, "{\"ok\":true,\"path\":") != 0 ||
     json_string(&b, final_path) != 0 ||
     json_appendf(&b,
                  ",\"size\":%lu,\"elapsedMs\":%ld,\"averageMBps\":%.2f,"
                  "\"recvMs\":%ld,\"writeMs\":%ld,\"syncMs\":%ld,"
                  "\"syncCount\":%u,\"bufferAligned\":%s,"
                  "\"destinationDev\":%lu,\"bufSize\":%u,"
                  "\"pathStyle\":\"zftpd-single-buffer-stor-2m\","
                  "\"keepAliveHint\":true}",
                  (unsigned long)bytes, elapsed_ms, mbps, recv_ms, write_ms,
                  sync_ms, sync_count,
                  upload_buffer_aligned ? "true" : "false", destination_dev,
                  (unsigned int)UPLOAD_BUF_SIZE) != 0) {
    free(b.data);
    return -1;
  }
  return serve_owned(req, 200, b.data, b.len);
}
