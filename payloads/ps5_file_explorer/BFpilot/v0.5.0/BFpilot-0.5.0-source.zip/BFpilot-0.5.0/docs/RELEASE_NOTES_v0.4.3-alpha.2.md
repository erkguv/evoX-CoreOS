# BFpilot v0.4.3 Alpha 2

Changes since v0.4.0:

- Separate Media-tile installer and settings/log directory under `/data/BFpilot`.
- Payload loading, permissions, case-insensitive paths, text editing and archives.
- Safer folder operations and conflict handling, with faster copies and downloads.
- Direct target transfers alongside Copy, Move and Paste Here.
- Double-click opening, clearer selection, a layout for smaller screens and
  upload feedback that appears only while dragging files.

See the current README for setup instructions.
