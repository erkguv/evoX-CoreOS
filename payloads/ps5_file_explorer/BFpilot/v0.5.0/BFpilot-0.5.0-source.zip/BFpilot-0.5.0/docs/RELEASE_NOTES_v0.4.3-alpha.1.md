# BFpilot v0.4.3 Alpha 1

Changes since v0.4.0:

- Separate Media-tile installer and one settings/log directory under `/data/BFpilot`.
- Payload loading, permissions, case-insensitive paths, multi-selection and archives.
- Text editing, folder uploads, overwrite/merge handling and ShadowMountPlus warnings.
- Faster large-file copies and downloads, with more transfer details in the logs.
- Copy/Move/Paste, double-click opening, clearer selection and drag feedback,
  corrected empty-folder sizing and a layout that adapts to smaller screens.

See the current README for setup instructions.
