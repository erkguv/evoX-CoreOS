/** Media tile, package details, permissions and console-control checks. */
import assert from 'assert'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..')
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8')

const param = JSON.parse(read('assets-app/param.json'))
const appinst = read('src/appinst_direct.c')
const transfer = read('src/transfer.c')
const websrv = read('src/websrv_lite.c')
const pkgFileH = read('src/pkg_file.h')
const pkgFileC = read('src/pkg_file.c')
const html = read('assets/files.html')

// Media tile
assert.strictEqual(param.applicationCategoryType, 65536, 'applicationCategoryType must be 65536 (Media App)')
assert.ok(param.deeplinkUri && param.deeplinkUri.includes('5905'), 'deeplinkUri must point to BFpilot port 5905')
assert.strictEqual(param.webAppUri, undefined, 'webAppUri must be absent to prevent WebMediaApp CE-117690-4 crash')
assert.ok(fs.existsSync(path.join(root, 'assets-app/pic1.png')), 'pic1.png must exist for 1080p backdrop')

// Tile registration fallback and asset permissions
assert.ok(appinst.includes('remount_system_ex'), 'appinst_direct must implement remount_system_ex')
assert.ok(appinst.includes('Sx4TTyrQccE'), 'appinst_direct must resolve app_uninstall to purge stale app.db entries')
assert.ok(appinst.includes('sceAppInstUtilAppInstallAll(NULL)'), 'appinst_direct must have fallback to sceAppInstUtilAppInstallAll')
assert.ok(appinst.includes('chmod(app_dir, 0755)'), 'appinst_direct must set directory permissions to 0755')
assert.ok(appinst.includes('chmod(param_path, 0644)'), 'appinst_direct must set asset permissions to 0644')

// 3. PKG Info & Icon Services
assert.ok(pkgFileH.includes('bfpilot_pkg_parse_details'), 'pkg_file.h declares bfpilot_pkg_parse_details')
assert.ok(pkgFileH.includes('bfpilot_pkg_read_icon'), 'pkg_file.h declares bfpilot_pkg_read_icon')
assert.ok(transfer.includes('/api/fs/pkg/info'), 'transfer.c routes /api/fs/pkg/info')
assert.ok(transfer.includes('/api/fs/pkg/icon'), 'transfer.c routes /api/fs/pkg/icon')
assert.ok(websrv.includes('/api/fs/pkg/info'), 'websrv_lite routes list includes /api/fs/pkg/info')

// 4. CHMOD API & recursive support
assert.ok(transfer.includes('/api/fs/chmod'), 'transfer.c routes /api/fs/chmod')
assert.ok(transfer.includes('chmod_recursive_dir'), 'transfer.c implements recursive directory chmod')
assert.ok(websrv.includes('/api/fs/chmod'), 'websrv_lite POST routes handle /api/fs/chmod')

// 5. UI: PKG modal, CHMOD modal, clickable storage, mode pill
assert.ok(html.includes('id="pkg-overlay"'), 'files.html contains #pkg-overlay')
assert.ok(html.includes('id="pkg-modal-icon"'), 'files.html contains #pkg-modal-icon')
assert.ok(html.includes('id="pkg-modal-install"'), 'files.html contains #pkg-modal-install button')
assert.ok(html.includes('id="chmod-overlay"'), 'files.html contains #chmod-overlay')
assert.ok(html.includes('id="chmod-octal"'), 'files.html contains #chmod-octal input')
assert.ok(html.includes('mode-clickable'), 'files.html supports clickable mode column')
assert.ok(html.includes('storage-item-btn'), 'files.html implements clickable storage buttons')
// 6. DualSense WebCard Navigation & Square Selection
assert.ok(!html.includes('id="tv-legend-bar"'), 'files.html must NOT contain legacy #tv-legend-bar')
assert.ok(html.includes('id="controller-legend"'), 'files.html contains #controller-legend bar')
assert.ok(html.includes('btn-square'), 'files.html must contain Square selection glyph')
assert.ok(!html.includes('btn-options'), 'files.html must NOT contain Start/Options button in UI')
assert.ok(!html.includes('btn-bumper'), 'files.html must NOT contain L1/R1 bumper buttons in UI')
assert.ok(!html.includes('tv-mode'), 'files.html must NOT contain tv-mode class')
assert.ok(!html.includes('toggle-fullscreen'), 'files.html must NOT contain broken toggle-fullscreen button')
assert.ok(html.includes('activateFocusedItem'), 'files.html defines activateFocusedItem')
assert.ok(html.includes('setFocusedIndex'), 'files.html defines setFocusedIndex')
assert.ok(html.includes('toggleFocusedSelection'), 'files.html defines toggleFocusedSelection')
assert.ok(html.includes('pollGamepad'), 'files.html defines pollGamepad')
assert.ok(appinst.includes('registration v4'), 'appinst_direct marker must be updated to v4')

console.log('Package, tile and console-control checks passed')

