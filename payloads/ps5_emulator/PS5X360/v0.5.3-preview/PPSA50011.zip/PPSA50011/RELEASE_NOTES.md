# PS5X360 v0.5.3-preview — VSync pacing fix

## Changes

- Refined the game-library UI, cover-flow presentation, navigation and settings.
- Improved support for Xbox 360 ISO disc images, alongside extracted XEX games
  and GOD/STFS packages, with safer file reading and executable loading.
- Added compatibility fixes across multiple games, including loading, memory
  handling and version-matched patch selection. Compatibility still varies by title.
- Disabling emulated VSync with the automatic frame limit no longer advances
  guest video interrupts every millisecond. The automatic guest rate remains
  60 Hz with VSync either on or off, including title patches that disable VSync.
- Existing explicit frame limits retain their previous behavior. This fixes
  accidental acceleration, not GPU/CPU bottlenecks or game-specific patch bugs.
- Updated the VSync setting description in English, Portuguese and Spanish.
- The release also offers optional console AutoLog 1.0.7-preview, which
  sends session-event reports rather than uploading merely quiet active logs.
  The 1.0.6 collector retries both local FTP ports, uses CWD + LIST, and reports
  the directory failure stage instead of only a generic I/O error.

## Verification

`tools/check-vsync-pacing.py` compiles the limiter calculations from the actual
Canary source. Before the fix it reported a 1,000,000 ns interval with VSync off;
after the fix both settings and the patch override retain the 16,666,666 ns
automatic interval. Hardware gameplay speed still needs tester confirmation.

The emulator core is experimental. An FPS unlock patch does not guarantee
stable 60 FPS, and this release is not validated on all firmware versions.
