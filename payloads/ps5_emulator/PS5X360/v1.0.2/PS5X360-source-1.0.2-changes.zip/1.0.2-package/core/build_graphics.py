"""Automatic readback of small resolves over the installed Kinect guest candidate.

Base: build/kinect-guest-audit-20261017/candidate (eboot 34d0ebca..., the build on the
console since 2026-10-17). Only vulkan_command_processor.cc.o changes (auto-readback.diff
against preimage/, the tree file whose object equals the base's: TREE-CHECK-20261019.md);
every other object is taken from that candidate byte for byte.

In xbox360ps5-radv-buildenv, /ws mounted:
  python3 build/graphics-20261020/build_graphics.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
import sys

root = Path('/ws/Xbox360PS5')
here = root / 'build/graphics-20261020'
base = root / 'build/kinect-guest-audit-20261017/candidate'
tree = root / 'build/unified-20261012/tree-merged'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == record['artifacts']['eboot.bin']['sha256'], 'base candidate changed'
for name, digest in record['objects'].items():
    assert sha(base / 'obj' / name) == digest, name
assert sha(here / 'preimage/vulkan_command_processor.cc') == \
    '082ae6a0c23fcd58d604433b532dd1b99f77c240209a1506aa42ecc0dc50ae70', 'preimage changed'

CHANGED = ['vulkan_command_processor.cc']


def compile_tree(names):
    script = (root / 'build/unified-20261012/build_tree.py').read_text()
    out = here / 'core'
    if out.exists():
        shutil.rmtree(out)
    sys.argv = ['build_tree.py', str(tree), str(out), '--only', ','.join(names)]
    exec(compile(script, 'build_tree.py', 'exec'),
         {'__file__': str(root / 'build/unified-20261012/build_tree.py'), '__name__': 'graphics_build'})
    results = json.loads((out / 'result.json').read_text())
    failed = {t: r for t, r in results.items() if r['state'] == 'FAILED'}
    assert not failed, json.dumps(failed, indent=2)
    return {Path(t).name: (out / t) for t in results if Path(t).name.endswith('.o')}


out = here / 'native'
assert not (out / 'eboot.bin').exists(), 'Preserve prior output: move native/ away first'
objects = compile_tree(CHANGED)
assert set(objects) == {'vulkan_command_processor.cc.o'}, sorted(objects)
(out / 'obj').mkdir(parents=True, exist_ok=True)
for name in record['objects']:
    shutil.copy2(base / 'obj' / name, out / 'obj' / name)
for name, path in objects.items():
    shutil.copy2(path, out / 'obj' / name)

support = root / 'build/kinect-guest-audit-20261017/link-support'
subprocess.run(['bash', str(support / 'link_game.sh'), str(root), str(out)], check=True)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)

final = {n: sha(out / 'obj' / n) for n in sorted(p.name for p in (out / 'obj').glob('*.o'))}
changed = sorted(n for n, d in final.items() if record['objects'].get(n) != d)
assert changed == ['vulkan_command_processor.cc.o'], changed
source = here / 'sources/vulkan_command_processor.cc'
source.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(tree / 'src/xenia/gpu/vulkan/vulkan_command_processor.cc', source)
receipt = {
    'build_id': 'graphics-20261020-auto-readback',
    'label': 'unchanged: the base objects carry 0.6.1-dev.27',
    'base_candidate': record['candidate_id'],
    'base_native_sha256': record['artifacts']['eboot.bin']['sha256'],
    'changed_objects': changed,
    'objects': final,
    'sources': {'build/unified-20261012/tree-merged/src/xenia/gpu/vulkan/vulkan_command_processor.cc': sha(source),
                'preimage': sha(here / 'preimage/vulkan_command_processor.cc')},
    'artifacts': {n: {'sha256': sha(out / n), 'bytes': (out / n).stat().st_size}
                  for n in ('llvm-pie.elf', 'eboot.elf', 'eboot.bin')},
    'installed': False,
    'hardware': 'pending',
}
(out / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('changed:', changed)
print('PASS', receipt['artifacts']['eboot.bin'])
