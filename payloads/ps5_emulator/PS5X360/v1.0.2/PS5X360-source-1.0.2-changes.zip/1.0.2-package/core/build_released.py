"""Released-memory reads for every game, over the automatic-readback build (ac59ede3).

Changed objects: vulkan_shared_memory.cc.o (copy released ranges when the host can read them)
and memory.cc.o (new physical allocations drop GPU copies of their range).

Base: build/kinect-guest-audit-20261017/candidate (eboot 34d0ebca..., the build on the
console since 2026-10-17). Only vulkan_command_processor.cc.o changes (auto-readback.diff
against preimage/, the tree file whose object equals the base's: TREE-CHECK-20261019.md);
every other object is taken from that candidate byte for byte.

In xbox360ps5-radv-buildenv, /ws mounted:
  python3 build/graphics-20261020/build_graphics.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
import sys

root = Path('/ws/Xbox360PS5')
here = root / 'build/graphics-20261020'
base = root / 'build/graphics-20261020/native'
tree = root / 'build/unified-20261012/tree-merged'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == record['artifacts']['eboot.bin']['sha256'] == 'ac59ede36c3a32be6fd9315ab5b0b7177ca5202649062466e3395da92ed4e003', 'base changed'
for name, digest in record['objects'].items():
    assert sha(base / 'obj' / name) == digest, name
assert sha(here / 'preimage/vulkan_command_processor.cc') == \
    '082ae6a0c23fcd58d604433b532dd1b99f77c240209a1506aa42ecc0dc50ae70', 'preimage changed'

CHANGED = ['vulkan_shared_memory.cc', 'memory.cc']
# xenia/memory.cc is the console's memory.cc.o; xenia/base/memory.cc stays the archived member.
WANTED = {'vulkan_shared_memory.cc.o': '/xenia-gpu-vulkan.dir/vulkan_shared_memory.cc.o',
          'memory.cc.o': '/xenia-core.dir/memory.cc.o'}


def compile_tree(names):
    script = (root / 'build/unified-20261012/build_tree.py').read_text()
    out = here / 'core2'
    if out.exists():
        shutil.rmtree(out)
    sys.argv = ['build_tree.py', str(tree), str(out), '--only', ','.join(names)]
    exec(compile(script, 'build_tree.py', 'exec'),
         {'__file__': str(root / 'build/unified-20261012/build_tree.py'), '__name__': 'graphics_build'})
    results = json.loads((out / 'result.json').read_text())
    failed = {t: r for t, r in results.items() if r['state'] == 'FAILED'}
    assert not failed, json.dumps(failed, indent=2)
    picked = {}
    for name, suffix in WANTED.items():
        hits = [t for t in results if t.endswith(suffix)]
        assert len(hits) == 1, (name, sorted(results))
        picked[name] = out / hits[0]
    return picked


out = here / 'native2'
assert not (out / 'eboot.bin').exists(), 'Preserve prior output: move native/ away first'
objects = compile_tree(CHANGED)
assert set(objects) == set(WANTED), sorted(objects)
(out / 'obj').mkdir(parents=True, exist_ok=True)
for name in record['objects']:
    shutil.copy2(base / 'obj' / name, out / 'obj' / name)
for name, path in objects.items():
    shutil.copy2(path, out / 'obj' / name)

support = root / 'build/kinect-guest-audit-20261017/link-support'
subprocess.run(['bash', str(support / 'link_game.sh'), str(root), str(out)], check=True)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)

final = {n: sha(out / 'obj' / n) for n in sorted(p.name for p in (out / 'obj').glob('*.o'))}
changed = sorted(n for n, d in final.items() if record['objects'].get(n) != d)
assert changed == ['memory.cc.o', 'vulkan_shared_memory.cc.o'], changed
(here / 'sources').mkdir(parents=True, exist_ok=True)
for rel in ('gpu/vulkan/vulkan_shared_memory.cc', 'memory.cc'):
    shutil.copy2(tree / 'src/xenia' / rel, here / 'sources' / Path(rel).name)
receipt = {
    'build_id': 'graphics-20261020-released-memory',
    'label': 'unchanged: the base objects carry 0.6.1-dev.27',
    'base_candidate': record['build_id'],
    'base_native_sha256': record['artifacts']['eboot.bin']['sha256'],
    'console_base_native_sha256': record['base_native_sha256'],
    'changed_objects': changed,
    'objects': final,
    'sources': {'build/unified-20261012/tree-merged/src/xenia/gpu/vulkan/vulkan_shared_memory.cc':
                sha(here / 'sources/vulkan_shared_memory.cc'),
                'build/unified-20261012/tree-merged/src/xenia/memory.cc': sha(here / 'sources/memory.cc'),
                'preimages': {n: sha(here / 'preimage' / n) for n in ('vulkan_shared_memory.cc', 'memory.cc')}},
    'artifacts': {n: {'sha256': sha(out / n), 'bytes': (out / n).stat().st_size}
                  for n in ('llvm-pie.elf', 'eboot.elf', 'eboot.bin')},
    'installed': False,
    'hardware': 'pending',
}
(out / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('changed:', changed)
print('PASS', receipt['artifacts']['eboot.bin'])
