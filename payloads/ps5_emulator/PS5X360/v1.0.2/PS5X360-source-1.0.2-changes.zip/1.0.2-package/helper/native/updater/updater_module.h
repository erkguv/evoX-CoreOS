// SPDX-License-Identifier: MIT
// The PS5X360 Updater as a module of the PS5X360 Helper (native/autolog/helper_update.c builds updater.c with
// UPD_MODULE defined). The flow, rules and switches are the standalone updater's (README.md); the difference is
// that a release ready while PS5X360 is open is kept staged ("pending") instead of waited for: the Helper calls
// upd_module_install_pending() every few seconds and it is installed once PS5X360 is closed, eboot.bin last.
// All calls come from one thread of the Helper.
#pragma once
#include <stddef.h>

enum {
  UPD_DONE = 0,        // up to date, installed, check-only, no-update: nothing waits
  UPD_FAILED = 1,      // a step failed (notified)
  UPD_BUSY = 3,        // another copy of the updater holds updater/lock
  UPD_PENDING = 4,     // a checked release is staged and waits for PS5X360 to close
  UPD_NET_FAILED = 5,  // GitHub could not be reached (notified unless the check was quiet)
};

// The installation folder (updater/test-root may redirect it); 0 when the state folder could be made.
int upd_module_init(const char *install_root);
// One update check, as one run of the standalone updater. quiet: no notification when GitHub is unreachable.
int upd_module_check(int quiet);
// Installs the staged release when PS5X360 is closed. UPD_PENDING while it is open; UPD_DONE when nothing waits.
int upd_module_install_pending(void);
// The tag of the staged release waiting for PS5X360 to close, or "" (returns 0 then).
int upd_module_pending(char *tag, size_t size);
// Number of releases this process has installed (the Helper restarts the Kinect tracker after one).
unsigned upd_module_installs(void);
// What the last check or install did, one line for helper/status.txt.
const char *upd_module_outcome(void);
// PS5X360 open: its sandbox folder has app0.
int upd_module_emulator_running(void);
// The console is set to Portuguese.
int upd_module_lang_pt(void);

// Supplied by the Helper: one process-wide lock around every HTTPS request (the collector takes it too).
void upd_net_lock(void);
void upd_net_unlock(void);
