// SPDX-License-Identifier: MIT
// PS5X360 Helper 1.2.0: paths, the helper log, notifications (Portuguese on a Portuguese console, English
// otherwise), request files and PPSA50011/helper/status.txt. Shared by the update and Kinect threads.
#pragma once
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include "mbedtls/sha256.h"
#include "../updater/updater_module.h"

#ifndef ROOT
#define ROOT "/data/homebrew/PPSA50011"
#endif
#define HELPER_VERSION "1.2.0"
#define HELPER_NAME "PS5X360 Helper " HELPER_VERSION
#define HELPER_DIR ROOT "/helper"
#define HELPER_STATUS HELPER_DIR "/status.txt"
#define HELPER_KINECT_STATE HELPER_DIR "/kinect-state.txt"
#define HELPER_KINECT_REQUEST HELPER_DIR "/kinect-request"
#define HELPER_UPDATE_REQUEST HELPER_DIR "/request-update"
#define HELPER_LOCK HELPER_DIR "/helper.lock"
#define HELPER_LOG HELPER_DIR "/helper.log"
#define HELPER_TEST_EXIT HELPER_DIR "/test-exit"

// Durations are written in milliseconds; host tests divide them by HELPER_TIME_DIV to run faster.
#ifndef HELPER_TIME_DIV
#define HELPER_TIME_DIV 1
#endif
#define HMS(ms) ((int64_t)(ms) / HELPER_TIME_DIV)

#ifdef PS5
extern int sceKernelSendNotificationRequest(int, void*, size_t, int);
#endif

static pthread_mutex_t helper_mutex = PTHREAD_MUTEX_INITIALIZER;
// One Mbed TLS/PSA state serves the whole payload: the updater and the collector take turns for HTTPS.
static pthread_mutex_t helper_net_mutex = PTHREAD_MUTEX_INITIALIZER;
void upd_net_lock(void) { pthread_mutex_lock(&helper_net_mutex); }
void upd_net_unlock(void) { pthread_mutex_unlock(&helper_net_mutex); }
#define HELPER_NET_LOCK_DEFINED 1

static volatile int helper_quit;  // host tests only (helper/test-exit)
static int helper_pt;

static struct {
  int resident;
  long long started, changed;
  char update[300], pending[64], logger[160], kinect[200];
  unsigned installs;  // releases installed by this process (read by the Kinect thread)
} helper_state = {0, 0, 0, "not checked yet", "none", "starting", "starting", 0};

static int64_t helper_ms(void) {
  struct timespec t;
  if (clock_gettime(CLOCK_MONOTONIC, &t)) return 0;
  return (int64_t)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}
static void helper_sleep_ms(int64_t ms) {
  if (ms <= 0) return;
  struct timespec t = {(time_t)(ms / 1000), (long)(ms % 1000) * 1000000L};
  while (nanosleep(&t, &t) && errno == EINTR) {}
}
#ifdef HELPER_TEST
static int helper_should_quit(void) { if (!access(HELPER_TEST_EXIT, F_OK)) helper_quit = 1; return helper_quit; }
#else
static int helper_should_quit(void) { return helper_quit; }
#endif

static int helper_write_atomic(const char* path, const char* text) {
  char temp[600];
  snprintf(temp, sizeof(temp), "%s.%d.tmp", path, (int)getpid());
  int fd = open(temp, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd < 0) return -1;
  size_t length = strlen(text);
  int ok = write(fd, text, length) == (ssize_t)length;
  if (fsync(fd)) ok = 0;
  if (close(fd)) ok = 0;
  if (!ok || rename(temp, path)) { unlink(temp); return -1; }
  return 0;
}

// helper/helper.log: what the Helper decided and why. Started again beside helper.log.old past 512 KiB.
static void helper_log(const char* format, ...) {
  char line[700];
  time_t now = time(NULL);
  struct tm utc;
  int n = gmtime_r(&now, &utc) ? (int)strftime(line, 32, "%Y-%m-%d %H:%M:%S ", &utc) : 0;
  va_list ap;
  va_start(ap, format);
  int m = vsnprintf(line + n, sizeof(line) - (size_t)n - 1, format, ap);
  va_end(ap);
  if (m < 0) return;
  n += m;
  if (n > (int)sizeof(line) - 2) n = (int)sizeof(line) - 2;
  line[n++] = '\n';
  pthread_mutex_lock(&helper_mutex);
  int fd = open(HELPER_LOG, O_WRONLY | O_CREAT | O_APPEND, 0644);
  if (fd >= 0) {
    off_t size = lseek(fd, 0, SEEK_END);
    if (size > 512 * 1024) {
      close(fd);
      rename(HELPER_LOG, HELPER_LOG ".old");
      fd = open(HELPER_LOG, O_WRONLY | O_CREAT | O_APPEND, 0644);
    }
    if (fd >= 0) { if (write(fd, line, (size_t)n) < 0) {} close(fd); }
  }
#ifndef PS5
  fwrite(line, 1, (size_t)n, stdout);
  fflush(stdout);
#endif
  pthread_mutex_unlock(&helper_mutex);
}

static void helper_notify(const char* english, const char* portuguese) {
  const char* text = helper_pt ? portuguese : english;
  helper_log("notice: %s", text);
#ifdef PS5
  static unsigned char request[3120];
  pthread_mutex_lock(&helper_mutex);
  memset(request, 0, sizeof(request));
  for (int i = 0; i < 4; i++) request[0x10 + i] = 0xff;  // target_id -1: plain text notification
  snprintf((char*)request + 45, 1024, "%s", text);
  sceKernelSendNotificationRequest(0, request, sizeof(request), 0);
  pthread_mutex_unlock(&helper_mutex);
#endif
}

// Callers hold helper_mutex.
static void helper_status_write_locked(void) {
  char text[1400];
  snprintf(text, sizeof(text),
           "helper=" HELPER_NAME "\npid=%d\nresident=%s\nstarted=%lld\nlast_change=%lld\nupdate=%s\n"
           "update_pending=%s\nlogger=%s\nkinect=%s\n",
           (int)getpid(), helper_state.resident ? "yes" : "no", helper_state.started, helper_state.changed,
           helper_state.update, helper_state.pending, helper_state.logger, helper_state.kinect);
  helper_write_atomic(HELPER_STATUS, text);
}
static void helper_status_set(char* field, size_t size, const char* value) {
  pthread_mutex_lock(&helper_mutex);
  if (strncmp(field, value, size - 1)) {
    snprintf(field, size, "%s", value);
    for (char* c = field; *c; c++) if (*c == '\n' || *c == '\r') *c = ' ';
    helper_state.changed = (long long)time(NULL);
    if (helper_state.resident) helper_status_write_locked();
  }
  pthread_mutex_unlock(&helper_mutex);
}

// A request file is taken by renaming it away first, so it acts once even if reading it fails.
// out gets its first word in lower case. 1 when a request was there.
static int helper_take_request(const char* path, char* out, size_t size) {
  char taken[600];
  snprintf(taken, sizeof(taken), "%s.taken", path);
  if (rename(path, taken)) return 0;
  char text[128] = "";
  int fd = open(taken, O_RDONLY | O_NOFOLLOW | O_NONBLOCK);
  ssize_t n = fd >= 0 ? read(fd, text, sizeof(text) - 1) : -1;
  if (fd >= 0) close(fd);
  unlink(taken);
  text[n > 0 ? n : 0] = 0;
  const char* word = text;
  while (*word && isspace((unsigned char)*word)) word++;
  size_t used = 0;
  while (word[used] && !isspace((unsigned char)word[used]) && used + 1 < size) {
    out[used] = (char)tolower((unsigned char)word[used]);
    used++;
  }
  out[used] = 0;
  return 1;
}

static int helper_file_sha256(const char* path, char out[65]) {
  int fd = open(path, O_RDONLY | O_NOFOLLOW);
  if (fd < 0) return -1;
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  mbedtls_sha256_starts(&sha, 0);
  static unsigned char buffer[1 << 15];  // the Kinect thread only
  ssize_t n;
  while ((n = read(fd, buffer, sizeof(buffer))) > 0) mbedtls_sha256_update(&sha, buffer, (size_t)n);
  close(fd);
  unsigned char digest[32];
  mbedtls_sha256_finish(&sha, digest);
  mbedtls_sha256_free(&sha);
  if (n < 0) return -1;
  for (int i = 0; i < 32; i++) snprintf(out + 2 * i, 3, "%02x", digest[i]);
  return 0;
}
static void helper_bytes_sha256(const void* data, size_t size, char out[65]) {
  unsigned char digest[32];
  mbedtls_sha256((const unsigned char*)data, size, digest, 0);
  for (int i = 0; i < 32; i++) snprintf(out + 2 * i, 3, "%02x", digest[i]);
}
