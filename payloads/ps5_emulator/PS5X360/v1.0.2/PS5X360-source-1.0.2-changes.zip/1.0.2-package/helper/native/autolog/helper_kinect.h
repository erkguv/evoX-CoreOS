// SPDX-License-Identifier: MIT
// PS5X360 Helper: the Kinect link. One thread keeps the standalone tracker (tools/kinect-tracker.elf, submitted
// to the local ELF loader) running for this boot:
// * starts it when the Helper loads, unless PPSA50011/no-kinect-start exists (that marker stops every automatic
//   start; it never stops a running tracker; explicit requests still act);
// * when it has gone (relay port 9301 free for a while, no stop asked) starts it again with a growing wait and at
//   most KINECT_CAP automatic restarts an hour; never while a start is in flight or another tracker owns the port;
// * acts on PPSA50011/helper/kinect-request (start | stop | restart | calibrate), consuming it;
// * after an update replaced tools/kinect-tracker.elf with different bytes, restarts it once PS5X360 is closed;
// * writes PPSA50011/helper/kinect-state.txt (key=value) whenever something there changes.
// It only probes the relay port by bind: it never connects to it (the relay serves one data client).
#pragma once
#include "tool_kinect.h"

#ifndef KINECT_TICK_MS
#define KINECT_TICK_MS 1000           // one look a second: a bind probe, a rename attempt, a stat-free log check
#endif
#define KINECT_GONE_MS 5000           // relay port free this long after running: the tracker has gone
#define KINECT_START_GRACE_MS 20000   // after a submission: time for the tracker to open the relay port
#define KINECT_STOP_WAIT_MS 20000     // after a stop file: time before the state says it has not left yet
#define KINECT_STABLE_MS 600000       // running this long: the next restart waits the shortest time again
#define KINECT_RETRY_MS 300000        // a missing or rejected tracker file is looked at again after this
#define KINECT_BUSY_RETRY_MS 5000     // launch lock held elsewhere, cooldown: look again after this
#define KINECT_CAP 5                  // automatic restarts in any hour
#define KINECT_CAP_WINDOW_MS 3600000
static const int64_t kinect_backoff_ms[] = {10000, 30000, 60000, 120000, 300000};

enum kinect_tracker { KT_STARTING, KT_RUNNING, KT_STOPPED, KT_FAILED, KT_DISABLED };
static const char* const kinect_tracker_names[] = {"starting", "running", "stopped", "failed", "disabled"};

static struct {
  enum kinect_tracker tracker;
  int relay;                 // 1 busy, 0 free, -1 the probe failed
  const char* camera;        // present, absent, unknown (from the tracker log's camera lines)
  char sha[65];              // SHA-256 of the tracker bytes submitted (or of the file, if found running)
  int restarts;              // automatic restarts this boot
  char reason[220];
  int want;                  // 1: keep it running; 0 after a stop
  int stopping;              // our stop file is out; waiting for the relay port to free
  int start_after_stop;      // a restart: start once the old tracker has left
  int update_restart;        // an update changed the tracker bytes
  int calibrate_on_running;  // the load-time start asks for one calibration, as the 1.1 Tool did
  int cap_said;
  int retry_kind;            // launch lock busy or cooldown: the launch kind to try again at next_try
  int64_t free_since, launched_at, running_since, next_try, stop_since;
  int step;                  // backoff step
  int64_t restart_at[KINECT_CAP];
  unsigned installs_seen;
  char deferred[16];         // stop/restart/calibrate received while a start was in flight
  long long log_offset;      // tracker log bytes already read
  char written[700];         // kinect-state.txt body last written (without last_change)
} ks;

static void kinect_reason(const char* format, ...) {
  va_list ap;
  va_start(ap, format);
  vsnprintf(ks.reason, sizeof(ks.reason), format, ap);
  va_end(ap);
  for (char* c = ks.reason; *c; c++) if (*c == '\n' || *c == '\r') *c = ' ';
}

static void kinect_publish(void) {
  char body[700], text[760], summary[200];
  const char* relay = ks.relay > 0 ? "busy" : ks.relay == 0 ? "free" : "unknown";
  snprintf(body, sizeof(body), "tracker=%s\ncamera=%s\nrelay=%s\ntracker_sha256=%s\nrestarts=%d\nreason=%s\n",
           kinect_tracker_names[ks.tracker], ks.camera, relay, ks.sha[0] ? ks.sha : "unknown", ks.restarts,
           ks.reason);
  if (!strcmp(body, ks.written)) return;
  snprintf(ks.written, sizeof(ks.written), "%s", body);
  long long now = (long long)time(NULL);
  // Same key order as the state file's documentation: last_change before reason.
  char* reason = strstr(body, "reason=");
  snprintf(text, sizeof(text), "%.*slast_change=%lld\n%s", (int)(reason - body), body, now, reason);
  helper_write_atomic(HELPER_KINECT_STATE, text);
  snprintf(summary, sizeof(summary), "tracker %s, camera %s, relay %s, restarts %d", kinect_tracker_names[ks.tracker],
           ks.camera, relay, ks.restarts);
  helper_status_set(helper_state.kinect, sizeof(helper_state.kinect), summary);
  helper_log("kinect: tracker=%s camera=%s relay=%s restarts=%d: %s", kinect_tracker_names[ks.tracker], ks.camera,
             relay, ks.restarts, ks.reason);
}

// The camera from the tracker's log (it is rewritten at each tracker start). Only new complete lines are read.
static void kinect_camera_line(const char* line) {
  if (!strncmp(line, "KTRACKER ", 9) || !strcmp(line, "stopping") || !strcmp(line, "exit")) ks.camera = "unknown";
  else if (!strncmp(line, "camera not found", 16)) ks.camera = "absent";
  else if (!strncmp(line, "camera busy", 11)) ks.camera = "present";
  else if (!strncmp(line, "camera ", 7) && strstr(line, " opened read/write")) ks.camera = "present";
  else if (!strncmp(line, "camera ", 7) && strstr(line, " is gone")) ks.camera = "absent";
}
static void kinect_camera(void) {
  // No tracker: the next one rewrites its log from the top, so read it again from the start.
  if (ks.relay <= 0) { ks.camera = "unknown"; ks.log_offset = 0; return; }
  int fd = open(TOOL_TRACKER_LOG, O_RDONLY | O_NOFOLLOW | O_NONBLOCK);
  if (fd < 0) return;
  off_t size = lseek(fd, 0, SEEK_END);
  if (size < ks.log_offset) { ks.log_offset = 0; ks.camera = "unknown"; }  // a new tracker started its log
  if (size <= ks.log_offset) { close(fd); return; }
  static char text[256 * 1024 + 1];
  long long from = ks.log_offset;
  if (size - from > (off_t)(sizeof(text) - 1)) from = (long long)size - (long long)(sizeof(text) - 1);
  ssize_t n = pread(fd, text, (size_t)(size - from), (off_t)from);
  close(fd);
  if (n <= 0) return;
  text[n] = 0;
  char* end = strrchr(text, '\n');
  if (!end) return;  // no complete line yet
  *end = 0;
  ks.log_offset = from + (end - text) + 1;
  for (char* line = text; line;) {
    char* next = strchr(line, '\n');
    if (next) *next++ = 0;
    kinect_camera_line(line);
    line = next;
  }
}

static int64_t kinect_backoff(void) {
  int i = ks.step < (int)(sizeof(kinect_backoff_ms) / sizeof(kinect_backoff_ms[0]))
              ? ks.step : (int)(sizeof(kinect_backoff_ms) / sizeof(kinect_backoff_ms[0])) - 1;
  ks.step++;
  return HMS(kinect_backoff_ms[i]);
}
static int kinect_recent_restarts(int64_t now, int64_t* oldest) {
  int count = 0;
  *oldest = INT64_MAX;
  for (int i = 0; i < KINECT_CAP; i++)
    if (ks.restart_at[i] && now - ks.restart_at[i] < HMS(KINECT_CAP_WINDOW_MS)) {
      count++;
      if (ks.restart_at[i] < *oldest) *oldest = ks.restart_at[i];
    }
  return count;
}
static void kinect_count_restart(int64_t now) {
  int slot = 0;
  for (int i = 1; i < KINECT_CAP; i++) if (ks.restart_at[i] < ks.restart_at[slot]) slot = i;
  ks.restart_at[slot] = now ? now : 1;
  ks.restarts++;
}

// A tracker was submitted and has not opened the relay port yet (it would remove a stop file on start).
static int kinect_in_flight(void) { return ks.tracker == KT_STARTING && !ks.retry_kind && ks.relay != 1; }

// kind: 0 asked for (a request or an update; no cooldown), 1 the load-time start, 2 an automatic restart.
static void kinect_launch(int kind, const char* why) {
  int64_t now = tool_millis();
  char sha[65];
  ks.retry_kind = 0;
  enum tool_result result = tool_launch(kind != 0, sha);
  tool_status(result, TOOL_CAL_NONE);
  int submitted = result == TOOL_STARTED || result == TOOL_UNCONFIRMED || result == TOOL_SEND_FAILED;
  if (submitted) {
    ks.launched_at = now;
    snprintf(ks.sha, sizeof(ks.sha), "%s", sha);
    if (kind == 2) kinect_count_restart(now);
  }
  switch (result) {
    case TOOL_STARTED:
      ks.tracker = KT_RUNNING;
      ks.running_since = now;
      kinect_reason("started by the Helper (%s)", why);
      break;
    case TOOL_UNCONFIRMED:
      ks.tracker = KT_STARTING;
      kinect_reason("submitted (%s); waiting for the tracker to open the relay port", why);
      break;
    case TOOL_PRESENT:
      ks.tracker = KT_RUNNING;
      ks.running_since = now;
      kinect_reason("relay port already open: another tracker runs (identity unverified)");
      break;
    case TOOL_BUSY:
    case TOOL_COOLDOWN:  // nothing submitted: try the same launch again shortly
      ks.tracker = KT_STARTING;
      ks.retry_kind = kind ? kind : -1;
      ks.next_try = now + HMS(KINECT_BUSY_RETRY_MS);
      kinect_reason("%s (%s); trying again shortly", tool_result_text(result), why);
      break;
    case TOOL_MISSING:
    case TOOL_INVALID:
    case TOOL_SELF:
      ks.tracker = KT_FAILED;
      ks.next_try = now + HMS(KINECT_RETRY_MS);
      kinect_reason("%s", tool_result_text(result));
      break;
    default:  // loader down, transfer cut, storage
      ks.tracker = KT_FAILED;
      ks.next_try = now + kinect_backoff();
      kinect_reason("%s (stage %s, errno %d)", tool_result_text(result), tool_stage, tool_error);
      break;
  }
  if (kind == 2 && submitted)
    helper_notify("PS5X360 Helper: Kinect tracker restarted", "PS5X360 Helper: rastreador do Kinect reiniciado");
}

static void kinect_stop(int then_start, const char* why) {
  int fd = open(TOOL_STOP_TRIGGER, O_WRONLY | O_CREAT | O_NOFOLLOW | O_NONBLOCK, 0644);
  if (fd < 0) { kinect_reason("%s: the stop file could not be written (errno %d)", why, errno); return; }
  const char body[] = "PS5X360 Helper\n";
  if (write(fd, body, sizeof(body) - 1) < 0) {}
  close(fd);
  ks.stopping = 1;
  ks.start_after_stop = then_start;
  ks.stop_since = tool_millis();
  kinect_reason("%s: waiting for the tracker to leave", why);
}

// The load-time request (as the 1.1 Tool made) is only logged; a requested one also becomes the state's reason.
static void kinect_calibrate(const char* why, int as_reason) {
  enum tool_calibration c = tool_request_calibration(TOOL_PRESENT);
  char text[160];
  if (c == TOOL_CAL_REQUESTED) snprintf(text, sizeof(text), "calibration requested (%s); the tracker does it with the camera on", why);
  else if (c == TOOL_CAL_PENDING) snprintf(text, sizeof(text), "a calibration request is already waiting for the tracker");
  else snprintf(text, sizeof(text), "the calibration file could not be written (errno %d)", errno);
  if (as_reason) kinect_reason("%s", text);
  else helper_log("kinect: %s", text);
}

static void kinect_request(const char* request) {
  int deferrable = !strcmp(request, "stop") || !strcmp(request, "restart") || !strcmp(request, "calibrate");
  if (kinect_in_flight() && deferrable) {  // the starting tracker would remove a stop file: act once it has settled
    snprintf(ks.deferred, sizeof(ks.deferred), "%s", request);
    helper_log("kinect: '%s' waits for the start in flight", request);
    return;
  }
  helper_log("kinect: request '%s'", request);
  if (!strcmp(request, "start")) {
    ks.want = 1;
    ks.step = 0;
    if (ks.relay == 1) kinect_reason("start requested: already running");
    else if (kinect_in_flight()) kinect_reason("start requested: a start is in flight");
    else kinect_launch(0, "start requested");
  } else if (!strcmp(request, "stop")) {
    ks.want = 0;
    ks.update_restart = 0;
    ks.retry_kind = 0;
    if (ks.relay == 1) kinect_stop(0, "stop requested");
    else { ks.tracker = KT_STOPPED; kinect_reason("stop requested (it was not running)"); }
  } else if (!strcmp(request, "restart")) {
    ks.want = 1;
    ks.step = 0;
    if (ks.relay == 1) kinect_stop(1, "restart requested");
    else kinect_launch(0, "restart requested");
  } else if (!strcmp(request, "calibrate")) {
    if (ks.relay == 1) kinect_calibrate("requested", 1);
    else kinect_reason("calibration needs a running tracker");
  } else {
    kinect_reason("unknown request '%.32s' ignored (start, stop, restart, calibrate)", request);
  }
}

static void kinect_tick(int first) {
  int64_t now = tool_millis();
  int relay = tool_relay_occupied();
  if (relay != -1 || ks.relay != 1) ks.relay = relay;  // a failed probe does not hide a running tracker
  if (relay == 1) ks.free_since = -1;
  else if (relay == 0 && ks.free_since < 0) ks.free_since = now;
  int automatic = access(ROOT "/no-kinect-start", F_OK) != 0;

  if (first) {
    helper_file_sha256(TOOL_HELPER, ks.sha);
    if (relay == 1) {
      ks.tracker = KT_RUNNING;
      ks.running_since = now;
      kinect_reason("already running when the Helper started (identity unverified)");
      kinect_calibrate("at load", 0);
    } else if (!automatic) {
      ks.tracker = KT_DISABLED;
      kinect_reason("no-kinect-start is set: no automatic start");
    } else {
      ks.calibrate_on_running = 1;
      kinect_launch(1, "start at load");
    }
    kinect_camera();
    kinect_publish();
    return;
  }

  // Requests: one at a time; a stop/restart/calibrate waits while a submitted tracker is still starting.
  char request[16];
  if (ks.deferred[0] && !kinect_in_flight()) {
    snprintf(request, sizeof(request), "%s", ks.deferred);
    ks.deferred[0] = 0;
    kinect_request(request);
  } else if (!ks.deferred[0] && !ks.stopping && helper_take_request(HELPER_KINECT_REQUEST, request, sizeof(request))) {
    kinect_request(request);
  }

  // An update installed by this Helper: did it change the tracker's bytes?
  pthread_mutex_lock(&helper_mutex);
  unsigned installs = helper_state.installs;
  pthread_mutex_unlock(&helper_mutex);
  if (installs != ks.installs_seen) {
    ks.installs_seen = installs;
    char sha[65] = "";
    if (!helper_file_sha256(TOOL_HELPER, sha) && strcmp(sha, ks.sha)) {
      ks.update_restart = 1;
      helper_log("kinect: the update replaced the tracker (%.16s -> %.16s)", ks.sha[0] ? ks.sha : "unknown", sha);
    }
  }

  if (ks.stopping) {  // our stop file is out
    if (relay == 0) {
      ks.stopping = 0;
      if (ks.start_after_stop) {
        ks.start_after_stop = 0;
        kinect_launch(0, ks.update_restart ? "restart after the update" : "restart");
        ks.update_restart = 0;
      } else {
        ks.tracker = KT_STOPPED;
        kinect_reason("stopped on request");
      }
    } else if (now - ks.stop_since > HMS(KINECT_STOP_WAIT_MS) && !strstr(ks.reason, "has not left")) {
      kinect_reason("stop file written %lld s ago; the tracker has not left yet",
                    (long long)((now - ks.stop_since) / 1000));
    }
    kinect_camera();
    kinect_publish();
    return;
  }

  // What the relay port says.
  if (relay == 1) {
    if (ks.tracker != KT_RUNNING) {
      int ours = ks.launched_at >= 0 && now - ks.launched_at < HMS(KINECT_START_GRACE_MS) + 2 * HMS(KINECT_TICK_MS);
      ks.tracker = KT_RUNNING;
      ks.running_since = now;
      ks.retry_kind = 0;
      if (ours) kinect_reason("started by the Helper");
      else kinect_reason("relay port open (tracker identity unverified)");
    }
    if (ks.calibrate_on_running) { ks.calibrate_on_running = 0; kinect_calibrate("at load", 0); }
    if (now - ks.running_since > HMS(KINECT_STABLE_MS)) ks.step = 0;
  } else if (relay == 0 && ks.tracker == KT_RUNNING && now - ks.free_since >= HMS(KINECT_GONE_MS)) {
    if (!access(TOOL_STOP_TRIGGER, F_OK)) {
      ks.want = 0;  // someone else asked it to stop: no restart until a start is asked for
      ks.tracker = KT_STOPPED;
      kinect_reason("stopped by " TOOL_STOP_TRIGGER);
    } else {
      ks.tracker = KT_FAILED;
      ks.next_try = now + kinect_backoff();
      kinect_reason("the tracker left (relay port free); next try in %lld s", (long long)((ks.next_try - now) / 1000));
    }
  } else if (relay == 0 && ks.tracker == KT_STARTING) {
    if (ks.retry_kind && now >= ks.next_try) {
      kinect_launch(ks.retry_kind > 0 ? ks.retry_kind : 0, "trying again");
    } else if (!ks.retry_kind && now - ks.launched_at >= HMS(KINECT_START_GRACE_MS)) {
      ks.tracker = KT_FAILED;
      ks.next_try = now + kinect_backoff();
      kinect_reason("the tracker did not open the relay port; next try in %lld s",
                    (long long)((ks.next_try - now) / 1000));
    }
  }

  // An update replaced the tracker: restart it with the new bytes, once PS5X360 is closed.
  if (ks.update_restart && !kinect_in_flight()) {
    if (!ks.want) {
      ks.update_restart = 0;  // the new bytes start whenever a start is asked for
    } else if (relay == 1) {
      if (!upd_module_emulator_running()) {
        ks.step = 0;
        kinect_stop(1, "the update replaced the tracker; restarting it");
      } else if (!strstr(ks.reason, "once PS5X360 is closed")) {
        kinect_reason("the update replaced the tracker: it restarts once PS5X360 is closed");
      }
    } else if (relay == 0 && ks.tracker != KT_STARTING) {
      ks.update_restart = 0;
      ks.step = 0;
      kinect_launch(0, "the update replaced the tracker");
    }
  }

  // Gone or never started: an automatic start, unless no-kinect-start, a stop, or the hourly limit says no.
  if (relay == 0 && !ks.stopping && ks.want && (ks.tracker == KT_FAILED || ks.tracker == KT_DISABLED) &&
      now >= ks.next_try) {
    if (!automatic) {
      if (ks.tracker != KT_DISABLED) {
        ks.tracker = KT_DISABLED;
        kinect_reason("no-kinect-start is set: no automatic start");
      }
    } else if (ks.tracker == KT_DISABLED) {
      kinect_launch(1, "no-kinect-start was removed");
    } else {
      int64_t oldest;
      if (kinect_recent_restarts(now, &oldest) >= KINECT_CAP) {
        ks.next_try = oldest + HMS(KINECT_CAP_WINDOW_MS);
        kinect_reason("restart limit reached (%d an hour); next try in %lld s", KINECT_CAP,
                      (long long)((ks.next_try - now) / 1000));
        if (!ks.cap_said) {
          ks.cap_said = 1;
          helper_notify("PS5X360 Helper: the Kinect tracker keeps closing; restarts paused for a while",
                        "PS5X360 Helper: o rastreador do Kinect continua fechando; reinÃ­cios pausados por um tempo");
        }
      } else {
        ks.cap_said = 0;
        kinect_launch(2, "automatic restart");
      }
    }
  }
  kinect_camera();
  kinect_publish();
}

static void* kinect_worker(void* unused) {
  (void)unused;
  ks.camera = "unknown";
  ks.relay = -1;
  ks.want = 1;
  ks.free_since = ks.launched_at = -1;
  ks.next_try = 0;
  pthread_mutex_lock(&helper_mutex);
  ks.installs_seen = helper_state.installs;
  pthread_mutex_unlock(&helper_mutex);
  kinect_tick(1);
  while (!helper_should_quit()) {
    helper_sleep_ms(HMS(KINECT_TICK_MS) > 0 ? HMS(KINECT_TICK_MS) : 1);
    kinect_tick(0);
  }
  return NULL;
}
