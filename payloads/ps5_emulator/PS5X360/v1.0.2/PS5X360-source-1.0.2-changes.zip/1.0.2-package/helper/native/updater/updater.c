// SPDX-License-Identifier: MIT
// PS5X360 Updater: an ordinary PS5 payload (send it with the ELF loader). Each time it runs it asks GitHub for
// the latest PS5X360 release; when that is newer than the installed build it downloads PPSA50011.zip, checks the
// size and SHA-256 GitHub publishes for it, unpacks it beside the installation checking every file, and puts the
// files in place once PS5X360 is closed, eboot.bin last.
//
// Rules (state in /data/homebrew/PPSA50011/updater):
// * Nothing is deleted from the installation. A replaced file that differs from the new one is kept in
//   backup/<previous version>/ (the two newest backups stay).
// * A settings file (.conf, .toml, .ini, assets/presets.txt) the user changed (it matches neither the previous
//   build's MANIFEST.json nor the new one) stays; the new copy is written beside it as <name>.new.
// * A cut half-way (power, crash) is finished on the next run from the checked files in stage/.
// * Switches (empty files in the state folder): no-update (do nothing), force (install the latest release even
//   when it is not newer; used once), check-only (download and check, install nothing), beta (also test releases).
//   updater/test-root holding a folder path with "test" in it installs there instead (console tests).
// Built with UPD_MODULE (native/autolog/helper_update.c) it is a module of the PS5X360 Helper instead of a payload
// of its own: see updater_module.h. The standalone payload is unchanged.
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <arpa/inet.h>
#include <sys/param.h>
#ifdef PS5
#include <sys/mount.h>
#else
#include <sys/vfs.h>
#endif
#include <sys/file.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "mbedtls/sha256.h"

#include "updater_module.h"
#ifdef UPD_MODULE
#define UPD_NO_HARDWARE_POLL 1  // the collector in the same payload defines mbedtls_hardware_poll
#define UPD_NET_LOCK() upd_net_lock()
#define UPD_NET_UNLOCK() upd_net_unlock()
#endif
#include "https.h"
#include "inflate.h"
#include "json_min.h"
#include "version.h"

#define REPO "BrinooTk/PS5X360"
#define ASSET "PPSA50011.zip"
#define PREFIX "PPSA50011/"
#define UPDATER_VERSION "1.0.0"

static char root[512] = "/data/homebrew/PPSA50011", state[600], sandbox[256] = "/mnt/sandbox";
static int lang_pt;
static FILE *logfile;
static int wait_limit = 20 * 60;  // seconds to wait for PS5X360 to close
static int close_grace = 3;       // seconds after PS5X360 closes before the first file moves
static int defer_install;         // module: a release ready while PS5X360 is open stays staged (pending)
static int quiet_network;         // module: no notification when GitHub cannot be reached
static int network_failed;        // the last check could not reach GitHub
static unsigned installs;         // releases this process installed
static char outcome[300] = "not checked yet";
static struct {
  char tag[64], previous[64], zip[700];
  int force;
} pending;
#ifndef PS5
static int stop_after;  // host tests: leave after this many placed files, as a power cut would
#endif

// ---- messages, log, notifications ----

static void say(const char *format, ...) {
  char line[1024];
  va_list ap;
  va_start(ap, format);
  vsnprintf(line, sizeof(line), format, ap);
  va_end(ap);
  char stamp[32];
  const time_t now = time(NULL);
  strftime(stamp, sizeof(stamp), "%Y-%m-%d %H:%M:%S", gmtime(&now));
  if (logfile) { fprintf(logfile, "%s %s\n", stamp, line); fflush(logfile); }
#ifndef PS5
  printf("%s\n", line);
#endif
}

#ifdef PS5
int sceKernelSendNotificationRequest(int, void *, size_t, int);
int sceSystemServiceParamGetInt(int, int *);
#endif
static void notify(const char *text) {
  say("notice: %s", text);
#ifdef PS5
  static unsigned char request[3120];
  memset(request, 0, sizeof(request));
  for (int i = 0; i < 4; i++) request[0x10 + i] = 0xff;
  snprintf((char *)request + 45, 1024, "%s", text);
  sceKernelSendNotificationRequest(0, request, sizeof(request), 0);
#endif
}
// English, or Portuguese on a console set to Portuguese.
#define T(en, pt) (lang_pt ? (pt) : (en))
static void set_outcome(const char *format, ...) {
  va_list ap;
  va_start(ap, format);
  vsnprintf(outcome, sizeof(outcome), format, ap);
  va_end(ap);
  for (char *c = outcome; *c; ++c)
    if (*c == '\n' || *c == '\r') *c = ' ';
}

// ---- files ----

static int mkdirs(const char *path) {
  char p[1024];
  snprintf(p, sizeof(p), "%s", path);
  for (char *s = p + 1; *s; ++s)
    if (*s == '/') { *s = 0; mkdir(p, 0777); *s = '/'; }
  return mkdir(p, 0777) && errno != EEXIST ? -1 : 0;
}
static int mkparents(const char *path) {
  char p[1024];
  snprintf(p, sizeof(p), "%s", path);
  char *slash = strrchr(p, '/');
  if (!slash) return 0;
  *slash = 0;
  return mkdirs(p);
}
static int exists(const char *path) { struct stat st; return !stat(path, &st); }
static int flag(const char *name) { char p[700]; snprintf(p, sizeof(p), "%s/%s", state, name); return exists(p); }

static char *read_file(const char *path, size_t *size, size_t limit) {
  FILE *f = fopen(path, "rb");
  if (!f) return NULL;
  char *data = NULL;
  size_t used = 0, capacity = 0;
  for (;;) {
    if (used + 65536 + 1 > capacity) {
      capacity = capacity ? capacity * 2 : 131072;
      if (capacity > limit + 65536 + 1) capacity = limit + 65536 + 1;
      char *grown = (char *)realloc(data, capacity);
      if (!grown) { free(data); fclose(f); return NULL; }
      data = grown;
    }
    const size_t n = fread(data + used, 1, capacity - used - 1, f);
    used += n;
    if (!n || used > limit) break;
  }
  fclose(f);
  if (used > limit) { free(data); return NULL; }
  data[used] = 0;
  if (size) *size = used;
  return data;
}

static int write_file(const char *path, const void *data, size_t size) {
  char tmp[1100];
  snprintf(tmp, sizeof(tmp), "%s.tmp", path);
  mkparents(path);
  const int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  if (fd < 0) return -1;
  const int ok = write(fd, data, size) == (ssize_t)size && !fsync(fd);
  close(fd);
  if (!ok || rename(tmp, path)) { unlink(tmp); return -1; }
  return 0;
}

static void hex(const unsigned char *digest, char out[65]) {
  for (int i = 0; i < 32; ++i) snprintf(out + i * 2, 3, "%02x", digest[i]);
}

static int file_sha256(const char *path, char out[65]) {
  const int fd = open(path, O_RDONLY);
  if (fd < 0) return -1;
  mbedtls_sha256_context sha;
  mbedtls_sha256_init(&sha);
  mbedtls_sha256_starts(&sha, 0);
  static unsigned char buf[1 << 16];
  ssize_t n;
  while ((n = read(fd, buf, sizeof(buf))) > 0) mbedtls_sha256_update(&sha, buf, (size_t)n);
  close(fd);
  unsigned char digest[32];
  mbedtls_sha256_finish(&sha, digest);
  mbedtls_sha256_free(&sha);
  if (n < 0) return -1;
  hex(digest, out);
  return 0;
}

static int remove_tree(const char *path) {
  struct stat st;
  if (lstat(path, &st)) return 0;
  if (!S_ISDIR(st.st_mode)) return unlink(path);
  DIR *d = opendir(path);
  if (d) {
    struct dirent *e;
    while ((e = readdir(d))) {
      if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      char child[1100];
      snprintf(child, sizeof(child), "%s/%s", path, e->d_name);
      remove_tree(child);
    }
    closedir(d);
  }
  return rmdir(path);
}

// Moves src over dst on the same drive; copies when rename cannot (another drive).
static int move_file(const char *src, const char *dst) {
  mkparents(dst);
  if (!rename(src, dst)) return 0;
  if (errno != EXDEV) return -1;
  char tmp[1100];
  snprintf(tmp, sizeof(tmp), "%s.tmp", dst);
  const int in = open(src, O_RDONLY), out = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  int ok = in >= 0 && out >= 0;
  static char buf[1 << 16];
  ssize_t n;
  while (ok && (n = read(in, buf, sizeof(buf))) > 0) ok = write(out, buf, (size_t)n) == n;
  if (out >= 0) { ok = ok && !fsync(out); close(out); }
  if (in >= 0) close(in);
  if (!ok || rename(tmp, dst)) { unlink(tmp); return -1; }
  unlink(src);
  return 0;
}

// ---- PS5X360 running? A running app has app0 in its sandbox folder (a closed one can leave "data" only). ----

static int emulator_running(void) {
  DIR *d = opendir(sandbox);
  if (!d) return 0;
  struct dirent *e;
  int running = 0;
  while (!running && (e = readdir(d))) {
    if (strncmp(e->d_name, "PPSA50011", 9)) continue;
    char p[600];
    snprintf(p, sizeof(p), "%s/%s/app0", sandbox, e->d_name);
    running = exists(p);
  }
  closedir(d);
  return running;
}

// ---- the release on GitHub ----

typedef struct {
  char tag[64];
  char url[512];
  char sha256[65];
  long long size;
  char *notes;
} release;

typedef struct {
  char *data;
  size_t used, capacity, limit;
} memory_sink;

static int memory_data(void *ctx, const uint8_t *data, size_t size) {
  memory_sink *m = (memory_sink *)ctx;
  if (m->used + size + 1 > m->limit) return -1;
  if (m->used + size + 1 > m->capacity) {
    size_t capacity = m->capacity ? m->capacity : 65536;
    while (capacity < m->used + size + 1) capacity *= 2;
    char *grown = (char *)realloc(m->data, capacity);
    if (!grown) return -1;
    m->data = grown;
    m->capacity = capacity;
  }
  memcpy(m->data + m->used, data, size);
  m->used += size;
  m->data[m->used] = 0;
  return 0;
}

static int read_release(const jm_doc *d, int r, release *out) {
  if (jm_string_of(d, jm_get(d, r, "tag_name"), out->tag, sizeof(out->tag))) return -1;
  const int assets = jm_get(d, r, "assets");
  for (int i = 0;; ++i) {
    const int a = jm_at(d, assets, i);
    if (a < 0) break;
    if (!jm_equals(d, jm_get(d, a, "name"), ASSET)) continue;
    char digest[80] = "";
    out->size = jm_number(d, jm_get(d, a, "size"));
    jm_string_of(d, jm_get(d, a, "digest"), digest, sizeof(digest));
    if (jm_string_of(d, jm_get(d, a, "browser_download_url"), out->url, sizeof(out->url))) return -1;
    if (strncmp(digest, "sha256:", 7) || strlen(digest) != 71) return -2;  // no published checksum: refuse
    snprintf(out->sha256, sizeof(out->sha256), "%s", digest + 7);
    const int body = jm_get(d, r, "body");
    if (body >= 0) {
      const size_t n = (size_t)(d->tokens[body].end - d->tokens[body].start) + 1;
      out->notes = (char *)malloc(n);
      if (out->notes && jm_string_of(d, body, out->notes, n)) { free(out->notes); out->notes = NULL; }
    }
    return 0;
  }
  return -3;  // this release has no PPSA50011.zip
}

static int latest_release(int beta, release *out, char *error, size_t error_size) {
  memset(out, 0, sizeof(*out));
  memory_sink m = {NULL, 0, 0, 4u << 20};
  const upd_sink sink = {NULL, memory_data, &m};
  const char *url = beta ? "https://api.github.com/repos/" REPO "/releases?per_page=10"
                         : "https://api.github.com/repos/" REPO "/releases/latest";
  const int status = upd_get(url, "application/vnd.github+json", &sink, error, error_size);
  if (status != 200) { network_failed = 1; free(m.data); return -1; }
  jm_doc d;
  int r = -1;
  if (jm_parse(&d, m.data, (int)m.used)) {
    snprintf(error, error_size, "GitHub's answer could not be read");
  } else if (!beta) {
    r = read_release(&d, 0, out);
  } else {
    for (int i = 0; r && jm_at(&d, 0, i) >= 0; ++i) {
      const int item = jm_at(&d, 0, i);
      if (jm_true(&d, jm_get(&d, item, "draft"))) continue;
      r = read_release(&d, item, out);
    }
  }
  if (r == -2) snprintf(error, error_size, "release %s has no published SHA-256 for " ASSET, out->tag);
  else if (r == -3) snprintf(error, error_size, "release %s has no " ASSET, out->tag);
  else if (r) snprintf(error, error_size, "no release found");
  jm_free(&d);
  free(m.data);
  return r ? -1 : 0;
}

// ---- download ----

typedef struct {
  int fd;
  mbedtls_sha256_context sha;
  long long got, expected;
  int next_tenth;
  const char *tag;
} file_sink;

static int file_length(void *ctx, long long length) {
  file_sink *f = (file_sink *)ctx;
  if (length >= 0 && length != f->expected) return -1;
  return 0;
}
static int file_data(void *ctx, const uint8_t *data, size_t size) {
  file_sink *f = (file_sink *)ctx;
  if (f->got + (long long)size > f->expected) return -1;
  if (write(f->fd, data, size) != (ssize_t)size) return -1;
  mbedtls_sha256_update(&f->sha, data, size);
  f->got += (long long)size;
  const int tenth = (int)(f->got * 10 / (f->expected ? f->expected : 1));
  if (tenth >= f->next_tenth) {
    if (tenth == 5) {
      char text[160];
      snprintf(text, sizeof(text), T("PS5X360 %s: downloading, 50%%", "PS5X360 %s: baixando, 50%%"), f->tag);
      notify(text);
    }
    say("download %d%%", tenth * 10);
    f->next_tenth = tenth + 1;
  }
  return 0;
}

static int download(const release *r, const char *path, char *error, size_t error_size) {
  char checked[700];
  snprintf(checked, sizeof(checked), "%s.checked", path);
  char digest[65];
  if (exists(checked) && !file_sha256(path, digest) && !strcmp(digest, r->sha256)) {
    say("%s already downloaded and checked", path);
    return 0;
  }
  mkparents(path);
  char part[700];
  snprintf(part, sizeof(part), "%s.part", path);
  file_sink f;
  memset(&f, 0, sizeof(f));
  f.fd = open(part, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  if (f.fd < 0) { snprintf(error, error_size, "cannot write %s (%d)", part, errno); return -1; }
  f.expected = r->size;
  f.tag = r->tag;
  mbedtls_sha256_init(&f.sha);
  mbedtls_sha256_starts(&f.sha, 0);
  const upd_sink sink = {file_length, file_data, &f};
  const int status = upd_get(r->url, "application/octet-stream", &sink, error, error_size);
  unsigned char raw[32];
  mbedtls_sha256_finish(&f.sha, raw);
  mbedtls_sha256_free(&f.sha);
  const int synced = !fsync(f.fd);
  close(f.fd);
  hex(raw, digest);
  if (status != 200 || !synced) { unlink(part); return -1; }
  if (f.got != r->size) { snprintf(error, error_size, "size %lld, GitHub says %lld", f.got, r->size); unlink(part); return -1; }
  if (strcmp(digest, r->sha256)) { snprintf(error, error_size, "SHA-256 %s, GitHub says %s", digest, r->sha256); unlink(part); return -1; }
  if (rename(part, path)) { snprintf(error, error_size, "rename %d", errno); return -1; }
  write_file(checked, digest, 64);
  say("downloaded %lld bytes, SHA-256 %s matches", f.got, digest);
  return 0;
}

// ---- zip ----

typedef struct {
  char name[512];  // path inside PPSA50011/
  int method;
  uint32_t crc, compressed, size, offset;
} zip_entry;

static uint32_t crc_table[256];
static void crc_init(void) {
  for (uint32_t i = 0; i < 256; ++i) {
    uint32_t c = i;
    for (int k = 0; k < 8; ++k) c = c & 1 ? 0xedb88320u ^ (c >> 1) : c >> 1;
    crc_table[i] = c;
  }
}
static uint32_t crc_update(uint32_t crc, const uint8_t *p, size_t n) {
  crc = ~crc;
  while (n--) crc = crc_table[(crc ^ *p++) & 0xff] ^ (crc >> 8);
  return ~crc;
}

static uint16_t le16(const uint8_t *p) { return (uint16_t)(p[0] | p[1] << 8); }
static uint32_t le32(const uint8_t *p) { return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24; }

// A name the installation may take: inside PPSA50011/, relative, no "..", no backslash, no empty part.
static int safe_name(const char *name) {
  if (!*name || name[0] == '/' || strchr(name, '\\') || strchr(name, ':')) return 0;
  for (const char *p = name; *p;) {
    const char *slash = strchr(p, '/');
    const size_t n = slash ? (size_t)(slash - p) : strlen(p);
    if (n == 0 || (n == 1 && p[0] == '.') || (n == 2 && p[0] == '.' && p[1] == '.')) return 0;
    if (!slash) break;
    p = slash + 1;
  }
  return 1;
}

static zip_entry *zip_list(int fd, int *count, uint64_t *total, char *error, size_t error_size) {
  struct stat st;
  if (fstat(fd, &st) || st.st_size < 22) { snprintf(error, error_size, "zip too small"); return NULL; }
  const size_t tail = st.st_size < 65557 ? (size_t)st.st_size : 65557;
  uint8_t *end = (uint8_t *)malloc(tail);
  if (!end || pread(fd, end, tail, st.st_size - (off_t)tail) != (ssize_t)tail) { free(end); return NULL; }
  long at = -1;
  for (long i = (long)tail - 22; i >= 0; --i)
    if (le32(end + i) == 0x06054b50) { at = i; break; }
  if (at < 0) { free(end); snprintf(error, error_size, "zip directory not found"); return NULL; }
  const int entries = le16(end + at + 10);
  const uint32_t dir_size = le32(end + at + 12), dir_offset = le32(end + at + 16);
  free(end);
  if (dir_offset == 0xffffffffu || entries == 0xffff || (off_t)dir_offset + dir_size > st.st_size) {
    snprintf(error, error_size, "zip directory unsupported");
    return NULL;
  }
  uint8_t *dir = (uint8_t *)malloc(dir_size);
  zip_entry *list = (zip_entry *)calloc((size_t)entries, sizeof(zip_entry));
  if (!dir || !list || pread(fd, dir, dir_size, dir_offset) != (ssize_t)dir_size) { free(dir); free(list); return NULL; }
  int n = 0;
  *total = 0;
  uint32_t p = 0;
  for (int record = 0; record < entries; ++record) {
    if (p + 46 > dir_size || le32(dir + p) != 0x02014b50) { snprintf(error, error_size, "zip directory damaged"); goto bad; }
    const int flags = le16(dir + p + 8), method = le16(dir + p + 10);
    const uint32_t crc = le32(dir + p + 16), compressed = le32(dir + p + 20), size = le32(dir + p + 24);
    const int name_len = le16(dir + p + 28), extra = le16(dir + p + 30), comment = le16(dir + p + 32);
    const uint32_t offset = le32(dir + p + 42);
    if (p + 46 + (uint32_t)name_len > dir_size) { snprintf(error, error_size, "zip directory damaged"); goto bad; }
    char name[600];
    if (name_len >= (int)sizeof(name)) { snprintf(error, error_size, "zip name too long"); goto bad; }
    memcpy(name, dir + p + 46, (size_t)name_len);
    name[name_len] = 0;
    p += 46 + (uint32_t)name_len + (uint32_t)extra + (uint32_t)comment;
    if (name_len && name[name_len - 1] == '/') continue;  // folders come with their files
    if (strncmp(name, PREFIX, strlen(PREFIX)) || !safe_name(name + strlen(PREFIX))) {
      snprintf(error, error_size, "zip holds a file outside " PREFIX ": %.200s", name);
      goto bad;
    }
    if ((flags & 1) || (method != 0 && method != 8) || size > (512u << 20) || compressed == 0xffffffffu) {
      snprintf(error, error_size, "zip entry not supported: %.200s", name);
      goto bad;
    }
    zip_entry *e = &list[n++];
    snprintf(e->name, sizeof(e->name), "%s", name + strlen(PREFIX));
    e->method = method;
    e->crc = crc;
    e->compressed = compressed;
    e->size = size;
    e->offset = offset;
    *total += size;
  }
  free(dir);
  *count = n;
  return list;
bad:
  free(dir);
  free(list);
  return NULL;
}

typedef struct {
  int fd;
  off_t at, end;
} zip_reader;
static int zip_read(void *ctx, uint8_t *buf, size_t size) {
  zip_reader *r = (zip_reader *)ctx;
  if (r->at >= r->end) return 0;
  if ((off_t)size > r->end - r->at) size = (size_t)(r->end - r->at);
  const ssize_t n = pread(r->fd, buf, size, r->at);
  if (n <= 0) return -1;
  r->at += n;
  return (int)n;
}

typedef struct {
  int fd;
  uint32_t crc;
  uint64_t size;
  mbedtls_sha256_context sha;
} entry_out;
static int entry_write(void *ctx, const uint8_t *data, size_t size) {
  entry_out *o = (entry_out *)ctx;
  if (write(o->fd, data, size) != (ssize_t)size) return -1;
  o->crc = crc_update(o->crc, data, size);
  mbedtls_sha256_update(&o->sha, data, size);
  o->size += size;
  return 0;
}

static inf_state inflater;

// One zip entry to dest, checked against the zip's CRC-32 and size. Its SHA-256 goes to sha.
static int extract(int zfd, const zip_entry *e, const char *dest, char sha[65], char *error, size_t error_size) {
  uint8_t local[30];
  if (pread(zfd, local, 30, e->offset) != 30 || le32(local) != 0x04034b50) {
    snprintf(error, error_size, "zip entry header damaged: %.200s", e->name);
    return -1;
  }
  const off_t data = (off_t)e->offset + 30 + le16(local + 26) + le16(local + 28);
  char part[1100];
  snprintf(part, sizeof(part), "%s.part", dest);
  mkparents(dest);
  entry_out o;
  memset(&o, 0, sizeof(o));
  o.fd = open(part, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  if (o.fd < 0) { snprintf(error, error_size, "cannot write %.200s (%d)", part, errno); return -1; }
  mbedtls_sha256_init(&o.sha);
  mbedtls_sha256_starts(&o.sha, 0);
  zip_reader r = {zfd, data, data + (off_t)e->compressed};
  int ok;
  if (e->method == 0) {
    static uint8_t buf[1 << 16];
    int n;
    ok = 1;
    while (ok && (n = zip_read(&r, buf, sizeof(buf))) > 0) ok = !entry_write(&o, buf, (size_t)n);
  } else {
    inflater.read = zip_read;
    inflater.read_ctx = &r;
    inflater.write = entry_write;
    inflater.write_ctx = &o;
    ok = !inf_run(&inflater);
  }
  unsigned char digest[32];
  mbedtls_sha256_finish(&o.sha, digest);
  mbedtls_sha256_free(&o.sha);
  ok = ok && !fsync(o.fd);
  close(o.fd);
  if (!ok || o.size != e->size || o.crc != e->crc) {
    snprintf(error, error_size, "damaged file in the zip: %.200s", e->name);
    unlink(part);
    return -1;
  }
  if (rename(part, dest)) { snprintf(error, error_size, "rename %d", errno); unlink(part); return -1; }
  hex(digest, sha);
  return 0;
}

// ---- manifests: {"path": {"bytes": n, "sha256": "..."}} ----

typedef struct {
  char *text;
  jm_doc doc;
  int ok;
} manifest;

static void manifest_load(manifest *m, const char *path) {
  memset(m, 0, sizeof(*m));
  size_t n = 0;
  m->text = read_file(path, &n, 16u << 20);
  m->ok = m->text && !jm_parse(&m->doc, m->text, (int)n) && m->doc.tokens[0].type == JM_OBJECT;
}
static void manifest_free(manifest *m) {
  if (m->ok) jm_free(&m->doc);
  free(m->text);
  memset(m, 0, sizeof(*m));
}
static int manifest_sha(const manifest *m, const char *name, char out[65]) {
  if (!m->ok) return -1;
  return jm_string_of(&m->doc, jm_get(&m->doc, jm_get(&m->doc, 0, name), "sha256"), out, 65);
}

static int is_setting(const char *name) {
  const char *dot = strrchr(name, '.');
  return !strcmp(name, "assets/presets.txt") ||
         (dot && (!strcmp(dot, ".conf") || !strcmp(dot, ".toml") || !strcmp(dot, ".ini")));
}

// ---- stage: the release unpacked and checked beside the installation ----

static void stage_path(char *out, size_t size, const char *tag, const char *suffix) {
  snprintf(out, size, "%s/stage/%s%s", state, tag, suffix);
}

static int stage_release(const char *zip, const char *tag, char *error, size_t error_size) {
  char dir[700], marker[700];
  stage_path(dir, sizeof(dir), tag, "");
  stage_path(marker, sizeof(marker), tag, ".checked");
  if (exists(marker)) { say("stage of %s already checked", tag); return 0; }
  remove_tree(dir);
  const int zfd = open(zip, O_RDONLY);
  if (zfd < 0) { snprintf(error, error_size, "cannot open the download"); return -1; }
  int count = 0;
  uint64_t total = 0;
  zip_entry *list = zip_list(zfd, &count, &total, error, error_size);
  if (!list) { if (!error[0]) snprintf(error, error_size, "zip unreadable"); close(zfd); return -1; }
  struct statfs fs;
  if (!statfs(state, &fs) && (uint64_t)fs.f_bavail * fs.f_bsize < total + (128u << 20)) {
    snprintf(error, error_size, "not enough free space: %llu MB needed",
             (unsigned long long)((total + (128u << 20)) >> 20));
    free(list);
    close(zfd);
    return -1;
  }
  say("unpacking %d files, %llu MB", count, (unsigned long long)(total >> 20));
  char (*sha)[65] = (char (*)[65])calloc((size_t)count, 65);
  int ok = sha != NULL, has_eboot = 0, has_version = 0;
  for (int i = 0; ok && i < count; ++i) {
    char dest[1100];
    snprintf(dest, sizeof(dest), "%s/%s", dir, list[i].name);
    ok = !extract(zfd, &list[i], dest, sha[i], error, error_size);
    has_eboot |= !strcmp(list[i].name, "eboot.bin");
    has_version |= !strcmp(list[i].name, "VERSION");
  }
  close(zfd);
  if (ok && (!has_eboot || !has_version)) { snprintf(error, error_size, "the zip has no eboot.bin or VERSION"); ok = 0; }
  if (ok) {  // the package's own list, when it has one
    char path[1100];
    snprintf(path, sizeof(path), "%s/MANIFEST.json", dir);
    manifest m;
    manifest_load(&m, path);
    int listed = 0;
    for (int i = 0; ok && m.ok && i < count; ++i) {
      char expected[65];
      if (manifest_sha(&m, list[i].name, expected)) continue;
      ++listed;
      if (strcmp(expected, sha[i])) { snprintf(error, error_size, "%.200s differs from MANIFEST.json", list[i].name); ok = 0; }
    }
    say("MANIFEST.json: %s, %d files checked by SHA-256", m.ok ? "present" : "absent", listed);
    manifest_free(&m);
  }
  free(sha);
  free(list);
  if (!ok) { remove_tree(dir); return -1; }
  write_file(marker, "checked\n", 8);
  return 0;
}

// ---- apply ----

static int prune_backups(void) {
  char dir[700];
  snprintf(dir, sizeof(dir), "%s/backup", state);
  for (;;) {
    DIR *d = opendir(dir);
    if (!d) return 0;
    struct dirent *e;
    int n = 0;
    time_t oldest = 0;
    char oldest_name[256] = "";
    while ((e = readdir(d))) {
      if (e->d_name[0] == '.') continue;
      char p[1100];
      snprintf(p, sizeof(p), "%s/%s", dir, e->d_name);
      struct stat st;
      if (stat(p, &st) || !S_ISDIR(st.st_mode)) continue;
      ++n;
      if (!oldest_name[0] || st.st_mtime < oldest) { oldest = st.st_mtime; snprintf(oldest_name, sizeof(oldest_name), "%s", e->d_name); }
    }
    closedir(d);
    if (n <= 2) return 0;
    char p[1100];
    snprintf(p, sizeof(p), "%s/%s", dir, oldest_name);
    say("removing the old backup %s", oldest_name);
    remove_tree(p);
  }
}

// Staged files still to place, in order: everything else, then MANIFEST.json, RELEASE.json, VERSION, eboot.bin.
typedef struct {
  char **names;
  int count, capacity;
} name_list;
static void collect(const char *base, const char *rel, name_list *out) {
  char p[1100];
  snprintf(p, sizeof(p), "%s%s%s", base, *rel ? "/" : "", rel);
  DIR *d = opendir(p);
  if (!d) return;
  struct dirent *e;
  while ((e = readdir(d))) {
    if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    char child[1100], full[1200];
    snprintf(child, sizeof(child), "%s%s%s", rel, *rel ? "/" : "", e->d_name);
    snprintf(full, sizeof(full), "%s/%s", base, child);
    struct stat st;
    if (lstat(full, &st)) continue;
    if (S_ISDIR(st.st_mode)) { collect(base, child, out); continue; }
    if (!S_ISREG(st.st_mode)) continue;
    if (out->count == out->capacity) {
      out->capacity = out->capacity ? out->capacity * 2 : 256;
      out->names = (char **)realloc(out->names, (size_t)out->capacity * sizeof(char *));
    }
    out->names[out->count++] = strdup(child);
  }
  closedir(d);
}
static int place_rank(const char *name) {
  if (!strcmp(name, "eboot.bin")) return 4;
  if (!strcmp(name, "VERSION")) return 3;
  if (!strcmp(name, "RELEASE.json")) return 2;
  if (!strcmp(name, "MANIFEST.json")) return 1;
  return 0;
}
static int by_rank(const void *a, const void *b) {
  const char *x = *(char *const *)a, *y = *(char *const *)b;
  const int rx = place_rank(x), ry = place_rank(y);
  return rx != ry ? rx - ry : strcmp(x, y);
}

static int wait_for_close(const char *tag) {
  if (!emulator_running()) return 0;
  char text[200];
  snprintf(text, sizeof(text), T("PS5X360 %s is ready: close PS5X360 to install it", "PS5X360 %s pronto: feche o PS5X360 para instalar"), tag);
  notify(text);
  if (defer_install) return 1;  // the Helper keeps it staged and installs it once PS5X360 is closed
  for (int waited = 0; waited < wait_limit; waited += 5) {
    sleep(5);
    if (!emulator_running()) { sleep((unsigned)close_grace); return 0; }
  }
  return -1;
}

static int apply(const char *tag, const char *previous, char *error, size_t error_size) {
  char dir[700], journal[700], old_copy[700];
  stage_path(dir, sizeof(dir), tag, "");
  stage_path(old_copy, sizeof(old_copy), tag, ".previous-manifest.json");
  snprintf(journal, sizeof(journal), "%s/install.txt", state);
  if (!exists(journal)) {
    char text[200];
    const int n = snprintf(text, sizeof(text), "%s\n%s\n", tag, previous);
    char current[700];
    snprintf(current, sizeof(current), "%s/MANIFEST.json", root);
    size_t size = 0;
    char *old = read_file(current, &size, 16u << 20);
    if (old) { write_file(old_copy, old, size); free(old); }
    if (write_file(journal, text, (size_t)n)) { snprintf(error, error_size, "cannot write the install journal"); return -1; }
  }
  manifest before;
  manifest_load(&before, old_copy);
  name_list files = {NULL, 0, 0};
  collect(dir, "", &files);
  qsort(files.names, (size_t)files.count, sizeof(char *), by_rank);
  say("placing %d files of %s (previous %s)", files.count, tag, previous);
  int ok = 1, kept = 0, backed = 0;
  for (int i = 0; ok && i < files.count; ++i) {
    const char *name = files.names[i];
#ifndef PS5
    if (stop_after && i >= stop_after) { say("test: stopping half-way"); _exit(9); }
#endif
    char src[1100], dst[1100];
    snprintf(src, sizeof(src), "%s/%s", dir, name);
    snprintf(dst, sizeof(dst), "%s/%s", root, name);
    if (!strcmp(name, "eboot.bin") && emulator_running()) { snprintf(error, error_size, "PS5X360 was opened during the update"); ok = 0; break; }
    if (!exists(dst)) { ok = !move_file(src, dst); continue; }
    char have[65], fresh[65], listed[65];
    if (file_sha256(dst, have) || file_sha256(src, fresh)) { snprintf(error, error_size, "cannot read %.200s", name); ok = 0; break; }
    if (!strcmp(have, fresh)) { unlink(src); continue; }
    const int user_changed = manifest_sha(&before, name, listed) ? before.ok : strcmp(listed, have) != 0;
    if (is_setting(name) && user_changed) {
      char beside[1200];
      snprintf(beside, sizeof(beside), "%s.new", dst);
      say("kept your %s; the new one is %s.new", name, name);
      ok = !move_file(src, beside);
      ++kept;
      continue;
    }
    char backup[1200];
    snprintf(backup, sizeof(backup), "%s/backup/%s/%s", state, previous, name);
    ok = !move_file(dst, backup) && !move_file(src, dst);
    ++backed;
  }
  for (int i = 0; i < files.count; ++i) free(files.names[i]);
  free(files.names);
  manifest_free(&before);
  if (!ok) { if (!error[0]) snprintf(error, error_size, "a file could not be placed (%d)", errno); return -1; }
  char marker[700];
  stage_path(marker, sizeof(marker), tag, ".checked");
  remove_tree(dir);
  unlink(marker);
  unlink(old_copy);
  unlink(journal);
  say("installed %s: %d files backed up, %d settings kept", tag, backed, kept);
  prune_backups();
  return 0;
}

// Downloads and unpacked copies of other releases (an older check-only run, a release replaced since) go.
static void clean_leftovers(const char *keep) {
  static const char *folders[] = {"stage", "download"};
  for (int f = 0; f < 2; ++f) {
    char dir[700];
    snprintf(dir, sizeof(dir), "%s/%s", state, folders[f]);
    DIR *d = opendir(dir);
    if (!d) continue;
    struct dirent *e;
    while ((e = readdir(d))) {
      if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
      const size_t n = keep ? strlen(keep) : 0;
      if (keep && !strncmp(e->d_name, keep, n) && (e->d_name[n] == 0 || e->d_name[n] == '.')) continue;
      char p[1100];
      snprintf(p, sizeof(p), "%s/%s", dir, e->d_name);
      say("removing the leftover %s/%s", folders[f], e->d_name);
      remove_tree(p);
    }
    closedir(d);
  }
}

// ---- main ----

static void trim(char *s) {
  size_t n = strlen(s);
  while (n && (s[n - 1] == '\n' || s[n - 1] == '\r' || s[n - 1] == ' ')) s[--n] = 0;
}

static void read_installed(char *installed, size_t size) {
  char p[700];
  snprintf(p, sizeof(p), "%s/VERSION", root);
  char *v = read_file(p, NULL, 256);
  if (v) { snprintf(installed, size, "%s", v); trim(installed); free(v); }
}

// Module: a checked release stays staged until PS5X360 is closed (upd_module_install_pending).
static int keep_pending(const char *tag, const char *previous, int force, const char *zip) {
  snprintf(pending.tag, sizeof(pending.tag), "%s", tag);
  snprintf(pending.previous, sizeof(pending.previous), "%s", previous);
  snprintf(pending.zip, sizeof(pending.zip), "%s", zip ? zip : "");
  pending.force = force;
  say("%s stays staged until PS5X360 is closed", tag);
  set_outcome("%s staged: waiting for PS5X360 to close", tag);
  return UPD_PENDING;
}

// Places the checked stage of tag, then (zip given) removes the download and records last-update.txt.
static int install_now(const char *tag, const char *previous, int force, const char *zip, char *error,
                       size_t error_size) {
  if (apply(tag, previous, error, error_size)) {
    if (defer_install && emulator_running()) {  // the journal lets the next try finish it
      say("PS5X360 was opened during the install of %s: it finishes once PS5X360 is closed", tag);
      return keep_pending(tag, previous, force, zip);
    }
    return UPD_FAILED;
  }
  ++installs;
  pending.tag[0] = 0;
  if (zip && zip[0]) {
    char checked[720];
    snprintf(checked, sizeof(checked), "%s.checked", zip);
    unlink(zip);
    unlink(checked);
    char last[700], text[300];
    snprintf(last, sizeof(last), "%s/last-update.txt", state);
    const int n = snprintf(text, sizeof(text), "%s -> %s%s\n", previous, tag, force ? " (forced)" : "");
    write_file(last, text, (size_t)n);
  }
  char text[200];
  snprintf(text, sizeof(text), T("PS5X360 updated to %s", "PS5X360 atualizado para %s"), tag);
  notify(text);
  set_outcome("installed %s", tag);
  return UPD_DONE;
}

static int run(void) {
  char error[512] = "", installed[64] = "0";
  network_failed = 0;
  read_installed(installed, sizeof(installed));
  say("PS5X360 Updater " UPDATER_VERSION ": installed %s, folder %s", installed, root);
  if (flag("no-update")) { say("no-update is set: nothing to do"); set_outcome("no-update is set: not checked"); return 0; }

  // A cut install: finish it from the checked files.
  {
    char journal[700];
    snprintf(journal, sizeof(journal), "%s/install.txt", state);
    char *text = read_file(journal, NULL, 4096);
    if (text) {
      char tag[64] = "", previous[64] = "";
      sscanf(text, "%63s %63s", tag, previous);
      free(text);
      char marker[700];
      stage_path(marker, sizeof(marker), tag, ".checked");
      if (tag[0] && exists(marker)) {
        say("finishing the cut install of %s", tag);
        if (wait_for_close(tag)) {
          if (defer_install) return keep_pending(tag, previous, 0, NULL);
          goto failed;
        }
        const int placed = install_now(tag, previous, 0, NULL, error, sizeof(error));
        if (placed == UPD_FAILED) goto failed;
        return placed;
      }
      unlink(journal);
    }
  }

  notify(T("PS5X360: checking for updates", "PS5X360: procurando atualização"));
  release r;
  if (latest_release(flag("beta"), &r, error, sizeof(error))) goto failed;
  const int newer = upd_version_compare(r.tag, installed);
  say("latest release %s (%lld bytes, SHA-256 %s); installed %s", r.tag, r.size, r.sha256, installed);
  int force = 0;
  clean_leftovers(newer > 0 || flag("force") ? r.tag : NULL);
  if (newer <= 0) {
    if (!flag("force")) {
      char text[200];
      if (newer < 0)
        snprintf(text, sizeof(text), T("PS5X360 %s is newer than the latest release (%s): nothing to do",
                                       "PS5X360 %s é mais novo que a última versão (%s): nada a fazer"), installed, r.tag);
      else
        snprintf(text, sizeof(text), T("PS5X360 is up to date (%s)", "PS5X360 está atualizado (%s)"), installed);
      notify(text);
      if (newer < 0) set_outcome("%s is newer than the latest release %s", installed, r.tag);
      else set_outcome("up to date (%s)", installed);
      free(r.notes);
      return 0;
    }
    char from[700], to[700];
    snprintf(from, sizeof(from), "%s/force", state);
    snprintf(to, sizeof(to), "%s/force.used", state);
    rename(from, to);
    force = 1;
    say("force is set: installing %s anyway", r.tag);
  }
  {
    char text[200];
    snprintf(text, sizeof(text), T("PS5X360 %s found: downloading %lld MB", "PS5X360 %s encontrado: baixando %lld MB"),
             r.tag, (r.size + (1 << 20) - 1) >> 20);
    notify(text);
  }
  char zip[700];
  snprintf(zip, sizeof(zip), "%s/download/%s.zip", state, r.tag);
  if (download(&r, zip, error, sizeof(error))) goto failed;
  if (stage_release(zip, r.tag, error, sizeof(error))) goto failed;
  if (r.notes) {
    char notes[700];
    snprintf(notes, sizeof(notes), "%s/release-notes/%s.md", state, r.tag);
    write_file(notes, r.notes, strlen(r.notes));
    free(r.notes);
  }
  if (flag("check-only")) {
    char text[200];
    snprintf(text, sizeof(text), T("PS5X360 %s downloaded and checked (check-only: not installed)",
                                   "PS5X360 %s baixado e conferido (check-only: não instalado)"), r.tag);
    notify(text);
    set_outcome("check-only: %s downloaded and checked, not installed", r.tag);
    return 0;
  }
  if (wait_for_close(r.tag)) {
    if (defer_install) return keep_pending(r.tag, installed, force, zip);
    notify(T("PS5X360 is still open: send the updater again after closing it", "PS5X360 continua aberto: envie o atualizador de novo depois de fechar"));
    return 1;
  }
  {
    const int placed = install_now(r.tag, installed, force, zip, error, sizeof(error));
    if (placed == UPD_FAILED) goto failed;
    return placed;
  }
failed:
  set_outcome("failed: %s", error);
  if (quiet_network && network_failed) {
    say("GitHub unreachable (%s): a later try follows", error);
  } else {
    char text[700];
    snprintf(text, sizeof(text), T("PS5X360 update failed: %s", "Falha ao atualizar o PS5X360: %s"), error);
    notify(text);
  }
  return defer_install && network_failed ? UPD_NET_FAILED : UPD_FAILED;
}

// The updater log, started again beside updater.log.old once it passes 1 MB.
static void open_log(void) {
  char log[700], old[720];
  snprintf(log, sizeof(log), "%s/updater.log", state);
  struct stat st;
  const int big = !stat(log, &st) && st.st_size > (1 << 20);
  if (logfile && !big) return;
  if (logfile) { fclose(logfile); logfile = NULL; }
  if (big) { snprintf(old, sizeof(old), "%s.old", log); rename(log, old); }
  logfile = fopen(log, "a");
}

// Language, test switches, the state folder and its log. root is set before.
static int setup(void) {
#ifndef PS5
  if (getenv("UPDATER_SANDBOX")) snprintf(sandbox, sizeof(sandbox), "%s", getenv("UPDATER_SANDBOX"));
  lang_pt = getenv("UPDATER_PT") != NULL;
  if (getenv("UPDATER_STOP_AFTER")) stop_after = atoi(getenv("UPDATER_STOP_AFTER"));
  if (getenv("UPDATER_WAIT")) wait_limit = atoi(getenv("UPDATER_WAIT"));
  if (getenv("UPDATER_CLOSE_GRACE")) close_grace = atoi(getenv("UPDATER_CLOSE_GRACE"));
#else
  int language = 0;
  if (!sceSystemServiceParamGetInt(1, &language)) lang_pt = language == 7 || language == 17;
#endif
  {  // a test installation elsewhere: its folder in updater/test-root (one line)
    char p[700];
    snprintf(p, sizeof(p), "%s/updater/test-root", root);
    char *other = read_file(p, NULL, 400);
    if (other) {
      trim(other);
      if (other[0] == '/' && strstr(other, "test")) snprintf(root, sizeof(root), "%s", other);
      free(other);
    }
  }
  snprintf(state, sizeof(state), "%s/updater", root);
  if (mkdirs(state)) return -1;
  open_log();
  crc_init();
  return 0;
}

#ifndef UPD_MODULE
int main(int argc, char **argv) {
  (void)argc;
  (void)argv;
#ifndef PS5
  if (getenv("UPDATER_ROOT")) snprintf(root, sizeof(root), "%s", getenv("UPDATER_ROOT"));
#endif
  if (setup()) return 2;
  // One copy at a time. The lock goes with the process, so a copy that died (or a power cut) leaves none.
  char lock[700];
  snprintf(lock, sizeof(lock), "%s/lock", state);
  const int fd = open(lock, O_RDWR | O_CREAT, 0666);
  if (fd < 0 || flock(fd, LOCK_EX | LOCK_NB)) {
    notify(T("PS5X360 Updater is already running", "O atualizador do PS5X360 já está rodando"));
    return 3;
  }
  const int result = run();
  close(fd);
  if (logfile) fclose(logfile);
  return result;
}
#else  // UPD_MODULE: called by the PS5X360 Helper

static int module_ready;

static int take_lock(void) {
  char lock[700];
  snprintf(lock, sizeof(lock), "%s/lock", state);
  const int fd = open(lock, O_RDWR | O_CREAT, 0666);
  if (fd < 0) return -1;
  if (flock(fd, LOCK_EX | LOCK_NB)) { close(fd); return -1; }
  return fd;
}

int upd_module_init(const char *install_root) {
  snprintf(root, sizeof(root), "%s", install_root);
  defer_install = 1;
  module_ready = !setup();
  if (!module_ready) set_outcome("the updater folder could not be made");
  return module_ready ? 0 : -1;
}

int upd_module_check(int quiet) {
  if (!module_ready) return UPD_FAILED;
  open_log();
  const int fd = take_lock();
  if (fd < 0) {
    say("another copy of the updater holds the lock: this check waits for the next one");
    set_outcome("another copy of the updater is running");
    return UPD_BUSY;
  }
  quiet_network = quiet;
  const int result = run();
  quiet_network = 0;
  close(fd);
  return result;
}

int upd_module_install_pending(void) {
  if (!module_ready || !pending.tag[0]) return UPD_DONE;
  if (emulator_running()) return UPD_PENDING;
  sleep((unsigned)close_grace);
  if (emulator_running()) return UPD_PENDING;
  open_log();
  const int fd = take_lock();
  if (fd < 0) return UPD_BUSY;
  char marker[700], journal[700], error[512] = "", installed[64] = "0";
  stage_path(marker, sizeof(marker), pending.tag, ".checked");
  snprintf(journal, sizeof(journal), "%s/install.txt", state);
  read_installed(installed, sizeof(installed));
  int result = UPD_DONE;
  if (!exists(marker)) {
    say("the staged %s is gone (installed or removed by another copy)", pending.tag);
    set_outcome("%s is no longer staged: nothing to install", pending.tag);
    pending.tag[0] = 0;
  } else if (!exists(journal) && !pending.force && upd_version_compare(pending.tag, installed) <= 0) {
    say("%s is installed already (VERSION says %s)", pending.tag, installed);
    set_outcome("up to date (%s)", installed);
    pending.tag[0] = 0;
  } else {
    char tag[64], previous[64], zip[700];
    const int force = pending.force;
    snprintf(tag, sizeof(tag), "%s", pending.tag);
    snprintf(zip, sizeof(zip), "%s", pending.zip);
    // A started install keeps its journal's previous build; a fresh one replaces what is installed now.
    snprintf(previous, sizeof(previous), "%s", exists(journal) ? pending.previous : installed);
    say("PS5X360 is closed: installing the staged %s", tag);
    result = install_now(tag, previous, force, zip, error, sizeof(error));
    if (result == UPD_FAILED) {
      pending.tag[0] = 0;
      set_outcome("failed: %s", error);
      char text[700];
      snprintf(text, sizeof(text), T("PS5X360 update failed: %s", "Falha ao atualizar o PS5X360: %s"), error);
      notify(text);
    }
  }
  close(fd);
  return result;
}

int upd_module_pending(char *tag, size_t size) {
  snprintf(tag, size, "%s", pending.tag);
  return pending.tag[0] != 0;
}
unsigned upd_module_installs(void) { return installs; }
const char *upd_module_outcome(void) { return outcome; }
int upd_module_emulator_running(void) { return emulator_running(); }
int upd_module_lang_pt(void) { return lang_pt; }
#endif
