// SPDX-License-Identifier: MIT
// PS5X360 version order. "0.6.0" < "0.6.0-fix1" (a fix after the release) < "0.6.1-dev.26-kinect" (a test build
// before 0.6.1) < "0.6.1". A leading "v" (release tags) is ignored.
#pragma once
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  long part[3];
  int stage;      // -1 test build (dev, experimental, alpha, beta, rc, local...), 0 release, 1 fix after it
  long stage_n;   // the number in the suffix (dev.26 -> 26, fix1 -> 1)
} upd_version;

static void upd_version_parse(const char *text, upd_version *v) {
  memset(v, 0, sizeof(*v));
  const char *p = text;
  while (*p == ' ' || *p == 'v' || *p == 'V') ++p;
  for (int i = 0; i < 3; ++i) {
    v->part[i] = strtol(p, (char **)&p, 10);
    if (*p != '.') break;
    ++p;
  }
  while (*p && *p != '-' && *p != '+') ++p;
  if (*p != '-') return;
  ++p;
  if (!strncmp(p, "fix", 3) || !strncmp(p, "hotfix", 6) || !strncmp(p, "patch", 5)) v->stage = 1;
  else v->stage = -1;
  while (*p && !isdigit((unsigned char)*p)) ++p;
  v->stage_n = *p ? strtol(p, NULL, 10) : 0;
}

// < 0 when a is older than b, 0 when equal, > 0 when newer.
static int upd_version_compare(const char *a, const char *b) {
  upd_version x, y;
  upd_version_parse(a, &x);
  upd_version_parse(b, &y);
  for (int i = 0; i < 3; ++i)
    if (x.part[i] != y.part[i]) return x.part[i] < y.part[i] ? -1 : 1;
  if (x.stage != y.stage) return x.stage < y.stage ? -1 : 1;
  if (x.stage_n != y.stage_n) return x.stage_n < y.stage_n ? -1 : 1;
  return 0;
}
