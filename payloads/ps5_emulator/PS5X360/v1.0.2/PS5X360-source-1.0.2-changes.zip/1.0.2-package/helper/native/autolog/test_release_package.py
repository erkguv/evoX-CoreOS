"""Release packaging regressions using a disposable miniature title; no real eboot changes."""
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[2] / 'tools/package-release.py'
spec = importlib.util.spec_from_file_location('release_packager', SCRIPT)
packager = importlib.util.module_from_spec(spec)
spec.loader.exec_module(packager)


class PackagingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ps5x360-release-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        packager.ROOT = self.root
        packager.APP = self.root / 'dist/PPSA50011'
        packager.PATCHES = self.root / 'absent-patches'
        def put(name, data=b'fixture'):
            p = self.root / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            return p
        self.put = put
        put('VERSION', b'0.5.8\n')
        for name in ('docs/releases/v0.5.8.md', 'docs/INSTALLATION.md', 'docs/CREDITS.md', 'LICENSE', 'native/autolog/README.md'):
            put(name)
        put('build/canary-game/eboot.bin', b'PS5X360 v0.5.8 fixture emulator')
        for name in ('eboot.bin', 'sce_module/libc.prx', 'sce_sys/param.json', 'sce_sys/icon0.png',
                     'sce_sys/pic0.png', 'sce_sys/pic1.png', 'assets/sounds/move.raw',
                     'assets/sounds/select.raw', 'assets/sounds/back.raw', 'assets/sounds/achievement.raw',
                     'assets/fonts/NotoSans-Regular.ttf', 'assets/fonts/NotoSans-SemiBold.ttf',
                     'assets/fonts/OFL.txt', 'assets/roms/README.txt'):
            put('dist/PPSA50011/' + name)
        self.tool = put('build/autolog-native/PS5X360-Tool.elf', b'\x7fELF PS5X360_TOOL_PAYLOAD_V1 fixture')
        self.tracker = put('build/kinect-fix2-20261015/out/kinect-tracker-fix2.elf', b'\x7fELF KTRACKER fix2 fixture')
        self.source = self.root / 'dist/PS5X360-Tool-ELF-v1.1.0-preview.zip'
        data = {'PS5X360-Tool.elf': self.tool.read_bytes(),
                'install/data/homebrew/PPSA50011/tools/kinect-tracker.elf': self.tracker.read_bytes()}
        with zipfile.ZipFile(self.source, 'w') as z:
            for name, content in data.items():
                z.writestr('PS5X360-Tool-ELF/' + name, content)
            z.writestr('PS5X360-Tool-ELF/manifest.json', json.dumps({'sha256': {
                name: hashlib.sha256(content).hexdigest() for name, content in data.items()}}))

    def package(self, *args):
        with contextlib.redirect_stdout(io.StringIO()):
            packager.main(list(args))
        return zipfile.ZipFile(self.root / 'dist/PPSA50011.zip')

    def test_default_excludes_components_without_needing_legacy_archive(self):
        self.source.unlink()
        with self.package() as z:
            self.assertNotIn('PPSA50011/tools/PS5X360-Tool.elf', z.namelist())
            self.assertFalse(json.loads(z.read('PPSA50011/RELEASE.json'))['optional_components']['ps5x360_tool']['enabled'])

    def test_enabled_contains_exact_artifacts_and_truthful_manifest(self):
        with self.package('--with-ps5x360-tool', '--kinect-tracker', str(self.tracker)) as z:
            self.assertEqual(z.read('PPSA50011/tools/PS5X360-Tool.elf'), self.tool.read_bytes())
            self.assertEqual(z.read('PPSA50011/tools/kinect-tracker.elf'), self.tracker.read_bytes())
            self.assertEqual(z.read('PPSA50011/licenses/PS5X360-Tool-source-v1.1.0-preview.zip'), self.source.read_bytes())
            release = json.loads(z.read('PPSA50011/RELEASE.json'))
            self.assertEqual(release['version'], '0.5.8')
            component = release['optional_components']['ps5x360_tool']
            self.assertTrue(component['enabled'])
            self.assertFalse(component['models_included'])
            self.assertFalse(component['firmware_included'])
            self.assertFalse(component['hardware_validated'])
            self.assertTrue(component['models_required_on_console'])
            manifest = json.loads(z.read('PPSA50011/MANIFEST.json'))
            self.assertEqual(manifest['tools/kinect-tracker.elf']['when_enabled'], 'ps5x360_tool')
            self.assertEqual(z.read('PPSA50011/eboot.bin'), (self.root / 'build/canary-game/eboot.bin').read_bytes())
        self.assertEqual((self.root / 'VERSION').read_bytes(), b'0.5.8\n')

    def test_explicit_tracker_required(self):
        with self.assertRaises(SystemExit):
            self.package('--with-ps5x360-tool')

    def test_tracker_requires_enable(self):
        with self.assertRaises(SystemExit):
            self.package('--kinect-tracker', str(self.tracker))

    def test_missing_tracker_is_failure(self):
        self.tracker.unlink()
        with self.assertRaises(SystemExit):
            self.package('--with-ps5x360-tool', '--kinect-tracker', str(self.tracker))

    def test_stale_tool_archive_is_failure(self):
        self.tool.write_bytes(self.tool.read_bytes() + b'new build')
        with self.assertRaises(SystemExit):
            self.package('--with-ps5x360-tool', '--kinect-tracker', str(self.tracker))

    def test_stale_tracker_archive_is_failure(self):
        self.tracker.write_bytes(self.tracker.read_bytes() + b'new build')
        with self.assertRaises(SystemExit):
            self.package('--with-ps5x360-tool', '--kinect-tracker', str(self.tracker))


if __name__ == '__main__':
    unittest.main()
