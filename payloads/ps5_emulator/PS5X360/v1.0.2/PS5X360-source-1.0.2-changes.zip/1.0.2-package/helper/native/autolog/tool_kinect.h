// SPDX-License-Identifier: MIT
// Kinect tracker launch primitives for the PS5X360 Helper: relay-port probe by bind, ELF validation, and one
// bounded raw-ELF submission to the local loader. No camera or private configuration access, no shell, no fork.
// The supervisor deciding when to launch is helper_kinect.h.
#pragma once
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "helper.h"

#ifndef TOOL_RELAY_PORT
#define TOOL_RELAY_PORT 9301
#endif
#ifndef TOOL_LOADER_PORT
#define TOOL_LOADER_PORT 9021
#endif
#ifndef TOOL_READY_MS
#define TOOL_READY_MS 3000
#endif
#ifndef TOOL_IO_MS
#define TOOL_IO_MS 4000
#endif
#ifndef TOOL_COOLDOWN_S
#define TOOL_COOLDOWN_S 60
#endif
#define TOOL_HELPER ROOT "/tools/kinect-tracker.elf"
#define TOOL_STATE ROOT "/autolog"
#define TOOL_ID "PS5X360_TOOL_PAYLOAD_V1"
#define TOOL_MAX_ELF (32u * 1024u * 1024u)
// The tracker's own files (native/kinect/kinect_tracker.c): it removes the stop file when it starts, leaves
// when it appears, consumes the calibration file during a camera session and writes its log.
#ifndef TOOL_CALIBRATION_TRIGGER
#define TOOL_CALIBRATION_TRIGGER "/data/kinect-tracker.calibrate"
#endif
#ifndef TOOL_STOP_TRIGGER
#define TOOL_STOP_TRIGGER "/data/kinect-tracker.stop"
#endif
#ifndef TOOL_TRACKER_LOG
#define TOOL_TRACKER_LOG "/data/kinect-tracker.log"
#endif
static const char *tool_stage="not started";
static long long tool_progress;
static int tool_error;
enum tool_calibration { TOOL_CAL_NONE, TOOL_CAL_REQUESTED, TOOL_CAL_PENDING, TOOL_CAL_FAILED };
enum tool_result {
  TOOL_PRESENT, TOOL_STARTED, TOOL_UNCONFIRMED, TOOL_DISABLED, TOOL_BUSY,
  TOOL_COOLDOWN, TOOL_MISSING, TOOL_INVALID, TOOL_SELF, TOOL_LOADER_DOWN,
  TOOL_SEND_FAILED, TOOL_STORAGE, TOOL_THREAD_FAILED
};
static const char* tool_result_text(enum tool_result r) {
  static const char* messages[]={
    "relay port occupied; existing service preserved (identity unverified)",
    "helper submitted; relay port became occupied (identity unverified)",
    "helper submitted; relay not observed within deadline; the Helper keeps watching",
    "helper activation disabled by no-kinect-start marker",
    "another Tool activation owns the launch lock",
    "recent submission preserved; launch cooldown active",
    "standalone helper missing at tools/kinect-tracker.elf",
    "helper rejected: not a supported standalone tracker ELF",
    "helper rejected: Tool payload cannot launch itself",
    "local ELF loader unavailable; no payload submitted",
    "loader transfer incomplete; the Helper retries with backoff",
    "helper state or payload read failed",
    "helper worker unavailable; collector continues"
  };
  return (unsigned)r<sizeof(messages)/sizeof(messages[0])?messages[r]:"unknown helper state";
}
static int64_t tool_millis(void) {
  struct timespec t;if(clock_gettime(CLOCK_MONOTONIC,&t))return -1;
  return (int64_t)t.tv_sec*1000+t.tv_nsec/1000000;
}
// Probe ownership by bind, without connecting to the relay's single data client.
// An occupied port is a collision guard, never a camera/tracker health claim.
static int tool_relay_occupied(void) {
  int fd=socket(AF_INET,SOCK_STREAM,0);if(fd<0)return -1;
  struct sockaddr_in a;memset(&a,0,sizeof(a));a.sin_family=AF_INET;
  a.sin_port=htons(TOOL_RELAY_PORT);a.sin_addr.s_addr=htonl(0x7f000001);
  int r=bind(fd,(struct sockaddr*)&a,sizeof(a)),e=errno;close(fd);
  return !r?0:e==EADDRINUSE?1:-1;
}
static int tool_wait(int fd,short events,int64_t deadline) {
  for(;;){int64_t at=tool_millis();if(at<0||at>=deadline)return -1;
    struct pollfd p={fd,events,0};int left=(int)(deadline-at);
    int r=poll(&p,1,left>100?100:left);
    if(r<0&&errno==EINTR)continue;
    if(r<0)return -1;
    if(r>0)return (p.revents&events)?0:-1;
  }
}
static int tool_loader_connect(int64_t deadline) {
  int fd=socket(AF_INET,SOCK_STREAM,0);if(fd<0)return -1;
  // Do not use socket fcntl: it is denied in the observed collector environment.
  int nonblock=1;if(ioctl(fd,FIONBIO,&nonblock)){close(fd);return -1;}
  struct sockaddr_in a;memset(&a,0,sizeof(a));a.sin_family=AF_INET;
  a.sin_port=htons(TOOL_LOADER_PORT);a.sin_addr.s_addr=htonl(0x7f000001);
  if(connect(fd,(struct sockaddr*)&a,sizeof(a))){
    if(errno!=EINPROGRESS||tool_wait(fd,POLLOUT,deadline)){close(fd);return -1;}
    int error=0;socklen_t n=sizeof(error);
    if(getsockopt(fd,SOL_SOCKET,SO_ERROR,&error,&n)||error){close(fd);return -1;}
  }
  return fd;
}
static int tool_contains(const uint8_t* p,size_t n,const char* marker) {
  size_t m=strlen(marker);for(size_t i=0;m<=n&&i<=n-m;i++)if(!memcmp(p+i,marker,m))return 1;return 0;
}
static uint16_t tool_u16(const uint8_t* p){return p[0]|(uint16_t)p[1]<<8;}
static uint32_t tool_u32(const uint8_t* p){return tool_u16(p)|(uint32_t)tool_u16(p+2)<<16;}
static uint64_t tool_u64(const uint8_t* p){uint64_t v=0;for(int i=7;i>=0;i--)v=v<<8|p[i];return v;}
static enum tool_result tool_validate(const uint8_t* p,size_t n) {
  if(tool_contains(p,n,TOOL_ID))return TOOL_SELF;
  if(n<64||memcmp(p,"\177ELF\2\1\1",7)||tool_u16(p+18)!=62||
     (tool_u16(p+16)!=2&&tool_u16(p+16)!=3)||!tool_u64(p+24)||
     tool_u16(p+52)!=64||tool_u16(p+54)!=56||!tool_contains(p,n,"KTRACKER "))return TOOL_INVALID;
  uint64_t off=tool_u64(p+32),entry=tool_u64(p+24);unsigned count=tool_u16(p+56);
  if(!count||count>128||off>n||(uint64_t)count*56>n-off)return TOOL_INVALID;
  int executable=0;
  for(unsigned i=0;i<count;i++){
    const uint8_t* h=p+(size_t)off+i*56;
    if(tool_u32(h)!=1)continue; // PT_LOAD (full 32-bit type)
    uint64_t at=tool_u64(h+8),va=tool_u64(h+16),file=tool_u64(h+32),mem=tool_u64(h+40);
    if(at>n||file>n-at||file>mem||mem>256u*1024u*1024u||va>UINT64_MAX-mem)return TOOL_INVALID;
    if((h[4]&1)&&entry>=va&&entry-va<file)executable=1;
  }
  return executable?TOOL_STARTED:TOOL_INVALID;
}
static enum tool_calibration tool_request_calibration(enum tool_result result) {
  if(result!=TOOL_PRESENT&&result!=TOOL_STARTED)return TOOL_CAL_NONE;
  // One file request only: never truncate an existing request or follow links.
  int fd=open(TOOL_CALIBRATION_TRIGGER,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_NONBLOCK,0600);
  if(fd<0)return errno==EEXIST?TOOL_CAL_PENDING:TOOL_CAL_FAILED;
  const char body[]="PS5X360 Helper: stand facing the Kinect with your whole body visible, including head, hands and feet.\n";
  int ok=write(fd,body,sizeof(body)-1)==sizeof(body)-1;
  if(fsync(fd))ok=0;if(close(fd))ok=0;
  // The tracker owns consuming/removing the marker. Never retry or delete it here.
  return ok?TOOL_CAL_REQUESTED:TOOL_CAL_FAILED;
}
// PPSA50011/autolog/kinect-status.txt: the last launch attempt, as the 1.1 Tool wrote it.
static void tool_status(enum tool_result result,enum tool_calibration calibration) {
  char text[640],temp[256];
  const char* instruction=calibration==TOOL_CAL_REQUESTED||calibration==TOOL_CAL_PENDING?
    "Calibration request queued; stand facing the Kinect with your whole body visible, including head, hands and feet. Completion requires helper/hardware confirmation.\n":
    calibration==TOOL_CAL_FAILED?"Calibration request file unavailable; stand with your whole body visible and request calibration again when storage is accessible.\n":"";
  int n=snprintf(text,sizeof(text),"PS5X360 Tool Kinect: %s; checked %lld UTC\nstage=%s errno=%d progress=%lld\n%s",tool_result_text(result),(long long)time(NULL),tool_stage,tool_error,tool_progress,instruction);
  snprintf(temp,sizeof(temp),TOOL_STATE "/kinect-status.%d.tmp",(int)getpid());
  int fd=open(temp,O_WRONLY|O_CREAT|O_TRUNC,0600);
  if(fd>=0){if(write(fd,text,(size_t)n)==n&&!fsync(fd))rename(temp,TOOL_STATE "/kinect-status.txt");close(fd);unlink(temp);}
}
// One bounded submission of tools/kinect-tracker.elf. honour_cooldown: refuse within TOOL_COOLDOWN_S of the
// last recorded submission (any process). sha gets the SHA-256 of the bytes sent (or "" when nothing was read).
static enum tool_result tool_launch(int honour_cooldown,char sha[65]) {
  sha[0]=0;tool_progress=0;tool_error=0;
  tool_stage="launch lock";
  int lockfd=open(TOOL_STATE "/kinect-launch.lock",O_CREAT|O_RDWR,0600);
  if(lockfd<0){tool_error=errno;return TOOL_STORAGE;}
  if(flock(lockfd,LOCK_EX|LOCK_NB)){close(lockfd);return TOOL_BUSY;}
  enum tool_result result=TOOL_STORAGE;int payload=-1,loader=-1;uint8_t* bytes=NULL;
  tool_stage="relay probe";int occupied=tool_relay_occupied();
  if(occupied){result=occupied>0?TOOL_PRESENT:TOOL_STORAGE;goto done;}
  FILE* recent=fopen(TOOL_STATE "/kinect-last-submit.txt","rb");
  if(recent){long long last=0;int ok=fscanf(recent,"%lld",&last);fclose(recent);
    long long elapsed=(long long)time(NULL)-last;
    if(honour_cooldown&&ok==1&&elapsed>=0&&elapsed<TOOL_COOLDOWN_S){result=TOOL_COOLDOWN;goto done;}}
  tool_stage="payload open";payload=open(TOOL_HELPER,O_RDONLY|O_NOFOLLOW|O_NONBLOCK);
  if(payload<0){result=errno==ENOENT?TOOL_MISSING:TOOL_STORAGE;goto done;}
  tool_stage="payload stat";struct stat st;if(fstat(payload,&st)||!S_ISREG(st.st_mode)||st.st_size<64||st.st_size>TOOL_MAX_ELF){result=TOOL_INVALID;goto done;}
  tool_stage="payload allocation";size_t length=(size_t)st.st_size;tool_progress=length;bytes=malloc(length);if(!bytes)goto done;
  tool_stage="payload read";size_t used=0;while(used<length){ssize_t n=read(payload,bytes+used,length-used);if(n<=0)goto done;used+=(size_t)n;tool_progress=used;}
  tool_stage="payload validation";
  result=tool_validate(bytes,length);if(result!=TOOL_STARTED)goto done;
  helper_bytes_sha256(bytes,length,sha);
  // Recheck ownership immediately before making an irreversible submission.
  tool_stage="relay recheck";occupied=tool_relay_occupied();if(occupied){result=occupied>0?TOOL_PRESENT:TOOL_STORAGE;goto done;}
  tool_stage="monotonic clock";int64_t at=tool_millis();if(at<0){result=TOOL_STORAGE;goto done;}
  loader=tool_loader_connect(at+1000);if(loader<0){result=TOOL_LOADER_DOWN;goto done;}
  // Persist before the first byte: the cooldown also covers a partial or uncertain transfer.
  tool_stage="submission receipt";recent=fopen(TOOL_STATE "/kinect-last-submit.txt","wb");
  if(!recent){result=TOOL_STORAGE;goto done;}
  int saved=fprintf(recent,"%lld\n",(long long)time(NULL))>0;
  if(fflush(recent)||fsync(fileno(recent)))saved=0;
  if(fclose(recent))saved=0;if(!saved){result=TOOL_STORAGE;goto done;}
  at=tool_millis();if(at<0){result=TOOL_STORAGE;goto done;}int64_t deadline=at+TOOL_IO_MS;
  tool_stage="payload transfer";
  used=0;while(used<length){
    if(tool_wait(loader,POLLOUT,deadline)){result=TOOL_SEND_FAILED;goto done;}
    ssize_t n=send(loader,bytes+used,length-used,MSG_NOSIGNAL);
    if(n<0&&(errno==EINTR||errno==EAGAIN||errno==EWOULDBLOCK))continue;
    if(n<=0){result=TOOL_SEND_FAILED;goto done;}used+=(size_t)n;
  }
  // elfldr's ordinary raw-ELF stream is terminated with a TCP write-half close.
  shutdown(loader,SHUT_WR);close(loader);loader=-1;
  tool_stage="relay observation";
  at=tool_millis();if(at<0){result=TOOL_UNCONFIRMED;goto done;}deadline=at+TOOL_READY_MS;
  result=TOOL_UNCONFIRMED;
  while(tool_millis()>=0&&tool_millis()<deadline){
    if(tool_relay_occupied()>0){result=TOOL_STARTED;break;}
    poll(NULL,0,TOOL_READY_MS<1000?10:100);
  }
done:
  tool_error=errno;
  if(loader>=0)close(loader);if(payload>=0)close(payload);free(bytes);close(lockfd);return result;
}
