// SPDX-License-Identifier: MIT
// Raw DEFLATE (RFC 1951) decoder for the updater's zip entries. Input comes from a callback and output leaves
// through a callback in 32 KiB pieces (the back-reference window), so a 57 MB eboot never sits in memory.
// Canonical Huffman codes are decoded one bit at a time: a few seconds for a whole release on the console.
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

typedef struct {
  int (*read)(void *ctx, uint8_t *buf, size_t size);           // bytes read, 0 at the end, < 0 on error
  void *read_ctx;
  int (*write)(void *ctx, const uint8_t *data, size_t size);   // 0 on success
  void *write_ctx;
  uint8_t in[65536];
  size_t in_pos, in_len;
  uint32_t bits;
  int bit_count;
  uint8_t window[32768];
  size_t window_pos;
  uint64_t total;  // bytes written so far
  int error;       // 1: bad data or input/output failure
} inf_state;

typedef struct {
  int16_t count[16];
  int16_t symbol[320];
} inf_huffman;

static int inf_byte(inf_state *z) {
  if (z->in_pos == z->in_len) {
    const int n = z->read(z->read_ctx, z->in, sizeof(z->in));
    if (n <= 0) { z->error = 1; return -1; }
    z->in_len = (size_t)n;
    z->in_pos = 0;
  }
  return z->in[z->in_pos++];
}

static uint32_t inf_bits(inf_state *z, int need) {
  while (z->bit_count < need) {
    const int c = inf_byte(z);
    if (c < 0) return 0;
    z->bits |= (uint32_t)c << z->bit_count;
    z->bit_count += 8;
  }
  const uint32_t value = need == 32 ? z->bits : z->bits & ((1u << need) - 1);
  z->bits >>= need;
  z->bit_count -= need;
  return value;
}

static int inf_flush(inf_state *z) {
  if (z->window_pos && z->write(z->write_ctx, z->window, z->window_pos)) { z->error = 1; return -1; }
  return 0;
}

static void inf_put(inf_state *z, uint8_t b) {
  z->window[z->window_pos++] = b;
  z->total++;
  if (z->window_pos == sizeof(z->window)) {
    inf_flush(z);
    z->window_pos = 0;
  }
}

// Lengths to a canonical code. Returns < 0 for an over-subscribed set; incomplete sets are allowed (a lone
// distance code), and decoding a code that is not there is an error.
static int inf_build(inf_huffman *h, const uint8_t *length, int n) {
  int16_t offsets[16];
  memset(h->count, 0, sizeof(h->count));
  for (int s = 0; s < n; ++s) h->count[length[s]]++;
  if (h->count[0] == n) return 0;
  int left = 1;
  for (int len = 1; len < 16; ++len) {
    left <<= 1;
    left -= h->count[len];
    if (left < 0) return -1;
  }
  offsets[1] = 0;
  for (int len = 1; len < 15; ++len) offsets[len + 1] = (int16_t)(offsets[len] + h->count[len]);
  for (int s = 0; s < n; ++s)
    if (length[s]) h->symbol[offsets[length[s]]++] = (int16_t)s;
  return left;
}

static int inf_decode(inf_state *z, const inf_huffman *h) {
  int code = 0, first = 0, index = 0;
  for (int len = 1; len < 16; ++len) {
    code |= (int)inf_bits(z, 1);
    if (z->error) return -1;
    const int count = h->count[len];
    if (code - count < first) return h->symbol[index + (code - first)];
    index += count;
    first += count;
    first <<= 1;
    code <<= 1;
  }
  z->error = 1;
  return -1;
}

static const uint16_t inf_length_base[29] = {3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
                                             35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
static const uint8_t inf_length_extra[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
                                             3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
static const uint16_t inf_distance_base[30] = {1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129,
                                               193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097,
                                               6145, 8193, 12289, 16385, 24577};
static const uint8_t inf_distance_extra[30] = {0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6,
                                               6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

static int inf_codes(inf_state *z, const inf_huffman *lengths, const inf_huffman *distances) {
  for (;;) {
    int symbol = inf_decode(z, lengths);
    if (symbol < 0) return -1;
    if (symbol < 256) {
      inf_put(z, (uint8_t)symbol);
      if (z->error) return -1;
      continue;
    }
    if (symbol == 256) return 0;
    symbol -= 257;
    if (symbol >= 29) { z->error = 1; return -1; }
    const unsigned length = inf_length_base[symbol] + inf_bits(z, inf_length_extra[symbol]);
    const int d = inf_decode(z, distances);
    if (d < 0 || d >= 30) { z->error = 1; return -1; }
    const unsigned distance = inf_distance_base[d] + inf_bits(z, inf_distance_extra[d]);
    if (z->error || distance > z->total || distance > sizeof(z->window)) { z->error = 1; return -1; }
    for (unsigned i = 0; i < length; ++i) {
      const uint8_t b = z->window[(z->window_pos + sizeof(z->window) - distance) % sizeof(z->window)];
      inf_put(z, b);
    }
    if (z->error) return -1;
  }
}

static int inf_stored(inf_state *z) {
  z->bits = 0;  // the rest of the current byte
  z->bit_count = 0;
  const unsigned len = inf_bits(z, 16), nlen = inf_bits(z, 16);
  if (z->error || (len ^ 0xffffu) != nlen) { z->error = 1; return -1; }
  for (unsigned i = 0; i < len; ++i) {
    const int c = inf_byte(z);
    if (c < 0) return -1;
    inf_put(z, (uint8_t)c);
  }
  return z->error ? -1 : 0;
}

static int inf_fixed(inf_state *z) {
  static inf_huffman lengths, distances;
  static int built;
  if (!built) {
    uint8_t l[288];
    int s = 0;
    for (; s < 144; ++s) l[s] = 8;
    for (; s < 256; ++s) l[s] = 9;
    for (; s < 280; ++s) l[s] = 7;
    for (; s < 288; ++s) l[s] = 8;
    inf_build(&lengths, l, 288);
    for (s = 0; s < 30; ++s) l[s] = 5;
    inf_build(&distances, l, 30);
    built = 1;
  }
  return inf_codes(z, &lengths, &distances);
}

static int inf_dynamic(inf_state *z) {
  static const uint8_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
  uint8_t l[320];
  inf_huffman lengths, distances;
  const int nlen = (int)inf_bits(z, 5) + 257, ndist = (int)inf_bits(z, 5) + 1, ncode = (int)inf_bits(z, 4) + 4;
  if (z->error || nlen > 286 || ndist > 30) { z->error = 1; return -1; }
  memset(l, 0, sizeof(l));
  for (int i = 0; i < ncode; ++i) l[order[i]] = (uint8_t)inf_bits(z, 3);
  if (z->error || inf_build(&lengths, l, 19) != 0) { z->error = 1; return -1; }  // must be complete
  for (int i = 0; i < nlen + ndist;) {
    int symbol = inf_decode(z, &lengths);
    if (symbol < 0) return -1;
    if (symbol < 16) { l[i++] = (uint8_t)symbol; continue; }
    uint8_t value = 0;
    int repeat;
    if (symbol == 16) {
      if (i == 0) { z->error = 1; return -1; }
      value = l[i - 1];
      repeat = 3 + (int)inf_bits(z, 2);
    } else if (symbol == 17) {
      repeat = 3 + (int)inf_bits(z, 3);
    } else {
      repeat = 11 + (int)inf_bits(z, 7);
    }
    if (z->error || i + repeat > nlen + ndist) { z->error = 1; return -1; }
    while (repeat--) l[i++] = value;
  }
  if (l[256] == 0) { z->error = 1; return -1; }  // no end-of-block code
  const int a = inf_build(&lengths, l, nlen);
  if (a < 0 || (a > 0 && nlen - lengths.count[0] != 1)) { z->error = 1; return -1; }
  const int b = inf_build(&distances, l + nlen, ndist);
  if (b < 0 || (b > 0 && ndist - distances.count[0] != 1)) { z->error = 1; return -1; }
  return inf_codes(z, &lengths, &distances);
}

// Inflates the whole stream. Returns 0 on success.
static int inf_run(inf_state *z) {
  z->in_pos = z->in_len = 0;
  z->bits = 0;
  z->bit_count = 0;
  z->window_pos = 0;
  z->total = 0;
  z->error = 0;
  int last;
  do {
    last = (int)inf_bits(z, 1);
    const int type = (int)inf_bits(z, 2);
    if (z->error) return -1;
    int r;
    if (type == 0) r = inf_stored(z);
    else if (type == 1) r = inf_fixed(z);
    else if (type == 2) r = inf_dynamic(z);
    else { z->error = 1; return -1; }
    if (r) return -1;
  } while (!last);
  return inf_flush(z);
}
