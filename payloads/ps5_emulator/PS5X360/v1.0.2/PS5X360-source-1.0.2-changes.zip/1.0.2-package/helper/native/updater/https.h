// SPDX-License-Identifier: MIT
// HTTPS GET for the updater over Mbed TLS (the same library and CA roots as the AutoLog collector): certificate
// and host name checked, redirects followed only to GitHub's own hosts, Content-Length and chunked bodies.
#pragma once
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include "mbedtls/ctr_drbg.h"
#include "mbedtls/entropy.h"
#include "mbedtls/error.h"
#include "mbedtls/ssl.h"
#include "mbedtls/x509_crt.h"
#include "psa/crypto.h"

#ifdef PS5
#include <sys/sysctl.h>
extern int sceNetInit(void);
extern int sceNetPoolCreate(const char *, int, int);
extern int sceNetResolverCreate(const char *, int, int);
extern int sceNetResolverStartNtoa(int, const char *, struct in_addr *, int, int, int);
extern int sceNetResolverDestroy(int);
#else
#include <sys/random.h>
#endif

#include "roots.h"  // CA_ROOTS: Mozilla's roots, generated for the AutoLog collector

typedef struct {
  int (*on_length)(void *ctx, long long length);  // optional; -1 when the server sends none
  int (*on_data)(void *ctx, const uint8_t *data, size_t size);  // 0 to go on
  void *ctx;
} upd_sink;

// Inside the PS5X360 Helper the AutoLog collector already supplies this entropy source (same sources).
#ifndef UPD_NO_HARDWARE_POLL
int mbedtls_hardware_poll(void *context, unsigned char *output, size_t len, size_t *olen) {
  (void)context;
  *olen = 0;
#ifdef PS5
  int mib[2] = {CTL_KERN, KERN_ARND};
  while (*olen < len) {
    size_t n = len - *olen;
    if (n > 256) n = 256;
    if (sysctl(mib, 2, output + *olen, &n, NULL, 0) || !n) {
      FILE *random = fopen("/dev/urandom", "rb");
      if (!random) return MBEDTLS_ERR_ENTROPY_SOURCE_FAILED;
      const size_t needed = len - *olen, got = fread(output + *olen, 1, needed, random);
      fclose(random);
      if (got != needed) return MBEDTLS_ERR_ENTROPY_SOURCE_FAILED;
      *olen += got;
      break;
    }
    *olen += n;
  }
#else
  while (*olen < len) {
    const ssize_t n = getrandom(output + *olen, len - *olen, 0);
    if (n < 0 && errno == EINTR) continue;
    if (n <= 0) return MBEDTLS_ERR_ENTROPY_SOURCE_FAILED;
    *olen += (size_t)n;
  }
#endif
  return 0;
}
#endif

// The Helper serialises its HTTPS requests with the collector's (one Mbed TLS/PSA state per process).
#ifndef UPD_NET_LOCK
#define UPD_NET_LOCK() ((void)0)
#define UPD_NET_UNLOCK() ((void)0)
#endif

static struct {
  int ready;
  mbedtls_entropy_context entropy;
  mbedtls_ctr_drbg_context rng;
  mbedtls_x509_crt roots;
  mbedtls_ssl_config conf;
} upd_tls;

static int upd_tls_init(char *error, size_t error_size) {
  if (upd_tls.ready) return 0;
  int r = (int)psa_crypto_init();
  if (r) { snprintf(error, error_size, "crypto init %d", r); return -1; }
  mbedtls_entropy_init(&upd_tls.entropy);
  mbedtls_ctr_drbg_init(&upd_tls.rng);
  mbedtls_x509_crt_init(&upd_tls.roots);
  mbedtls_ssl_config_init(&upd_tls.conf);
  if ((r = mbedtls_ctr_drbg_seed(&upd_tls.rng, mbedtls_entropy_func, &upd_tls.entropy,
                                 (const unsigned char *)"PS5X360-Updater", 15)) ||
      (r = mbedtls_x509_crt_parse(&upd_tls.roots, (const unsigned char *)CA_ROOTS, sizeof(CA_ROOTS))) < 0 ||
      (r = mbedtls_ssl_config_defaults(&upd_tls.conf, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM,
                                       MBEDTLS_SSL_PRESET_DEFAULT))) {
    snprintf(error, error_size, "TLS setup %d", r);
    return -1;
  }
  mbedtls_ssl_conf_authmode(&upd_tls.conf, MBEDTLS_SSL_VERIFY_REQUIRED);
  mbedtls_ssl_conf_ca_chain(&upd_tls.conf, &upd_tls.roots, NULL);
  mbedtls_ssl_conf_rng(&upd_tls.conf, mbedtls_ctr_drbg_random, &upd_tls.rng);
  upd_tls.ready = 1;
  return 0;
}

static int upd_resolve(const char *host, struct in_addr *address) {
#ifdef PS5
  static int pool = -1;
  if (pool < 0) {
    sceNetInit();
    pool = sceNetPoolCreate("PS5X360Updater", 64 * 1024, 0);
    if (pool < 0) return -1;
  }
  const int resolver = sceNetResolverCreate("PS5X360Updater", pool, 0);
  if (resolver < 0) return -1;
  const int r = sceNetResolverStartNtoa(resolver, host, address, 5000000, 2, 0);
  sceNetResolverDestroy(resolver);
  return r < 0 ? -1 : 0;
#else
  struct addrinfo hints, *found = NULL;
  memset(&hints, 0, sizeof(hints));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  if (getaddrinfo(host, NULL, &hints, &found) || !found) return -1;
  *address = ((struct sockaddr_in *)found->ai_addr)->sin_addr;
  freeaddrinfo(found);
  return 0;
#endif
}

static int upd_send(void *ctx, const unsigned char *data, size_t len) {
  const ssize_t n = send(*(int *)ctx, data, len, 0);
  return n >= 0 ? (int)n : MBEDTLS_ERR_SSL_INTERNAL_ERROR;
}
static int upd_recv(void *ctx, unsigned char *data, size_t len) {
  const ssize_t n = recv(*(int *)ctx, data, len, 0);
  return n >= 0 ? (int)n : MBEDTLS_ERR_SSL_INTERNAL_ERROR;
}

typedef struct {
  mbedtls_ssl_context ssl;
  int fd;
  unsigned char buf[16384];
  size_t pos, len;
  int closed;
} upd_conn;

static int upd_fill(upd_conn *c) {
  if (c->closed) return 0;
  for (;;) {
    const int n = mbedtls_ssl_read(&c->ssl, c->buf, sizeof(c->buf));
    if (n == MBEDTLS_ERR_SSL_WANT_READ || n == MBEDTLS_ERR_SSL_WANT_WRITE) continue;
#ifdef MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET
    if (n == MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET) continue;
#endif
    if (n == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY || n == 0) { c->closed = 1; return 0; }
    if (n < 0) return n;
    c->pos = 0;
    c->len = (size_t)n;
    return n;
  }
}

static int upd_getc(upd_conn *c) {
  if (c->pos == c->len && upd_fill(c) <= 0) return -1;
  return c->buf[c->pos++];
}

static int upd_line(upd_conn *c, char *out, size_t size) {
  size_t n = 0;
  for (;;) {
    const int ch = upd_getc(c);
    if (ch < 0) return -1;
    if (ch == '\n') break;
    if (ch != '\r' && n + 1 < size) out[n++] = (char)ch;
  }
  out[n] = 0;
  return (int)n;
}

// Hands `count` body bytes (or all until the connection closes, count < 0) to the sink.
static int upd_body(upd_conn *c, long long count, const upd_sink *sink) {
  while (count != 0) {
    if (c->pos == c->len) {
      const int n = upd_fill(c);
      if (n < 0) return -1;
      if (n == 0) return count < 0 ? 0 : -1;
    }
    size_t take = c->len - c->pos;
    if (count > 0 && (long long)take > count) take = (size_t)count;
    if (sink->on_data(sink->ctx, c->buf + c->pos, take)) return -2;
    c->pos += take;
    if (count > 0) count -= (long long)take;
  }
  return 0;
}

static int upd_host_allowed(const char *host) {
  static const char *suffixes[] = {".githubusercontent.com", ".github.com"};
  if (!strcmp(host, "github.com") || !strcmp(host, "api.github.com")) return 1;
  const size_t n = strlen(host);
  for (size_t i = 0; i < sizeof(suffixes) / sizeof(suffixes[0]); ++i) {
    const size_t m = strlen(suffixes[i]);
    if (n > m && !strcmp(host + n - m, suffixes[i])) return 1;
  }
  return 0;
}

#ifndef PS5
// Host tests only: with UPDATER_FAKE_GITHUB set, an address is answered from the file in that folder named after
// the address's last part ("latest", "releases?per_page=10", "PPSA50011.zip"); a file "offline" there acts as a
// DNS failure. The PS5 build has no such path.
static int upd_fake_get(const char *url, const upd_sink *sink, char *error, size_t error_size) {
  const char *dir = getenv("UPDATER_FAKE_GITHUB"), *name = strrchr(url, '/');
  char path[4096];
  snprintf(path, sizeof(path), "%s/offline", dir);
  if (!access(path, F_OK)) { snprintf(error, error_size, "DNS failed for api.github.com"); return -1; }
  snprintf(path, sizeof(path), "%s/%s", dir, name ? name + 1 : url);
  FILE *f = fopen(path, "rb");
  if (!f) { snprintf(error, error_size, "HTTP 404 from api.github.com"); return 404; }
  fseek(f, 0, SEEK_END);
  const long long length = ftell(f);
  fseek(f, 0, SEEK_SET);
  if (sink->on_length && sink->on_length(sink->ctx, length)) { fclose(f); return -2; }
  static uint8_t buf[1 << 16];
  size_t n;
  int status = 200;
  while (status == 200 && (n = fread(buf, 1, sizeof(buf), f)) > 0)
    if (sink->on_data(sink->ctx, buf, n)) { snprintf(error, error_size, "download stopped"); status = -2; }
  fclose(f);
  return status;
}
#endif

// GET url into sink. Returns the final HTTP status (200 on success), or < 0 with error set.
static int upd_get_once(const char *url, const char *accept, const upd_sink *sink, char *error, size_t error_size) {
  static char current[4096], header[8192], location[4096];
#ifndef PS5
  if (getenv("UPDATER_FAKE_GITHUB")) return upd_fake_get(url, sink, error, error_size);
#endif
  snprintf(current, sizeof(current), "%s", url);
  if (upd_tls_init(error, error_size)) return -1;
  for (int hop = 0; hop < 6; ++hop) {
    char host[256];
    const char *path;
    if (strncmp(current, "https://", 8)) { snprintf(error, error_size, "not an https address"); return -1; }
    const char *h = current + 8;
    path = strchr(h, '/');
    const size_t host_len = path ? (size_t)(path - h) : strlen(h);
    if (!host_len || host_len >= sizeof(host)) { snprintf(error, error_size, "bad address"); return -1; }
    memcpy(host, h, host_len);
    host[host_len] = 0;
    if (!path) path = "/";
    if (!upd_host_allowed(host)) { snprintf(error, error_size, "refused host %s", host); return -1; }

    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(443);
    if (upd_resolve(host, &address.sin_addr)) { snprintf(error, error_size, "DNS failed for %s", host); return -1; }
    static upd_conn c;
    memset(&c.pos, 0, sizeof(c) - offsetof(upd_conn, pos));
    c.fd = socket(AF_INET, SOCK_STREAM, 0);
    if (c.fd < 0) { snprintf(error, error_size, "socket %d", errno); return -1; }
    struct timeval timeout = {30, 0};
    setsockopt(c.fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(c.fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    if (connect(c.fd, (struct sockaddr *)&address, sizeof(address))) {
      snprintf(error, error_size, "connect to %s: %d", host, errno);
      close(c.fd);
      return -1;
    }
    mbedtls_ssl_init(&c.ssl);
    int status = -1, r;
    if ((r = mbedtls_ssl_setup(&c.ssl, &upd_tls.conf)) || (r = mbedtls_ssl_set_hostname(&c.ssl, host))) {
      snprintf(error, error_size, "TLS %d", r);
      goto out;
    }
    mbedtls_ssl_set_bio(&c.ssl, &c.fd, upd_send, upd_recv, NULL);
    while ((r = mbedtls_ssl_handshake(&c.ssl)) == MBEDTLS_ERR_SSL_WANT_READ || r == MBEDTLS_ERR_SSL_WANT_WRITE) {}
    if (r) {
      const uint32_t flags = mbedtls_ssl_get_verify_result(&c.ssl);
      if (flags & (MBEDTLS_X509_BADCERT_EXPIRED | MBEDTLS_X509_BADCERT_FUTURE))
        snprintf(error, error_size, "certificate date refused: check the console's clock");
      else
        snprintf(error, error_size, "TLS handshake with %s: -0x%04x (verify 0x%x)", host, -r, (unsigned)flags);
      goto out;
    }
    {
      const int n = snprintf(header, sizeof(header),
                             "GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: PS5X360-Updater/1.0\r\nAccept: %s\r\n"
                             "X-GitHub-Api-Version: 2022-11-28\r\nConnection: close\r\n\r\n",
                             path, host, accept);
      if (n <= 0 || n >= (int)sizeof(header)) { snprintf(error, error_size, "address too long"); goto out; }
      for (int sent = 0; sent < n;) {
        const int w = mbedtls_ssl_write(&c.ssl, (const unsigned char *)header + sent, (size_t)(n - sent));
        if (w == MBEDTLS_ERR_SSL_WANT_READ || w == MBEDTLS_ERR_SSL_WANT_WRITE) continue;
        if (w <= 0) { snprintf(error, error_size, "send %d", w); goto out; }
        sent += w;
      }
    }
    if (upd_line(&c, header, sizeof(header)) < 0 || sscanf(header, "HTTP/1.%*d %d", &status) != 1) {
      snprintf(error, error_size, "no HTTP answer from %s", host);
      status = -1;
      goto out;
    }
    {
      long long length = -1;
      int chunked = 0;
      location[0] = 0;
      for (;;) {
        const int n = upd_line(&c, header, sizeof(header));
        if (n < 0) { snprintf(error, error_size, "headers cut"); status = -1; goto out; }
        if (n == 0) break;
        if (!strncasecmp(header, "content-length:", 15)) length = strtoll(header + 15, NULL, 10);
        else if (!strncasecmp(header, "transfer-encoding:", 18) && strstr(header, "chunked")) chunked = 1;
        else if (!strncasecmp(header, "location:", 9)) {
          const char *v = header + 9;
          while (*v == ' ') ++v;
          snprintf(location, sizeof(location), "%s", v);
        }
      }
      if (status >= 300 && status < 400 && location[0]) {
        snprintf(current, sizeof(current), "%s", location);
        mbedtls_ssl_close_notify(&c.ssl);
        mbedtls_ssl_free(&c.ssl);
        close(c.fd);
        continue;
      }
      if (status != 200) { snprintf(error, error_size, "HTTP %d from %s", status, host); goto out; }
      if (sink->on_length && sink->on_length(sink->ctx, chunked ? -1 : length)) { status = -2; goto out; }
      if (!chunked) {
        r = upd_body(&c, length, sink);
      } else {
        r = 0;
        for (;;) {
          if (upd_line(&c, header, sizeof(header)) < 0) { r = -1; break; }
          const long long size = strtoll(header, NULL, 16);
          if (size < 0) { r = -1; break; }
          if (size == 0) break;
          if ((r = upd_body(&c, size, sink))) break;
          if (upd_line(&c, header, sizeof(header)) < 0) { r = -1; break; }
        }
      }
      if (r) {
        snprintf(error, error_size, r == -2 ? "download stopped" : "download cut");
        status = r == -2 ? -2 : -1;
      }
    }
  out:
    mbedtls_ssl_free(&c.ssl);
    close(c.fd);
    return status;
  }
  snprintf(error, error_size, "too many redirects");
  return -1;
}

static int upd_get(const char *url, const char *accept, const upd_sink *sink, char *error, size_t error_size) {
  UPD_NET_LOCK();
  const int status = upd_get_once(url, accept, sink, error, error_size);
  UPD_NET_UNLOCK();
  return status;
}
