// SPDX-License-Identifier: MIT
// The PS5X360 Updater (native/updater) compiled as a module of the PS5X360 Helper: its own translation unit, so its
// static names stay apart from the collector's. See native/updater/updater_module.h.
#define UPD_MODULE 1
#include "../updater/updater.c"
