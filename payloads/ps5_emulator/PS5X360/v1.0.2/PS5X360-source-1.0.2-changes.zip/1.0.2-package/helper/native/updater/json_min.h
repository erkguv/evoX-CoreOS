// SPDX-License-Identifier: MIT
// A small JSON tokenizer for the updater: GitHub's release answer and the package's MANIFEST.json. Tokens point
// into the text; nothing is copied until a string is asked for.
#pragma once
#include <stdlib.h>
#include <string.h>

enum { JM_OBJECT = 1, JM_ARRAY, JM_STRING, JM_PRIMITIVE };

typedef struct {
  int type;
  int start, end;  // text[start, end): for strings without the quotes
  int size;        // children: members (key + value pairs count as 2) or elements
  int next;        // the token after this one and everything inside it
} jm_token;

typedef struct {
  const char *text;
  int length;
  jm_token *tokens;
  int count, capacity;
} jm_doc;

static int jm_new(jm_doc *d, int type, int start) {
  if (d->count == d->capacity) {
    const int capacity = d->capacity ? d->capacity * 2 : 256;
    jm_token *grown = (jm_token *)realloc(d->tokens, (size_t)capacity * sizeof(jm_token));
    if (!grown) return -1;
    d->tokens = grown;
    d->capacity = capacity;
  }
  jm_token *t = &d->tokens[d->count];
  t->type = type;
  t->start = start;
  t->end = start;
  t->size = 0;
  t->next = 0;
  return d->count++;
}

static void jm_space(const jm_doc *d, int *at) {
  while (*at < d->length && (d->text[*at] == ' ' || d->text[*at] == '\n' || d->text[*at] == '\r' || d->text[*at] == '\t')) ++*at;
}

static int jm_value(jm_doc *d, int *at, int depth);

static int jm_string(jm_doc *d, int *at) {
  const int t = jm_new(d, JM_STRING, *at + 1);
  if (t < 0) return -1;
  for (++*at; *at < d->length; ++*at) {
    const char c = d->text[*at];
    if (c == '\\') { ++*at; continue; }
    if (c == '"') {
      d->tokens[t].end = *at;
      ++*at;
      d->tokens[t].next = d->count;
      return t;
    }
    if ((unsigned char)c < 0x20) return -1;
  }
  return -1;
}

static int jm_value(jm_doc *d, int *at, int depth) {
  if (depth > 32) return -1;
  jm_space(d, at);
  if (*at >= d->length) return -1;
  const char c = d->text[*at];
  if (c == '"') return jm_string(d, at);
  if (c == '{' || c == '[') {
    const int t = jm_new(d, c == '{' ? JM_OBJECT : JM_ARRAY, *at);
    if (t < 0) return -1;
    const char close = c == '{' ? '}' : ']';
    ++*at;
    jm_space(d, at);
    if (*at < d->length && d->text[*at] == close) {
      ++*at;
      d->tokens[t].end = *at;
      d->tokens[t].next = d->count;
      return t;
    }
    for (;;) {
      if (c == '{') {
        jm_space(d, at);
        if (*at >= d->length || d->text[*at] != '"' || jm_string(d, at) < 0) return -1;
        jm_space(d, at);
        if (*at >= d->length || d->text[*at] != ':') return -1;
        ++*at;
        d->tokens[t].size++;
      }
      if (jm_value(d, at, depth + 1) < 0) return -1;
      d->tokens[t].size++;
      jm_space(d, at);
      if (*at >= d->length) return -1;
      if (d->text[*at] == ',') { ++*at; continue; }
      if (d->text[*at] != close) return -1;
      ++*at;
      d->tokens[t].end = *at;
      d->tokens[t].next = d->count;
      return t;
    }
  }
  const int t = jm_new(d, JM_PRIMITIVE, *at);
  if (t < 0) return -1;
  while (*at < d->length && !strchr(",}] \n\r\t", d->text[*at])) ++*at;
  d->tokens[t].end = *at;
  d->tokens[t].next = d->count;
  return d->tokens[t].end > d->tokens[t].start ? t : -1;
}

// Parses text (not copied: it must outlive the document). Returns 0 on success.
static int jm_parse(jm_doc *d, const char *text, int length) {
  memset(d, 0, sizeof(*d));
  d->text = text;
  d->length = length;
  int at = 0;
  if (jm_value(d, &at, 0) != 0) return -1;
  jm_space(d, &at);
  return at == length ? 0 : -1;
}

static void jm_free(jm_doc *d) {
  free(d->tokens);
  d->tokens = NULL;
}

static int jm_equals(const jm_doc *d, int t, const char *s) {
  const int n = (int)strlen(s);
  return t >= 0 && d->tokens[t].type == JM_STRING && d->tokens[t].end - d->tokens[t].start == n &&
         !memcmp(d->text + d->tokens[t].start, s, (size_t)n);
}

// The value of key in object t, or -1.
static int jm_get(const jm_doc *d, int t, const char *key) {
  if (t < 0 || d->tokens[t].type != JM_OBJECT) return -1;
  int k = t + 1;
  for (int i = 0; i < d->tokens[t].size / 2; ++i) {
    const int v = k + 1;
    if (jm_equals(d, k, key)) return v;
    k = d->tokens[v].next;
  }
  return -1;
}

// Element i of array t, or -1.
static int jm_at(const jm_doc *d, int t, int i) {
  if (t < 0 || d->tokens[t].type != JM_ARRAY || i >= d->tokens[t].size) return -1;
  int e = t + 1;
  while (i--) e = d->tokens[e].next;
  return e;
}

// A string value unescaped into out (ASCII escapes and \u00XX; other \u become '?'). 0 on success.
static int jm_string_of(const jm_doc *d, int t, char *out, size_t size) {
  if (t < 0 || d->tokens[t].type != JM_STRING || !size) return -1;
  size_t n = 0;
  for (int i = d->tokens[t].start; i < d->tokens[t].end; ++i) {
    char c = d->text[i];
    if (c == '\\' && i + 1 < d->tokens[t].end) {
      c = d->text[++i];
      if (c == 'n') c = '\n';
      else if (c == 't') c = '\t';
      else if (c == 'r') c = '\r';
      else if (c == 'b') c = '\b';
      else if (c == 'f') c = '\f';
      else if (c == 'u' && i + 4 < d->tokens[t].end) {
        char hex[5] = {d->text[i + 1], d->text[i + 2], d->text[i + 3], d->text[i + 4], 0};
        const long code = strtol(hex, NULL, 16);
        c = code > 0 && code < 0x80 ? (char)code : '?';
        i += 4;
      }
    }
    if (n + 1 >= size) return -1;
    out[n++] = c;
  }
  out[n] = 0;
  return 0;
}

static long long jm_number(const jm_doc *d, int t) {
  if (t < 0 || d->tokens[t].type != JM_PRIMITIVE) return -1;
  return strtoll(d->text + d->tokens[t].start, NULL, 10);
}

static int jm_true(const jm_doc *d, int t) {
  return t >= 0 && d->tokens[t].type == JM_PRIMITIVE && !strncmp(d->text + d->tokens[t].start, "true", 4);
}
