# PS5X360 Helper 1.2.0

`PS5X360-Helper.elf` is the one payload a PS5X360 user puts in the etaHEN autoload folder. Each boot it keeps
PS5X360 up to date from the GitHub releases, keeps the Kinect tracker running, and runs the AutoLog collector
exactly as the 1.1 Tool did. The build also writes `PS5X360-Tool.elf` (and the older `PS5X360-AutoLog.elf`) with
identical bytes, so an autoload entry that already names the Tool keeps working. Put only one of the names in
the autoload folder (a second one is harmless: it only asks the first for another update check).

It follows the documented behaviour of the PS5SX2 Helper and Installer (github.com/Swordpdf/PS5SX2,
`ps5/installer/README.md`, GPL-3.0); no code was taken from it. This code is MIT, except the SDK adapter noted at
the end.

## What it does when it is loaded

The first copy loaded after a boot takes `PPSA50011/helper/helper.lock` and stays resident:

1. **AutoLog collector:** starts at once, with the same consent notice, notification, opt-out markers, lock and
   behaviour as the 1.1 Tool (see "AutoLog collector" below). Reporting off does not turn the rest off.
2. **Update check:** one check of the latest PS5X360 release, with the rules of the PS5X360 Updater
   (`native/updater/README.md`): size and SHA-256 published by GitHub, every file checked against the zip and the
   package's `MANIFEST.json`, an install journal, backups of replaced files, settings you changed kept (the new copy
   goes beside them as `<name>.new`), `eboot.bin` placed last, nothing installed while PS5X360 is open, a
   notification at each step (Portuguese on a console set to Portuguese, English otherwise). When GitHub cannot be
   reached (the console may still be connecting) the check is tried again after 30 s, 2 min and 10 min; only the
   last try shows a failure notification.
3. **Kinect link:** submits `PPSA50011/tools/kinect-tracker.elf` to the local ELF loader (127.0.0.1:9021) unless
   `PPSA50011/no-kinect-start` exists, and asks for one calibration (`/data/kinect-tracker.calibrate`) once it runs,
   as the 1.1 Tool did. The tracker shows its own notification when it does the calibration with the camera on.

A **later copy** loaded in the same boot (another autoload entry, or a manual send) does not supervise anything:
it writes `helper/request-update` so the resident copy checks for an update now, writes `helper/kinect-request`
with `start` when `helper/kinect-state.txt` says `tracker=failed`, shows "PS5X360 Helper is already running:
checking for updates", then runs the collector as the 1.1 Tool did. That leaves at once while the resident
collector holds `autolog/collector.lock`; if the collector is not running (for example it was switched off and on
again), this copy becomes the collector, as loading the 1.1 Tool again did.

## While resident

- **Updates** (a look every 5 s, cheap): a release staged while PS5X360 was open is installed as soon as PS5X360 is
  closed. There is no 20-minute limit as in the standalone updater. If PS5X360 is opened while files are being
  placed, the journal lets the next look finish the install once it is closed. `helper/request-update` (any
  content) asks for a check now; the request file is consumed.
- **Kinect link** (a look every second, cheap: one bind probe of the relay port, one rename attempt, a size check
  of the tracker log):
  - The tracker has gone when relay port 9301 has been free for 5 s and no stop was asked for. It is started again
    after 10 s, 30 s, 1 min, 2 min, then 5 min between tries; a run of 10 minutes starts that list again. At most 5
    automatic restarts in any hour; then one notification and a pause until the hour allows another. Each restart
    shows "PS5X360 Helper: Kinect tracker restarted". The 1.1 Tool's 60-second submission cooldown
    (`autolog/kinect-last-submit.txt`) still applies to automatic starts. A missing or rejected tracker file is
    looked at again every 5 minutes, and at once after an update.
  - Never two at once: a submission is made only while the relay port is free and no other submission is waiting
    (up to 20 s for the tracker to open the port); `autolog/kinect-launch.lock` keeps other copies out; the tracker
    itself leaves when the port is taken.
  - A stop file (`/data/kinect-tracker.stop`) written by someone else, followed by the tracker leaving, means
    stopped: no restart until a `start` or `restart` request.
  - After an update replaced `tools/kinect-tracker.elf` with different bytes, the tracker is restarted with the new
    bytes once PS5X360 is closed (started, if it was not running; nothing, if it was stopped on request).
  - The relay port is only probed by binding it. The Helper never connects to it: the relay serves one data client.
    A busy port shows that something holds it, not that it is our tracker or that the camera works.
- With reporting off, or after the collector stopped, the Helper stays resident for updates and the Kinect link.
  It has no exit switch: it ends with the console (or when its process is killed).

## Files

All under `/data/homebrew/PPSA50011/`.

| File | What it is |
| --- | --- |
| `helper/status.txt` | `helper=PS5X360 Helper 1.2.0`, `pid`, `resident`, `started`, `last_change` (epochs), `update` (what the last check or install did), `update_pending` (the tag waiting for PS5X360 to close, or `none`), `logger`, `kinect` (one-line summary). |
| `helper/kinect-state.txt` | `tracker=starting\|running\|stopped\|failed\|disabled`, `camera=present\|absent\|unknown`, `relay=busy\|free` (`unknown` when the probe itself failed), `tracker_sha256` (the bytes submitted, or the file's when it was found running), `restarts` (automatic, this boot), `last_change` (epoch), `reason` (one line). Rewritten only when something in it changes. |
| `helper/kinect-request` | One word: `start`, `stop`, `restart` or `calibrate` (case ignored). It is consumed (renamed away, then removed) before it acts. `stop` writes `/data/kinect-tracker.stop` and waits for the relay port to free; `restart` is a stop then a start; `calibrate` writes `/data/kinect-tracker.calibrate` when the tracker runs. A `stop`, `restart` or `calibrate` that arrives while a submitted tracker is still starting waits until it has settled (a starting tracker removes the stop file). Other words are consumed and ignored. |
| `helper/request-update` | Any content: check for an update now. Consumed. |
| `helper/helper.log` | What the Helper decided and why (512 KiB, then `helper.log.old`). |
| `updater/…` | The updater's own state and log, as for the standalone updater. |
| `autolog/kinect-status.txt` | The last tracker launch attempt, as the 1.1 Tool wrote it. |

`camera` comes from the tracker log's lines (`native/kinect/kinect_tracker.c`): `camera … opened read/write` and
`camera busy` give `present`; `camera … is gone` and `camera not found` give `absent`; no tracker, a tracker start
(`KTRACKER …`) or `stopping`/`exit` give `unknown`.

## Switches (turning parts off)

- Logs: an empty `PPSA50011/no-log-upload` (or `PPSA50011/autolog/no-log-upload`) stops reporting, as before.
  Neither marker is ever deleted or rewritten.
- Updates: `PPSA50011/updater/no-update`. The other updater switches still apply: `force` (install the latest
  release even when it is not newer, used once), `check-only`, `beta` (also pre-releases), `test-root`.
- Kinect: `PPSA50011/no-kinect-start` stops every automatic start (at load and restarts); it does not stop a running
  tracker, and explicit requests still act. To stop a running tracker, write `stop` to `helper/kinect-request`.

## Build and test

```
docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" -w /ws/Xbox360PS5 \
  -e PS5_PAYLOAD_SDK=/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk castation-buildenv bash tools/build-native-autolog.sh
docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" -w /ws/Xbox360PS5 xbox360ps5-radv-buildenv python3 tools/check-native-autolog-tool.py
docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" -w /ws/Xbox360PS5 xbox360ps5-radv-buildenv bash tools/check-native-autolog.sh
```

The build links `collector.c` with `helper_update.c` (the updater compiled as a module in its own translation
unit, `native/updater/updater_module.h`) and `libSceSystemService` (console language). It writes
`build/autolog-native/PS5X360-Helper.elf` plus the `PS5X360-Tool.elf` and `PS5X360-AutoLog.elf` copies; with
`HELPER_OUT=<folder>` it also copies the Helper and the Tool name there. `tools/check-native-autolog-elf.py` checks
every import against the SDK's modules, the relocation types, a nonzero entry, no shell/process imports, and the
self-launch marker. The standalone `PS5X360-Updater.elf` still builds with `tools/build-native-updater.sh ps5`.

`tools/check-native-autolog-tool.py` (host, ASan/UBSan, loopback and temporary folders only, durations divided by
100) runs the production Helper around a stand-in collector, with a fake ELF loader that starts a fake tracker
(binds the relay port, removes the stop file, writes camera lines, leaves on the stop file), a fake GitHub
(`UPDATER_FAKE_GITHUB`, host builds only) and a fake PS5X360 sandbox. It covers: missing, invalid, self and
malformed tracker files; loader down; `no-kinect-start` (and an explicit start despite it); a foreign relay never
connected to; launch lock and cooldown; a stalled loader; exact ELF streaming; camera states from the log;
`calibrate`, `restart`, `stop` and `start` requests consumed; no restart after a stop request or an outside stop
file; a dead tracker restarted, counted and notified, never two at once; the hourly cap with growing waits;
reporting opt-out leaving the Helper resident with Kinect on; an update staged while PS5X360 is open and installed
once it closes (settings kept, backup, last-update), followed by a tracker restart with the new bytes; a later copy
that triggers a check and a Kinect start and leaves; GitHub unreachable at load (quiet retry); `check-only` and
`force`. `tools/check-native-autolog.sh` keeps covering the collector (redaction, digest, opt-out, outbox,
deduplication).

## Not verified on the console

Helper 1.2.0 has only been built and tested on a host. Not yet seen on a PS5: the resident process staying up for a
whole session, the two threads and their stacks, the language lookup through `libSceSystemService` inside this
payload, sandbox detection of PS5X360 from this payload, the pending install after closing PS5X360, the
supervisor restarting a real tracker through the real loader, the camera state from a real tracker log, and the
autoload path of etaHEN. The 1.1 Tool's console results (below) and the standalone updater's (its README) do not
cover this build.

## AutoLog collector (unchanged from the 1.1 Tool)

### Reporting notice and opt-out

Loading this diagnostic ELF enables automatic sharing of game diagnostic logs
with the project's developer, including an activation connectivity check and
directory access diagnostics. A console notification announces reporting.
Reports contain the game name, emulator build and diagnostic log excerpts.
Games, saves, profiles, the complete library and unrelated application logs are
not read or uploaded. Lines containing credentials, addresses, URLs or private
source paths are removed on a best-effort basis. Other information printed by a
game may remain. Cloudflare and Discord process these reports; the receiving
channel is private, but the developer can read and retain its attachments.

To stop and prevent further uploads, create this empty file on the console:

`/data/homebrew/PPSA50011/no-log-upload`

The collector checks it between operations and immediately before sending.
An already submitted request cannot be recalled. Keep the marker in place
across boots; remove it and load the ELF again only when you want to resume.

The route is **PS5 game logs → verified HTTPS → Brino's Cloudflare relay → private `auto-log` Discord channel.**
A PC is not needed. Testers do not configure an account, webhook, relay address or password. The ELF has the
developer's report endpoint and a limited submission credential built in; it is recoverable from the distributed
client and grants report submission only. The Discord webhook and the owner's upload credential stay server-side.
Inside the Helper, the collector's HTTPS takes turns with the updater's (one Mbed TLS state per process); nothing
else about delivery changed.

### Activation check

When loaded, the collector sends a small **activation check** report through the same verified HTTPS endpoint and
public console credential used for game reports: the collector version and directory scan status, not game logs,
games or saves. It is sent once per collector process; failed attempts retry with backoff. It confirms transport
only. The last accepted report ID and acknowledgement are kept in `autolog/last-delivery.txt`.

### Collection and delivery

- Original game logs remain in `PPSA50011/logs`.
- `PPSA50011/autolog/NOTICE.txt`: reporting notice. `autolog/status.txt`: collector status, PID and check time.
- `autolog/last-delivery.txt`: last exact Discord receipt and report ID.
- `autolog/outbox`: at most 20 bounded reports, up to 20 MiB total. `*.seen`: session fingerprints.

Only sessions started after the persisted `autolog/collect-after.txt` UTC epoch are considered (also limited to the
last 24 hours, up to 30 per scan); on first activation this cutoff is the activation time. Launcher-only logs and
`boot.log` are excluded. A session is sent after a recorded native or guest crash, an explicit ENGINE EXIT/RESTART
line, `Guide: back to the launcher`, or a later emulator session, once its logs stay unchanged for 30 seconds. Each
session is queued once; reports are capped below 1 MiB. A queued report is removed only after the relay returns the
matching SHA-256 receipt after Discord acknowledges the attachment. TLS requires a trusted certificate, the right
host name and a valid console clock; there is no unencrypted fallback.

When the POSIX directory API refuses access, the collector lists the two fixed log folders through the console's
own FTP service over loopback (ports 2121, then 1337; CWD + LIST). It does not enable FTP, open router ports or
change process privileges.

### Earlier console results (1.1 Tool and older collector builds)

- 2026-10-17, owner's PS5 (firmware 13.60), 1.1 Tool on the SDK runtime: submitted the Fix2 tracker, the tracker
  consumed the calibration request and captured real colour/depth frames; 1473 audio firmware acknowledged, motor
  at 5 degrees. The collector-only minimal startup (`AUTOLOG_MINIMAL_CRT=1`) had returned `EACCES` at the relay
  probe and is kept for historical comparison only; it cannot resolve `libSceSystemService`, so it is not a Helper
  build.
- Collector 1.0.7 sent its activation check (HTTP 200, receipt
  `6cb52f5f3bc1e09027c459e3885905a359f01ebb9518224571791802bd660389`); an earlier build read real game logs and
  sent a GTA IV report (`975f543b575f13cdf2a85d42133a12ee8b38e98cd8fa93a807261e9d7d854b98`).
- Other firmware, reboot cycles and persistence across emulator exits remain unverified.

### Packaging and source

`python tools/package-native-autolog.py --tracker <tracker.elf>` and
`python tools/package-release.py --with-ps5x360-tool --kinect-tracker <tracker.elf>` package the payload and
tracker; without those flags release packaging leaves them out. `python native/autolog/test_release_package.py`
tests packaging against temporary fixtures. The source archive includes the generated CA/relay headers and the
exact Mbed TLS 3.6.7 source archive (SHA-256
`a7e8bcbec0e6f761b4af24f25677626b35f762f68eef79c08677a363212d11f6`); never substitute a Discord webhook for the
generated submission key. Server provisioning is owner-only.

The distributed executable includes the PS5 payload SDK's userland syscall adapter under GPL-3.0-or-later,
copyright John Törnblom; its complete source and licence are included. The emulator is not linked to this payload.
The independently written files keep their MIT notices; Mbed TLS keeps its own licence.

## Source files

- `collector.c`: the AutoLog collector and `main` (calls `tool_run`).
- `tool_lifecycle.h`: resident or later copy, the update thread, threads around the collector.
- `helper_kinect.h`: the Kinect link (supervisor) and `helper/kinect-state.txt`.
- `tool_kinect.h`: relay probe, tracker ELF validation, one bounded submission, `autolog/kinect-status.txt`.
- `helper.h`: paths, `helper/helper.log`, notifications, request files, `helper/status.txt`.
- `helper_update.c`: `native/updater/updater.c` built as the Helper's update module.
- `local_files.h`: the loopback FTP directory fallback and the PS5 stat fallback.
- `test.c`, `test_tool.c`: host harnesses (collector; Helper).
