// SPDX-License-Identifier: MIT
// Host harness: the production Helper lifecycle (update module, Kinect link, status files) around a stand-in
// collector. Built by tools/check-native-autolog-tool.py with HELPER_TEST (helper/test-exit ends the process).
#include "tool_lifecycle.h"
#include <sys/random.h>
// In the Helper the collector supplies Mbed TLS's entropy source; the stand-in does the same on the host.
int mbedtls_hardware_poll(void* context,unsigned char* output,size_t len,size_t* olen) {
  (void)context;ssize_t n=getrandom(output,len,0);*olen=n>0?(size_t)n:0;return n==(ssize_t)len?0:-1;
}
static int collector(void) {
  FILE* f=fopen(ROOT "/collector-entered.txt","wb");
  if(!f)return 99;
  fprintf(f,"%lld\n",(long long)tool_millis());fclose(f);
  return access(ROOT "/no-log-upload",F_OK)&&access(TOOL_STATE "/no-log-upload",F_OK)?23:0;
}
int main(void) { return tool_run(collector); }
