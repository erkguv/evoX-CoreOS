# PS5X360 Updater 1.0.0

`PS5X360-Updater.elf` is an ordinary PS5 payload. Send it with your ELF loader (port 9021) whenever you want
PS5X360 brought up to date. Each time it runs it:

1. reads the installed build from `/data/homebrew/PPSA50011/VERSION`;
2. asks GitHub for the latest release of `BrinooTk/PS5X360` (over HTTPS, certificate and host name checked);
3. stops there when that release is not newer ("PS5X360 is up to date", or "newer than the latest release" for a
   test build);
4. otherwise downloads the release's `PPSA50011.zip` and checks its size and the SHA-256 GitHub publishes for it;
5. unpacks it into `updater/stage/` beside the installation, checking every file against the zip's CRC-32 and
   the package's own `MANIFEST.json` (SHA-256 per file);
6. waits up to 20 minutes for PS5X360 to be closed ("close PS5X360 to install it") and then puts the files in place,
   `eboot.bin` last.

Notifications on the PS5 tell each step, in Portuguese on a console set to Portuguese and in English otherwise.
The full story is in `/data/homebrew/PPSA50011/updater/updater.log`.

## What it changes

| Files | Rule |
| --- | --- |
| Files in the release (`eboot.bin`, `sce_sys`, `sce_module`, `assets`, licences, notes) | Replaced. A replaced file that differs from the new one is kept in `updater/backup/<previous version>/`. |
| Settings in the release (`*.conf`, `*.toml`, `*.ini`, `assets/presets.txt`) that you changed | Kept. The new copy is written beside it as `<name>.new`. A file is "yours" when it matches neither the previous build's `MANIFEST.json` nor the new file. |
| Everything else (games, saves, logs, caches, DLC, title updates, your own files) | Never touched. Nothing is ever deleted from the installation. |

Only the two newest backups are kept. Downloads and unpacked copies of releases that are not being installed are
removed on the next run.

**Power cut or crash half-way:** the install is recorded in `updater/install.txt` before the first file moves, and
files only move by renaming checked copies on the same drive. The next run finishes the install from
`updater/stage/`. Until `eboot.bin` (the last file) is in place, the previous executable still starts.

**Won't install when:** PS5X360 stays open for 20 minutes (send the updater again later); the release has no
published SHA-256; the download or a file in it does not match; there is not enough free space (the unpacked size
plus 128 MB); another copy of the updater is running.

## Switches

Empty files in `/data/homebrew/PPSA50011/updater/`:

- `no-update`: do nothing.
- `force`: install the latest release even when it is not newer (for example, to go back from a test build). It is
  used once (renamed `force.used`).
- `check-only`: download, check and unpack, but install nothing.
- `beta`: also consider pre-releases.
- `test-root` (one line, a folder path containing "test"): install into that folder instead (console tests).

## Inside the PS5X360 Helper

The same code is also built into the PS5X360 Helper (`native/autolog`, Helper 1.2.0) as a module:
`native/autolog/helper_update.c` compiles `updater.c` with `UPD_MODULE`, and the Helper calls the functions in
`updater_module.h`. The flow, rules, switches, log and state folder are the ones above. The differences:

- a release ready while PS5X360 is open stays staged instead of waited for; the Helper looks every 5 s and installs
  it once PS5X360 is closed, with no 20-minute limit. If PS5X360 is opened while files are being placed, the
  journal finishes the install on a later look;
- a check at load that cannot reach GitHub is tried again by the Helper without a failure notification, except for
  the last try;
- the Helper's HTTPS requests take turns with the AutoLog collector's (one Mbed TLS state per process), and the
  collector supplies the entropy source.

Host builds also accept `UPDATER_FAKE_GITHUB=<folder>`: addresses are answered from files in that folder (named after
the address's last part) instead of HTTPS, for the Helper's tests. `UPDATER_CLOSE_GRACE` sets the pause after
PS5X360 closes (3 s). The PS5 build has neither.

## Build and test

Needs the AutoLog collector's Mbed TLS 3.6.7 (`.deps/autolog/mbedtls-3.6.7`) and its generated CA roots and library
(`build/autolog-native/roots.h`, `libmbedtls.a`; `tools/build-native-autolog.sh`).

```
docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" -w /ws/Xbox360PS5 castation-buildenv sh tools/build-native-updater.sh ps5
docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" -w /ws/Xbox360PS5 xbox360ps5-radv-buildenv sh -c "sh tools/build-native-updater.sh host && sh build/updater-native/test/run_tests.sh"
```

The host tests (AddressSanitizer and UndefinedBehaviorSanitizer, against the real GitHub release) cover: PS5X360
open (download, check, wait, give up), a cut after 300 of 572 files and the next run finishing it, a user-changed
setting kept as `.new`, a file outside the package untouched, up to date in Portuguese, check-only with force, the
leftover clean-up, and every installed file equal to the zip.

Checked on the owner's PS5 (firmware 13.60) on 2026-10-16: GitHub over HTTPS (about 1 s), "newer than the latest
release" with 0.6.1-dev.26 installed, and a forced check-only run of v0.6.0 (24.7 MB downloaded in 6 s, SHA-256
matched, 572 files unpacked and checked in 16 s), then the clean-up.

## Files

- `updater.c`: the flow, zip reading, staging, placing, switches, notifications.
- `https.h`: HTTPS GET over Mbed TLS; redirects only to GitHub hosts; Content-Length and chunked bodies.
- `inflate.h`: a raw DEFLATE decoder (RFC 1951) streaming to the file.
- `json_min.h`: a small JSON tokenizer for GitHub's answer and `MANIFEST.json`.
- `version.h`: version order (`0.6.0 < 0.6.0-fix1 < 0.6.1-dev.26 < 0.6.1`).

Independently written; the design follows the PS5SX2 installer's documented behaviour (GPL-3, no code taken).
