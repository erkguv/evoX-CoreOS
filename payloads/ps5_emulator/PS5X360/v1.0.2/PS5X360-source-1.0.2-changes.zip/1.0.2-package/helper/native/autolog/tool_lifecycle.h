// SPDX-License-Identifier: MIT
// PS5X360 Helper 1.2.0 lifecycle. The first copy loaded after a boot takes helper/helper.lock and stays resident:
// an update thread (one check at load, then installs a staged release once PS5X360 is closed and answers
// helper/request-update) and the Kinect link thread (helper_kinect.h) run beside the AutoLog collector, which
// keeps its own consent, lock and behaviour. A later copy asks the resident one for an update check (and a Kinect
// start when the link has failed), then runs the collector exactly as before, which leaves at once while the
// resident's collector holds its lock.
#pragma once
#include <pthread.h>
#include <signal.h>
#include "helper_kinect.h"

#ifndef HELPER_UPDATE_POLL_MS
#define HELPER_UPDATE_POLL_MS 5000  // a request file and "is PS5X360 still open?": two cheap looks
#endif
// A check at load that cannot reach GitHub (the console may still be connecting) is tried again quietly.
static const int64_t helper_update_retry_ms[] = {30000, 120000, 600000};

static volatile int helper_collector_done;
static int helper_collector_result;

static int helper_logger_off(void) {
  return !access(ROOT "/no-log-upload", F_OK) || !access(TOOL_STATE "/no-log-upload", F_OK);
}
static void helper_logger_refresh(void) {
  char text[160];
  int off = helper_logger_off();
  if (!helper_collector_done) snprintf(text, sizeof(text), off ? "off: no-log-upload is set" : "on (details in autolog/status.txt)");
  else if (helper_collector_result == 1) snprintf(text, sizeof(text), "not running here: another copy holds autolog/collector.lock");
  else if (off) snprintf(text, sizeof(text), "off: no-log-upload is set");
  else snprintf(text, sizeof(text), "stopped (code %d)", helper_collector_result);
  helper_status_set(helper_state.logger, sizeof(helper_state.logger), text);
}

static void helper_update_publish(void) {
  char tag[64];
  int pending = upd_module_pending(tag, sizeof(tag));
  helper_status_set(helper_state.update, sizeof(helper_state.update), upd_module_outcome());
  helper_status_set(helper_state.pending, sizeof(helper_state.pending), pending ? tag : "none");
  unsigned installs = upd_module_installs();
  pthread_mutex_lock(&helper_mutex);
  helper_state.installs = installs;
  pthread_mutex_unlock(&helper_mutex);
}

static void* helper_update_worker(void* unused) {
  (void)unused;
  helper_log("update: check at load");
  int result = upd_module_check(1);
  helper_update_publish();
  int retries = 0;
  int64_t retry_at = result == UPD_NET_FAILED || result == UPD_BUSY ? helper_ms() + HMS(helper_update_retry_ms[0]) : -1;
  while (!helper_should_quit()) {
    helper_sleep_ms(HMS(HELPER_UPDATE_POLL_MS) > 0 ? HMS(HELPER_UPDATE_POLL_MS) : 1);
    if (helper_should_quit()) break;
    helper_logger_refresh();
    char request[64];
    if (helper_take_request(HELPER_UPDATE_REQUEST, request, sizeof(request))) {
      helper_log("update: check requested (helper/request-update)");
      result = upd_module_check(0);
      retry_at = -1;
      helper_update_publish();
      continue;
    }
    if (retry_at >= 0 && helper_ms() >= retry_at) {
      retries++;
      int last = retries >= (int)(sizeof(helper_update_retry_ms) / sizeof(helper_update_retry_ms[0]));
      helper_log("update: trying the check again (%d)", retries);
      result = upd_module_check(!last);
      retry_at = !last && (result == UPD_NET_FAILED || result == UPD_BUSY) ? helper_ms() + HMS(helper_update_retry_ms[retries]) : -1;
      helper_update_publish();
      continue;
    }
    char tag[64];
    if (upd_module_pending(tag, sizeof(tag))) {
      result = upd_module_install_pending();
      if (result != UPD_PENDING) {
        helper_log("update: staged %s: %s", tag, upd_module_outcome());
        helper_update_publish();
      }
    }
  }
  return NULL;
}

// Explicit stack sizes: a payload thread's default stack may be small on the console.
static int helper_thread(pthread_t* thread, void* (*worker)(void*), size_t stack) {
  pthread_attr_t attr;
  if (pthread_attr_init(&attr)) return pthread_create(thread, NULL, worker, NULL);
  pthread_attr_setstacksize(&attr, stack);
  int result = pthread_create(thread, &attr, worker, NULL);
  pthread_attr_destroy(&attr);
  return result;
}

// A later copy: ask the resident Helper, then run the collector as the 1.1 Tool did.
static int helper_later_copy(int (*collector)(void)) {
  helper_log("later copy (pid %d): the resident Helper is asked for an update check", (int)getpid());
  helper_write_atomic(HELPER_UPDATE_REQUEST, "requested by a later load of the Helper\n");
  char state[512] = "";
  int fd = open(HELPER_KINECT_STATE, O_RDONLY | O_NOFOLLOW | O_NONBLOCK);
  if (fd >= 0) { ssize_t n = read(fd, state, sizeof(state) - 1); state[n > 0 ? n : 0] = 0; close(fd); }
  if (!strncmp(state, "tracker=failed\n", 15) && access(HELPER_KINECT_REQUEST, F_OK)) {
    helper_log("later copy: the Kinect link had failed: a start is asked for");
    helper_write_atomic(HELPER_KINECT_REQUEST, "start\n");
  }
  helper_notify("PS5X360 Helper is already running: checking for updates",
                "PS5X360 Helper já está rodando: procurando atualização");
  return collector();
}

static int tool_run(int (*collector)(void)) {
  mkdir(ROOT,0755);mkdir(TOOL_STATE,0700);mkdir(HELPER_DIR,0755);
  int updater_ready = !upd_module_init(ROOT);
  helper_pt = upd_module_lang_pt();
  int lock = open(HELPER_LOCK, O_CREAT | O_RDWR, 0600);
  if (lock < 0 || flock(lock, LOCK_EX | LOCK_NB)) {
    if (lock >= 0) close(lock);
    return helper_later_copy(collector);
  }
#ifdef HELPER_TEST
  unlink(HELPER_TEST_EXIT);
#endif
  pthread_mutex_lock(&helper_mutex);
  helper_state.resident = 1;
  helper_state.started = helper_state.changed = (long long)time(NULL);
  helper_status_write_locked();
  pthread_mutex_unlock(&helper_mutex);
  helper_log(HELPER_NAME " resident (pid %d); updater %s", (int)getpid(), updater_ready ? "ready" : "unavailable");
  helper_logger_refresh();
  // A peer closing an HTTPS or loader socket must not end the payload (the collector sets this too, later).
  signal(SIGPIPE, SIG_IGN);
  pthread_t update, kinect;
  int update_started = helper_thread(&update, helper_update_worker, 1024 * 1024) == 0;  // TLS handshakes
  int kinect_started = helper_thread(&kinect, kinect_worker, 256 * 1024) == 0;
  if (!update_started) helper_status_set(helper_state.update, sizeof(helper_state.update), "update thread unavailable");
  if (!kinect_started) {
    tool_status(TOOL_THREAD_FAILED, TOOL_CAL_NONE);
    helper_status_set(helper_state.kinect, sizeof(helper_state.kinect), "Kinect thread unavailable");
  }
  // The collector's consent, locks and lifecycle run at once and independently, as in the 1.1 Tool.
  int result = collector();
  helper_collector_result = result;
  helper_collector_done = 1;
  helper_logger_refresh();
  // With reporting off (or the collector stopped) the Helper stays resident for updates and the Kinect link.
  if (update_started) pthread_join(update, NULL);
  if (kinect_started) pthread_join(kinect, NULL);
  helper_log(HELPER_NAME " leaving (pid %d)", (int)getpid());
  close(lock);
  return result;
}
