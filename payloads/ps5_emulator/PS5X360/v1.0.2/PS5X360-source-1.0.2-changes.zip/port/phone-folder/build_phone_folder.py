"""phone_camera_tls.cpp.o with an open certificate folder (0777, files 0666; an existing 0700 folder
is opened at start). Earlier builds made /data/homebrew/PPSA50011/phone-camera 0700 for the
title's own user, so FTP and file managers got "Permission denied" and could not delete the
PPSA50011 folder (tester report, 2026-10-22).

The object comes from build/kinect-native-20261009 and every later build links it unchanged.
First that source is rebuilt with its recorded command and must equal the linked object; then
phone_camera_tls.cpp here (the same source plus the change) is compiled the same way into
../extra-obj/, which build_online.py --link puts over the base object.

In xbox360ps5-radv-buildenv, /ws mounted:  python3 build_phone_folder.py
"""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
kinect = root / 'build/kinect-native-20261009'
mbed = root / '.deps/autolog/mbedtls-3.6.7'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
linked = json.loads((here.parent / 'native/build.json').read_text())['objects']['phone_camera_tls.cpp.o']


def with_paths(command, source, obj, extra=()):
    """As kinect-native-20261009/build.py."""
    cmd = list(command)
    cmd[1:1] = list(extra)
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(obj)
    for flag in ('-MT', '-MF'):
        if flag in cmd:
            i = cmd.index(flag)
            del cmd[i:i + 2]
    for flag in ('-MD', '-MMD'):
        while flag in cmd:
            cmd.remove(flag)
    return cmd


web_cmd = json.loads((root / 'build/kinect-update-20261008/web/compile-receipt.json').read_text())['commands'][1]
mbed_flags = ['-DMBEDTLS_USER_CONFIG_FILE="mbedtls_ps5x360_config.h"', f'-I{mbed}/include']
cwd = root / 'build/canary-ps5'
proof = here / 'phone_camera_tls.proof.o'
subprocess.run(with_paths(web_cmd, kinect / 'phone_camera_tls.cpp', proof, ['-I' + str(kinect), *mbed_flags]),
               cwd=cwd, check=True)
assert sha(proof) == linked, 'phone_camera_tls inputs drifted'
out = here.parent / 'extra-obj'
out.mkdir(exist_ok=True)
subprocess.run(with_paths(web_cmd, here / 'phone_camera_tls.cpp', out / 'phone_camera_tls.cpp.o',
                          ['-I' + str(kinect), *mbed_flags]), cwd=cwd, check=True)
print('proof equal; new object', sha(out / 'phone_camera_tls.cpp.o')[:16])
