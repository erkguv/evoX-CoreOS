#!/usr/bin/env bash
set -euo pipefail
# build/kinect-guest-audit-20261017/link-support/link_game.sh plus --wrap=getaddrinfo and freeaddrinfo (port-src/ps5_resolver.cpp).
base=$(realpath "$1")
out=$(realpath "$2")
reference="$base/.deps/references/PS5_Vulkan"
sdk="$reference/.deps/native/ps5-payload-sdk"
native="$reference/tooling/native"
gl="$base/build/dual-renderer/namespaced-gl-sdk-all"
driver_import="$base/build/dual-renderer/native-dual-link-probe/imports/libSceAgcDriver.so"
[[ -f "$driver_import" ]] || { echo 'Combined AGC import metadata is missing' >&2; exit 2; }
source "/ws/Xbox360PS5/build/kinect-guest-audit-20261017/link-support/radv-link.sh"
PS5_CLANG=clang-18 radv_link_recipe "$reference" "$sdk" "$reference/.deps/native/radv-release/lib/libvulkan_radeon.ps5.a"
# The recipe binds getaddrinfo and freeaddrinfo to the platform's (which refuses every lookup)
# with --defsym, and that binding also took the __wrap_ names: the eboots up to 1.0.2 never
# reached ps5_resolver.cpp (console log 2026-10-22: no lookup lines, curl 6). Both names are
# bound to ps5_resolver.cpp's instead (the recipe's version script keeps them local).
kept=()
for flag in "${radv_link_flags[@]}"; do
  case $flag in
    --defsym=getaddrinfo=*) kept+=(--defsym=getaddrinfo=__wrap_getaddrinfo) ;;
    --defsym=freeaddrinfo=*) kept+=(--defsym=freeaddrinfo=__wrap_freeaddrinfo) ;;
    *) kept+=("$flag") ;;
  esac
done
radv_link_flags=("${kept[@]}")
mapfile -t objects < <(find "$base/build/canary-ps5/CMakeFiles/xbox360ps5-title-objects.dir" -name '*.o' ! -name 'canary_game_main.cpp.o' ! -name 'launcher.cpp.o' | sort)
# A freshly compiled isolated title source replaces its parent object. Kernel
# overrides are linked before archives and extracted only once by the linker.
filtered=()
for object in "${objects[@]}"; do
  [[ -f "$out/obj/$(basename "$object")" ]] || filtered+=("$object")
done
objects=("${filtered[@]}")
mapfile -t archives < <(find "$base/build/canary-ps5" -name '*.a' | sort)
link_native() {
  "$sdk/bin/prospero-lld" "${radv_linker_script[@]}" --eh-frame-hdr --gc-sections "$@" \
    "${radv_link_flags[@]}" --wrap=mmap --wrap=mprotect --wrap=munmap --wrap=ffs --wrap=stat --wrap=lstat --wrap=timegm --wrap=sceKernelDebugOutText --wrap=getaddrinfo --wrap=freeaddrinfo --wrap=gai_strerror --wrap=getnameinfo --wrap=fnmatch --wrap=curlx_nonblock \
    --version-script "$native/app-symbols.map" --version-script "$base/tooling/native-game-symbols.map" \
    --exclude-libs=ALL -u radv_GetInstanceProcAddr -e _start -o "$out/llvm-pie.elf" \
    "$base/build/canary-game/obj/app_crt.o" "$out/obj/"*.o "${objects[@]}" \
    "$gl/lib/libSceAgc.so" "$driver_import" \
    --start-group "${archives[@]}" -L "$gl/lib" "$gl/lib/libPS5OpenGL.a" --end-group \
    "${radv_link_inputs[@]}" --as-needed "$sdk"/target/lib/*.so
}
link_native
python3 "$base/tools/resolve-mesa-weaks.py" "$out/llvm-pie.elf" "$out/mesa-weaks"
link_native @"$out/mesa-weaks.rsp" --version-script "$out/mesa-weaks.map"
tool="$base/build/canary-game/host/ps5-native-tool"
"$tool" link --in "$out/llvm-pie.elf" --out "$out/eboot.elf" \
  --stub-dir "$sdk/target/lib" --stub "$gl/lib/libSceAgc.so" --stub "$driver_import" \
  --module-sdk 0x02000009 --companion-sdk 0x08050001 --file-name eboot.elf
python3 "$base/build/native-runtime-stage/tools/verify-image.py" "$out/llvm-pie.elf" "$out/eboot.elf"
"$tool" self --sign --in "$out/eboot.elf" --out "$out/eboot.bin" --magic 0x1D3D154F
