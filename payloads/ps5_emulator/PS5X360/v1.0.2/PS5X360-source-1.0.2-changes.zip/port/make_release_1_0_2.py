"""PS5X360 1.0.2 release assets in release-1.0.2/assets:
  PPSA50011.zip      the 1.0.2 Desktop package with eboot.bin from native/ (b1d1b3cb: online
                     fixes + open phone-camera folder), the network libraries' licences
                     (release-1.0.0/licenses), RELEASE.json, RELEASE_NOTES.md, MANIFEST.json
  PS5X360-source-1.0.2-changes.zip
                     the 1.0.2 package's source-and-licenses.zip, the online core's changes,
                     libcurl's change, the PS5 name resolver, the link script and the phone-camera
                     source
  PS5X360-Helper.elf the Helper 1.3.0 (Desktop/PS5X360-Helper-1.3.0-20261022)
  PS5X360-Content-Installer.exe (build/content-installer/dist)
Nothing is uploaded.   python make_release_1_0_2.py
"""
import hashlib
import io
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]
desktop = Path.home() / 'Desktop'
package = desktop / 'PS5X360-1.0.2-20261022'
out = here / 'release-1.0.2/assets'
sha = lambda b: hashlib.sha256(b).hexdigest()
out.mkdir(parents=True, exist_ok=True)

eboot = (here / 'native/eboot.bin').read_bytes()
assert sha(eboot).startswith('b1d1b3cb'), 'native/eboot.bin is not the 1.0.2 release build'
with zipfile.ZipFile(package / 'PPSA50011.zip') as z:
    files = {i.filename: z.read(i) for i in z.infolist() if not i.is_dir()}
assert files['PPSA50011/VERSION'] == b'1.0.2\n'
files['PPSA50011/eboot.bin'] = eboot
for lic in sorted((here / 'release-1.0.0/licenses').iterdir()):
    files['PPSA50011/licenses/' + lic.name] = lic.read_bytes()
files['PPSA50011/licenses/PS5X360-NOTICE.txt'] = (here / 'release-1.0.0/LICENSE-NOTICE.txt').read_bytes()
files['PPSA50011/RELEASE.json'] = (json.dumps({
    'version': '1.0.2', 'executable_sha256': sha(eboot), 'candidate': False, 'published': True,
    'candidate_id': 'online-phone-folder-b1d1b3cb', 'base_candidate': 'core-e6cd2e4-20261021',
}, indent=2) + '\n').encode()
files['PPSA50011/RELEASE_NOTES.md'] = (here / 'release-1.0.2/NOTES-v1.0.2.md').read_bytes()
files.pop('PPSA50011/ONLINE-TEST.json', None)
files.pop('PPSA50011/MANIFEST.json', None)
manifest = {k[len('PPSA50011/'):]: {'bytes': len(v), 'sha256': sha(v)} for k, v in sorted(files.items())}
files['PPSA50011/MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(out / 'PPSA50011.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for k, v in sorted(files.items()):
        z.writestr(k, v)
with zipfile.ZipFile(out / 'PPSA50011.zip') as z:
    assert z.testzip() is None and z.read('PPSA50011/eboot.bin') == eboot

diff = lambda folder, *base: subprocess.run(['git', '-C', str(folder), 'diff', *base], capture_output=True,
                                            check=True).stdout
with zipfile.ZipFile(out / 'PS5X360-source-1.0.2-changes.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    with zipfile.ZipFile(package / 'source-and-licenses.zip') as earlier:
        for item in earlier.infolist():
            if not item.is_dir():
                z.writestr('1.0.2-package/' + item.filename, earlier.read(item))
    # The online core: its PS5 commits since the netplay merge, and the changes made since.
    z.writestr('online-core/commits-since-netplay-merge.diff', diff(here / 'tree', '5acad1590', 'HEAD'))
    z.writestr('online-core/uncommitted.diff', diff(here / 'tree'))
    z.writestr('libcurl-3163ec0.diff', diff(here / 'deps/libcurl'))
    for name in ('port-src/ps5_resolver.cpp', 'link_online.sh', 'build_online.py', 'make_release_1_0_2.py',
                 'phone-folder/phone_camera_tls.cpp', 'phone-folder/build_phone_folder.py'):
        z.write(here / name, 'port/' + name)

shutil.copy2(desktop / 'PS5X360-Helper-1.3.0-20261022/PS5X360-Helper.elf', out / 'PS5X360-Helper.elf')
shutil.copy2(root / 'build/content-installer/dist/PS5X360-Content-Installer.exe',
             out / 'PS5X360-Content-Installer.exe')
for f in sorted(out.iterdir()):
    print(f.name, f.stat().st_size, sha(f.read_bytes())[:16])
print('eboot.bin', sha(eboot)[:16], 'entries', len(files))
