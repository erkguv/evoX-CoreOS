"""Online play (Xenia netplay, AdrianCassar netplay_canary_experimental d2cf527aa) in the PS5 core,
over the e6cd2e4 build (build/core-e6cd2e4-20261021/native, eboot 0854c878).

Trees (worktrees of .deps/xenia-canary):
  control: build/core-e6cd2e4-20261021/tree (956255121 = the e6cd2e4 build's core)
  online:  tree/ (branch claude/online-20261021: the LAN port reverted, netplay merged, PS5
           network adapter and Discord stand-ins)
Network libraries: net-libs/out (wolfSSL, libcurl, CA bundle, miniupnpc; see net-libs/).

In xbox360ps5-radv-buildenv, /ws mounted, in this order:
  build_online.py --control   every core file from the control tree (xam_content: dash overlay)
  build_online.py --core      every core file from tree/, netplay's new files included
  build_online.py --title     the port objects that read a core header netplay changes
  build_online.py --link      native/ (eboot), receipt native/build.json
An object replaces the base one when its online compile differs from its control compile.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root = Path('/ws/Xbox360PS5')
here = root / 'build/online-20261021'
unified = root / 'build/unified-20261012'
upstream = root / 'build/upstream-c28af11-20261020'
kinect_home = root / 'build/kinect-home-20261021'
core = root / 'build/canary-ps5'
base = root / 'build/core-e6cd2e4-20261021/native'
control_tree = root / 'build/core-e6cd2e4-20261021/tree'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == record['artifacts']['eboot.bin']['sha256'] == \
    '0854c87830589590c96f3a8eb5652062c59e4849848d5a041d9e96e90ca2083a', 'base changed'
DASH_INCLUDE = root / 'build/dash-mode-20261020/include'
# The control has the installed build's own versions of the files it patched over the core tree.
OVERLAY = {'control': {'xam_content.cc': root / 'build/core-e6cd2e4-20261021/overlay/xam_content.cc',
                       'xam_content_aggregate.cc': root / 'build/dash-mode-20261020/core-ps5/xam_content_aggregate.cc',
                       'xam_input.cc': root / 'build/input-fix-20261021/xam_input.cc'},
           'online': {}}
mode = sys.argv[1] if len(sys.argv) > 1 else ''
title_dir = core / 'CMakeFiles/xbox360ps5-title-objects.dir'
title_names = {p.name for p in title_dir.rglob('*.o')}

# Netplay's new files and their libraries (compiled like the named neighbour). Windows-only
# and desktop-application files stay out; the PS5 has its own network adapter manager.
SKIP = ('network_adapter_manager_win.cc', 'network_adapter_manager_linux.cc')
# Netplay's new files are all in the kernel but one; base/ui also hold other platforms' files.
NEIGHBOUR = {'src/xenia/kernel': 'xevent.cc', 'src/xenia/base': 'logging.cc'}
BASE_NEW = ('jpeg_utils.cc',)


def new_files(tree):
    listed = set()
    for line in (core / 'build.ninja').read_text().splitlines():
        if line.startswith('build ') and '.o: ' in line:
            parts = line.split(': ', 1)[1].split()
            if len(parts) > 1 and '/.deps/xenia-canary/src/' in parts[1]:
                listed.add(parts[1].split('/.deps/xenia-canary/', 1)[1])
    found = []
    for lib, like in NEIGHBOUR.items():
        for path in sorted((tree / lib).rglob('*.c*')):
            rel = path.relative_to(tree).as_posix()
            if path.suffix not in ('.cc', '.cpp') or rel in listed or path.name in SKIP:
                continue
            if lib == 'src/xenia/base' and path.name not in BASE_NEW:
                continue
            if '/testing/' in rel or path.name.endswith('_test.cc') or '_win.' in path.name or '_mac.' in path.name:
                continue
            found.append((path.parent.relative_to(tree).as_posix(), path.name, like, lib))
    return found


# _LIBCPP_ENABLE_EXPERIMENTAL: std::jthread and std::stop_token (libc++ 18 keeps them experimental).
EXTRA_FLAGS = ['-I' + str(DASH_INCLUDE), '-D_LIBCPP_ENABLE_EXPERIMENTAL', '-DCURL_STATICLIB', '-DMINIUPNP_STATICLIB', '-I' + str(here / 'inc-root'),
               '-I' + str(here / 'deps/libcurl/include'), '-I' + str(here / 'deps/miniupnp/miniupnpc/include'),
               '-I' + str(here / 'net-libs/out/miniupnpc')]

SWAP = '''
for k, job in enumerate(jobs):
    name = job[1][:-2]
    command = list(job[2])
    if name in OVERLAY_FILES:
        command[command.index('-c') + 1] = str(OVERLAY_FILES[name])
        command.insert(1, '-I' + str(DASH))
    if EXTRA:
        command[1:1] = EXTRA
    jobs[k] = (job[0], job[1], command, job[3], job[4])
'''


def compile_core(tree, out, which):
    script = (unified / 'build_tree.py').read_text()
    needle = "result, i = [command[0], '-I' + str(port)], 1"
    assert script.count(needle) == 1
    script = script.replace(needle, "result, i = [command[0], '-I' + str(root / 'build/kinect-relay-20261015/emu-include'), "
                            "'-I' + str(root / 'build/kinect-usb-20261014/emu-include'), "
                            "'-I' + str(root / 'build/disc-20261015/include'), '-I' + str(port)], 1")
    extras = [] if which == 'control' else new_files(tree)
    folders = ''.join(f'({folder!r}, {name!r}, {like!r}), ' for folder, name, like, _ in extras)
    needle = "for folder, name, like in (('src/xenia/ui', 'controller_keyboard_dialog.cc', 'imgui_dialog.cc'),"
    assert script.count(needle) == 1
    script = script.replace(needle, "for folder, name, like in (" + folders +
                            "('src/xenia/apu', 'nop_audio_driver.cc', 'audio_system.cc'), "
                            "('src/xenia/apu', 'pacing_audio_driver.cc', 'audio_system.cc'), "
                            "('src/xenia/base', 'assert.cc', 'logging.cc'), "
                            "('src/xenia/ui', 'controller_keyboard_dialog.cc', 'imgui_dialog.cc'),")
    # A new file's neighbour is looked up in its own library folder, not in the new file's.
    needle = "    neighbour = next(t for t, s in targets if s.name == like and str(s.parent).endswith(folder))\n"
    assert script.count(needle) == 1
    script = script.replace(needle, "    neighbour = next(t for t, s in targets if s.name == like and "
                            "(str(s.parent).endswith(folder) or str(s.parent).endswith(LIB.get(name, folder))))\n")
    needle = "if only:\n    jobs = [j for j in jobs if j[1][:-2] in only or j[1] in only]\n"
    assert script.count(needle) == 1
    script = script.replace(needle, needle + SWAP)
    only = os.environ.get('ONLY')
    if out.exists() and not only:
        shutil.rmtree(out)
    sys.argv = ['build_tree.py', str(tree), str(out)] + (['--only', only] if only else [])
    exec(compile(script, 'build_tree.py', 'exec'),
         {'__file__': str(unified / 'build_tree.py'), '__name__': 'online_build', 'DASH': DASH_INCLUDE,
          'OVERLAY_FILES': OVERLAY[which], 'EXTRA': EXTRA_FLAGS if which == 'online' else [],
          'LIB': {name: lib for _, name, _, lib in extras}})
    results = json.loads((out / 'result.json').read_text())
    failed = {t: r for t, r in results.items() if r['state'] == 'FAILED'}
    (out / 'failed.json').write_text(json.dumps(failed, indent=2))
    print('compiled', len(results), 'failed', len(failed), '(new files:', len(extras), ')')
    return results, failed


def without_output(command):
    command = list(command)
    for flag, width in (('-o', 2), ('-MF', 2), ('-MT', 2), ('-MD', 1), ('-MMD', 1)):
        while flag in command:
            i = command.index(flag)
            del command[i:i + width]
    return command


PORT = json.loads((upstream / 'port.json').read_text())
CHANGED_HEADERS = set((here / 'changed-headers.txt').read_text().split()) if (here / 'changed-headers.txt').exists() else set()
LABEL_CONTROL, LABEL = '0.6.1-dev.28', '1.0.2'
KINECT_UI = root / 'build/ui-kinect-20261020'


def port_jobs(which):
    """(member, recipe member, source, extra include folders) of every port object that reads a
    core header netplay changes, with the source the installed build was made from."""
    home = kinect_home if which == 'control' else here / 'home'
    title_main = (kinect_home if which == 'control' else here) / 'title-src/canary_game_main.cpp'
    jobs = {
        'launcher.cpp.o': ('launcher.cpp.o', home / 'launcher.cpp', [home, KINECT_UI]),
        'kinect_skin.cpp.o': ('launcher.cpp.o', home / 'kinect_skin.cpp', [home]),
        'xex_package_decoder.cpp.o': ('launcher.cpp.o', home / 'xex_package_decoder.cpp', [home]),
        **({'game_art.cpp.o': ('launcher.cpp.o', home / 'game_art.cpp', [home])} if which == 'online' else {}),
        'canary_game_main.cpp.o': ('canary_game_main.cpp.o', title_main, [DASH_INCLUDE]),
    }
    for member, r in PORT.items():
        if member in jobs or not r.get('source') or not r.get('headers'):
            continue
        if any(h.split('/src/', 1)[-1] in CHANGED_HEADERS for h in r['headers'] if '/src/xenia/' in h):
            source = Path(r['source']) if os.path.isabs(r['source']) else Path(os.path.normpath(os.path.join(r['cwd'], r['source'])))
            adapted = upstream / 'title-src' / source.name
            jobs[member] = (member, adapted if adapted.exists() else None, [])
    if which == 'online':
        # Host names for libcurl and miniupnpc (the link wraps getaddrinfo), built as covers.cpp.
        jobs['ps5_resolver.cpp.o'] = ('covers.cpp.o', here / 'port-src/ps5_resolver.cpp', [])
    return jobs


def compile_port(member, recipe_member, source, extra, tree, out, label):
    recipe = PORT[recipe_member]
    command = without_output(recipe['command'])
    old = command[command.index('-c') + 1]
    original = Path(old) if os.path.isabs(old) else Path(os.path.normpath(os.path.join(recipe['cwd'], old)))
    if source is not None:
        command[command.index('-c') + 1] = str(source)
        command += ['-iquote', str(original.parent)]
    command.insert(1, '-I' + str(tree / 'src'))
    command.insert(1, '-I' + str(upstream / 'title-include'))
    for folder in extra:
        command.insert(1, '-I' + str(folder))
    if tree == here / 'tree':
        command[1:1] = EXTRA_FLAGS
    command = [f'-DXBOX360PS5_VERSION="{label}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in command]
    output = out / member
    output.parent.mkdir(parents=True, exist_ok=True)
    done = subprocess.run(command + ['-o', str(output)], cwd=recipe['cwd'], capture_output=True, text=True)
    if done.returncode:
        return member, {'state': 'FAILED', 'errors': [l for l in done.stderr.splitlines() if 'error' in l][:12]}
    return member, {'state': 'built', 'sha256': sha(output)}


def run_ports(which, tree, out, label):
    jobs = port_jobs(which)
    with ThreadPoolExecutor(max_workers=int(os.environ.get('JOBS', '8'))) as pool:
        results = dict(pool.map(lambda j: compile_port(j[0], *j[1], tree, out, label), jobs.items()))
    (out / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
    return results


if mode == '--control':
    results, failed = compile_core(control_tree, here / 'core-control', 'control')
    sys.exit(1 if failed else 0)

if mode == '--title-control':
    results = run_ports('control', control_tree, here / 'title-control', LABEL_CONTROL)
    ok = True
    archived = {p.name: sha(p) for p in title_dir.rglob('*.o')}
    for member, r in sorted(results.items()):
        # The base's object, else the archived title object the link takes (notify.cpp.o).
        equal = r.get('sha256') == record['objects'].get(member, archived.get(member))
        ok &= equal
        print(member, r['state'], 'EQUAL' if equal else 'DIFFERS', r.get('errors', ''))
    sys.exit(0 if ok else 1)

if mode == '--title':
    results = run_ports('online', here / 'tree', here / 'title-online', LABEL)
    for member, r in sorted(results.items()):
        print(member, r['state'], r.get('errors', ''))
    sys.exit(1 if any(r['state'] == 'FAILED' for r in results.values()) else 0)

if mode == '--core':
    results, failed = compile_core(here / 'tree', here / 'core-online', 'online')
    for t, r in sorted(failed.items())[:60]:
        print('FAILED', t)
        for line in [l for l in r['error'].splitlines() if 'error' in l][:4]:
            print('   ', line[:300])
    sys.exit(1 if failed else 0)

if mode == '--link':
    out = here / os.environ.get('PS5X360_ONLINE_OUTPUT', 'native')
    assert not (out / 'eboot.bin').exists(), 'Preserve prior output: move native/ away first'
    online = json.loads((here / 'core-online/result.json').read_text())
    assert not [t for t, r in online.items() if r['state'] == 'FAILED']
    title = json.loads((here / 'title-online/result.json').read_text())
    assert not [m for m, r in title.items() if r['state'] == 'FAILED']
    (out / 'obj').mkdir(parents=True)
    for name in record['objects']:
        shutil.copy2(base / 'obj' / name, out / 'obj' / name)
    # The LAN port's stand-in for netplay's network layer: netplay brings its own (XLiveAPI).
    (out / 'obj/xnet_lan.cc.o').unlink()
    # Each compiled file against the object it stands for, as build_full.py decides: the base's
    # object of that name (or of its library-prefixed name), else the archived core object. A
    # file that differs replaces it; one flat folder, so a clash takes the library prefix.
    by_name = {}
    for target in online:
        by_name.setdefault(Path(target).name, []).append(target)
    # Two files of one name (base/memory.cc, memory.cc): the base's object of that name stands
    # for the one that defines most of the same symbols.
    def defined(path):
        listing = subprocess.run(['llvm-nm-18', '--defined-only', '--format=just-symbols', str(path)],
                                 capture_output=True, text=True).stdout.split()
        return set(listing)
    owner = {}
    for name, targets in by_name.items():
        if len(targets) > 1 and name in record['objects']:
            mine = defined(base / 'obj' / name)
            owner[name] = max(targets, key=lambda t: len(mine & defined(here / 'core-online' / t)))
    replaced = {}
    for target, r in sorted(online.items()):
        member = Path(target).name
        prefixed = target.split('CMakeFiles/', 1)[1].split('.dir/', 1)[0] + '__' + member
        if prefixed in record['objects']:
            want, where = record['objects'][prefixed], 'base'
            member = prefixed
        elif member in record['objects'] and (len(by_name[member]) == 1 or owner.get(member) == target):
            want, where = record['objects'][member], 'base'
        elif (core / target).exists():
            want, where = sha(core / target), 'archived'
        else:
            want, where = None, 'new'
        if r['sha256'] == want:
            continue
        if member in replaced or member in title_names or (where == 'archived' and member in record['objects']):
            member = prefixed
        assert member not in replaced and member not in title_names, member
        shutil.copy2(here / 'core-online' / target, out / 'obj' / member)
        replaced[member] = {'from': 'core', 'target': target, 'was': where}
    for member, r in sorted(title.items()):
        assert member not in replaced, member
        shutil.copy2(here / 'title-online' / member, out / 'obj' / member)
        replaced[member] = {'from': 'port'}
    # Port objects rebuilt outside the title list (phone-folder/build_phone_folder.py).
    for obj in sorted((here / 'extra-obj').glob('*.o')):
        assert obj.name in record['objects'] and obj.name not in replaced, obj.name
        shutil.copy2(obj, out / 'obj' / obj.name)
        replaced[obj.name] = {'from': 'extra-obj'}
    # The network libraries' objects, one flat folder: each gets its library's prefix.
    libs = {'curl': here / 'net-libs/out/libcurl/lib/libcurl.a', 'wolfssl': here / 'net-libs/out/wolfssl/libwolfssl.a',
            'cacert': here / 'net-libs/out/libcacert.a', 'upnpc': here / 'net-libs/out/miniupnpc/libminiupnpc.a'}
    scratch = here / 'net-objects'
    if scratch.exists():
        shutil.rmtree(scratch)
    for lib, archive in libs.items():
        folder = scratch / lib
        folder.mkdir(parents=True)
        subprocess.run(['ar', 'x', str(archive)], cwd=folder, check=True)
        for obj in sorted(folder.glob('*.o')):
            member = f'net_{lib}__{obj.name}'
            assert not (out / 'obj' / member).exists(), member
            shutil.copy2(obj, out / 'obj' / member)
            replaced[member] = {'from': lib}
    subprocess.run(['bash', str(here / 'link_online.sh'), str(root), str(out)], check=True)
    final = {n: sha(out / 'obj' / n) for n in sorted(p.name for p in (out / 'obj').glob('*.o'))}
    receipt = dict(record)
    receipt.update({
        'build_id': 'online-20261021',
        'version': LABEL,
        'netplay': 'AdrianCassar/xenia-canary netplay_canary_experimental d2cf527aa (2026-10-21)',
        'core_tree': {'branch': 'claude/online-20261021', 'control': '956255121'},
        'base_build': record['build_id'],
        'base_native_sha256': record['artifacts']['eboot.bin']['sha256'],
        'changed_objects': sorted(set(record.get('changed_objects', [])) | set(replaced)),
        'replaced_objects': replaced,
        'objects': final,
        'artifacts': {n: {'sha256': sha(out / n), 'bytes': (out / n).stat().st_size}
                      for n in ('llvm-pie.elf', 'eboot.elf', 'eboot.bin')},
        'installed': False,
        'hardware': 'pending',
    })
    (out / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('replaced or new:', len(replaced))
    print('PASS', receipt['artifacts']['eboot.bin'])
    sys.exit(0)

print(__doc__)
