# PS5X360 v0.5.6

This release brings further game compatibility improvements, a more complete library and save interface, and CPU/GPU memory optimizations. Compatibility continues to improve, but results depend on the game, firmware and homebrew setup.

## What's new

- **Performance improvements:** faster lookups for GPU memory that is already valid, less redundant memory invalidation and protection work, and PS5 mutexes that briefly spin before blocking. These changes reduce CPU/GPU synchronization overhead.
- **Dynamic buffer optimization:** repeatedly rewritten vertex data can use content comparison to avoid repeated write protection and faults. Texture, index and GPU-written data retain their required tracking. The Guide lets you switch this optimization off when comparing a game.
- **Further game compatibility improvements:** safer guest thread cleanup, memory handling, save storage and crash-context collection. These are shared emulator changes, rather than a promise that every previously reported game now works.
- **Updated UI:** cover-flow presentation, a Saved data panel, and the emulator version visible in the library, settings, loading screen and in-game Guide.
- **Saves in the emulator folder:** saved games, profiles and achievements prefer `PPSA50011/saves`. Existing sandbox saves are copied without deleting the originals; inaccessible storage keeps a fallback.
- **Separate game logs:** each session has a named file in `PPSA50011/logs`, with build, title identity and crash information.
- **Optional AutoLog 1.0.9:** the separate PS5 ELF sends completed-session/crash diagnostics through the configured relay, with activation confirmation and a persistent delivery receipt. No PC collector is required. Reporting remains optional.
- Retains XEX, ISO and GOD/STFS support, multiple game locations, cover downloads, executable-matched patches, English/Portuguese/Spanish UI and console-language detection.
- Public builds do not automatically pause presentation to take a five-second CPU sample. Manual performance measurement remains available.

## Development testing

Recent development-console GTA IV sessions showed improved performance in some areas, including gameplay summaries around 26–40 FPS in one revision. The scenes differed between sessions, so this is indicative rather than a controlled benchmark or a guaranteed result. This release does **not** promise locked 30/60 FPS or full-library compatibility.

Host checks cover mutex exclusion/recursion, memory invalidation boundaries, repeated range requests, and dynamic-buffer histories with matching GPU data. Console coverage remains limited; unresolved crashes, graphical problems and loading stalls still need reports from the exact release being used.

## Downloads and installation

1. Download **PPSA50011.zip** and extract it.
2. Copy the complete `PPSA50011` folder to `/data/homebrew/` using your console's FTP service. Update the existing folder without deleting games, saves or logs.
3. Open PS5X360 through your already working homebrew environment.
4. Keep each game in its own folder under `PPSA50011/assets/roms`, or add other accessible folders in Settings.

The optional **PS5X360-AutoLog-v1.0.9-preview.elf** is a separate logger. Read `PPSA50011/AUTOLOG.md` or the [AutoLog instructions](https://github.com/BrinooTk/PS5X360/blob/main/native/autolog/README.md) before loading it once after console boot. It does not install the emulator or a boot service. Games, BIOS and keys are not included.

Development setup: firmware 13.60, etaHEN, ShadowMountPlus and kstuff. Other setups require their own validation.

Support current and future projects: https://ko-fi.com/brinoblitz
