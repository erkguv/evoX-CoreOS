Put each game in its own folder here: an extracted game (default.xex and its
data folders), an .iso image, or a GOD/STFS package. The library lists them.
To start one game directly, write its full /app0 path in assets/game.txt.
No game, console BIOS or keys are included.
