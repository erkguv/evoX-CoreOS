# PS5X360 0.6.1-dev.27-rumble — private candidate

Everything in 0.6.1-dev.26-kinect, plus:

- Controller vibration (GitHub issue #46). The PS5 opens a title's controllers in haptics mode, where the two
  Xbox 360 motor values are ignored although the system accepts them; each controller is now put in rumble mode
  when it is opened. Optional /data/homebrew/PPSA50011/vibration.conf: strength=0..100 (percent, 0 = off),
  mode=0..3 or mode=off (leave the controller as the system opened it).
- PS5X360 Updater (PS5X360-Updater.elf, next to this package): send it with the ELF loader and it installs the
  latest GitHub release when that is newer than the installed build. See UPDATER.md.

Close PS5X360 completely before installing. Games, saves, profiles and settings are kept.
