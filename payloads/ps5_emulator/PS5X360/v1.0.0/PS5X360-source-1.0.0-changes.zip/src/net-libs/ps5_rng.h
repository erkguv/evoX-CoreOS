/* Xbox360PS5: wolfSSL's seed comes from the console's own random number service
   (port-src/ps5_resolver.cpp); a title may not open /dev/urandom, and without a seed every TLS
   context failed, which libcurl reports as "out of memory" (CURLE 27). */
#ifndef PS5X_RNG_H
#define PS5X_RNG_H
int ps5x_wolfssl_seed(unsigned char* output, unsigned int size);
#endif
