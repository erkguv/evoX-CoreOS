// SPDX-License-Identifier: MIT
// The original Xbox 360 dashboard (the user's own dash.xex, never shipped) as
// the home screen: while it runs, the title tells the kernel which games the
// library has, the kernel lists them to the dashboard as installed games, and
// hands the dashboard's request to play one back to the title.
#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace xbox360ps5::dashboard {

struct Game {
  uint32_t title_id = 0;
  std::u16string name;
  // What the dashboard gets as the content's file name and launches with: at
  // most 42 characters, unique in the list.
  std::string key;
  uint64_t size = 0;
  uint64_t time = 0;  // FILETIME of the game's last change.
  std::vector<uint8_t> icon;  // PNG, at most 0x3D00 bytes; may be empty.
};

// Set by the title only while the running title is the dashboard.
inline std::function<std::vector<Game>()> list_games;
inline bool FindGame(const std::string& key, Game& found) {
  if (!list_games) return false;
  for (auto& game : list_games()) {
    if (game.key == key) {
      found = std::move(game);
      return true;
    }
  }
  return false;
}
// The dashboard asked to play the game with this key. True when the title
// restarts into it (the call that asked then ends the dashboard).
inline std::function<bool(const std::string& key)> launch_game;

}  // namespace xbox360ps5::dashboard
