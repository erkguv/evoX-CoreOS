// SPDX-License-Identifier: MIT
#include "game_art.hpp"
#include "xenia/base/logging.h"

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstring>
#include <fstream>
#include <mutex>
#include <set>
#include <thread>

namespace game_art {
namespace {
namespace fs = std::filesystem;
constexpr const char* kFolder = "/data/homebrew/PPSA50011/game-art";
constexpr const char* kHost = "download.xbox.com";

std::mutex mutex;
std::set<std::string> asked;  // Titles already fetched (or tried) in this run.
std::atomic<bool> busy{false}, fresh{false};

// The body of http://<host><path> when the answer is 200, else empty. HTTP/1.0: the server
// closes the connection after the body, so no chunked transfer.
std::vector<uint8_t> Get(const std::string& path) {
  std::vector<uint8_t> body;
  addrinfo hints{}, *found = nullptr;
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM;
  if (getaddrinfo(kHost, "80", &hints, &found) != 0 || !found) return body;
  const int sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock >= 0) {
    timeval timeout{8, 0};
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    if (connect(sock, found->ai_addr, found->ai_addrlen) == 0) {
      const std::string request = "GET " + path + " HTTP/1.0\r\nHost: " + kHost +
                                  "\r\nUser-Agent: PS5X360\r\nConnection: close\r\n\r\n";
      if (send(sock, request.data(), request.size(), 0) == ssize_t(request.size())) {
        std::vector<uint8_t> answer;
        uint8_t buffer[16384];
        for (ssize_t got; (got = recv(sock, buffer, sizeof(buffer), 0)) > 0 && answer.size() < (8u << 20);)
          answer.insert(answer.end(), buffer, buffer + got);
        const uint8_t end[] = {'\r', '\n', '\r', '\n'};
        const auto split = std::search(answer.begin(), answer.end(), std::begin(end), std::end(end));
        const std::string head(answer.begin(), split);
        if (split != answer.end() && head.rfind("HTTP/1.", 0) == 0 && head.size() > 12 && head.compare(9, 3, "200") == 0)
          body.assign(split + 4, answer.end());
      }
    }
    close(sock);
  }
  freeaddrinfo(found);
  return body;
}

bool IsPicture(const std::vector<uint8_t>& data) {
  return data.size() > 64 && ((data[0] == 0xFF && data[1] == 0xD8) || (data[0] == 0x89 && data[1] == 'P'));
}

// Saves through a temporary name, so a half-written picture is never loaded.
bool Save(const fs::path& file, const std::vector<uint8_t>& data) {
  const fs::path part = file.string() + ".part";
  {
    std::ofstream out(part, std::ios::binary | std::ios::trunc);
    out.write(reinterpret_cast<const char*>(data.data()), std::streamsize(data.size()));
    if (!out) return false;
  }
  std::error_code error;
  fs::rename(part, file, error);
  return !error;
}

void Run(std::vector<std::string> ids) {
  std::error_code error;
  fs::create_directories(kFolder, error);
  bool saved = false;
  for (const auto& id : ids) {
    std::string lower = id;
    for (auto& ch : lower) ch = char(std::tolower(static_cast<unsigned char>(ch)));
    const std::string base = "/content/images/66acd000-77fe-1000-9115-d802" + lower + "/1033/";
    const std::pair<fs::path, const char*> wanted[] = {{Background(id), "background.jpg"}, {Tile(id), "tile.png"}};
    for (const auto& [file, name] : wanted) {
      if (fs::exists(file, error)) continue;
      const auto data = Get(base + name);
      const bool ok = IsPicture(data) && Save(file, data);
      saved |= ok;
      XELOGW("Home: game art {} {} for {} ({} bytes)", name, ok ? "saved" : "not found", id, data.size());
    }
  }
  if (saved) fresh = true;
  busy = false;
}
}  // namespace

fs::path Background(const std::string& title_id) { return fs::path(kFolder) / (title_id + "-background.jpg"); }
fs::path Tile(const std::string& title_id) { return fs::path(kFolder) / (title_id + "-tile.png"); }

void Fetch(const std::vector<std::string>& title_ids) {
  std::vector<std::string> wanted;
  {
    std::lock_guard<std::mutex> lock(mutex);
    for (const auto& id : title_ids)
      if (id.size() == 8 && asked.insert(id).second) wanted.push_back(id);
  }
  if (wanted.empty()) return;
  if (busy.exchange(true)) {
    // Another run is going: these are asked again on a later call.
    std::lock_guard<std::mutex> lock(mutex);
    for (const auto& id : wanted) asked.erase(id);
    return;
  }
  std::thread(Run, std::move(wanted)).detach();
}

bool TakeNew() { return fresh.exchange(false); }
}  // namespace game_art
