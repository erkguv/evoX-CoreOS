// SPDX-License-Identifier: MIT
#include "kinect_skin.hpp"

#include <algorithm>
#include <array>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>

namespace fs = std::filesystem;
namespace xbox360ps5::kinect_skin {
namespace {
// Where each picture is: the package, its name there, and the cache file name
// (a fixed literal: no name read from a package ever becomes a path).
struct Wanted {
  Asset asset;
  const char* package;  // "shrdres" is the shrdres.xzp file beside dash.xex.
  const char* entry;
  const char* file;
};
constexpr std::array<Wanted, size_t(Asset::kCount)> kWanted = {{
    {Asset::kBackground, "controlp", "aura_background.jpg", "background.jpg"},
    {Asset::kFloor, "controlp", "aura_floor.png", "floor.png"},
    {Asset::kHighlight, "controlp", "aura_highlight.png", "highlight.png"},
    {Asset::kBall, "controlp", "Legend_Menu.png", "ball.png"},
    {Asset::kBallGlow, "controlp", "SphereHighlight.png", "ball-glow.png"},
    {Asset::kAvatar, "controlp", "avatar_silhouette.png", "avatar.png"},
    {Asset::kSlot, "slots", "BlankGreen.jpg", "slot.jpg"},
    {Asset::kGameLibrary, "slots", "icon_gamelib.png", "icon-games.png"},
    {Asset::kSettings, "slots", "icon_settings.png", "icon-settings.png"},
    {Asset::kWireless, "slots", "icon_wireless.png", "icon-network.png"},
    {Asset::kDisc, "slots", "icon_disc.png", "icon-disc.png"},
    {Asset::kSlotGradient, "dashcomm", "slot_gradient.png", "slot-gradient.png"},
    {Asset::kSideShadow, "dashcomm", "slotSideShadow.png", "side-shadow.png"},
    {Asset::kBottomShadow, "dashcomm", "bottomshadow.png", "bottom-shadow.png"},
    {Asset::kXboxLogo, "dashcomm", "xboxLogo.png", "xbox-logo.png"},
    {Asset::kBasics, "dashcomm", "XboxBasicsSlot.jpg", "basics.jpg"},
    {Asset::kKinectWave, "dashcomm", "Kinect_wave.jpg", "kinect.jpg"},
    {Asset::kGamerscore, "shrdres", "Gscore.png", "gamerscore.png"},
    {Asset::kLowlight, "controlp", "aura_lowlight.png", "lowlight.png"},
}};
constexpr size_t kMaxImage = 8u << 20;

uint16_t Be16(const std::vector<uint8_t>& b, size_t p) { return uint16_t(b[p] << 8 | b[p + 1]); }
uint32_t Be32(const std::vector<uint8_t>& b, size_t p) {
  return uint32_t(b[p]) << 24 | uint32_t(b[p + 1]) << 16 | uint32_t(b[p + 2]) << 8 | b[p + 3];
}
// A JPEG or PNG of a sane size; anything else is treated as missing.
bool ValidImage(const std::vector<uint8_t>& b) {
  static const uint8_t jpeg[] = {0xff, 0xd8, 0xff}, png[] = {0x89, 'P', 'N', 'G', '\r', '\n', 0x1a, '\n'};
  if (b.size() < 64 || b.size() > kMaxImage) return false;
  return std::equal(std::begin(jpeg), std::end(jpeg), b.begin()) || std::equal(std::begin(png), std::end(png), b.begin());
}
bool ReadFile(const fs::path& path, size_t limit, std::vector<uint8_t>& out) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  if (!in) return false;
  const auto length = in.tellg();
  if (length <= 0 || uint64_t(length) > limit) return false;
  out.resize(size_t(length));
  in.seekg(0);
  return bool(in.read(reinterpret_cast<char*>(out.data()), length));
}
bool WriteAtomic(const fs::path& path, const std::vector<uint8_t>& bytes) {
  const fs::path temp = path.string() + ".tmp";
  {
    std::ofstream out(temp, std::ios::binary | std::ios::trunc);
    if (!out || !out.write(reinterpret_cast<const char*>(bytes.data()), std::streamsize(bytes.size()))) return false;
  }
  std::error_code error;
  fs::rename(temp, path, error);
  if (error) fs::remove(temp, error);
  return !error;
}
// The wanted pictures of one XUIZ package: header "XUIZ", u32 version, u32 total
// size, u32 0, u32 table size, u16 count, entries (u32 size, u32 offset, u8 name
// length, name), data after the table. A name listed twice: the last one wins.
bool ExtractPackage(const std::vector<uint8_t>& b, std::string_view package,
                    std::vector<std::vector<uint8_t>>& images) {
  if (b.size() < 0x16 || b.size() > (64u << 20) || std::string_view(reinterpret_cast<const char*>(b.data()), 4) != "XUIZ")
    return false;
  const uint64_t base = 0x16ull + Be32(b, 0x10);
  if (Be32(b, 8) != b.size() || base > b.size()) return false;
  size_t p = 0x16;
  const uint16_t count = Be16(b, 0x14);
  for (uint16_t i = 0; i < count; ++i) {
    if (p + 9 > base) return false;
    const uint32_t size = Be32(b, p), offset = Be32(b, p + 4);
    const uint8_t length = b[p + 8];
    if (!length || p + 9ull + length > base || base + uint64_t(offset) + size > b.size()) return false;
    std::string name(b.begin() + long(p) + 9, b.begin() + long(p) + 9 + length);
    for (char& ch : name) if (ch == '\\') ch = '/';
    for (const auto& wanted : kWanted) {
      if (package == wanted.package && name == wanted.entry && size <= kMaxImage)
        images[size_t(wanted.asset)].assign(b.begin() + long(base + offset), b.begin() + long(base + offset + size));
    }
    p += 9 + length;
  }
  return p == base;
}
// FNV-1a of the file: a new dash.xex gets a new cache folder.
bool Fingerprint(const fs::path& path, std::string& output) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return false;
  uint64_t value = 14695981039346656037ull;
  std::array<char, 65536> chunk{};
  size_t total = 0;
  while (in) {
    in.read(chunk.data(), chunk.size());
    const auto got = in.gcount();
    for (std::streamsize i = 0; i < got; ++i) {
      value ^= uint8_t(chunk[size_t(i)]);
      value *= 1099511628211ull;
    }
    total += size_t(got);
    if (total > (128u << 20)) return false;
  }
  if (!in.eof() || total < 1024) return false;
  std::ostringstream key;
  key << std::hex << std::setw(16) << std::setfill('0') << value;
  output = key.str();
  return true;
}
}  // namespace

bool SkinAssets::LoadSkin(const fs::path& dash_path, const fs::path& cache_root, const PackageDecoder& decoder) {
  available_ = false;
  images_.assign(size_t(Asset::kCount), {});
  std::string key;
  if (!Fingerprint(dash_path, key)) return false;
  const fs::path cache = cache_root / ("v3-" + key);
  // A complete cache has background.jpg and a "done" mark: what is missing in
  // the user's files stays missing without being looked for at every start.
  std::vector<uint8_t> mark;
  if (ReadFile(cache / "done", 64, mark)) {
    for (const auto& wanted : kWanted) {
      std::vector<uint8_t> bytes;
      if (ReadFile(cache / wanted.file, kMaxImage, bytes) && ValidImage(bytes)) images_[size_t(wanted.asset)] = std::move(bytes);
    }
  } else {
    if (!decoder) return false;
    for (const char* package : {"controlp", "slots", "dashcomm"}) {
      std::vector<uint8_t> bytes;
      if (decoder(dash_path, package, bytes)) ExtractPackage(bytes, package, images_);
    }
    std::vector<uint8_t> shared;
    if (ReadFile(dash_path.parent_path() / "shrdres.xzp", 64u << 20, shared)) ExtractPackage(shared, "shrdres", images_);
    for (auto& image : images_) if (!image.empty() && !ValidImage(image)) image.clear();
    if (images_[size_t(Asset::kBackground)].empty()) return false;
    std::error_code error;
    fs::create_directories(cache, error);
    if (!error) {
      bool written = true;
      for (const auto& wanted : kWanted) {
        const auto& bytes = images_[size_t(wanted.asset)];
        if (!bytes.empty()) written = WriteAtomic(cache / wanted.file, bytes) && written;
      }
      if (written) WriteAtomic(cache / "done", std::vector<uint8_t>{'1', '\n'});
    }
  }
  available_ = !images_[size_t(Asset::kBackground)].empty();
  return available_;
}

bool SkinAssets::LoadOwn(const std::vector<fs::path>& folders) {
  available_ = false;
  images_.assign(size_t(Asset::kCount), {});
  for (const auto& wanted : kWanted) {
    for (const auto& folder : folders) {
      std::vector<uint8_t> bytes;
      if (ReadFile(folder / wanted.file, kMaxImage, bytes) && ValidImage(bytes)) {
        images_[size_t(wanted.asset)] = std::move(bytes);
        break;
      }
    }
  }
  // Without a background.jpg the home keeps the emulator's own green background.
  available_ = std::any_of(images_.begin(), images_.end(), [](const auto& image) { return !image.empty(); });
  return available_;
}

const std::vector<uint8_t>* SkinAssets::Read(Asset asset) const {
  if (!available_ || int(asset) < 0 || asset >= Asset::kCount) return nullptr;
  const auto& bytes = images_[size_t(asset)];
  return bytes.empty() ? nullptr : &bytes;
}

}  // namespace xbox360ps5::kinect_skin
