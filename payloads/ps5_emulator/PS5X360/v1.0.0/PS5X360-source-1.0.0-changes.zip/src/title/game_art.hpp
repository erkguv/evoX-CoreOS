// SPDX-License-Identifier: MIT
// A game's Marketplace art for the home's "Jogar ..." slot: its background (1280x720) and its
// tile icon (64x64), fetched once by title ID from Microsoft's image server over plain HTTP
// (as covers.cpp fetches box art) and kept in /data/homebrew/PPSA50011/game-art, where the PC can
// also put them (FTP).
#pragma once
#include <filesystem>
#include <string>
#include <vector>

namespace game_art {
// <folder>/<TITLEID>-background.jpg or <TITLEID>-tile.png; the file may not exist yet.
std::filesystem::path Background(const std::string& title_id);
std::filesystem::path Tile(const std::string& title_id);
// Fetches, on a thread of its own, what these titles do not have yet (one run at a time; a title
// the server has nothing for is not asked again in this run of the emulator).
void Fetch(const std::vector<std::string>& title_ids);
// True once after a run that saved new pictures, so they are loaded.
bool TakeNew();
}  // namespace game_art
