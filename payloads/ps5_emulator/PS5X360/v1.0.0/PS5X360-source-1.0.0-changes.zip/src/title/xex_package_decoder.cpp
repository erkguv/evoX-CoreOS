// SPDX-License-Identifier: MIT
// Small, bounded XEX2 resource reader using Xenia's linked AES/LZX codecs.
#include "xex_package_decoder.hpp"

#include <algorithm>
#include <array>
#include <cstring>
#include <fstream>
#include <iterator>

// Signature from xenia/cpu/lzx.h. Forward declaring avoids importing the
// unrelated CPU headers into this small parser.
extern int lzx_decompress(const void* lzx_data, size_t lzx_len, void* dest,
                          size_t dest_len, uint32_t window_size,
                          void* window_data, size_t window_data_len);

// Exported by Xenia's xex_module.cc, already part of the native image.
extern void aes_decrypt_buffer(const uint8_t* session_key, const uint8_t* input_buffer,
                               size_t input_size, uint8_t* output_buffer,
                               size_t output_size);

namespace xbox360ps5::kinect_skin {
namespace {
constexpr std::array<uint8_t, 16> kRetailKey = {
    0x20, 0xB1, 0x85, 0xA5, 0x9D, 0x28, 0xFD, 0xC3,
    0x40, 0x58, 0x3F, 0xBB, 0x08, 0x96, 0xBF, 0x91};
constexpr size_t kMaxXex = 128u << 20;
constexpr size_t kMaxImage = 192u << 20;

bool Range(size_t length, uint64_t offset, uint64_t size) {
  return offset <= length && size <= length - offset;
}
uint16_t Be16(const std::vector<uint8_t>& b, size_t p) {
  return uint16_t(b[p]) << 8 | b[p + 1];
}
uint32_t Be32(const std::vector<uint8_t>& b, size_t p) {
  return uint32_t(b[p]) << 24 | uint32_t(b[p + 1]) << 16 | uint32_t(b[p + 2]) << 8 | b[p + 3];
}
bool ReadFile(const std::filesystem::path& path, std::vector<uint8_t>& out) {
  std::ifstream in(path, std::ios::binary | std::ios::ate);
  if (!in) return false;
  const auto length = in.tellg();
  if (length < 0 || static_cast<uint64_t>(length) > kMaxXex) return false;
  out.resize(static_cast<size_t>(length));
  in.seekg(0);
  return bool(in.read(reinterpret_cast<char*>(out.data()), length));
}

bool DecodePackage(const std::filesystem::path& path, std::string_view wanted,
                   std::vector<uint8_t>& result) {
  result.clear();
  if (wanted.size() > 8 || wanted.empty()) return false;
  std::vector<uint8_t> xex;
  if (!ReadFile(path, xex) || !Range(xex.size(), 0, 0x18) ||
      std::memcmp(xex.data(), "XEX2", 4)) return false;
  const uint32_t header_size = Be32(xex, 8);
  const uint32_t security = Be32(xex, 0x10);
  const uint32_t count = Be32(xex, 0x14);
  if (count > 4096 || header_size >= xex.size() ||
      !Range(xex.size(), 0x18, uint64_t(count) * 8) ||
      !Range(xex.size(), security, 0x160)) return false;

  uint32_t format = 0, resources = 0, image_base = 0;
  for (uint32_t i = 0; i < count; ++i) {
    const uint32_t key = Be32(xex, 0x18 + i * 8);
    const uint32_t value = Be32(xex, 0x1c + i * 8);
    if (key == 0x000003ff) format = value;
    if (key == 0x000002ff) resources = value;
    if (key == 0x00010001) image_base = value;
  }
  if (!image_base) image_base = Be32(xex, security + 0x110);
  const uint32_t image_size = Be32(xex, security + 4);
  if (!Range(xex.size(), format, 16) || !Range(xex.size(), resources, 4) ||
      image_size == 0 || image_size > kMaxImage || !image_base) return false;
  const uint32_t res_size = Be32(xex, resources);
  if (res_size < 4 || (res_size - 4) % 16 ||
      !Range(xex.size(), resources, res_size)) return false;

  uint32_t address = 0, size = 0;
  for (uint32_t i = 0; i < (res_size - 4) / 16; ++i) {
    const size_t p = resources + 4 + i * 16;
    const size_t name_size = strnlen(reinterpret_cast<const char*>(xex.data() + p), 8);
    if (std::string_view(reinterpret_cast<const char*>(xex.data() + p), name_size) == wanted) {
      address = Be32(xex, p + 8);
      size = Be32(xex, p + 12);
    }
  }
  if (!size || address < image_base ||
      !Range(image_size, uint64_t(address) - image_base, size)) return false;

  const uint16_t encryption = Be16(xex, format + 4);
  const uint16_t compression = Be16(xex, format + 6);
  const size_t payload_size = xex.size() - header_size;
  std::vector<uint8_t> payload(payload_size);
  if (encryption == 0) {
    std::copy(xex.begin() + header_size, xex.end(), payload.begin());
  } else if (encryption == 1 && !(payload_size % 16)) {
    std::array<uint8_t, 16> session{};
    aes_decrypt_buffer(kRetailKey.data(), xex.data() + security + 0x150,
                       16, session.data(), 16);
    aes_decrypt_buffer(session.data(), xex.data() + header_size,
                       payload_size, payload.data(), payload_size);
  } else {
    return false;
  }

  std::vector<uint8_t> image(image_size, 0);
  if (compression == 0) {
    if (payload.size() > image.size()) return false;
    std::copy(payload.begin(), payload.end(), image.begin());
  } else if (compression == 1) {
    const uint32_t format_size = Be32(xex, format);
    if (format_size < 8 || (format_size - 8) % 8 ||
        !Range(xex.size(), format, format_size)) return false;
    size_t source = 0, target = 0;
    for (uint32_t i = 0; i < (format_size - 8) / 8; ++i) {
      const uint32_t bytes = Be32(xex, format + 8 + i * 8);
      const uint32_t zero = Be32(xex, format + 12 + i * 8);
      if (!Range(payload.size(), source, bytes) ||
          !Range(image.size(), target, uint64_t(bytes) + zero)) return false;
      std::copy(payload.begin() + source, payload.begin() + source + bytes,
                image.begin() + target);
      source += bytes; target += bytes + zero;
    }
  } else if (compression == 2) {
    const uint32_t window = Be32(xex, format + 8);
    uint32_t block = Be32(xex, format + 12);
    if (window < (1u << 15) || window > (1u << 21) || !block) return false;
    std::vector<uint8_t> packed;
    packed.reserve(payload.size());
    size_t source = 0;
    while (block) {
      if (!Range(payload.size(), source, block) || block < 24) return false;
      const size_t end = source + block;
      const uint32_t next = Be32(payload, source);
      source += 24;  // block size and SHA-1 digest
      bool terminated = false;
      while (source + 2 <= end) {
        const uint16_t chunk = Be16(payload, source);
        source += 2;
        if (!chunk) { terminated = true; break; }
        if (!Range(end, source, chunk)) return false;
        packed.insert(packed.end(), payload.begin() + source,
                      payload.begin() + source + chunk);
        source += chunk;
      }
      if (!terminated) return false;
      source = end;
      block = next;
    }
    if (packed.empty() || lzx_decompress(packed.data(), packed.size(), image.data(),
                                         image.size(), window, nullptr, 0) != 0) return false;
  } else {
    return false;
  }

  const size_t offset = address - image_base;
  result.assign(image.begin() + offset, image.begin() + offset + size);
  return result.size() >= 4 && std::memcmp(result.data(), "XUIZ", 4) == 0;
}
}  // namespace

PackageDecoder MakeXexPackageDecoder() { return DecodePackage; }

}  // namespace xbox360ps5::kinect_skin
