// SPDX-License-Identifier: MIT
// The Kinect-era home's pictures, read from the owner's own dash.xex (and the
// shrdres.xzp beside it) on the console. No dashboard resource is in this code
// or in the PS5X360 package: a fixed list of names is looked up in the user's
// files and kept in a private cache on the console.
#pragma once

#include <cstdint>
#include <filesystem>
#include <functional>
#include <string_view>
#include <vector>

namespace xbox360ps5::kinect_skin {

// Reads the owner's dash.xex at dash_path and returns one XUIZ package
// ("controlp", "slots", "dashcomm", ...) of it.
using PackageDecoder = std::function<bool(const std::filesystem::path& dash_path,
                                          std::string_view package,
                                          std::vector<uint8_t>& bytes)>;

// The pictures the home uses. kBackground is required; any other may be missing.
enum class Asset : int {
  kBackground, kFloor, kHighlight, kBall, kBallGlow, kAvatar, kSlot, kGameLibrary, kSettings,
  kWireless, kDisc, kSlotGradient, kSideShadow, kBottomShadow, kXboxLogo, kBasics, kKinectWave,
  kGamerscore, kLowlight, kCount
};

class SkinAssets {
 public:
  // From the private cache under cache_root, else from the user's files
  // (through decoder), which then fill the cache. False when there is no
  // dash.xex or it cannot be read: the home then draws its own art.
  bool LoadSkin(const std::filesystem::path& dash_path, const std::filesystem::path& cache_root,
                const PackageDecoder& decoder);
  // PS5X360's own pictures, under the same file names as the cache: each one from the first
  // folder that has it. False when none of them has background.jpg.
  bool LoadOwn(const std::vector<std::filesystem::path>& folders);
  // Nullptr when that picture is not there.
  const std::vector<uint8_t>* Read(Asset asset) const;
  bool available() const { return available_; }

 private:
  bool available_ = false;
  std::vector<std::vector<uint8_t>> images_;
};

}  // namespace xbox360ps5::kinect_skin
