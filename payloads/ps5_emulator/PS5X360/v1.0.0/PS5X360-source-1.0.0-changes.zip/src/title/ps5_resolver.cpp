// Xbox360PS5: host names and three missing libc calls for the network libraries (libcurl, miniupnpc, the netplay core).
// The platform's getaddrinfo refuses every lookup (ps5platform/libc.h), so the link wraps
// getaddrinfo and freeaddrinfo with these. A name is asked of public DNS servers, then of the
// console's own resolver, as covers.cpp finds its cover server (the console's DNS is often a
// jailbreak helper that blocks sites). IPv4 only; the service must be a port number or empty.
// Every result is one block made here, and only freeaddrinfo here frees it.
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <initializer_list>

extern "C" int sceNetResolverCreate(const char* name, int memory, int flags);
extern "C" int sceNetResolverStartNtoa(int resolver, const char* host, in_addr* address, int timeout,
                                       int retries, int flags);
extern "C" int sceNetResolverDestroy(int resolver);

namespace {

// One A record for host straight from a DNS server over UDP (covers.cpp's QueryDns).
in_addr_t QueryDns(const char* server, const char* host) {
  const int sock = socket(AF_INET, SOCK_DGRAM, 0);
  if (sock < 0) return 0;
  timeval timeout{3, 0};
  setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
  uint8_t query[512] = {0x58, 0x36, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0};  // id, recursion, 1 question
  size_t length = 12;
  for (const char* label = host; *label;) {
    const char* dot = std::strchr(label, '.');
    const size_t size = dot ? size_t(dot - label) : std::strlen(label);
    if (size == 0 || size > 63 || length + size + 6 > sizeof(query)) {
      close(sock);
      return 0;
    }
    query[length++] = uint8_t(size);
    std::memcpy(&query[length], label, size);
    length += size;
    label += size + (dot ? 1 : 0);
  }
  const uint8_t tail[] = {0, 0, 1, 0, 1};  // end of name, type A, class IN
  std::memcpy(&query[length], tail, sizeof(tail));
  length += sizeof(tail);
  sockaddr_in to{};
  to.sin_len = sizeof(to);
  to.sin_family = AF_INET;
  to.sin_port = htons(53);
  to.sin_addr.s_addr = inet_addr(server);
  in_addr_t found = 0;
  uint8_t answer[512];
  if (sendto(sock, query, length, 0, reinterpret_cast<sockaddr*>(&to), sizeof(to)) == ssize_t(length)) {
    const ssize_t got = recv(sock, answer, sizeof(answer), 0);
    if (got > 12 && answer[0] == 0x58 && answer[1] == 0x36 && (answer[3] & 15) == 0) {
      const int answers = answer[6] << 8 | answer[7];
      size_t at = length;  // The answers follow the echoed question.
      for (int n = 0; n < answers && at < size_t(got); ++n) {
        if ((answer[at] & 0xC0) == 0xC0) {
          at += 2;
        } else {
          while (at < size_t(got) && answer[at]) at += answer[at] + 1;
          ++at;
        }
        if (at + 10 > size_t(got)) break;
        const int type = answer[at] << 8 | answer[at + 1];
        const int data = answer[at + 8] << 8 | answer[at + 9];
        at += 10;
        if (type == 1 && data == 4 && at + 4 <= size_t(got)) {
          std::memcpy(&found, &answer[at], 4);
          break;
        }
        at += size_t(data);
      }
    }
  }
  close(sock);
  return found;
}

in_addr_t Resolve(const char* host) {
  for (const char* server : {"1.1.1.1", "8.8.8.8"}) {
    if (const in_addr_t address = QueryDns(server, host)) return address;
  }
  const int resolver = sceNetResolverCreate("xbox360ps5-net", 0, 0);
  if (resolver < 0) return 0;
  in_addr address{};
  const int status = sceNetResolverStartNtoa(resolver, host, &address, 5 * 1000 * 1000, 2, 0);
  sceNetResolverDestroy(resolver);
  return status >= 0 ? address.s_addr : 0;
}

struct Block {
  addrinfo info;
  sockaddr_in address;
};

}  // namespace

extern "C" int __wrap_getaddrinfo(const char* node, const char* service, const addrinfo* hints, addrinfo** result) {
  if (!result || (!node && !service)) return EAI_NONAME;
  *result = nullptr;
  const int family = hints ? hints->ai_family : AF_UNSPEC;
  if (family != AF_UNSPEC && family != AF_INET) return EAI_FAMILY;
  const int flags = hints ? hints->ai_flags : 0;
  unsigned long port = 0;
  if (service && *service) {
    char* end = nullptr;
    port = std::strtoul(service, &end, 10);
    if (*end || port > 65535) return EAI_SERVICE;
  }
  in_addr address{};
  if (!node || !*node) {
    address.s_addr = htonl((flags & AI_PASSIVE) ? INADDR_ANY : INADDR_LOOPBACK);
  } else if (inet_pton(AF_INET, node, &address) != 1) {
    if (flags & AI_NUMERICHOST) return EAI_NONAME;
    address.s_addr = Resolve(node);
    if (!address.s_addr) return EAI_NONAME;
  }
  auto* block = static_cast<Block*>(std::calloc(1, sizeof(Block)));
  if (!block) return EAI_MEMORY;
  block->address.sin_len = sizeof(sockaddr_in);
  block->address.sin_family = AF_INET;
  block->address.sin_port = htons(uint16_t(port));
  block->address.sin_addr = address;
  block->info.ai_family = AF_INET;
  block->info.ai_socktype = hints ? hints->ai_socktype : 0;
  block->info.ai_protocol = hints ? hints->ai_protocol : 0;
  block->info.ai_addrlen = sizeof(sockaddr_in);
  block->info.ai_addr = reinterpret_cast<sockaddr*>(&block->address);
  *result = &block->info;
  return 0;
}

extern "C" void __wrap_freeaddrinfo(addrinfo* info) {
  // Each result is a single block whose first member is the addrinfo.
  std::free(info);
}

// Three calls the title's libc leaves out that libcurl and miniupnpc link against. Interface
// names only qualify IPv6 link-local addresses, which the console's network never hands out
// here: no name has an index. pipe2 is pipe with its flags set afterwards.
#include <fcntl.h>
#include <net/if.h>

extern "C" unsigned int if_nametoindex(const char*) { return 0; }

extern "C" char* if_indextoname(unsigned int, char*) {
  errno = ENXIO;
  return nullptr;
}

// libcurl makes its wake-up channel with this (every transfer: a failure there was reported
// as "out of memory", CURLE 27, with no text). The console may refuse pipe; then the channel
// is a TCP connection to itself on the loopback address, which libcurl reads and writes the
// same way. Close-on-exec is only a wish (a title starts no other program).
namespace {
int LoopbackPair(int fds[2]) {
  const int listener = socket(AF_INET, SOCK_STREAM, 0);
  if (listener < 0) return -1;
  sockaddr_in at{};
  at.sin_len = sizeof(at);
  at.sin_family = AF_INET;
  at.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
  socklen_t length = sizeof(at);
  int ends[2] = {-1, -1};
  if (bind(listener, reinterpret_cast<sockaddr*>(&at), sizeof(at)) == 0 && listen(listener, 1) == 0 &&
      getsockname(listener, reinterpret_cast<sockaddr*>(&at), &length) == 0) {
    ends[1] = socket(AF_INET, SOCK_STREAM, 0);
    if (ends[1] >= 0 && connect(ends[1], reinterpret_cast<sockaddr*>(&at), sizeof(at)) == 0)
      ends[0] = accept(listener, nullptr, nullptr);
  }
  close(listener);
  if (ends[0] < 0) {
    if (ends[1] >= 0) close(ends[1]);
    return -1;
  }
  fds[0] = ends[0];
  fds[1] = ends[1];
  return 0;
}
}  // namespace

extern "C" int pipe2(int fds[2], int flags) {
  if (pipe(fds) != 0 && LoopbackPair(fds) != 0) return -1;
  for (int n = 0; n < 2; ++n) {
    if (flags & O_NONBLOCK) {
      // As xsocket.cc: the descriptor's flag, else the console's own socket option (SO_NBIO).
      const int now = fcntl(fds[n], F_GETFL);
      const int one = 1;
      if ((now < 0 || fcntl(fds[n], F_SETFL, now | O_NONBLOCK) < 0) &&
          setsockopt(fds[n], SOL_SOCKET, 0x1200, &one, sizeof(one)) < 0) {
        close(fds[0]);
        close(fds[1]);
        return -1;
      }
    }
    if (flags & O_CLOEXEC) fcntl(fds[n], F_SETFD, FD_CLOEXEC);
  }
  return 0;
}

// Three more that libcurl and miniupnpc import from libScePosixForWebKit, a module a title does
// not get: the import stays at address zero and the first call jumps there (online mode with
// UPnP crashed in ssdpDiscoverDevices, 2026-10-21). The link wraps them (a definition of the
// plain name would be exported, which the title converter refuses). Numeric answers only.
extern "C" const char* __wrap_gai_strerror(int error) {
  switch (error) {
    case 0: return "Success";
    case EAI_NONAME: return "Name does not resolve";
    case EAI_FAMILY: return "Address family not supported";
    case EAI_SERVICE: return "Service not supported";
    case EAI_MEMORY: return "Out of memory";
    default: return "Name lookup failed";
  }
}

extern "C" int __wrap_getnameinfo(const sockaddr* address, socklen_t length, char* host, size_t host_length, char* service,
                           size_t service_length, int) {
  if (!address || address->sa_family != AF_INET || length < socklen_t(sizeof(sockaddr_in))) return EAI_FAMILY;
  const auto* in = reinterpret_cast<const sockaddr_in*>(address);
  if (host && host_length && !inet_ntop(AF_INET, &in->sin_addr, host, socklen_t(host_length))) return EAI_OVERFLOW;
  if (service && service_length) {
    const int written = std::snprintf(service, service_length, "%u", unsigned(ntohs(in->sin_port)));
    if (written < 0 || size_t(written) >= service_length) return EAI_OVERFLOW;
  }
  return 0;
}

// Shell patterns: '*', '?', '[...]' (with '!' or '^' and ranges) and '\' escapes; no flags.
extern "C" int __wrap_fnmatch(const char* pattern, const char* text, int) {
  for (;; ++pattern, ++text) {
    if (*pattern == '*') {
      while (*pattern == '*') ++pattern;
      if (!*pattern) return 0;
      for (; *text; ++text)
        if (__wrap_fnmatch(pattern, text, 0) == 0) return 0;
      return 1;
    }
    if (!*text) return *pattern ? 1 : 0;
    if (*pattern == '?') continue;
    if (*pattern == '[') {
      const char* p = pattern + 1;
      const bool negate = *p == '!' || *p == '^';
      if (negate) ++p;
      bool found = false;
      for (bool first = true; *p && (first || *p != ']'); first = false, ++p) {
        if (p[1] == '-' && p[2] && p[2] != ']') {
          found |= *text >= p[0] && *text <= p[2];
          p += 2;
        } else {
          found |= *p == *text;
        }
      }
      if (*p != ']' || found == negate) return 1;
      pattern = p;
      continue;
    }
    if (*pattern == '\\' && pattern[1]) ++pattern;
    if (*pattern != *text) return 1;
  }
}

// wolfSSL's seed (net-libs/ps5_rng.h): the platform's arc4random (ps5platform, bound by the
// link recipe; the same source libc++'s random_device uses here). 0 on success, as wolfSSL
// expects.
extern "C" void arc4random_buf(void* buffer, size_t size);
extern "C" int ps5x_wolfssl_seed(unsigned char* output, unsigned int size) {
  arc4random_buf(output, size);
  return 0;
}
