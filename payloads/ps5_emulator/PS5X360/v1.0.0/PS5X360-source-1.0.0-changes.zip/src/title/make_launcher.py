"""launcher.cpp = build/ui-kinect-20261020/launcher.cpp (Codex's Kinect home navigation over the
console's NXE launcher) with the home drawn in the manner of the 2.0.13604 dashboard:
kinect_state.inc (state and slots, before the first use), kinect_home.inc (drawing, before
Launcher::Draw), kinect_shelf.inc (inside DrawShelf) and kinect_press.inc (inside Press) replace
Codex's card page; kinect_skin.cpp replaces skin_assets.cpp (19 pictures instead of 3).

    python make_launcher.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
source = (here.parents[1] / "ui-kinect-20261020/launcher.cpp").read_text(encoding='utf-8')


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old[:80], text.count(old))
    return text.replace(old, new)


def between(text, start, end, new):
    i = text.index(start)
    j = text.index(end, i)
    assert text.count(start) == 1
    return text[:i] + new + text[j:]


s = source
s = replace(s, '#include "../ui-kinect-assets-20261020/skin_assets.hpp"\n#include "../ui-kinect-assets-20261020/xex_package_decoder.hpp"\n',
            '#include "kinect_skin.hpp"\n#include "xex_package_decoder.hpp"\n#include "game_art.hpp"\n')
s = replace(s, 'bool home_profiles_open = false;\n', 'bool home_profiles_open = false;\n#include "kinect_state.inc"\n')
s = replace(s, '}  // namespace\n\nvoid Launcher::Draw(ImGuiIO& io) {', '#include "kinect_home.inc"\n}  // namespace\n\nvoid Launcher::Draw(ImGuiIO& io) {')
# Draw: the dashboard's background when the pictures are there, under the home and the library alike.
s = between(s, '  if (NxeUi()) DrawNxeBackground(c, time_);\n', '  if (!loading_.empty()) {\n',
            '  // The Kinect-era home\'s pictures, from the owner\'s dash.xex (kinect_home.inc).\n'
            '  const KinectSkinTextures& kinect_skin_textures = KinectSkin(NxeUi() && drawer_ ? KinectMakeTexture(\n'
            '      [this](uint32_t w, uint32_t h, const uint8_t* pixels) {\n'
            '        return drawer_->CreateTexture(w, h, xe::ui::ImmediateTextureFilter::kLinear, false, pixels);\n'
            '      }) : KinectMakeTexture());\n'
            '  if (NxeUi() && kinect_skin_textures.loaded()) DrawKinectBackground(c, kinect_skin_textures, time_, !home_library_open);\n'
            '  else if (NxeUi()) DrawNxeBackground(c, time_);\n'
            '  else\n'
            '    c.list->AddRectFilledMultiColor(ImVec2(0, 0), io.DisplaySize, c.Color(0x0f1b2e), c.Color(0x0b1322),\n'
            '                                  c.Color(kInk), c.Color(0x06070a));\n')
s = between(s, '  if (NxeUi() && !home_library_open) {\n    using kinect_ui::Page;\n', '  if (NxeUi()) {\n    const int count',
            '  if (NxeUi() && !home_library_open) {\n#include "kinect_shelf.inc"\n  }\n')
s = between(s, '  if (mode_ == Mode::shelf && NxeUi() && !home_library_open) {\n    using kinect_ui::Input;\n',
            '  if (mode_ == Mode::shelf && home_library_open && key == Key::circle) {',
            '  if (mode_ == Mode::shelf && NxeUi() && !home_library_open) {\n#include "kinect_press.inc"\n  }\n')
import sys
sys.path.insert(0, str(here))
from make_launcher_tail import theme
s = theme(s, replace)
(here / 'launcher.cpp').write_text(s, encoding='utf-8')
print('launcher.cpp', len(s.splitlines()), 'lines')
