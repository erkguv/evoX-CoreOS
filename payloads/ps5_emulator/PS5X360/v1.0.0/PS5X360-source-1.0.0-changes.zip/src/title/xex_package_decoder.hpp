// SPDX-License-Identifier: MIT
#pragma once

#include "kinect_skin.hpp"

namespace xbox360ps5::kinect_skin {

// Uses the AES and LZX routines already linked in Xenia. Only call this with
// the owner's locally installed dashboard XEX; never package the result.
PackageDecoder MakeXexPackageDecoder();

}  // namespace xbox360ps5::kinect_skin
