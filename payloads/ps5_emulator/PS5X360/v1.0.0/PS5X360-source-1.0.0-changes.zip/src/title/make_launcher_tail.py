# The second half of make_launcher.py (kept apart so its escapes stay plain): the library's
# colours, the cover library and the twice-encoded text. Run by make_launcher.py on its text `s`.


def theme(s, replace):
    # Text the NXE build wrote twice-encoded (UTF-8 read as Windows-1252): back to plain UTF-8.
    import re
    cp1252 = set(bytes(range(0x80, 0x100)).decode('cp1252', errors='ignore'))
    def repair(match):
        text = match.group(0)
        try:
            return text.encode('cp1252').decode('utf-8')
        except (UnicodeEncodeError, UnicodeDecodeError):
            return text
    run = '[' + re.escape(''.join(sorted(cp1252))) + ']+'
    s = re.sub(run, repair, s)
    assert 'estÃ¡' not in s and 'ConfiguraÃ' not in s, 'twice-encoded text left'
    # The whole library in the dashboard's colours while the new interface is on: the colours
    # become variables, set at the start of every frame (ui-classic.on keeps the graphite ones).
    s = replace(s, 'constexpr uint32_t kInk = 0x0a0c11, kSheet = 0x12161d, kSurface = 0x1a1f28, kSurfaceHigh = 0x252c38,\n'
                   '                   kAccent = 0x35d07f, kText = 0xf3f5f8, kBody = 0xd5dae2, kMuted = 0x9aa3b2,\n'
                   '                   kFaint = 0x6f7888, kWarning = 0xf0a67a, kWhite = 0xffffff, kCaseGreen = 0x8cc63f;\n',
                '''uint32_t kInk = 0x0a0c11, kSheet = 0x12161d, kSurface = 0x1a1f28, kSurfaceHigh = 0x252c38,
         kAccent = 0x35d07f, kText = 0xf3f5f8, kBody = 0xd5dae2, kMuted = 0x9aa3b2,
         kFaint = 0x6f7888, kWarning = 0xf0a67a;
constexpr uint32_t kWhite = 0xffffff, kCaseGreen = 0x8cc63f;
// The Kinect-era dashboard's colours: light grey panels, dark type, its green.
void ApplyTheme(bool dashboard) {
  if (dashboard) {
    kSheet = 0xe8e9ea; kSurface = 0xd6d9dc; kSurfaceHigh = 0xc4e0a6; kAccent = 0x5aa02c;
    kText = 0x262626; kBody = 0x3a3d40; kMuted = 0x6c7177; kFaint = 0x969ba1; kWarning = 0xc0501e;
  } else {
    kSheet = 0x12161d; kSurface = 0x1a1f28; kSurfaceHigh = 0x252c38; kAccent = 0x35d07f;
    kText = 0xf3f5f8; kBody = 0xd5dae2; kMuted = 0x9aa3b2; kFaint = 0x6f7888; kWarning = 0xf0a67a;
  }
}
''')
    s = replace(s, 'void Launcher::Draw(ImGuiIO& io) {\n', 'void Launcher::Draw(ImGuiIO& io) {\n  ApplyTheme(NxeUi());\n')
    # The library opened from the home lists the games as covers, the classic shelf's way.
    s = replace(s, '  if (NxeUi()) {\n    const int count = int(view_.size());',
                '  if (NxeUi() && !home_library_open) {\n    const int count = int(view_.size());')
    # In the library of covers over the dashboard's background: a light floor instead of the dark
    # one, the dashboard's green around the chosen case, and Circle to go back home.
    s = replace(s, '      c.list->AddQuadFilled(lower.tl, lower.tr, lower.br, lower.bl, c.Color(0x20262f));\n',
                '      c.list->AddQuadFilled(lower.tl, lower.tr, lower.br, lower.bl, c.Color(NxeUi() ? 0xc9ccd0 : 0x20262f));\n')
    s = replace(s, '    c.list->AddRectFilledMultiColor(c.At(0, floor), c.At(1920, floor + 260), c.Color(kInk, 0.25f), c.Color(kInk, 0.25f),\n'
                   '                                    c.Color(0x06080c, 1.0f), c.Color(0x06080c, 1.0f));\n',
                '    if (NxeUi())\n'
                '      c.list->AddRectFilledMultiColor(c.At(0, floor), c.At(1920, 1080), c.Color(0xe9eaeb, 0.35f),\n'
                '                                      c.Color(0xe9eaeb, 0.35f), c.Color(0xdfe1e3, 0.95f), c.Color(0xdfe1e3, 0.95f));\n'
                '    else\n'
                '      c.list->AddRectFilledMultiColor(c.At(0, floor), c.At(1920, floor + 260), c.Color(kInk, 0.25f), c.Color(kInk, 0.25f),\n'
                '                                      c.Color(0x06080c, 1.0f), c.Color(0x06080c, 1.0f));\n')
    s = replace(s, '        c.list->AddQuad(q.tl, q.tr, q.br, q.bl, c.Color(0x64ff9c, strength * layer.second),\n',
                '        c.list->AddQuad(q.tl, q.tr, q.br, q.bl, c.Color(NxeUi() ? 0x7cc84a : 0x64ff9c, strength * layer.second),\n')
    s = replace(s, '      if (chosen) c.list->AddQuad(q.tl, q.tr, q.br, q.bl, c.Color(0xc6ffe0, 0.85f * pulse), c.scale);\n',
                '      if (chosen) c.list->AddQuad(q.tl, q.tr, q.br, q.bl, c.Color(NxeUi() ? 0xffffff : 0xc6ffe0, 0.85f * pulse), c.scale);\n')
    s = replace(s, "  x = c.Hint('m', Tr(\"Recarregar lista\"), x, 990);\n  c.Text(Tr(\"L1 / R1   Filtro\")",
                "  x = c.Hint('m', Tr(\"Recarregar lista\"), x, 990);\n  if (NxeUi()) x = c.Hint('o', Tr(\"Voltar\"), x, 990);\n  c.Text(Tr(\"L1 / R1   Filtro\")")
    # With PS5X360's own art (a black background) the library of covers keeps the graphite floor and
    # white type; the light floor is for the dashboard's white one.
    s = replace(s, "c.Color(NxeUi() ? 0xc9ccd0 : 0x20262f)", "c.Color(NxeUi() && (!KinectSkin(nullptr).own || KinectSkin(nullptr).bright) ? 0xc9ccd0 : 0x20262f)")
    s = replace(s, "    if (NxeUi())\n      c.list->AddRectFilledMultiColor(c.At(0, floor), c.At(1920, 1080), c.Color(0xe9eaeb, 0.35f),",
                "    if (NxeUi() && (!KinectSkin(nullptr).own || KinectSkin(nullptr).bright))\n      c.list->AddRectFilledMultiColor(c.At(0, floor), c.At(1920, 1080), c.Color(0xe9eaeb, 0.35f),")
    s = replace(s, "  DrawShelf(c);\n  if (sheet_ > 0.01f) {",
                "  ApplyTheme(NxeUi() && !(home_library_open && KinectSkin(nullptr).own && !KinectSkin(nullptr).bright));\n  DrawShelf(c);\n  ApplyTheme(NxeUi());\n  if (sheet_ > 0.01f) {")
    # Going from the home to the library and back: what comes in rises, grows and fades in,
    # from the middle outwards (the covers nearer the middle first).
    s = replace(s, "  DrawShelf(c);\n  ApplyTheme(NxeUi());\n  if (sheet_ > 0.01f) {", '''  {
    static bool library_was = false;
    static float arrive = 1.0f;
    if (home_library_open != library_was) arrive = 0.0f;
    library_was = home_library_open;
    arrive = std::min(1.0f, arrive + dt / 0.5f);
    const int first = c.list->VtxBuffer.Size;
    DrawShelf(c);
    if (NxeUi() && arrive < 1.0f) {
      const ImVec2 middle = c.At(960, 600);
      const float half = 960 * c.scale;
      for (int n = first; n < c.list->VtxBuffer.Size; ++n) {
        ImDrawVert& v = c.list->VtxBuffer[n];
        const float t = std::clamp(arrive * 1.5f - 0.5f * std::min(1.0f, std::fabs(v.pos.x - middle.x) / half), 0.0f, 1.0f);
        const float e = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
        const float grow = 0.84f + 0.16f * e;
        v.pos.x = middle.x + (v.pos.x - middle.x) * grow;
        v.pos.y = middle.y + (v.pos.y - middle.y) * grow + (1.0f - e) * 110 * c.scale;
        const uint32_t alpha = (v.col >> IM_COL32_A_SHIFT) & 0xFF;
        v.col = (v.col & ~IM_COL32_A_MASK) | (uint32_t(float(alpha) * e) << IM_COL32_A_SHIFT);
      }
    }
  }
  ApplyTheme(NxeUi());
  if (sheet_ > 0.01f) {''')
    s = replace(s, "  const ImTextureID texture = has_cover ? reinterpret_cast<ImTextureID>(textures[size_t(game.cover)].get()) : ImTextureID();\n",
                "  const ImTextureID texture = has_cover ? reinterpret_cast<ImTextureID>(textures[size_t(game.cover)].get()) : ImTextureID();\n"
                "  // The new interface's library shows only the game's cover: no case, no green top.\n"
                "  if (NxeUi() && texture) {\n"
                "    CoverImage(c.list, texture, q, art.front_u0, 0, art.front_u1, 1, shade(0xffffff));\n"
                "    return;\n"
                "  }\n")
    return s
