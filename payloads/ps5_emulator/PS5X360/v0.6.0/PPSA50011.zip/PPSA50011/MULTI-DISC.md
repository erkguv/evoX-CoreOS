# Native Xbox 360 disc switching candidate

This isolated candidate preserves the installed gradient/scheduling/cache/socket baseline. It replaces the desktop-dependent XamSwapDisc flow with a validated native runtime transaction. No restart of the game or campaign is required by this hook.

## Layout

Extracted discs:

    roms/Max Payne 3/Disc 1/default.xex
    roms/Max Payne 3/Disc 2/default.xex

Keep all other files from each disc inside its own directory. Start Disc 1 normally in the library. ISO images may instead use matching names such as `Max Payne 3 Disc 1.iso` and `Max Payne 3 Disc 2.iso` in the game directory.

An adjacent `discs.m3u` can explicitly list the disc XEX files or ISO/ZAR images, one relative path per line. Blank lines and # comments are allowed. The current library does not launch the playlist itself: launch Disc 1. An invalid explicit playlist is rejected instead of guessing another set.

## Runtime checks

When the game calls XamSwapDisc, the candidate finds associated media and reads the target default.xex through its prepared VFS device. It validates title ID, advertised disc count, requested disc number and savegame ID. Media IDs may differ between discs. Missing, invalid or ambiguous matches return an error and leave the current mount intact.

After validation, the VFS replaces the device under its normal critical-region lock. Existing aliases still target the same mount. Old devices are retained until VFS teardown so existing file handles do not borrow freed entries. At most sixteen replaced devices are retained per VFS instance; further swaps are refused safely. This is a bounded first implementation, not a guarantee for every multi-disc title or more than sixteen swaps in one session.

The existing title, profiles, content root and save path are preserved. A later executable launch uses the newly selected source through the existing title-switch mechanism. This does not install an install-only disc, combine installation data, implement online services, or emulate unsupported games.

## Evidence

Native build and packaging results are recorded separately. Actual Max Payne 3 disc transition, saves and continuation require PS5 testing. No public release or console installation is implied by this folder. Graphics bugs remain under separate investigation.
