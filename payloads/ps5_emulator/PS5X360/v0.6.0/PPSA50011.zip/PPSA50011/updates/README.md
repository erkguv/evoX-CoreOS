# Title updates

1. Copy the Xbox 360 title update package for your game into this folder (`PPSA50011/updates`).
   An `updates` folder beside the game, or in a game library folder, works too.
2. Press **Play**: the newest update that fits the game is installed and the game starts with it.
   Or open the game's sheet, go to **Updates** with L1/R1 and use Cross to install it, turn it
   on or turn it off. Square reloads the list.

- One update is active at a time. Turning one on puts the other aside; nothing is deleted.
- An update is made for one edition of a game disc. One made for another edition is labelled
  "another edition" and is not installed by itself.
- Patches made for the game without an update do not apply while an update is active.
- If the title is not identified yet, start the game once and come back.

Installed updates are kept in `saves/0000000000000000/<TITLE_ID>/000B0000` (on) and
`000B0000-off` (off).
