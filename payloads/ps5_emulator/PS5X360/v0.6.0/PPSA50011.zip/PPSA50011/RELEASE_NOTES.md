# PS5X360 v0.6.0

Everything since v0.5.9: frame generation that keeps working at uneven frame rates, title updates
and DLC handled from the game's sheet, Kinect with a phone and no PC, several games past their
loading screens, and fewer hitches while shaders compile.

## Frame generation

Settings > Performance > Frame generation. Off by default.

- It is now [ps5-framegen](https://github.com/Swordpdf/ps5-framegen) by Swordpdf: FSR3 optical
  flow, with handling of still HUD parts and of scene cuts.
- **Modes:** Off, Automatic, 2x, 3x, 4x. The mode is the most pictures generated between two
  frames of the game.
- **It no longer waits for a steady 30 FPS.** When the game's rate is uneven, pictures are placed
  by the game's measured pace, from about 10 FPS up to 3 FPS under the display's rate. A game
  already at the display's rate has no room for a generated picture; pauses and loading screens
  have no new frames to work from.
- It adds pictures between the game's frames; it does not make the game itself run faster. At
  uneven rates most pictures on screen are generated, so fast motion can smear.
- The "video clock 120 Hz" option no longer keeps frame generation from starting.
- A 120 Hz output row exists but is **untested**: it needs a 120 Hz display and a change to the
  application's `param.json` that this package does not make. 3x and 4x mainly matter there.

## Title updates and DLC

- New **Updates** tab on a game's sheet. Copy the update package to `PPSA50011/updates` (or an
  `updates` folder beside the game; the `dlc` folders are searched too). Pressing Play installs the
  newest one by itself; the tab installs, turns on and turns off. One update is active at a time,
  and an update made for another edition of the disc is flagged and not installed by itself.
- The **DLCs** tab shows each package as On, Off or Not installed, turns one off without deleting
  it and says why a file was ignored. Play installs waiting DLC by itself.
- A patch made for a game without an update does not apply while an update is active.

## Kinect with a phone, without a PC

The camera page is served by the PS5 itself: scan the Kinect QR code in Settings. The first time,
the phone installs a certificate made by your own console. The page estimates where the body
stands and how far the hands reach. Still experimental, and only Dragon Ball Z for Kinect.

## Games and compatibility

- **Left 4 Dead 2 and other games stuck on loading at random:** a thread suspended by itself and
  from outside at the same moment could lose its resume.
- **State of Decay:** the console refused a local network port the game asked for; another one is
  used instead.
- **I Am Alive:** file read completions were never delivered to a waiting thread.
- **Prince of Persia: The Forgotten Sands:** a patch for a sound deadlock at loading, on by default.
- **Bully:** games that keep many files open no longer run out of them.
- **Controllers:** broader capability answers; a failed vibration no longer reports the pad as
  disconnected. Fable II and Bayonetta still do not respond to buttons.
- **Fewer hitches while shaders compile:** with "picture read by the game" set to Fast, every draw
  waited for its shader. It now waits only in the Complete mode.

## Known problems

- Hitches from shader compilation itself remain, mostly the first time in each area.
- Modern Warfare 3: wrong distant textures. Modern Warfare 2 was not retested.
- Title updates were tested with made-up packages only; no real update was at hand.

## What was seen on the developer's PS5 (firmware 13.60)

With the build this release is made from (0.5.9-updates.5), on 2026-10-11:

- GTA IV at 33 to 59 FPS: frame generation active on about 97 to 99% of the game's frames once in
  the game; with the previous build it stayed idle there.
- Bully at 22 to 25 FPS: active on nearly every frame. No failed present was logged.
- Earlier builds of the same line: steady 30 FPS games (Lost Odyssey, Dragon Ball Z for Kinect)
  active throughout.

**The v0.6.0 executable itself was not opened on a console before publication.** It is the same
build with the version text changed: every object is identical except the launcher, which is
compiled with the text `0.6.0` (`v0.6.0-build.json`).

Not tested on a console: a real title update, the 3x and 4x modes, the 120 Hz output, other
firmware versions. No frame rate or compatibility is promised.

## Install

1. Close PS5X360.
2. Extract `PPSA50011.zip` and copy the `PPSA50011` folder over `/data/homebrew/PPSA50011` by FTP.
   Keep your games, saves, profiles, settings and logs: the ZIP holds application files only.
3. Open PS5X360 and check that the menu shows v0.6.0.

`PS5X360-AutoLog-v1.0.9-preview.elf` is optional and unchanged. Games, BIOS and keys are not
included. The PC relay for the phone camera is no longer needed.

## Licences and source

The project's own code is MIT. The executable also contains GPL-3 parts (the PS5 Vulkan runtime
and, new here, ps5-framegen, built on AMD FidelityFX SDK shaders under MIT), so it is distributed
under the GPL 3; notices are in `licenses/` and `CREDITS.md`. `PS5X360-source-0.6.0-changes.zip`
holds the sources and build recipes of everything changed since v0.5.9; the sources up to v0.5.9
are the `PS5X360-source-0.5.9-fix1.zip` asset of that release.

Support current and future projects: https://ko-fi.com/brinoblitz
