# DLC installation

1. Copy complete Xbox 360 DLC STFS package files to `PPSA50011/dlc/`. Alternatively use `dlc/` beside the game executable/image, or `dlc/` under a configured game library root (including an external device). Nested folders are scanned within a bounded depth.
2. Open the game sheet and select **DLCs** with L1/R1. If the title has not been identified, launch it once and return to the library.
3. Press Square to refresh, select a package and press Cross to install. Wait for copy and verification before starting a game. A conflicting installed filename is never replaced.
4. Packages are installed in the active content/save root shown by the menu, under `0000000000000000/<TITLE_ID>/00000002/<PACKAGE_FILENAME>`. The active root is normally the homebrew `saves` folder, with the existing mount fallback preserved. DLCs and saves use their respective content types.

Only valid read-only STFS MarketplaceContent packages with the selected title ID are accepted. This page does not install disc images, arcade games, profiles, saves, title updates, or extracted DLC folders. It does not download content or modify licenses. Games may require a matching game revision/title update and otherwise compatible emulation to recognize particular DLCs.

Copies use bounded buffers and a private staging directory outside content enumeration; the complete copy is compared with the source and parsed before publication. Existing packages, ROMs and saves are preserved. Storage errors are reported in the menu. Forcefully closing the application can leave a private staging directory, which is never presented as installed content.

Local parser/copy tests and native build validation do not establish real DLC acceptance by a game on PS5. Verify a known matching DLC on hardware separately.
