# Sources of the changes in PS5X360 v0.6.0

The v0.6.0 executable is assembled from the v0.5.9 objects with some objects rebuilt. This
archive holds the sources and build recipes of what changed since v0.5.9. The sources up to
v0.5.9 are the `PS5X360-source-0.5.9-fix1.zip` asset of that release:
https://github.com/BrinooTk/PS5X360/releases/tag/v0.5.9-fix1

| Folder | What |
|---|---|
| `loading-fix-20261009` | thread suspension on the console's threads (games stuck on loading) |
| `net-fix-20261009` | socket bind fallback and error codes, guest APC delivery in alertable waits, controller driver |
| `prince-fix-20261009` | patch file for Prince of Persia: The Forgotten Sands |
| `menu-perf-20261009`, `framegen-counter-20261009` | frame generation switch in the menu, the on-screen rates |
| `bully-loading-20261009` | read-only file pool for games that keep many files open |
| `kinect-native-20261009`, `kinect-phone` | DLC page and DLC installed on Play; the Kinect camera page and its server on the console |
| `0.5.9-framegen.3-local-SOURCE` | integration of ps5-framegen (Swordpdf, GPL-3.0-or-later; `COPYING`, `PROVENANCE.json`) |
| `0.5.9-framegen.4-local-SOURCE` | pacing changes and the optional shader timing |
| `title-updates-20261010` | the Updates tab and the update manager, with its test |
| `stutter-wait-20261010` | a draw waits for its pipeline only in the full readback mode |
| `framegen-modes-20261010` | Off/Automatic/2x/3x/4x, the output rate row, the 120 Hz guest clock |
| `framegen-adaptive-20261010`, `framegen-always-20261010` | adaptive pacing, then in every mode |
| `updates-integration-20261010`, `release-v060` | recipes that build and package the executables |

Frame generation: https://github.com/Swordpdf/ps5-framegen (GPL-3.0-or-later; shaders from the AMD
FidelityFX SDK, MIT). A program that includes it is distributed under the GPL 3.
