"""A draw waits for its real pipeline only in the full readback mode.

Reads the command processor source of the installed build
(build/framegen-sword-20261010/cp/xenia/gpu/vulkan/vulkan_command_processor.cc, whose object is
in framegen.4 unchanged) and writes the changed copy under cp/ next to this script.
usage: python apply_wait.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
relative = 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc'
text = (here.parent / 'framegen-sword-20261010' / relative).read_text(encoding='utf-8')
old = '''  // draw waits for its real pipeline instead.
  if (pipeline->is_placeholder.load(std::memory_order_acquire)) {
    if (GetReadbackResolveMode() != ReadbackResolveMode::kDisabled) {
'''
new = '''  // draw waits for its real pipeline instead.
  // Only in the full mode, which such a game needs anyway: the fast mode hands
  // the game the previous resolve's picture, so it cannot rely on what one draw
  // left there, and making every draw wait for a compile was the largest
  // measured cause of hitches with it switched on (813 waits and no stand-in in
  // the console sessions of 2026-10-10; frame rate dips followed the waits).
  if (pipeline->is_placeholder.load(std::memory_order_acquire)) {
    if (GetReadbackResolveMode() == ReadbackResolveMode::kFull) {
'''
assert text.count(old) == 1, text.count(old)
target = here / relative
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(text.replace(old, new), encoding='utf-8', newline='\n')
# The source includes this file by a path relative to itself; it is copied unchanged.
import shutil
shutil.copy2(here.parent / 'framegen-sword-20261010/cp/xenia/gpu/pm4_command_processor_implement.h',
             here / 'cp/xenia/gpu/pm4_command_processor_implement.h')
print('written', target)
