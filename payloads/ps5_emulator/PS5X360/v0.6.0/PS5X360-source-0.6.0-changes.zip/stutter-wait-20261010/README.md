# Draws no longer wait for shader pipelines in the fast readback mode

One condition in `VulkanCommandProcessor::IssueDraw` (see `apply_wait.py`).

## Why

With the "picture read by the game" setting (readback) on, a draw whose pipeline was still a
stand-in waited for the real one. That wait exists for games that keep what they draw once and
read back (Left 4 Dead 2 builds its font pages that way) and it was applied to every readback
mode. The owner's general settings had readback = fast, so asynchronous shader compilation was
cancelled for every game.

Console sessions of 2026-10-10 (nine games, builds framegen.1 to framegen.4):

- `shaders still compiling: 0 draws used a stand-in, N waited for theirs`: 813 waits, no stand-in.
- 30-second windows with waits: median dip (mean rate minus lowest one-second rate) 6.3 FPS,
  11 of 18 windows dipped more than 5 FPS. Windows without waits: median 0.0, 1 of 13.

## The change

The draw waits only in the **full** readback mode. Left 4 Dead 2 runs in that mode by its preset.
The fast mode gives the game the previous resolve's picture, so a game cannot rely on one
draw's result there.

Residual risk: a game that bakes a picture once under the fast mode may keep an empty element
drawn with a stand-in shader; such a game needs the full mode in its own settings.

## Evidence

- `build/updates-integration-20261010/build_safe.py`: the unchanged source reproduces the
  installed object byte for byte; the changed one is linked into `0.5.9-updates.3-safe-local`.
- **Not measured yet on the console.** Expected in a game log: `N draws used a stand-in, 0 waited
  for theirs`, and a smaller gap between the rate and its minimum in `Performance:` lines.
- Hitches from compile activity itself (shader translation and the stand-in compile on the GPU
  thread, cold driver compiles) remain; see `build/updates-integration-20261010/agent-stutter-report.md`.
