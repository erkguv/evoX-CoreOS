"""Prove the shipped main and launcher objects rebuild byte for byte (vulkan.4 commands, frozen sources).

Run in xbox360ps5-radv-buildenv with /ws mounted. Writes compile.json next to this file.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = json.loads((root / 'build/vulkan-refine4/game-candidate/build.json').read_text())
shipped = root / 'build/net-fix-20261009/native-net3/obj'
frozen = root / 'build/loading-20261008/agent-iamalive/frozen/src'
result = {}
for name in ('canary_game_main.cpp', 'launcher.cpp'):
    command = [str(a) for a in next(c for c in receipt['commands'] if isinstance(c, list)
                                    and any(str(a).endswith('/' + name) for a in c))]
    src_i, obj_i = command.index('-c') + 1, command.index('-o') + 1
    worktree_source = command[src_i]
    with tempfile.TemporaryDirectory() as tmp:
        outcomes = {}
        for label, source in (('worktree', worktree_source), ('frozen', str(frozen / name))):
            cmd = list(command)
            cmd[src_i] = source
            cmd[obj_i] = str(Path(tmp) / (label + '.o'))
            run = subprocess.run(cmd, cwd=root, capture_output=True, text=True)
            outcomes[label] = {'source': source, 'source_sha256': sha(source),
                               'object_sha256': sha(cmd[obj_i]) if run.returncode == 0 else 'compile failed: ' + run.stderr[-400:]}
    result[name] = {'shipped_sha256': sha(shipped / (name + '.o')), 'command': command, **outcomes}
    print(name, 'shipped', result[name]['shipped_sha256'][:16],
          {k: v['object_sha256'][:16] for k, v in outcomes.items()})
(here / 'compile.json').write_text(json.dumps(result, indent=2))
