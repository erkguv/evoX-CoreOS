# Network bind candidate (private test build)

Based on the installed 0.5.9-loading.1-local build: every object is unchanged
except the socket implementation.

- When the PS5 refuses a bind that a PC accepts (EACCES/EPERM, or an address
  the console does not own), the emulator binds a real endpoint the console
  allows: the same port on any local address, then the port + 10000, then a
  port chosen by the system. The game reads the endpoint it got through
  getsockname. Each fallback is logged with the refused type, protocol,
  address and port.
- Socket errors reach the game as Winsock codes (EACCES -> 10013, and so on)
  instead of raw BSD errno numbers.
- bind(0) keeps its meaning (a system-chosen port) instead of being moved to
  the fixed port 10000.

Target: State of Decay (584111E8), whose main thread had a bind refused with
errno 13 right before it used an object that was never created. Not yet
verified on the console. The loading.1 thread wait change and the State of
Decay zero-page preset are kept.

## 0.5.9-net.2: guest APCs in alertable waits

On Linux and the PS5 a host wait never returned for a queued guest APC, so a
thread waiting alertably never ran the completions queued to it. Alertable
waits now run pending APCs before waiting and wait in 5 ms slices so that an
APC queued from another thread is run too. I Am Alive's Wwise I/O thread
queued its own read completion and then waited for it forever (loading
screen). On the PC runner the game now passes its loading screen.
