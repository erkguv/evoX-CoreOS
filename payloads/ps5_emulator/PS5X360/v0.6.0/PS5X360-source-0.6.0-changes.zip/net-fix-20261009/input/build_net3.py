"""PS5 candidate 0.5.9-net.3: net.2 + controller driver fix + the frame generation prototype (off unless framegen.conf).

Run in xbox360ps5-radv-buildenv with the parent folder mounted at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-radv-buildenv:latest python3 -u /ws/Xbox360PS5/build/net-fix-20261009/input/build_net3.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/net-fix-20261009/native-apc'      # 0.5.9-net.2-local, installed on the console
framegen = root / 'build/framegen-20261008/integration-native/obj'
out = root / 'build/net-fix-20261009/native-net3'
label_old = b'PS5X360 v0.5.8-vulkan.4'
label_new = b'PS5X360 v0.5.9-net.3'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


base_receipt = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == base_receipt['native_sha256'] == \
    '7e86b8944f8965f29b172f3aefe98944e14febc16f7174bac96b64ffe0de9e18'

# reproduce.py proved this command rebuilds the shipped driver object byte for byte.
repro = json.loads((here / 'compile.json').read_text())
assert repro['rebuilt_sha256'] == repro['shipped_sha256'] == sha(base / 'obj/dualsense_input.cpp.o')
command = list(repro['command'])
src_i, obj_i = command.index('-c') + 1, command.index('-o') + 1

# Frame generation objects, frozen in build/framegen-20261008 against this exact presenter preimage.
framegen_objects = {
    'vulkan_presenter.cc.o': 'feaa5665113e859a893095b07f7e39b79301f4f60339d6add8f3c9d7d9a37d24',
    'frame_interpolator.cpp.o': '6f13be0f4ff8e44d07e88e60a2212c9afadd00608c2f8af9b5ca5c82040f1dfd',
    'framegen_cvar.cc.o': '35c33ae75efa88a141edf4f6c1309a90b98b3d6476cd0575a84f722267729eeb',
}
assert sha(base / 'obj/vulkan_presenter.cc.o') == '4c04a082f769f521be967dc0eecb3418fc10d67767fb9ea60f3546295ef077d7'
for name, expected in framegen_objects.items():
    assert sha(framegen / name) == expected, name

if out.exists():
    shutil.rmtree(out)
(out / 'obj').mkdir(parents=True)
retained = {}
for p in sorted((base / 'obj').glob('*.o')):
    if p.name in ('dualsense_input.cpp.o', 'vulkan_presenter.cc.o'):
        continue
    shutil.copy2(p, out / 'obj' / p.name)
    retained[p.name] = sha(p)
for name in framegen_objects:
    shutil.copy2(framegen / name, out / 'obj' / name)
build = list(command)
build[src_i] = str(here / 'dualsense_input.cpp')
build[obj_i] = str(out / 'obj/dualsense_input.cpp.o')
subprocess.run(build, cwd=root, check=True)

link = ['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)]
subprocess.run(link, check=True)
assert all(sha(out / 'obj' / n) == v for n, v in retained.items())

for name in ('llvm-pie.elf', 'eboot.elf'):
    data = (out / name).read_bytes()
    assert data.count(label_old + b'\0') == 1, name
    offset = data.index(label_old + b'\0')
    phoff = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    ph = [struct.unpack_from('<IIQQQQQQ', data, phoff + i * size) for i in range(count)]
    assert any(p[0] == 1 and p[1] == 4 and p[2] <= offset and offset + len(label_old) + 1 <= p[2] + p[5] for p in ph)
    result = data[:offset] + label_new + b'\0' * (len(label_old) + 1 - len(label_new)) + data[offset + len(label_old) + 1:]
    assert len(result) == len(data)
    for p in ph:
        if p[0] == 1 and p[1] & 1:
            assert data[p[2]:p[2] + p[5]] == result[p[2]:p[2] + p[5]]
    (out / name).write_bytes(result)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)

image = (out / 'llvm-pie.elf').read_bytes()
for marker in (b'Alertable wait: ran queued APCs', b'answering a capabilities query',
               b'refused a vibration command', b'Framegen private config'):
    assert marker in image, marker

proof = {
    'version': '0.5.9-net.3-local',
    'baseline': str(base),
    'baseline_native_sha256': base_receipt['native_sha256'],
    'native_sha256': sha(out / 'eboot.bin'),
    'elf_sha256': sha(out / 'llvm-pie.elf'),
    'replaced_objects': ['dualsense_input.cpp.o', 'vulkan_presenter.cc.o'],
    'added_objects': ['frame_interpolator.cpp.o', 'framegen_cvar.cc.o'],
    'controller_source_sha256': sha(here / 'dualsense_input.cpp'),
    'controller_preimage_sha256': repro['source_sha256'],
    'controller_object_sha256': sha(out / 'obj/dualsense_input.cpp.o'),
    'framegen_objects': framegen_objects,
    'framegen_enable': '/data/homebrew/PPSA50011/framegen.conf, first line ps5_frame_interpolation=true; off without it',
    'unchanged_objects': retained,
    'compile': build,
    'link': link,
    'label': label_new.decode(),
    'hardware': 'pending',
}
(out / 'build.json').write_text(json.dumps(proof, indent=2))
print('PASS', proof['native_sha256'])
