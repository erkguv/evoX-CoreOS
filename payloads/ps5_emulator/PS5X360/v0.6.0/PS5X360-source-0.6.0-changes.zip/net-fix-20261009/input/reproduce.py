"""Prove the shipped controller driver object is rebuilt byte for byte from the dual-renderer worktree source.

Run in xbox360ps5-radv-buildenv with /ws mounted. Writes compile.json next to this file.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

receipt = json.loads((root / 'build/vulkan-refine2/game-candidate/build.json').read_text())
command = next(c for c in receipt['commands']
               if isinstance(c, list) and any(str(a).endswith('/dualsense_input.cpp') for a in c))
command = [str(a) for a in command]
src_i, obj_i = command.index('-c') + 1, command.index('-o') + 1
shipped = root / 'build/net-fix-20261009/native-apc/obj/dualsense_input.cpp.o'
with tempfile.TemporaryDirectory() as tmp:
    rebuilt = Path(tmp) / 'rebuilt.o'
    cmd = list(command)
    cmd[obj_i] = str(rebuilt)
    subprocess.run(cmd, cwd=root, check=True)
    result = {'source': command[src_i], 'source_sha256': sha(command[src_i]),
              'shipped_sha256': sha(shipped), 'rebuilt_sha256': sha(rebuilt), 'command': command}
(here / 'compile.json').write_text(json.dumps(result, indent=2))
print(json.dumps({k: v for k, v in result.items() if k != 'command'}, indent=2))
print('IDENTICAL' if result['rebuilt_sha256'] == result['shipped_sha256'] else 'DIFFERENT')
