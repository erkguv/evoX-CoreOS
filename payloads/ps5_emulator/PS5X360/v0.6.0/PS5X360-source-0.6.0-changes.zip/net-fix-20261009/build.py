"""PS5 candidate 0.5.9-net.1: the installed loading.1 build with one socket object replaced.

Run in xbox360ps5-radv-buildenv with the parent folder mounted at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-radv-buildenv:latest python3 -u /ws/Xbox360PS5/build/net-fix-20261009/build.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess

root = Path('/ws/Xbox360PS5')
work = root / 'build/net-fix-20261009'
base = root / 'build/loading-fix-20261009/native'   # installed on the console as 0.5.9-loading.1-local
kinect = root / 'build/kinect-update-20261008/final-native'
out = work / 'native'
label_old = b'PS5X360 v0.5.8-vulkan.4'
label_new = b'PS5X360 v0.5.9-net.1'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


base_receipt = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == '8b5090d10da5c222bb33d0920a0ed2b5be45e9dda7fde961fa6f97272f0aa310'
assert sha(base / 'eboot.bin') == base_receipt['native_sha256']

# Core archives and title objects must still be the ones the shipped builds linked.
kinect_receipt = json.loads((kinect / 'build.json').read_text())
for name, expected in kinect_receipt['baseline_inputs'].items():
    p = Path(name)
    if p.suffix in ('.o', '.a'):
        assert sha(p) == expected, name

# The compiler and headers must still reproduce the shipped socket object exactly.
command = list(json.loads((root / 'build/mw3-socket-fix-20261008/build.json').read_text())['command'])
src_i, obj_i = command.index('-c') + 1, command.index('-o') + 1
probe = work / 'reproduce-shipped-xsocket.o'
repro = list(command)
repro[src_i] = str(root / 'build/mw3-socket-fix-20261008/xsocket.cc')
repro[obj_i] = str(probe)
subprocess.run(repro, cwd=root / 'build/canary-ps5', check=True)
shipped = '1dbee541151ed5519246c77c4de2fdaf53f22231e856e1cee50eb62661a084a8'
assert sha(probe) == shipped == sha(base / 'obj/xsocket.cc.o'), 'toolchain/headers drifted'
probe.unlink()

(out / 'obj').mkdir(parents=True, exist_ok=True)
retained = {}
for p in sorted((base / 'obj').glob('*.o')):
    if p.name == 'xsocket.cc.o':
        continue
    shutil.copy2(p, out / 'obj' / p.name)
    retained[p.name] = sha(p)
build = list(command)
build[src_i] = str(work / 'xsocket.cc')
build[obj_i] = str(out / 'obj/xsocket.cc.o')
subprocess.run(build, cwd=root / 'build/canary-ps5', check=True)

link = ['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)]
subprocess.run(link, check=True)
assert all(sha(out / 'obj' / n) == v for n, v in retained.items())

# Footer label: patched in the read-only data of the linked image, as for 0.5.9.
for name in ('llvm-pie.elf', 'eboot.elf'):
    data = (out / name).read_bytes()
    assert data.count(label_old + b'\0') == 1, name
    offset = data.index(label_old + b'\0')
    phoff = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    ph = [struct.unpack_from('<IIQQQQQQ', data, phoff + i * size) for i in range(count)]
    assert any(p[0] == 1 and p[1] == 4 and p[2] <= offset and offset + len(label_old) + 1 <= p[2] + p[5] for p in ph)
    result = data[:offset] + label_new + b'\0' * (len(label_old) + 1 - len(label_new)) + data[offset + len(label_old) + 1:]
    assert len(result) == len(data)
    for p in ph:
        if p[0] == 1 and p[1] & 1:
            assert data[p[2]:p[2] + p[5]] == result[p[2]:p[2] + p[5]]
    (out / name).write_bytes(result)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)

proof = {
    'version': '0.5.9-net.1-local',
    'baseline': str(base),
    'baseline_native_sha256': base_receipt['native_sha256'],
    'native_sha256': sha(out / 'eboot.bin'),
    'elf_sha256': sha(out / 'llvm-pie.elf'),
    'replaced_object': 'xsocket.cc.o',
    'socket_source_sha256': sha(work / 'xsocket.cc'),
    'socket_errno_sha256': sha(work / 'socket_errno.h'),
    'socket_object_sha256': sha(out / 'obj/xsocket.cc.o'),
    'shipped_socket_reproduced': shipped,
    'unchanged_objects': retained,
    'compile': build,
    'link': link,
    'label': label_new.decode(),
    'hardware': 'pending',
}
(out / 'build.json').write_text(json.dumps(proof, indent=2))
print('PASS', proof['native_sha256'])
