"""Host check runner: the existing Linux runner relinked with the APC kernel threading object.

Run in xbox360ps5-canary with /ws mounted. Proves first that the runner's own archive member
is rebuilt byte for byte from the current source, so only the APC change differs.
Output: build/net-fix-20261009/apc/host/xbox360ps5-runner
"""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tempfile

root = Path('/ws/Xbox360PS5')
build = root / 'build/canary-runner'
here = Path(__file__).resolve().parent
out = here / 'host'
out.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def command_for(target_suffix):
    target = next(line.split(': ', 1)[0][6:] for line in (build / 'build.ninja').read_text().splitlines()
                  if line.startswith('build ') and line.split(': ', 1)[0].endswith(target_suffix))
    raw = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', target],
                                              text=True).splitlines()[-1])
    return target, raw


target, raw = command_for('/xboxkrnl_threading.cc.o')
cmd, i = [], 0
while i < len(raw):
    if raw[i] in ('-MT', '-MF', '-o'):
        i += 2
        continue
    if raw[i] in ('-MD', '-MMD'):
        i += 1
        continue
    cmd.append(raw[i])
    i += 1
src_i = cmd.index('-c') + 1
archive = next(build.rglob('libxenia-kernel.a'))
with tempfile.TemporaryDirectory() as tmp:
    subprocess.run(['llvm-ar-18', 'x', str(archive), 'xboxkrnl_threading.cc.o'], cwd=tmp, check=True)
    member = sha(Path(tmp) / 'xboxkrnl_threading.cc.o')
    rebuilt = Path(tmp) / 'rebuilt.o'
    subprocess.run(cmd + ['-o', str(rebuilt)], cwd=build, check=True)
    same = sha(rebuilt) == member
print('host member', member, 'rebuilt identical' if same else 'REBUILT DIFFERS')

obj = out / 'xboxkrnl_threading.cc.o'
fixed = list(cmd)
fixed[src_i] = str(here / 'xboxkrnl_threading.cc')
subprocess.run(fixed + ['-o', str(obj)], cwd=build, check=True)

# Link the runner with the new object ahead of the archives.
link = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', 'xbox360ps5-runner'],
                                           text=True).splitlines()[-1])
o = link.index('-o')
link[o + 1] = str(out / 'xbox360ps5-runner')
link.insert(o + 2, str(obj))
link = [a for a in link if a not in (':', '&&')]
subprocess.run(link, cwd=build, check=True)
data = (out / 'xbox360ps5-runner').read_bytes()
assert b'Alertable wait: ran queued APCs' in data
(out / 'receipt.json').write_text(json.dumps({'member_sha256': member, 'rebuilt_identical': same,
                                              'object_sha256': sha(obj),
                                              'runner_sha256': sha(out / 'xbox360ps5-runner'),
                                              'link': link}, indent=2))
print('PASS host runner', sha(out / 'xbox360ps5-runner'))
