"""PS5 candidate 0.5.9-net.2: 0.5.9-net.1 plus a kernel threading object that delivers APCs in alertable waits.

Run in xbox360ps5-radv-buildenv with the parent folder mounted at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-radv-buildenv:latest python3 -u /ws/Xbox360PS5/build/net-fix-20261009/apc/build_apc.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/net-fix-20261009/native'      # 0.5.9-net.1-local, installed on the console
out = root / 'build/net-fix-20261009/native-apc'
label_old = b'PS5X360 v0.5.8-vulkan.4'
label_new = b'PS5X360 v0.5.9-net.2'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


base_receipt = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == base_receipt['native_sha256'] == \
    'e4fd2c5f6455d08b524df879db733877f37609423f1ff406126fb4c163f0b666'

# reproduce.py proved this command rebuilds the shipped archive member byte for byte.
repro = json.loads((here / 'compile.json').read_text())
assert repro['rebuilt_sha256'] == repro['archive_member_sha256']
assert sha(repro['source']) == repro['source_sha256'], 'kernel threading source changed since the proof'
command = list(repro['command'])
src_i = command.index('-c') + 1

if out.exists():
    shutil.rmtree(out)
(out / 'obj').mkdir(parents=True)
retained = {}
for p in sorted((base / 'obj').glob('*.o')):
    shutil.copy2(p, out / 'obj' / p.name)
    retained[p.name] = sha(p)
assert 'xboxkrnl_threading.cc.o' not in retained
build = list(command)
build[src_i] = str(here / 'xboxkrnl_threading.cc')
subprocess.run(build + ['-o', str(out / 'obj/xboxkrnl_threading.cc.o')], cwd=root / 'build/canary-ps5', check=True)

link = ['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)]
subprocess.run(link, check=True)
assert all(sha(out / 'obj' / n) == v for n, v in retained.items())

for name in ('llvm-pie.elf', 'eboot.elf'):
    data = (out / name).read_bytes()
    assert data.count(label_old + b'\0') == 1, name
    offset = data.index(label_old + b'\0')
    phoff = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    ph = [struct.unpack_from('<IIQQQQQQ', data, phoff + i * size) for i in range(count)]
    assert any(p[0] == 1 and p[1] == 4 and p[2] <= offset and offset + len(label_old) + 1 <= p[2] + p[5] for p in ph)
    result = data[:offset] + label_new + b'\0' * (len(label_old) + 1 - len(label_new)) + data[offset + len(label_old) + 1:]
    assert len(result) == len(data)
    for p in ph:
        if p[0] == 1 and p[1] & 1:
            assert data[p[2]:p[2] + p[5]] == result[p[2]:p[2] + p[5]]
    (out / name).write_bytes(result)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)

# The new object must be the one linked: its marker string has to be in the image.
assert b'Alertable wait: ran queued APCs' in (out / 'llvm-pie.elf').read_bytes()

proof = {
    'version': '0.5.9-net.2-local',
    'baseline': str(base),
    'baseline_native_sha256': base_receipt['native_sha256'],
    'native_sha256': sha(out / 'eboot.bin'),
    'elf_sha256': sha(out / 'llvm-pie.elf'),
    'added_override': 'xboxkrnl_threading.cc.o',
    'kernel_threading_source_sha256': sha(here / 'xboxkrnl_threading.cc'),
    'kernel_threading_preimage_sha256': repro['source_sha256'],
    'kernel_threading_shipped_member_sha256': repro['archive_member_sha256'],
    'kernel_threading_object_sha256': sha(out / 'obj/xboxkrnl_threading.cc.o'),
    'socket_object_sha256': sha(out / 'obj/xsocket.cc.o'),
    'unchanged_objects': retained,
    'compile': build,
    'link': link,
    'label': label_new.decode(),
    'hardware': 'pending',
}
(out / 'build.json').write_text(json.dumps(proof, indent=2))
print('PASS', proof['native_sha256'])
