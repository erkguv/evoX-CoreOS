"""Prove the kernel threading object can be rebuilt byte-identically from the current source.

Run in xbox360ps5-radv-buildenv with /ws mounted. Writes compile.json (the exact command) next to this file.
"""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tempfile

root = Path('/ws/Xbox360PS5')
build = root / 'build/canary-ps5'
here = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

suffix = '/xboxkrnl_threading.cc.o'
target = next(line.split(': ', 1)[0][6:] for line in (build / 'build.ninja').read_text().splitlines()
              if line.startswith('build ') and line.split(': ', 1)[0].endswith(suffix))
raw = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', target], text=True).splitlines()[-1])
cmd, i = [], 0
while i < len(raw):
    if raw[i] in ('-MT', '-MF', '-o'):
        i += 2
        continue
    if raw[i] in ('-MD', '-MMD'):
        i += 1
        continue
    cmd.append(raw[i])
    i += 1
source = cmd[cmd.index('-c') + 1]
built = build / target
with tempfile.TemporaryDirectory() as tmp:
    member = Path(tmp) / 'member.o'
    # The archive member that the shipped executables linked.
    names = subprocess.check_output(['llvm-ar-18', 't', str(build / 'obj/Linux/libxenia-kernel.a')], text=True).split()
    assert names.count('xboxkrnl_threading.cc.o') == 1
    subprocess.run(['llvm-ar-18', 'x', str(build / 'obj/Linux/libxenia-kernel.a'), 'xboxkrnl_threading.cc.o'], cwd=tmp, check=True)
    (Path(tmp) / 'xboxkrnl_threading.cc.o').rename(member)
    out = Path(tmp) / 'rebuilt.o'
    subprocess.run(cmd + ['-o', str(out)], cwd=build, check=True)
    result = {'target': target, 'source': source, 'source_sha256': sha(source),
              'cmakefiles_object_sha256': sha(built), 'archive_member_sha256': sha(member),
              'rebuilt_sha256': sha(out), 'command': cmd}
(here / 'compile.json').write_text(json.dumps(result, indent=2))
print(json.dumps({k: v for k, v in result.items() if k != 'command'}, indent=2))
print('IDENTICAL' if result['rebuilt_sha256'] == result['archive_member_sha256'] == result['cmakefiles_object_sha256'] else 'DIFFERENT')
