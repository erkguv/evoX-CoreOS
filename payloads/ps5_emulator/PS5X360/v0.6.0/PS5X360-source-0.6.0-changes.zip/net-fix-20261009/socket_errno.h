#pragma once
#include <cerrno>
#include <cstdint>

namespace xe::kernel::socket_errno {
// Symbolic errno values, not Linux numeric literals: PS5 uses BSD numbering.
inline uint32_t ToGuest(int error) {
  switch (error) {
    case EINTR: return 10004;
    case EBADF: return 10009;
    case EACCES: return 10013;
    case EPERM: return 10013;
    case EFAULT: return 10014;
    case EINVAL: return 10022;
    case EMFILE: return 10024;
    case EAGAIN:
#if EWOULDBLOCK != EAGAIN
    case EWOULDBLOCK:
#endif
      return 10035;
    case EINPROGRESS: return 10036;
    case EALREADY: return 10037;
    case ENOTSOCK: return 10038;
    case EDESTADDRREQ: return 10039;
    case EMSGSIZE: return 10040;
    case EPROTOTYPE: return 10041;
    case ENOPROTOOPT: return 10042;
    case EPROTONOSUPPORT: return 10043;
#ifdef ESOCKTNOSUPPORT
    case ESOCKTNOSUPPORT: return 10044;
#endif
    case EOPNOTSUPP: return 10045;
#ifdef EPFNOSUPPORT
    case EPFNOSUPPORT: return 10046;
#endif
    case EAFNOSUPPORT: return 10047;
    case EADDRINUSE: return 10048;
    case EADDRNOTAVAIL: return 10049;
    case ENETDOWN: return 10050;
    case ENETUNREACH: return 10051;
    case ENETRESET: return 10052;
    case ECONNABORTED: return 10053;
    case ECONNRESET: return 10054;
    case ENOBUFS: return 10055;
    case EISCONN: return 10056;
    case ENOTCONN: return 10057;
#ifdef ESHUTDOWN
    case ESHUTDOWN: return 10058;
#endif
    case ETIMEDOUT: return 10060;
    case ECONNREFUSED: return 10061;
#ifdef EHOSTDOWN
    case EHOSTDOWN: return 10064;
#endif
    case EHOSTUNREACH: return 10065;
    default: return static_cast<uint32_t>(error);  // Preserve unknown failure.
  }
}
}  // namespace xe::kernel::socket_errno
