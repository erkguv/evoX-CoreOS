# Network bind candidate (private test build)

Based on the installed 0.5.9-loading.1-local build: every object is unchanged
except the socket implementation.

- When the PS5 refuses a bind that a PC accepts (EACCES/EPERM, or an address
  the console does not own), the emulator binds a real endpoint the console
  allows: the same port on any local address, then the port + 10000, then a
  port chosen by the system. The game reads the endpoint it got through
  getsockname. Each fallback is logged with the refused type, protocol,
  address and port.
- Socket errors reach the game as Winsock codes (EACCES -> 10013, and so on)
  instead of raw BSD errno numbers.
- bind(0) keeps its meaning (a system-chosen port) instead of being moved to
  the fixed port 10000.

Target: State of Decay (584111E8), whose main thread had a bind refused with
errno 13 right before it used an object that was never created. Not yet
verified on the console. The loading.1 thread wait change and the State of
Decay zero-page preset are kept.

## 0.5.9-net.2: guest APCs in alertable waits

On Linux and the PS5 a host wait never returned for a queued guest APC, so a
thread waiting alertably never ran the completions queued to it. Alertable
waits now run pending APCs before waiting and wait in 5 ms slices so that an
APC queued from another thread is run too. I Am Alive's Wwise I/O thread
queued its own read completion and then waited for it forever (loading
screen). On the PC runner the game now passes its loading screen.

## 0.5.9-net.3: controller driver and frame generation prototype

- Controller: capability queries with flags other than GAMEPAD (0 = any
  device, 0xFF, ANY_USER) were refused, so some games saw no controller; a
  refused vibration command made the pad read as disconnected. Both now answer
  as a connected Xbox 360 pad would (first occurrence of each is logged).
- Frame generation prototype from build/framegen-20261008 (presenter hook,
  bounded optical-flow midpoint between two finished frames). Off unless
  /data/homebrew/PPSA50011/framegen.conf has the first line
  ps5_frame_interpolation=true. Only admitted near a steady 30 FPS at 60 Hz;
  adds about one frame of latency. Untested on the console.
- I Am Alive preset: fast readback (scene brightness).
