/**
 ******************************************************************************
 * Xenia : Xbox 360 Emulator Research Project                                 *
 ******************************************************************************
 * Copyright 2013 Ben Vanik. All rights reserved.                             *
 * Released under the BSD license - see LICENSE in the root for more details. *
 ******************************************************************************
 */

#include "src/xenia/kernel/xsocket.h"

#include <cstring>
#include "socket_errno.h"

#include <algorithm>
#include <vector>
#include "xenia/base/logging.h"
#include "xenia/base/platform.h"
#include "xenia/kernel/kernel_state.h"
#include "xenia/kernel/xam/xam_module.h"

#ifdef XE_PLATFORM_WIN32
// clang-format off
#include "xenia/base/platform_win.h"
#include <WS2tcpip.h>
#include <WinSock2.h>
// clang-format on
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace xe {
namespace kernel {

// Translate socket options to native
// Note:
// SO_DONTLINGER = ~SO_LINGER
// SO_EXCLUSIVEADDRUSE = ~SO_REUSEADDR
// TODO: Check SO_DONTLINGER and SO_EXCLUSIVEADDRUSE usage on linux
const std::map<uint32_t, uint32_t> supported_socket_options = {
    {0x0004, SO_REUSEADDR}, {0x0020, SO_BROADCAST}, {0x0080, SO_LINGER},
    {0x1001, SO_SNDBUF},    {0x1002, SO_RCVBUF},    {0x1005, SO_SNDTIMEO},
    {0x1006, SO_RCVTIMEO},  {~0x0080, ~SO_LINGER},  {~0x0004, ~SO_REUSEADDR}};

// Translate socket TCP options to native
const std::map<uint32_t, uint32_t> supported_tcp_options = {
    {0x0001, TCP_NODELAY}};

// Translate socket levels to native
const std::map<uint32_t, uint32_t> supported_levels = {{0xFFFF, SOL_SOCKET},
                                                       {0x6, IPPROTO_TCP}};

// Translate ioctl commands to native
const std::map<uint32_t, uint32_t> supported_controls = {
    {0x8004667E, FIONBIO}, {0x4004667F, FIONREAD}};

#ifndef XE_PLATFORM_WIN32
namespace {
// Xbox360PS5: the host's own address structure for one in the guest's layout,
// and back. The guest's (as Windows' and Linux's) begins with a 16-bit
// family. On systems derived from BSD, the PS5 among them, it begins with a
// length byte and an 8-bit family: handing the guest layout to bind or
// connect gave length 2 and family 0, and the call failed with "address
// family not supported" (errno 47). Left 4 Dead 2 ends itself when it cannot
// bind its port; other games carried on without a network.
// The port and the address are in network order in both.
sockaddr_in ToHostAddress(uint16_t family, const void* port, const void* address) {
  sockaddr_in host = {};
#if XE_PLATFORM_PS5
  host.sin_len = sizeof(host);
#endif
  host.sin_family = static_cast<decltype(host.sin_family)>(family);
  std::memcpy(&host.sin_port, port, sizeof(host.sin_port));
  std::memcpy(&host.sin_addr, address, sizeof(host.sin_addr));
  return host;
}
}  // namespace
#endif

XSocket::XSocket(KernelState* kernel_state)
    : XObject(kernel_state, kObjectType) {}

XSocket::XSocket(KernelState* kernel_state, uint64_t native_handle)
    : XObject(kernel_state, kObjectType), native_handle_(native_handle) {}

XSocket::~XSocket() { Close(); }

X_STATUS XSocket::Initialize(AddressFamily af, Type type, Protocol proto) {
  af_ = af;
  type_ = type;
  proto_ = proto;

  if (proto == Protocol::XE_IPPROTO_VDP) {
    // VDP is a layer on top of UDP.
    proto = Protocol::XE_IPPROTO_UDP;
  }

  native_handle_ = socket(af, type, proto);
  if (native_handle_ == -1) {
    return X_STATUS_UNSUCCESSFUL;
  }

  return X_STATUS_SUCCESS;
}

X_STATUS XSocket::Close() {
#if XE_PLATFORM_WIN32
  int ret = closesocket(native_handle_);
#else
  int ret = close(native_handle_);
#endif

  if (ret != 0) {
    return X_STATUS_UNSUCCESSFUL;
  }

  return X_STATUS_SUCCESS;
}

X_STATUS XSocket::GetOption(uint32_t level, uint32_t optname, void* optval_ptr,
                            uint32_t* optlen) {
  int ret =
      getsockopt(native_handle_, level, optname, static_cast<char*>(optval_ptr),
                 reinterpret_cast<socklen_t*>(optlen));
  if (ret < 0) {
    // TODO: WSAGetLastError()
    return X_STATUS_UNSUCCESSFUL;
  }
  return X_STATUS_SUCCESS;
}
X_STATUS XSocket::SetOption(uint32_t level, uint32_t optname, void* optval_ptr,
                            uint32_t optlen) {
  if (level == 0xFFFF && (optname == 0x5801 || optname == 0x5802)) {
    // Disable socket encryption
    secure_ = false;
    return X_STATUS_SUCCESS;
  }

  int native_level = level;

  assert_false(!supported_levels.contains(level));

  if (supported_levels.contains(level)) {
    native_level = supported_levels.at(level);
  }

  int native_optname = optname;

  if (level == 0xFFFF) {
    assert_false(!supported_socket_options.contains(optname));

    if (supported_socket_options.contains(optname)) {
      native_optname = supported_socket_options.at(optname);
    }
  }

  if (level == IPPROTO_TCP) {
    assert_false(!supported_tcp_options.contains(optname));

    if (supported_tcp_options.contains(optname)) {
      native_optname = supported_tcp_options.at(optname);
    }
  }

  int ret = setsockopt(native_handle_, native_level, native_optname,
                       static_cast<char*>(optval_ptr), optlen);
  if (ret < 0) {
    // TODO: WSAGetLastError()
    XELOGE("XSocket::SetOption: failed with error {:08X}", GetLastWSAError());
    return X_STATUS_UNSUCCESSFUL;
  }

  // SO_BROADCAST
  if (level == 0xFFFF && optname == 0x0020) {
    broadcast_socket_ = true;
  }

  return X_STATUS_SUCCESS;
}

X_STATUS XSocket::IOControl(uint32_t cmd, uint8_t* arg_ptr) {
#ifdef XE_PLATFORM_WIN32
  int ret = ioctlsocket(native_handle_, cmd, (u_long*)arg_ptr);
  if (ret < 0) {
    // TODO: Get last error
    return X_STATUS_UNSUCCESSFUL;
  }
  return X_STATUS_SUCCESS;
#else
#if XE_PLATFORM_PS5
  // Xbox360PS5: the console refuses the generic ioctl on a socket (errno 13).
  // Non-blocking mode is set on the descriptor (or by the console's own
  // socket option), and the bytes waiting are found by peeking. The guest's
  // argument is a big-endian 32-bit value.
  if (cmd == 0x8004667E) {  // FIONBIO
    const int enable = xe::load_and_swap<uint32_t>(arg_ptr) != 0;
    const int flags = fcntl(native_handle_, F_GETFL, 0);
    if (flags >= 0 &&
        !fcntl(native_handle_, F_SETFL,
               enable ? flags | O_NONBLOCK : flags & ~O_NONBLOCK)) {
      return X_STATUS_SUCCESS;
    }
    constexpr int kSoNbio = 0x1200;
    return setsockopt(native_handle_, SOL_SOCKET, kSoNbio, &enable,
                      sizeof(enable))
               ? X_STATUS_UNSUCCESSFUL
               : X_STATUS_SUCCESS;
  }
  if (cmd == 0x4004667F) {  // FIONREAD
    int waiting = 0;
    if (ioctl(native_handle_, FIONREAD, &waiting) < 0) {
      std::vector<char> scratch(65536);
      const auto peeked = recv(native_handle_, scratch.data(), scratch.size(),
                               MSG_PEEK | MSG_DONTWAIT);
      waiting = peeked > 0 ? int(peeked) : 0;
    }
    xe::store_and_swap<uint32_t>(arg_ptr, uint32_t(waiting));
    return X_STATUS_SUCCESS;
  }
#endif
  int native_cmd = cmd;

  assert_false(!supported_controls.contains(cmd));

  if (supported_controls.contains(cmd)) {
    native_cmd = supported_controls.at(cmd);
  }

  int ret = ioctl(native_handle_, native_cmd, arg_ptr);

  if (ret < 0) {
    return X_STATUS_UNSUCCESSFUL;
  }

  return X_STATUS_SUCCESS;
#endif
}

X_STATUS XSocket::Connect(N_XSOCKADDR* name, int name_len) {
#ifdef XE_PLATFORM_WIN32
  int ret = connect(native_handle_, (sockaddr*)name, name_len);
#else
  const sockaddr_in host =
      ToHostAddress(name->address_family, name->sa_data, name->sa_data + 2);
  int ret = connect(native_handle_, (const sockaddr*)&host, sizeof(host));
#endif
  if (ret < 0) {
    return X_STATUS_UNSUCCESSFUL;
  }

  return X_STATUS_SUCCESS;
}

X_STATUS XSocket::Bind(N_XSOCKADDR_IN* name, int name_len) {
  // On Linux and Windows (when running under Wine), ports < 1024 require root
  // privileges. Remap to port + 10000 to avoid privilege issues.
  // Note: sin_port is xe::be<uint16_t> which automatically handles endianness,
  // so we use it directly without ntohs/htons.
  const uint16_t original_port = uint16_t(name->sin_port);
  if (original_port != 0 && original_port < 1024) {
    uint16_t new_port = original_port + 10000;
    name->sin_port = new_port;
    XELOGW("XSocket::Bind: port {} requires privileges, remapping to port {}",
           original_port, new_port);
  }

#ifdef XE_PLATFORM_WIN32
  int ret = bind(native_handle_, (sockaddr*)name, name_len);
#else
  const sockaddr_in host =
      ToHostAddress(name->sin_family, &name->sin_port, &name->sin_addr);
  int ret = bind(native_handle_, (const sockaddr*)&host, sizeof(host));
  bool moved = false;
#if XE_PLATFORM_PS5
  // Xbox360PS5: the console refuses some binds a PC accepts: errno 13 (EACCES)
  // where a PC binds, as it does for the generic socket ioctl, and an address
  // the console does not own. State of Decay's main thread hit this and then
  // used an object its network start-up never made. A title only needs a
  // working local endpoint, so bind one the console allows: the same port on
  // any local address, then the port moved up by 10000, then a port the
  // system picks. Each attempt is a real bind; the guest reads the endpoint it
  // got back through getsockname.
  if (ret < 0 && (errno == EACCES || errno == EPERM || errno == EADDRNOTAVAIL)) {
    const int refused = errno;
    const uint16_t port = ntohs(host.sin_port);
    sockaddr_in other = host;
    other.sin_addr.s_addr = htonl(INADDR_ANY);
    const uint16_t ports[] = {
        port, uint16_t(port != 0 && port <= 55535 ? port + 10000 : 0), 0};
    for (uint16_t candidate : ports) {
      if (candidate == port && host.sin_addr.s_addr == other.sin_addr.s_addr) {
        continue;  // That is the bind that was just refused.
      }
      other.sin_port = htons(candidate);
      ret = bind(native_handle_, (const sockaddr*)&other, sizeof(other));
      if (ret == 0) {
        break;
      }
    }
    const int last = errno;
    if (ret == 0) {
      moved = true;
      sockaddr_in got = {};
      socklen_t got_length = sizeof(got);
      getsockname(native_handle_, reinterpret_cast<sockaddr*>(&got), &got_length);
      XELOGW("XSocket::Bind: the console refused type {} protocol {} address {:08X} port {} (errno {}); bound address {:08X} port {} instead",
             uint32_t(type_), uint32_t(proto_), ntohl(host.sin_addr.s_addr), port,
             refused, ntohl(got.sin_addr.s_addr), ntohs(got.sin_port));
    } else {
      errno = refused;
      XELOGE("XSocket::Bind: no endpoint accepted after the console refused port {} (last errno {})",
             port, last);
      errno = refused;
    }
  }
#endif
#endif

  if (ret < 0) {
#ifdef XE_PLATFORM_WIN32
    const int raw_error = WSAGetLastError();
    const uint32_t guest_error = uint32_t(raw_error);
#else
    const int raw_error = errno;
    const uint32_t guest_error = socket_errno::ToGuest(raw_error);
#endif
    XELOGE("XSocket::Bind failed: fd {} type {} protocol {} family {} address {:08X} guest_port {} host_port {} len {} raw_host {} guest_wsa {}",
           native_handle_, uint32_t(type_), uint32_t(proto_),
           uint32_t(name->sin_family), uint32_t(name->sin_addr),
           original_port, uint16_t(name->sin_port), name_len, raw_error, guest_error);
    // Logging may call libc; keep the original bind failure for the caller.
#ifdef XE_PLATFORM_WIN32
    WSASetLastError(raw_error);
#else
    errno = raw_error;
#endif
    return X_STATUS_UNSUCCESSFUL;
  }

  bound_ = true;
  bound_port_ = name->sin_port;
#ifndef XE_PLATFORM_WIN32
  if (original_port == 0 || moved) {
#else
  if (original_port == 0) {
#endif
    // Successful real bind(0) selected an ephemeral port. Do not invent one.
    sockaddr_in assigned = {};
    socklen_t assigned_length = sizeof(assigned);
    if (getsockname(native_handle_, reinterpret_cast<sockaddr*>(&assigned),
                    &assigned_length) == 0) {
      bound_port_ = ntohs(assigned.sin_port);
    } else {
      XELOGW("XSocket::Bind: bind(0) succeeded but querying assigned port failed");
    }
  }

  return X_STATUS_SUCCESS;
}

X_STATUS XSocket::Listen(int backlog) {
  int ret = listen(native_handle_, backlog);
  if (ret < 0) {
    return X_STATUS_UNSUCCESSFUL;
  }

  return X_STATUS_SUCCESS;
}

object_ref<XSocket> XSocket::Accept(N_XSOCKADDR* name, int* name_len) {
#ifdef XE_PLATFORM_WIN32
  sockaddr n_sockaddr;
  socklen_t n_name_len = sizeof(sockaddr);
  uintptr_t ret = accept(native_handle_, &n_sockaddr, &n_name_len);
  if (ret == -1) {
    std::memset(name, 0, *name_len);
    *name_len = 0;
    return nullptr;
  }

  std::memcpy(name, &n_sockaddr, n_name_len);
  *name_len = n_name_len;
#else
  sockaddr_in host = {};
  socklen_t host_length = sizeof(host);
  uintptr_t ret = accept(native_handle_, (sockaddr*)&host, &host_length);
  if (ret == -1) {
    std::memset(name, 0, *name_len);
    *name_len = 0;
    return nullptr;
  }
  // The peer in the guest's layout: a 16-bit family, the port, the address.
  *name = N_XSOCKADDR();
  name->address_family = host.sin_family;
  std::memset(name->sa_data, 0, sizeof(name->sa_data));
  std::memcpy(name->sa_data, &host.sin_port, sizeof(host.sin_port));
  std::memcpy(name->sa_data + 2, &host.sin_addr, sizeof(host.sin_addr));
  *name_len = sizeof(N_XSOCKADDR);
#endif

  // Create a kernel object to represent the new socket, and copy parameters
  // over.
  auto socket = object_ref<XSocket>(new XSocket(kernel_state_, ret));
  socket->af_ = af_;
  socket->type_ = type_;
  socket->proto_ = proto_;

  return socket;
}

int XSocket::Shutdown(int how) { return shutdown(native_handle_, how); }

int XSocket::Recv(uint8_t* buf, uint32_t buf_len, uint32_t flags) {
  return recv(native_handle_, reinterpret_cast<char*>(buf), buf_len, flags);
}

int XSocket::RecvFrom(uint8_t* buf, uint32_t buf_len, uint32_t flags,
                      N_XSOCKADDR_IN* from, uint32_t* from_len) {
  // Pop from secure packets first
  // TODO(DrChat): Enable when I commit XNet
  /*
  {
    std::lock_guard<std::mutex> lock(incoming_packet_mutex_);
    if (incoming_packets_.size()) {
      packet* pkt = (packet*)incoming_packets_.front();
      int data_len = pkt->data_len;
      std::memcpy(buf, pkt->data, std::min((uint32_t)pkt->data_len, buf_len));

      from->sin_family = 2;
      from->sin_addr = pkt->src_ip;
      from->sin_port = pkt->src_port;

      incoming_packets_.pop();
      uint8_t* pkt_ui8 = (uint8_t*)pkt;
      delete[] pkt_ui8;

      return data_len;
    }
  }
  */

  sockaddr_in nfrom;
  socklen_t nfromlen = sizeof(sockaddr_in);
  int ret = recvfrom(native_handle_, reinterpret_cast<char*>(buf), buf_len,
                     flags, (sockaddr*)&nfrom, &nfromlen);
  if (from) {
    from->sin_family = nfrom.sin_family;
    from->sin_addr = ntohl(nfrom.sin_addr.s_addr);  // BE <- BE
    from->sin_port = nfrom.sin_port;
    std::memset(from->x_sin_zero, 0, sizeof(from->x_sin_zero));
  }

  if (from_len) {
    *from_len = nfromlen;
  }

  return ret;
}

int XSocket::Send(const uint8_t* buf, uint32_t buf_len, uint32_t flags) {
  return send(native_handle_, reinterpret_cast<const char*>(buf), buf_len,
              flags);
}

int XSocket::SendTo(uint8_t* buf, uint32_t buf_len, uint32_t flags,
                    N_XSOCKADDR_IN* to, uint32_t to_len) {
  // Send 2 copies of the packet: One to XNet (for network security) and an
  // unencrypted copy for other Xenia hosts.
  // TODO(DrChat): Enable when I commit XNet.
  /*
  auto xam = kernel_state()->GetKernelModule<xam::XamModule>("xam.xex");
  auto xnet = xam->xnet();
  if (xnet) {
    xnet->SendPacket(this, to, buf, buf_len);
  }
  */

#ifdef XE_PLATFORM_WIN32
  sockaddr_in nto;
  if (to) {
    nto.sin_addr.s_addr = to->sin_addr;
    nto.sin_family = to->sin_family;
    nto.sin_port = to->sin_port;
  }

  return sendto(native_handle_, reinterpret_cast<char*>(buf), buf_len, flags,
                to ? (sockaddr*)&nto : nullptr, to_len);
#else
  sockaddr_in nto = {};
  if (to) {
    nto = ToHostAddress(to->sin_family, &to->sin_port, &to->sin_addr);
  }
  return sendto(native_handle_, reinterpret_cast<char*>(buf), buf_len, flags,
                to ? (const sockaddr*)&nto : nullptr, to ? sizeof(nto) : 0);
#endif
}

bool XSocket::QueuePacket(uint32_t src_ip, uint16_t src_port,
                          const uint8_t* buf, size_t len) {
  packet* pkt = reinterpret_cast<packet*>(new uint8_t[sizeof(packet) + len]);
  pkt->src_ip = src_ip;
  pkt->src_port = src_port;

  pkt->data_len = (uint16_t)len;
  std::memcpy(pkt->data, buf, len);

  std::lock_guard<std::mutex> lock(incoming_packet_mutex_);
  incoming_packets_.push((uint8_t*)pkt);

  // TODO: Limit on number of incoming packets?
  return true;
}

X_STATUS XSocket::GetSockName(uint8_t* buf, int* buf_len) {
#ifdef XE_PLATFORM_WIN32
  struct sockaddr sa = {};

  int ret = getsockname(native_handle_, &sa, (socklen_t*)buf_len);
  if (ret < 0) {
    return X_STATUS_UNSUCCESSFUL;
  }

  std::memcpy(buf, &sa, *buf_len);
  return X_STATUS_SUCCESS;
#else
  sockaddr_in host = {};
  socklen_t host_length = sizeof(host);
  if (getsockname(native_handle_, (sockaddr*)&host, &host_length) < 0) {
    return X_STATUS_UNSUCCESSFUL;
  }
  // In the guest's layout and byte order: a big-endian 16-bit family, the
  // port, the address, eight zero bytes.
  uint8_t guest[16] = {};
  guest[1] = uint8_t(host.sin_family);
  std::memcpy(guest + 2, &host.sin_port, sizeof(host.sin_port));
  std::memcpy(guest + 4, &host.sin_addr, sizeof(host.sin_addr));
  const int length = std::min<int>(*buf_len, int(sizeof(guest)));
  if (length > 0) {
    std::memcpy(buf, guest, size_t(length));
  }
  *buf_len = length > 0 ? length : 0;
  return X_STATUS_SUCCESS;
#endif
}

uint32_t XSocket::GetLastWSAError() const {
#ifdef XE_PLATFORM_WIN32
  return WSAGetLastError();
#else
  return socket_errno::ToGuest(errno);
#endif
}

}  // namespace kernel
}  // namespace xe
