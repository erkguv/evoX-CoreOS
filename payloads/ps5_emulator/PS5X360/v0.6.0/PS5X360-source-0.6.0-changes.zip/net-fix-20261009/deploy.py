"""Install 0.5.9-net.1-local on the PS5 (192.168.0.19) with a backup; refuses while the emulator runs.

Replaces eboot.bin, VERSION, RELEASE.json, RELEASE_NOTES.md and MANIFEST.json only.
ROMs, saves, settings, presets, camera configuration and logs are not touched.
"""
from pathlib import Path
import datetime
import ftplib
import hashlib
import importlib.util
import io
import json
import socket
import zipfile

HOST = '192.168.0.19'
root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
import sys
variant = sys.argv[1] if len(sys.argv) > 1 else 'net'
native = work / {'apc': 'native-apc', 'net3': 'native-net3'}.get(variant, 'native')
proof = json.loads((native / 'build.json').read_text())


def sha(b):
    return hashlib.sha256(b).hexdigest()


names = ('eboot.bin', 'VERSION', 'RELEASE.json', 'RELEASE_NOTES.md', 'MANIFEST.json')
with zipfile.ZipFile(work / {'apc': 'package-apc', 'net3': 'package-net3'}.get(variant, 'package') / 'PPSA50011.zip') as z:
    updates = {n: z.read('PPSA50011/' + n) for n in names}
assert sha(updates['eboot.bin']) == proof['native_sha256']
spec = importlib.util.spec_from_file_location('verify', root / 'tools/deploy-native-probe.py')
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)


def closed(f):
    for port in range(8360, 8368):
        with socket.socket() as s:
            s.settimeout(.3)
            if s.connect_ex((HOST, port)) == 0:
                raise RuntimeError('Emulator still active (settings page answering)')
    lines = []
    f.retrlines('LIST /mnt/sandbox', lines.append)
    if any('PPSA50011' in s for s in lines):
        raise RuntimeError('Title still mounted: close PS5X360 first')


stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup = work / 'console-backups' / stamp
backup.mkdir(parents=True, exist_ok=False)
remote = 'eboot-before-net-fix-' + stamp + '.bak'
temp = 'eboot-net-' + stamp + '.new'
base = {'apc': work / 'native', 'net3': work / 'native-apc'}.get(variant, root / 'build/loading-fix-20261009/native')
with ftplib.FTP() as f:
    f.connect(HOST, 2121, timeout=30)
    f.login()
    closed(f)
    f.cwd('/data/homebrew/PPSA50011')

    def read(n):
        b = io.BytesIO()
        f.retrbinary('RETR ' + n, b.write, blocksize=1024 * 1024)
        return b.getvalue()

    previous = {n: read(n) for n in names}
    # What is installed must be the loading.1 build this candidate was linked from.
    verify.verify_eboot(previous['eboot.bin'], (base / 'eboot.bin').read_bytes(), (base / 'eboot.elf').read_bytes())
    for n, b in previous.items():
        p = backup / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
    f.storbinary('STOR ' + temp, io.BytesIO(updates['eboot.bin']), blocksize=1024 * 1024)
    verify.verify_eboot(read(temp), updates['eboot.bin'], (native / 'eboot.elf').read_bytes())
    closed(f)
    f.rename('eboot.bin', remote)
    try:
        f.rename(temp, 'eboot.bin')
        for n, b in updates.items():
            if n != 'eboot.bin':
                f.storbinary('STOR ' + n, io.BytesIO(b))
        result = verify.verify_eboot(read('eboot.bin'), updates['eboot.bin'], (native / 'eboot.elf').read_bytes())
        for n, b in updates.items():
            if n != 'eboot.bin':
                assert read(n) == b, n
    except Exception:
        try:
            f.rename('eboot.bin', 'eboot-rejected-net-' + stamp + '.bak')
        except ftplib.error_perm:
            pass
        f.rename(remote, 'eboot.bin')
        for n, b in previous.items():
            if n != 'eboot.bin':
                f.storbinary('STOR ' + n, io.BytesIO(b))
        raise
receipt = dict(installed=True, version=proof['version'], native_sha256=proof['native_sha256'],
               backup=remote, local_backup=str(backup), verification=result,
               hardware_gameplay='pending', save_and_camera_configuration_changed=False)
(work / f'deployment-{variant}.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
