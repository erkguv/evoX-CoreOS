"""Package 0.5.9-net.1-local over the installed loading.1 package (only the executable and its notes change)."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
import sys
variant = sys.argv[1] if len(sys.argv) > 1 else 'net'
native = work / {'apc': 'native-apc', 'net3': 'native-net3'}.get(variant, 'native')
proof = json.loads((native / 'build.json').read_text())
version = proof['version']


def sha(b):
    return hashlib.sha256(b).hexdigest()


base_zip = {'apc': work / 'package/PPSA50011.zip', 'net3': work / 'package-apc/PPSA50011.zip'}.get(variant, root / 'build/loading-fix-20261009/package/PPSA50011.zip')
with zipfile.ZipFile(base_zip) as z:
    files = {i.filename: z.read(i) for i in z.infolist() if not i.is_dir()}
assert b'[584111E8]' in files['PPSA50011/assets/presets.txt']

notes = '''# Network bind candidate (private test build)

Based on the installed 0.5.9-loading.1-local build: every object is unchanged
except the socket implementation.

- When the PS5 refuses a bind that a PC accepts (EACCES/EPERM, or an address
  the console does not own), the emulator binds a real endpoint the console
  allows: the same port on any local address, then the port + 10000, then a
  port chosen by the system. The game reads the endpoint it got through
  getsockname. Each fallback is logged with the refused type, protocol,
  address and port.
- Socket errors reach the game as Winsock codes (EACCES -> 10013, and so on)
  instead of raw BSD errno numbers.
- bind(0) keeps its meaning (a system-chosen port) instead of being moved to
  the fixed port 10000.

Target: State of Decay (584111E8), whose main thread had a bind refused with
errno 13 right before it used an object that was never created. Not yet
verified on the console. The loading.1 thread wait change and the State of
Decay zero-page preset are kept.
'''
if variant in ('apc', 'net3'):
    notes += '''
## 0.5.9-net.2: guest APCs in alertable waits

On Linux and the PS5 a host wait never returned for a queued guest APC, so a
thread waiting alertably never ran the completions queued to it. Alertable
waits now run pending APCs before waiting and wait in 5 ms slices so that an
APC queued from another thread is run too. I Am Alive's Wwise I/O thread
queued its own read completion and then waited for it forever (loading
screen). On the PC runner the game now passes its loading screen.
'''
if variant == 'net3':
    notes += '''
## 0.5.9-net.3: controller driver and frame generation prototype

- Controller: capability queries with flags other than GAMEPAD (0 = any
  device, 0xFF, ANY_USER) were refused, so some games saw no controller; a
  refused vibration command made the pad read as disconnected. Both now answer
  as a connected Xbox 360 pad would (first occurrence of each is logged).
- Frame generation prototype from build/framegen-20261008 (presenter hook,
  bounded optical-flow midpoint between two finished frames). Off unless
  /data/homebrew/PPSA50011/framegen.conf has the first line
  ps5_frame_interpolation=true. Only admitted near a steady 30 FPS at 60 Hz;
  adds about one frame of latency. Untested on the console.
- I Am Alive preset: fast readback (scene brightness).
'''
    files['PPSA50011/assets/presets.txt'] = (work / 'presets.txt').read_bytes()
image = (native / 'eboot.bin').read_bytes()
assert sha(image) == proof['native_sha256']
files['PPSA50011/eboot.bin'] = image
files['PPSA50011/VERSION'] = (version + '\n').encode()
files['PPSA50011/RELEASE.json'] = json.dumps(proof, indent=2).encode()
files['PPSA50011/RELEASE_NOTES.md'] = notes.encode()
files.pop('PPSA50011/MANIFEST.json', None)
manifest = {n.removeprefix('PPSA50011/'): {'sha256': sha(b), 'bytes': len(b)} for n, b in files.items()}
files['PPSA50011/MANIFEST.json'] = json.dumps(manifest, indent=2).encode()

out = work / {'apc': 'package-apc', 'net3': 'package-net3'}.get(variant, 'package')
out.mkdir(exist_ok=True)
with zipfile.ZipFile(out / 'PPSA50011.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for n, b in files.items():
        z.writestr(n, b)
with zipfile.ZipFile(out / 'PPSA50011.zip') as z:
    assert z.testzip() is None
    for n, p in manifest.items():
        assert sha(z.read('PPSA50011/' + n)) == p['sha256']
(out / 'README.md').write_text(notes)
(out / 'proof.json').write_text(json.dumps(dict(
    version=version, native_sha256=sha(image),
    zip_sha256=sha((out / 'PPSA50011.zip').read_bytes()),
    verified_manifest_files=len(manifest), hardware='pending'), indent=2))

desktop = Path.home() / {'apc': 'Desktop/PS5X360-net2-test-20261009', 'net3': 'Desktop/PS5X360-net3-test-20261009'}.get(variant, 'Desktop/PS5X360-net-test-20261009')
desktop.mkdir(exist_ok=True)
for n in ('PPSA50011.zip', 'README.md', 'proof.json'):
    shutil.copy2(out / n, desktop / n)
delta = Path.home() / 'Desktop/Xbox360PS5-source/net-fix-20261009'
delta.mkdir(parents=True, exist_ok=True)
for p in (work / 'xsocket.cc', work / 'socket_errno.h', work / 'build.py', work / 'package.py',
          work / 'deploy.py', work / 'apc/xboxkrnl_threading.cc', work / 'apc/build_apc.py',
          work / 'apc/reproduce.py', work / 'apc/compile.json', work / 'input/dualsense_input.cpp',
          work / 'input/build_net3.py', work / 'input/reproduce.py', work / 'presets.txt'):
    if p.exists():
        shutil.copy2(p, delta / p.name)
for p in (native / 'build.json',):
    if p.exists():
        shutil.copy2(p, delta / (variant + '-' + p.name))
print(json.dumps({'folder': str(desktop), 'native_sha256': sha(image), 'manifest_files': len(manifest)}))
