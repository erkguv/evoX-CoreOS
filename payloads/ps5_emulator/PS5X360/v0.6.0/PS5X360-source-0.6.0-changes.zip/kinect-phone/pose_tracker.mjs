// Estimated monocular geometry only; no measured depth or native ABI changes.
import {skeleton} from './pose.mjs?v=calibration1';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const median = a => [...a].sort((x,y)=>x-y)[Math.floor(a.length/2)];
const confidence = p => p ? Math.min(Number.isFinite(p.visibility) ? clamp(p.visibility,0,1) : 0,
  p.presence === undefined ? 1 : Number.isFinite(p.presence) ? clamp(p.presence,0,1) : 0) : 0;
const mean = (a,b) => ({x:(a.x+b.x)/2,y:(a.y+b.y)/2,z:(a.z+b.z)/2});
const norm = p => Math.hypot(p.x,p.y,p.z);
const sub = (a,b) => ({x:a.x-b.x,y:a.y-b.y,z:a.z-b.z});
const zero = () => ({x:0,y:0,z:0});
const valid = p => p && [p.x,p.y,p.z].every(Number.isFinite);
const torsoIDs = [11,12,23,24];
const standIDs = [0,7,8,11,12,23,24,25,26,27,28,31,32];
export const POSE_REASONS = Object.freeze({
  LEGACY:'legacy',INVALID_WORLD:'invalid_world',STAND_VISIBLE:'stand_visible',
  STAND_UPRIGHT:'stand_upright',FACE_CAMERA:'face_camera',MODEL_STATURE:'model_stature',
  CAMERA_PROJECTION:'camera_projection',KEEP_STILL:'keep_still',COLLECTING:'collecting',
  CALIBRATED:'calibrated_estimate',TORSO_UNAVAILABLE:'torso_unavailable',
  PROJECTION_LOST:'projection_lost',ASPECT_CHANGED:'aspect_changed',DEPTH_RANGE:'depth_range',
  ROOT_RANGE:'root_range',PACKET_RANGE:'packet_range',NATIVE_DEPTH_RANGE:'native_depth_range',OUT_OF_ORDER:'out_of_order'
});
const reasons = new Map([
  ['Legacy hip-relative mapping; calibration is optional',POSE_REASONS.LEGACY],
  ['Invalid or missing world pose',POSE_REASONS.INVALID_WORLD],
  ['Stand fully visible with head and feet confidently tracked',POSE_REASONS.STAND_VISIBLE],
  ['Stand upright with straight legs',POSE_REASONS.STAND_UPRIGHT],
  ['Face the level camera and stand upright',POSE_REASONS.FACE_CAMERA],
  ['Unreliable model stature',POSE_REASONS.MODEL_STATURE],
  ['Unreliable camera projection',POSE_REASONS.CAMERA_PROJECTION],
  ['Keep still for two seconds',POSE_REASONS.KEEP_STILL],
  ['Stand still facing the camera',POSE_REASONS.COLLECTING],
  ['Calibrated: monocular estimated distance',POSE_REASONS.CALIBRATED],
  ['Torso projection is unavailable',POSE_REASONS.TORSO_UNAVAILABLE],
  ['Torso projection lost; no retained calibrated pose',POSE_REASONS.PROJECTION_LOST],
  ['Camera aspect changed; recalibrate',POSE_REASONS.ASPECT_CHANGED],
  ['Unreliable or out-of-range depth projection',POSE_REASONS.DEPTH_RANGE],
  ['Root outside physical operating range',POSE_REASONS.ROOT_RANGE],
  ['Translated pose outside XMP1 bounds',POSE_REASONS.PACKET_RANGE],
  ['Pose would clip fixed native depth transform',POSE_REASONS.NATIVE_DEPTH_RANGE],
  ['Timestamp must advance monotonically',POSE_REASONS.OUT_OF_ORDER]
]);

class Euro {
  constructor(beta=5) { this.beta=beta; }
  next(x,t) {
    if (this.t === undefined) { this.t=t; this.raw=x; this.value=x; this.speed=0; return x; }
    const dt=(t-this.t)/1000;
    const alpha = hz => 1/(1+1/(2*Math.PI*hz*dt));
    this.speed += alpha(1)*((x-this.raw)/dt-this.speed);
    this.value += alpha(1.5+this.beta*Math.abs(this.speed))*(x-this.value);
    this.raw=x; this.t=t; return this.value;
  }
}

export class CalibratedPoseTracker {
  constructor() { this.smoothing=false; this.resetCalibration(); }
  resetMotion() { this.filters=new Map(); this.lastTime=null; this.lastDimensions=null; this.samples=[]; }
  resetCalibration() { this.calibration=null; this.options=null; this.phase='idle'; this.resetMotion(); }
  setSmoothing(enabled) { this.smoothing=Boolean(enabled); this.resetMotion(); }
  beginCalibration({heightMetres=1.75,distanceMetres=2.5,sensorHeightMetres=.8}={}) {
    if (![heightMetres,distanceMetres,sensorHeightMetres].every(Number.isFinite) ||
        heightMetres<1 || heightMetres>2.3 || distanceMetres<1 || distanceMetres>3.8 ||
        sensorHeightMetres<.2 || sensorHeightMetres>2) throw new RangeError('Invalid physical calibration settings');
    this.resetCalibration(); this.options={heightMetres,distanceMetres,sensorHeightMetres}; this.phase='collecting';
  }
  status(reason, root=zero(), distanceMetres=null) {
    const elapsed=this.samples.length ? this.samples.at(-1).t-this.samples[0].t : 0;
    return {phase:this.phase, progress:this.phase==='calibrated' ? 1 : this.phase==='collecting' ?
      clamp(Math.min(elapsed/2000,this.samples.length/30),0,1) : 0,
      reason:reasons.get(reason),distanceMetres,root,calibrated:this.phase==='calibrated'};
  }
  filter(key,value,t) {
    if (!this.smoothing) return value;
    if (!this.filters.has(key)) this.filters.set(key,new Euro(key.startsWith('root') ? 3 : 5));
    return this.filters.get(key).next(value,t);
  }
  geometry(world,image,w,h) {
    if (!Array.isArray(image) || image.length!==33 || !Number.isFinite(w) || !Number.isFinite(h) ||
        w<64 || h<64 || w>8192 || h>8192) return null;
    if (torsoIDs.some(i=>!valid(world[i]) || !valid(image[i]) || confidence(world[i])<.7 ||
        confidence(image[i])<.7 || image[i].x<0 || image[i].x>1 || image[i].y<0 || image[i].y>1)) return null;
    const hip=mean(image[23],image[24]), shoulder=mean(image[11],image[12]);
    const wh=mean(world[23],world[24]), ws=mean(world[11],world[12]);
    const delta={x:ws.x-wh.x,y:wh.y-ws.y,z:ws.z-wh.z}; // camera-away Z
    const hipPixel={x:(hip.x-.5)*w,y:(.5-hip.y)*h};
    const shoulderPixel={x:(shoulder.x-.5)*w,y:(.5-shoulder.y)*h};
    if (Math.hypot(delta.x,delta.y)<.12 || Math.hypot(delta.x,delta.y)>.9 ||
        Math.hypot(shoulderPixel.x-hipPixel.x,shoulderPixel.y-hipPixel.y)<16) return null;
    const points=torsoIDs.map(i=>({x:world[i].x-wh.x,y:wh.y-world[i].y,z:world[i].z-wh.z,
      px:(image[i].x-.5)*w,py:(.5-image[i].y)*h}));
    return {delta,hipPixel,shoulderPixel,hip,wh,points};
  }
  collect(world,image,g,t) {
    if (standIDs.some(i=>!valid(world[i]) || !valid(image[i]) || confidence(world[i])<.75 ||
        confidence(image[i])<.75 || image[i].x<.02 || image[i].x>.98 || image[i].y<.02 || image[i].y>.98)) {
      this.samples=[]; return 'Stand fully visible with head and feet confidently tracked';
    }
    for (const [a,b,c] of [[23,25,27],[24,26,28]]) {
      const u=sub(world[a],world[b]),v=sub(world[c],world[b]);
      if (norm(u)<.1 || norm(v)<.1 || (u.x*v.x+u.y*v.y+u.z*v.z)/(norm(u)*norm(v))>-.94) {
        this.samples=[]; return 'Stand upright with straight legs';
      }
    }
    const feet=mean(world[31],world[32]);
    const stature=(feet.y-world[0].y)/.92; // nose-to-crown allowance, explicitly approximate
    if (stature<.8 || stature>2.7 || g.delta.y<.25 || Math.abs(g.delta.z)>.15 || Math.abs(g.delta.x)>.15) {
      this.samples=[]; return 'Face the level camera and stand upright';
    }
    const scale=this.options.heightMetres/stature;
    if (scale<.5 || scale>2) { this.samples=[]; return 'Unreliable model stature'; }
    const d={x:g.delta.x*scale,y:g.delta.y*scale,z:g.delta.z*scale};
    const D=this.options.distanceMetres;
    // Fit each actual landmark, avoiding midpoint projection bias under yaw.
    const ax=(g.shoulderPixel.x-g.hipPixel.x)*(D+d.z)+g.hipPixel.x*d.z;
    const ay=(g.shoulderPixel.y-g.hipPixel.y)*(D+d.z)+g.hipPixel.y*d.z;
    const points=g.points.map(p=>({...p,x:p.x*scale,y:p.y*scale,z:p.z*scale}));
    let numerator=0,denominator=0;
    for(const [axis,pixel] of [['x','px'],['y','py']]) {
      const avg=points.reduce((s,p)=>s+p[axis],0)/4;
      const projected=points.map(p=>p[pixel]*(D+p.z));
      const avgP=projected.reduce((s,p)=>s+p,0)/4;
      for(let i=0;i<4;i++){numerator+=(points[i][axis]-avg)*(projected[i]-avgP);denominator+=(points[i][axis]-avg)**2;}
    }
    const f=numerator/denominator;
    const projectionY=points.reduce((s,p)=>s+p.py*(D+p.z)/f-p.y,0)/4;
    const height=(feet.y-g.wh.y)*scale;
    if (!Number.isFinite(f) || f<150 || f>10000 || height<.35 || height>1.4) {
      this.samples=[]; return 'Unreliable camera projection';
    }
    const sample={t,scale,f,height,px:g.hipPixel.x,py:g.hipPixel.y,projectionY,span:Math.hypot(ax,ay)};
    const first=this.samples[0];
    if (first && (Math.hypot(sample.px-first.px,sample.py-first.py)>8 ||
        Math.abs(sample.scale/first.scale-1)>.04 || Math.abs(sample.f/first.f-1)>.04 ||
        Math.abs(sample.height-first.height)>.035)) {
      this.samples=[sample]; return 'Keep still for two seconds';
    }
    // Rate limit accepted samples, keeping the collection memory bounded.
    if (!this.samples.length || t-this.samples.at(-1).t>=30) this.samples.push(sample);
    if (this.samples.length>=30 && t-this.samples[0].t>=2000) {
      const scale=median(this.samples.map(s=>s.scale)), focal=median(this.samples.map(s=>s.f));
      const hipHeight=median(this.samples.map(s=>s.height));
      const projectionY=median(this.samples.map(s=>s.projectionY));
      this.calibration={scale,focal,aspect:this.lastDimensions[0]/this.lastDimensions[1],
        width:this.lastDimensions[0],height:this.lastDimensions[1],
        yOffset:hipHeight-this.options.sensorHeightMetres-.1-projectionY};
      this.phase='calibrated'; this.filters.clear(); return 'Calibrated: monocular estimated distance';
    }
    return 'Stand still facing the camera';
  }
  update(worldPoints,imagePoints,timestampMs,videoWidth,videoHeight) {
    if (!Number.isFinite(timestampMs)) {
      this.filters.clear(); this.samples=[]; return {pose:null,status:this.status('Invalid or missing world pose')};
    }
    if (this.lastTime!==null && timestampMs<=this.lastTime) {
      this.filters.clear(); this.samples=[];
      return {pose:null,status:this.status('Timestamp must advance monotonically')};
    }
    if (this.lastTime!==null && timestampMs-this.lastTime>250) this.resetMotion();
    this.lastTime=timestampMs;
    let pose;
    try { pose=skeleton(worldPoints,timestampMs); } catch {
      this.filters.clear(); this.samples=[]; return {pose:null,status:this.status('Invalid or missing world pose')};
    }
    if (this.lastDimensions && (videoWidth!==this.lastDimensions[0] || videoHeight!==this.lastDimensions[1])) {
      this.filters.clear(); this.samples=[];
    }
    this.lastTime=timestampMs; this.lastDimensions=[videoWidth,videoHeight];
    const g=this.geometry(worldPoints,imagePoints,videoWidth,videoHeight);
    let reason='Legacy hip-relative mapping; calibration is optional';
    if (this.phase==='collecting') {
      if (!g) { this.samples=[]; reason='Torso projection is unavailable'; }
      else reason=this.collect(worldPoints,imagePoints,g,timestampMs);
    }
    let root=zero(),distance=null;
    if (this.calibration) {
      const c=this.calibration;
      const invalid=reason=>{this.filters.clear(); return {pose:null,status:this.status(reason)};};
      if (!g) return invalid('Torso projection lost; no retained calibrated pose');
      if (Math.abs(videoWidth/videoHeight-c.aspect)>.005) return invalid('Camera aspect changed; recalibrate');
      const f=c.focal*videoWidth/c.width;
      const points=g.points.map(p=>({x:p.x*c.scale,y:p.y*c.scale,z:p.z*c.scale,qx:p.px/f,qy:p.py/f}));
      let numerator=0,denominator=0;
      for(const [axis,q] of [['x','qx'],['y','qy']]) {
        const avgQ=points.reduce((s,p)=>s+p[q],0)/4;
        const r=points.map(p=>p[q]*p.z-p[axis]),avgR=r.reduce((s,p)=>s+p,0)/4;
        for(let i=0;i<4;i++){numerator-=(points[i][q]-avgQ)*(r[i]-avgR);denominator+=(points[i][q]-avgQ)**2;}
      }
      const D=numerator/denominator;
      const X=points.reduce((s,p)=>s+p.qx*(D+p.z)-p.x,0)/4;
      const Y=points.reduce((s,p)=>s+p.qy*(D+p.z)-p.y,0)/4;
      const residual=Math.sqrt(points.reduce((s,p)=>s+(X+p.x-p.qx*(D+p.z))**2+(Y+p.y-p.qy*(D+p.z))**2,0)/4);
      if (!Number.isFinite(D) || D<.9 || D>3.9 || points.some(p=>D+p.z<.6) ||
          residual>.025 || Math.hypot(g.delta.x*c.scale,g.delta.y*c.scale)<.18) return invalid('Unreliable or out-of-range depth projection');
      root={x:X,y:Y+c.yOffset,z:2.5-D};
      if (Math.abs(root.x)>1.8 || Math.abs(root.y)>1.8) return invalid('Root outside physical operating range');
      for (const axis of ['x','y','z']) root[axis]=this.filter('root.'+axis,root[axis],timestampMs);
      distance=2.5-root.z;
      reason='Calibrated: monocular estimated distance';
    }
    for (let i=0;i<pose.joints.length;i++) {
      const joint=pose.joints[i];
      for (const axis of ['x','y','z']) {
        const key=i+'.'+axis;
        if (joint.confidence<.5) this.filters.delete(key);
        // Filtering operates before common root translation; confidence is untouched.
        const relative=joint.confidence<.5 ? joint[axis] : this.filter(key,joint[axis],timestampMs);
        joint[axis]=relative*(this.calibration?.scale ?? 1)+root[axis];
      }
    }
    if (pose.joints.some(j=>['x','y','z'].some(a=>!Number.isFinite(j[a]) || Math.abs(j[a])>4))) {
      this.filters.clear(); return {pose:null,status:this.status('Translated pose outside XMP1 bounds')};
    }
    if (this.calibration && pose.joints.some(j=>j.confidence>=.5 && (2.5-j.z<.8 || 2.5-j.z>4))) {
      this.filters.clear(); return {pose:null,status:this.status('Pose would clip fixed native depth transform')};
    }
    return {pose,status:this.status(reason,root,distance)};
  }
}
