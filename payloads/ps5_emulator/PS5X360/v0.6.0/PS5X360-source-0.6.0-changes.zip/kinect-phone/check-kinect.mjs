// Kinect tracker checks on the synthetic body of demo_body.mjs (a pinhole camera; the fake
// model output underestimates depth and carries noise, like MediaPipe). Run: node check-kinect.mjs
import assert from 'node:assert/strict';
import {KinectTracker, GestureMonitor, BODY_DISTANCE, mirrorLandmarks} from './kinect_tracker.mjs';
import {STAND, PUNCH_RIGHT, blend, observe, demoFrame, DEMO_SECONDS} from './demo_body.mjs';

const W = 640, H = 480;
const PUNCH = PUNCH_RIGHT;
const punchPose = k => blend(STAND, {...STAND, ...PUNCH}, k);

let t = 1000;
function run(tracker, frames, body, place, options, gestures) {
  let out;
  for (let i = 0; i < frames; i++) {
    t += 33;
    const b = typeof body === 'function' ? body(i) : body, p = typeof place === 'function' ? place(i) : place;
    const {world, image} = observe(b, p, options);
    out = tracker.update(world, image, t, W, H);
    gestures?.update(out.pose, t);
  }
  return out;
}

const home = {x: 0, y: 0, distance: BODY_DISTANCE};
const close = (a, b, tolerance, label) => assert.ok(Math.abs(a - b) <= tolerance, `${label}: ${a.toFixed(3)} vs ${b} ±${tolerance}`);

{ // Calibration, then steps back, sideways and a jump.
  const tracker = new KinectTracker(), gestures = new GestureMonitor();
  let r = run(tracker, 10, STAND, home);
  assert.equal(r.status.calibrated, false, 'calibrates over about a second, not instantly');
  r = run(tracker, 40, STAND, home, {}, gestures);
  assert.ok(r.status.calibrated, 'calibrated after standing still');
  close(r.status.root.distance, 2.5, .05, 'start distance');
  close(r.pose.joints[0].z, 0, .05, 'hips at the console body distance');
  r = run(tracker, 45, STAND, i => ({x: 0, y: 0, distance: 2.5 + .5 * Math.min(1, i / 15)}), {}, gestures);
  close(r.status.root.distance, 3, .1, 'step back distance');
  close(r.pose.joints[0].z, -.5, .1, 'hips moved away from the sensor');
  assert.ok(gestures.events.some(e => e.name === 'step_back') || gestures.cooldown.has('step_back'), 'step back seen');
  r = run(tracker, 45, STAND, i => ({x: .4 * Math.min(1, i / 10), y: 0, distance: 3}));
  close(r.pose.joints[0].x, .4, .06, 'sideways');
  r = run(tracker, 30, STAND, {x: .4, y: .2, distance: 3});
  close(r.pose.joints[0].y, .2, .05, 'hips raised (jump)');
  // Re-centre: the current place becomes the middle again.
  tracker.resetCalibration();
  r = run(tracker, 50, STAND, {x: .4, y: 0, distance: 3});
  close(r.pose.joints[0].x, 0, .05, 're-centred sideways');
  close(r.status.root.distance, 2.5, .06, 're-centred distance');
  console.log('PASS: calibration, step back/forward, sideways, jump, re-centre');
}

{ // Punch: the model underestimates depth; bone lengths recover the reach.
  const tracker = new KinectTracker(), gestures = new GestureMonitor();
  const rest = run(tracker, 60, STAND, home).pose.joints;
  for (const [hand, shoulder] of [[7, 4], [11, 8]])
    assert.ok(Math.abs(rest[hand].z - rest[shoulder].z) < .06, 'hands at rest are not pushed forward or back');
  const raw = 0.62 * .4;  // what the model alone would report for the hand
  let r = run(tracker, 5, i => punchPose((i + 1) / 5), home, {}, gestures);
  r = run(tracker, 6, punchPose(1), home, {}, gestures);
  const reach = r.pose.joints[11].z - r.pose.joints[8].z;
  assert.ok(reach > .48, `right hand forward of its shoulder: ${reach.toFixed(3)} (model alone ${raw.toFixed(3)}, true .62)`);
  assert.ok(r.pose.joints[7].z - r.pose.joints[4].z < .12, 'left hand stays by the body');
  assert.ok(gestures.cooldown.has('right_punch') && !gestures.cooldown.has('left_punch'), 'right punch seen, on the right side');
  const stronger = new KinectTracker({reach: 1.3});
  run(stronger, 60, STAND, home);
  const s = run(stronger, 11, i => punchPose(Math.min(1, (i + 1) / 5)), home);
  assert.ok(s.pose.joints[11].z - s.pose.joints[8].z > reach * 1.15, 'reach factor extends punches');
  console.log(`PASS: punch reach ${reach.toFixed(2)} m (model alone ${raw.toFixed(2)}, true 0.62), gesture side, reach factor`);
}

{ // Smoothing: a still body shakes much less than the raw model output.
  const tracker = new KinectTracker();
  run(tracker, 60, STAND, home, {jitter: .02});
  const values = [];
  for (let i = 0; i < 60; i++) values.push(run(tracker, 1, STAND, home, {jitter: .02}).pose.joints[11].x);
  const mean = values.reduce((a, b) => a + b) / values.length;
  const sd = Math.sqrt(values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length);
  assert.ok(sd < .02 * .577 * .6, `hand jitter ${sd.toFixed(4)} m`);
  console.log(`PASS: still-body jitter ${(sd * 1000).toFixed(1)} mm (raw about ${(20 * .577).toFixed(1)} mm)`);
}

{ // A briefly hidden wrist stays put instead of jumping; bad input is refused.
  const tracker = new KinectTracker();
  run(tracker, 60, STAND, home);
  const before = run(tracker, 1, STAND, home).pose.joints[10];
  const moved = {...STAND, 16: [-.6, .9, .3]};
  const during = run(tracker, 5, moved, home, {hidden: [16]}).pose.joints[10];
  close(during.x, before.x, .03, 'hidden wrist held');
  assert.equal(tracker.update([], [], t + 33, W, H).pose, null);
  assert.equal(tracker.update(observe(STAND, home).world, observe(STAND, home).image, t, W, H).pose, null, 'old frame refused');
  console.log('PASS: hidden joint hold, malformed and out-of-order input');
}

{ // Packet bounds: everything stays inside the relay's ±4 m.
  const tracker = new KinectTracker();
  run(tracker, 50, STAND, home);
  const r = run(tracker, 40, STAND, {x: 1.5, y: 0, distance: 3.7});
  assert.ok(r.pose.joints.every(j => ['x', 'y', 'z'].every(a => Math.abs(j[a]) <= 4)));
  close(r.status.root.distance, 3.7, .15, 'far distance');
  console.log('PASS: far and sideways poses stay inside packet bounds');
}

{ // The demo routine: every move is read as itself, and the slow reach is not a punch.
  const tracker = new KinectTracker(), gestures = new GestureMonitor(), seen = new Map(), all = [];
  for (let ms = 0; ms < DEMO_SECONDS * 1000; ms += 33) {
    const {world, image} = demoFrame(ms / 1000);
    const r = tracker.update(world, image, 50000 + ms, W, H);
    gestures.update(r.pose, 50000 + ms);
    for (const e of gestures.events) if (!all.some(x => x.name === e.name && x.t === e.t)) all.push(e);
    for (const s of gestures.states) if (!seen.has(s)) seen.set(s, ms / 1000);
  }
  for (const e of all) if (!seen.has(e.name)) seen.set(e.name, (e.t - 50000) / 1000);
  const list = all.map(e => e.name + '@' + ((e.t - 50000) / 1000).toFixed(1)).join(', ');
  const within = (name, a, b) => assert.ok(all.some(e => e.name === name && (e.t - 50000) / 1000 >= a && (e.t - 50000) / 1000 <= b) ||
    (seen.get(name) >= a && seen.get(name) <= b), `${name} expected ${a}-${b} s (events: ${list})`);
  within('guard', 1, 2.6); within('right_punch', 2.8, 3.5); within('left_punch', 3.6, 4.3);
  within('two_hand_push', 4.5, 5.3); within('step_back', 5.5, 7); within('step_side', 10, 11.2);
  within('jump', 11.5, 12.1); within('right_kick', 12.5, 13.4);
  const strikes = all.filter(e => /punch|uppercut|swipe|kick/.test(e.name)).map(e => [e.name, (e.t - 50000) / 1000]);
  const expected = ([name, s]) => (name === 'right_punch' && s >= 2.8 && s <= 3.5) || (name === 'left_punch' && s >= 3.6 && s <= 4.3) ||
    (name === 'right_kick' && s >= 12.5 && s <= 13.4);
  assert.ok(strikes.every(expected), 'only the real strikes are read (no punch in the push, kick or slow reach): ' + list);
  console.log('PASS: demo moves: ' + list + (seen.size ? ' | states: ' + [...seen].filter(([n]) => !all.some(e => e.name === n)).map(([n, s]) => n + '@' + s.toFixed(1)).join(', ') : ''));
}

{ // Punch reach lengthens fast strikes only; a slow reach keeps its real depth.
  const reachOf = (factor, frames) => {
    const tracker = new KinectTracker({reach: factor});
    run(tracker, 60, STAND, home);
    const r = run(tracker, frames, i => punchPose(Math.min(1, (i + 1) / (frames - 4))), home);
    return r.pose.joints[10].z - r.pose.joints[8].z;
  };
  const fastPlain = reachOf(1, 9), fastLong = reachOf(1.5, 9), slowPlain = reachOf(1, 60), slowLong = reachOf(1.5, 60);
  assert.ok(fastLong > fastPlain * 1.2, `fast punch extended: ${fastPlain.toFixed(2)} -> ${fastLong.toFixed(2)}`);
  assert.ok(Math.abs(slowLong - slowPlain) < .03, `slow reach unchanged: ${slowPlain.toFixed(2)} vs ${slowLong.toFixed(2)}`);
  console.log(`PASS: reach 1.5x: fast punch ${fastPlain.toFixed(2)} -> ${fastLong.toFixed(2)} m, slow reach ${slowPlain.toFixed(2)} -> ${slowLong.toFixed(2)} m`);
}

{ // Mirror: the physical right-hand punch is reported as the left hand, on the other side.
  const plain = new KinectTracker(), mirrored = new KinectTracker({mirror: true});
  run(plain, 60, STAND, home); run(mirrored, 60, STAND, home);
  const a = run(plain, 11, i => punchPose(Math.min(1, (i + 1) / 5)), home).pose.joints;
  const b = run(mirrored, 11, i => punchPose(Math.min(1, (i + 1) / 5)), home).pose.joints;
  assert.ok(a[11].z - a[8].z > .4 && b[11].z - b[8].z < .12, 'plain: right hand forward; mirrored: right hand at rest');
  assert.ok(b[7].z - b[4].z > .4, 'mirrored: the punch is the left hand');
  close(b[7].x, -a[11].x, .03, 'mirrored hand on the other side');
  assert.ok(b[4].x < b[8].x === a[4].x < a[8].x, 'mirrored body still faces the camera');
  const twice = mirrorLandmarks(mirrorLandmarks(observe(STAND, home).image, true), true);
  assert.equal(twice.length, 33);
  console.log('PASS: mirror swaps sides and keeps the body facing the camera');
}

{ // A pause in the frames keeps the body where it was instead of jumping to the centre.
  const tracker = new KinectTracker();
  run(tracker, 50, STAND, home);
  run(tracker, 40, STAND, {x: .5, y: 0, distance: 3});
  t += 600;  // camera pause
  const r = run(tracker, 1, STAND, {x: .5, y: 0, distance: 3});
  close(r.pose.joints[0].x, .5, .06, 'sideways kept after a pause');
  close(r.status.root.distance, 3, .1, 'distance kept after a pause');
  console.log('PASS: body position survives a pause in the frames');
}
