# Motion research bridge

This tool can send 20 estimated joints from a local PC camera to the PS5X360 research receiver. It does not provide a working Kinect device to games.

## Run

Enable Settings > System > Settings page for a phone on the console. Enable Controls > Camera motion (research), preferably for the target game only. Start `python tools/kinect-phone/server.py --console 192.168.0.19` on the PC (replace the IP for other consoles). If the settings page uses another port, pass `--console-port 8361` (8360–8367). Open http://localhost:8780. Enter the six-character key displayed on the PS5, click Connect PS5 and Start camera. Keys are kept in relay memory only. The console key changes after restarting the emulator.

The PC relay binds only to 127.0.0.1 and forwards only joint data to one private LAN address. The browser never sends camera video. Stop, Disconnect or hiding the page stops tracking/transmission; the PS5 expires the last pose after 500 ms. Do not expose this development relay to the Internet. Pairing grants access over plain LAN HTTP; it is not encrypted transport.

For camera-only use, start the ordinary static server as before and skip Connect PS5. On a phone, trusted HTTPS is required for camera access. This loopback PC relay is not a phone transport; that remains a separate implementation step.

## Protocol

`XMP1`: 4 magic bytes, sequence uint32 LE, nonzero sender session uint32 LE, tracked flag uint32 LE, then 20 joints × (x,y,z,confidence) float32 LE = 336 bytes. Coordinates are hip-relative estimated metres with Y-up/Z-forward; +/-4 bounds, confidence 0–1, no NaN/Infinity. Head, hands and spine are approximate. No sensor-space distance, Kinect depth/color frame, floor plane or audio is implied. A lost body is sent explicitly with tracked=0. Receive time uses the console's monotonic clock.

The native overlay confirms delivery. `GET /api/motion/status` requires the console pairing key and reports enabled/tracked/packets/sequence/age_ms/guest_sensor_ready. That final field remains false. Never advertise the Kinect device as ready until the required guest interfaces and frame layout have been implemented and tested.

The native receiver has no backlog, writes no pose history and runs through the existing web settings service. Non-Kinect games keep the existing device behavior when research is off.

References: https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker/web_js and https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia

If the console restarts and rejects the old key (HTTP 403), the relay clears the pairing and the browser reports an expired pairing. Enter the new console key and reconnect. HTTP 502 instead means the console endpoint is unreachable; check that the emulator is open and that the port matches its settings page. Reconnecting restores research pose delivery only, not guest Kinect gameplay.

## From experimental.23

The console hands the received pose to the game as its Kinect skeleton when it
can find the game's skeleton function (see `docs/KINECT-INTEGRATION.md`). The
page sends 30 poses a second and shows what the game is doing with them.
`guest_skeleton_bound`, `guest_skeleton_frames` and `guest_skeleton_bodies` in
the status say whether the function was bound, how many frames the game took
and how many of them held a body. `guest_sensor_ready` still reads false: the
depth, colour, identity and speech sides of the sensor are not emulated.

Turn Camera motion on in the settings of the Kinect game, not in the general
settings.

## Kinect mode (2026-10-09)

The page now defaults to **Kinect mode** (`kinect_tracker.mjs`). Kinect games read where
the body stands and how far each hand reaches towards the sensor; the phone model alone
reports a hip-relative pose and underestimates depth. Kinect mode adds, on the phone:

- **Body position.** About one second of standing still facing the camera calibrates
  the torso's size in the picture against the start distance (default 2.5 m, the
  console's body distance). Afterwards the torso size gives the distance, so steps
  forward and back move the skeleton; the hips' place in the picture gives sideways
  steps, jumps and crouches. "Re-centre here" repeats the calibration.
- **Limb depth.** Arm and leg bones keep their length. A bone that looks shorter in the
  picture than its learned length (the 90th percentile of its picture length over about
  16 s) points towards or away from the camera by the missing amount; the model gives the
  direction. A straight punch at the camera now reaches forward about twice as far as
  the model alone reported in the synthetic check (0.51 m vs 0.25 m, true 0.62 m).
  Near full picture length the model's own depth is kept, so relaxed arms are not pushed.
  "Punch reach" can lengthen forward arm motion by 1.25x or 1.5x.
- **Smoothing.** One Euro filters per joint: a still body shakes about half as much, fast
  hands keep their speed. A joint hidden for less than 400 ms stays where it was.
- **Hands** are the index/pinky knuckle midpoint (near the palm centre NUI reports),
  in both modes.

The console needs no change: `SkeletonSpace` places every joint at `2.5 m - z`, so the
game's skeleton, the hand-reach adapter and the pose-derived depth silhouette all follow
the new positions. Root distance is limited to 1-3.8 m, inside the native 0.8-4 m clamp.

The page also draws a full skeleton (torso, head, colour per side, hands that grow when
they come forward), a top view of where the body and hands are, labels for punches,
steps, jumps, guard, crouch and lean (display only; the game does its own recognition),
mirrors the front-camera preview (data unchanged), keeps the screen awake, offers
Fast/Balanced/Precise models on the phone GPU (processor fallback) and a full-screen
view. Interface in English, Portuguese and Spanish.

`index.html?demo` runs a synthetic routine without camera or model download;
`?demo=3.1` calibrates for 2 s and then holds that second of the routine.
Checks: `node check.mjs` (mapping) and `node check-kinect.mjs` (tracker, on the
synthetic body of `demo_body.mjs`). `pose_tracker.mjs` (the earlier manual
calibration) is no longer used by the page.

Everything here is estimated from one camera. It is not Kinect depth, and whether a
given game accepts these motions must be tested on the console.

### Staying found (2026-10-09, second update)

The first console test (DBZ for Kinect, 23:16 UTC console time) received about 12 poses a
second, and about 29% of the game's skeleton frames had no body (1210 of 1709). The console
gives a new tracking identity each time a body is found again (`SkeletonIdentity`), so the
game kept looking for its player. Changes:

- **1 s grace.** When a camera frame has no pose (missed detection, or inference slower than
  250 ms), the page keeps sending the last pose for up to a second before reporting the body
  lost, as the sensor does through short occlusions.
- **Faster delivery.** The relay answers with HTTP/1.1 keep-alive (one TLS connection for all
  frames instead of a new handshake per frame; 15 ms to 0.3 ms per local request on the PC)
  and the page keeps up to two frames in flight (the console drops any frame older than the
  newest, so order is safe). The top-right corner shows the PS5 send rate.
- **No jump to the centre.** A pause in the frames no longer resets the body's place.
- **Pairing banner.** The console key changes whenever the emulator or a game restarts; a
  large banner on the camera view (full screen included) says when the PS5 refused the old key.
- **Left and right: Swapped (mirror).** Flips the picture and swaps the sides before tracking,
  so the body still faces the sensor and the physical left hand is reported as the right one.
  For setups where the game took the left hand for the right.

Not changed here: the game's own sensor view draws the player from its camera-image
processing, which the emulator does not run; the virtual depth image is a silhouette built
from the skeleton. Whether the view shows the player is a native question.
