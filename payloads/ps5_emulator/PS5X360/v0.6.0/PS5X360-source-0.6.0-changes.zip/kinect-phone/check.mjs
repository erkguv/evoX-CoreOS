import assert from 'node:assert/strict';
import {skeleton} from './pose.mjs';
const points=Array.from({length:33},(_,i)=>({x:i/10,y:(i+1)/10,z:(i+2)/10,visibility:.8}));
const frame=skeleton(points,123);
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,a+' != '+b);
assert.equal(frame.joints.length,20);
// Hip-relative: the hip midpoint (23+24) is the origin; Y and Z are flipped.
near(frame.joints[0].x,0);near(frame.joints[0].y,0);near(frame.joints[0].z,0);
near(frame.joints[4].x,1.1-2.35);
near(frame.joints[8].x,1.2-2.35);
near(frame.joints[4].y,-1.2+2.45);
near(frame.joints[4].z,-1.3+2.55);
near(frame.joints[1].x,(1.15-2.35)/2);
// Hands: index/pinky knuckle midpoint.
near(frame.joints[7].x,1.8-2.35);
near(frame.joints[11].x,1.9-2.35);
assert.throws(()=>skeleton([],1));
assert.throws(()=>skeleton(points,NaN));
points[15].x=Infinity;assert.throws(()=>skeleton(points,1));
console.log('PASS: joint order, hip origin, hand midpoint, axis conversion, malformed input rejection');
