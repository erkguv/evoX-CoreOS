"""0.5.9-framegen.2: the 0.5.9-kinect-dlc.3 build with the FSR3-based frame generation, the overlay
drawn on generated pictures, and the readback log fix (GTA IV map load crash).

Run in xbox360ps5-radv-buildenv with the parent folder at /ws (after apply_presenter.py and
compile_shaders.py):
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-radv-buildenv \
      python3 -u /ws/Xbox360PS5/build/framegen-fsr3-20261010/build.py
- vulkan_presenter.cc.o: the installed object's recorded source (framegen-counter) is rebuilt with
  its recorded command and must match byte for byte; then presenter/vulkan_presenter.cc (sidecar
  with FSR3 optical flow, new pacing) is compiled with the same command.
- fsr3_flow.cpp.o: new, compiled with the presenter's command.
- launcher.cpp.o: the kinect-dlc.3 source and command must reproduce the installed object; then
  the same source is compiled with the new version label.
- vulkan_command_processor.cc.o: its recorded source (performance-refine scheduling-candidate) is
  rebuilt with its recorded command and must match; then cp/ (apply_readback_fix.py) is compiled.
- Every other object is the kinect-dlc.3 one, unchanged; the read-only version literals are
  patched as in earlier test builds.
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/framegen-fsr3-20261010/native'
counter = root / 'build/framegen-counter-20261009/presenter'
out = here / 'native'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
VERSION = '0.5.9-framegen.3-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')

base_record = json.loads((base / 'build.json').read_text())
assert sha(base / 'eboot.bin') == base_record['native_sha256'] == \
    'cc81cf3b35ed75de4d4c0a251a373218a96d58a691347a877a4fd6a807d78bad', 'base is not the installed kinect-dlc.3'
if out.exists():
    shutil.rmtree(out)
(out / 'obj').mkdir(parents=True)
for p in (base / 'obj').glob('*.o'):
    if p.name != 'fsr3_flow.cpp.o': shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    cmd = list(command)
    cmd[1:1] = list(extra)
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(obj)
    subprocess.run(cmd, cwd=root, check=True)
    return cmd


# Presenter: proof, then the edited source; the frame generation module with the same command.
presenter_cmd = base_record['commands']['presenter']
compile_with(presenter_cmd, root / 'build/framegen-fsr3-20261010/presenter/vulkan_presenter.cc', here / 'presenter.proof.o')
assert sha(here / 'presenter.proof.o') == sha(base / 'obj/vulkan_presenter.cc.o'), 'presenter inputs drifted'
presenter_build = compile_with(presenter_cmd, here / 'presenter/vulkan_presenter.cc', out / 'obj/vulkan_presenter.cc.o',
                               ['-I' + str(here)])
flow_build = compile_with(presenter_cmd, here / 'vendor/ps5_framegen.cpp', out / 'obj/ps5_framegen.cpp.o', ['-I' + str(here / 'vendor'), '-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"', '-Wno-missing-field-initializers'])

# Command processor: proof, then the readback log fix.
cp_record = base_record['commands']['command_processor']


def compile_cp(source, obj):
    cmd = list(cp_record)
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(obj)
    subprocess.run(cmd, cwd=root / 'build/canary-ps5', check=True)
    return cmd


compile_cp(root / 'build/framegen-fsr3-20261010/cp/xenia/gpu/vulkan/vulkan_command_processor.cc',
           here / 'command_processor.proof.o')
assert sha(here / 'command_processor.proof.o') == sha(base / 'obj/vulkan_command_processor.cc.o'), 'command processor inputs drifted'
cp_build = compile_cp(here / 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc', out / 'obj/vulkan_command_processor.cc.o')

# Launcher: proof, then the new label.
launcher_cmd = base_record['commands']['launcher']
compile_with(launcher_cmd, root / 'build/kinect-native-20261009/launcher.cpp', here / 'launcher.proof.o')
assert sha(here / 'launcher.proof.o') == sha(base / 'obj/launcher.cpp.o'), 'launcher inputs drifted'
launcher_cmd = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in launcher_cmd]
assert f'-DXBOX360PS5_VERSION="{LABEL}"' in launcher_cmd
launcher_build = compile_with(launcher_cmd, root / 'build/kinect-native-20261009/launcher.cpp', out / 'obj/launcher.cpp.o')

# Source clock: compile its original with the archive's original recipe first.
import shlex
gs_target='core/src/xenia/gpu/CMakeFiles/xenia-gpu.dir/graphics_system.cc.o'
gs_cmd=shlex.split(subprocess.check_output(['ninja','-t','commands',gs_target],cwd=root/'build/canary-ps5',text=True).strip())
def compile_gs(source,obj):
    cmd=list(gs_cmd); cmd[1:1]=['-I'+str(here)]
    cmd[cmd.index('-c')+1]=str(source); cmd[cmd.index('-o')+1]=str(obj)
    subprocess.run(cmd,cwd=root/'build/canary-ps5',check=True)
    return cmd
compile_gs(root/'.deps/xenia-canary/src/xenia/gpu/graphics_system.cc',here/'graphics_system.proof.o')
assert sha(here/'graphics_system.proof.o') == sha(root/'build/canary-ps5'/gs_target), 'graphics system inputs drifted'
gs_build=compile_gs(here/'graphics_system.cc',out/'obj/graphics_system.cc.o')
subprocess.run(['python3',str(here/'device_feature.py')],check=True)
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)
changed = {'vulkan_presenter.cc.o', 'launcher.cpp.o', 'vulkan_command_processor.cc.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed and p.name != 'fsr3_flow.cpp.o'}
assert all(sha(out / 'obj' / n) == h for n, h in retained.items())
assert sorted(p.name for p in (out / 'obj').glob('*.o')) == sorted([*retained, *changed, 'ps5_framegen.cpp.o', 'graphics_system.cc.o', 'vulkan_device.cc.o'])

# Display version as in the earlier test builds (read-only literals; code unchanged).
for name in ('llvm-pie.elf', 'eboot.elf'):
    data = bytearray((out / name).read_bytes())
    original = bytes(data)
    phoff = struct.unpack_from('<Q', original, 32)[0]
    size, count = struct.unpack_from('<HH', original, 54)
    headers = [struct.unpack_from('<IIQQQQQQ', original, phoff + n * size) for n in range(count)]
    for old, new in ((b'PS5X360 v0.5.8-vulkan.4', f'PS5X360 {SHORT}'.encode()), (b'BOOT version 0.5.8-vulkan.4', f'BOOT version {SHORT}'.encode()),
                     (b'0.5.8-vulkan.4', SHORT.encode())):
        assert len(new) <= len(old), (old, new)
        needle = b'\0' + old + b'\0'
        assert data.count(needle) == 1, (name, old)
        at = data.index(needle) + 1
        assert any(h[0] == 1 and h[1] == 4 and h[2] <= at and at + len(old) < h[2] + h[5] for h in headers)
        data[at:at + len(old)] = new + b'\0' * (len(old) - len(new))
    for h in headers:
        if h[0] == 1 and h[1] & 1:
            assert data[h[2]:h[2] + h[5]] == original[h[2]:h[2] + h[5]], 'code changed'
    (out / name).write_bytes(bytes(data))
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'), str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)
image = (out / 'llvm-pie.elf').read_bytes()
assert f'PS5X360 v{LABEL}'.encode() in (out / 'obj/launcher.cpp.o').read_bytes(), 'menu version label'
assert b'Framegen: Sword FSR3 ready' in image and b'Framegen enabled (Sword FSR3 optical flow)' in image
assert b'PS5X360 Kinect camera (this console)' in image, 'kinect-dlc features kept'
assert b'not inspected (diagnostic only)' in image, 'readback log fix'

(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'presenter_preimage_identical': True, 'launcher_preimage_identical': True, 'command_processor_preimage_identical': True,
    'objects': {p.name: sha(p) for p in (out/'obj').glob('*.o')},
    'unchanged_objects': retained,
    'commands': {'presenter': presenter_build, 'sword_framegen': flow_build, 'source_clock': gs_build, 'launcher': launcher_build, 'command_processor': cp_build},
    'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
