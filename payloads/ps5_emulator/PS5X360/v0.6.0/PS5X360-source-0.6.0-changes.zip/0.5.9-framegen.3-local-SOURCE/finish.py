from pathlib import Path
import hashlib,json,struct,subprocess,shlex
root=Path('/ws/Xbox360PS5'); here=Path(__file__).resolve().parent
base=root/'build/framegen-fsr3-20261010/native'; out=here/'native'
base_record=json.loads((base/'build.json').read_text())
VERSION='0.5.9-framegen.3-local'; LABEL=VERSION.removesuffix('-local'); SHORT=LABEL.removeprefix('0.5.9-')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed={'vulkan_presenter.cc.o','launcher.cpp.o','vulkan_command_processor.cc.o'}
retained={p.name:sha(p) for p in (base/'obj').glob('*.o') if p.name not in changed and p.name!='fsr3_flow.cpp.o'}
assert all(sha(out/'obj'/name)==value for name,value in retained.items())
for name in changed:
    proof={'vulkan_presenter.cc.o':'presenter.proof.o','launcher.cpp.o':'launcher.proof.o','vulkan_command_processor.cc.o':'command_processor.proof.o'}[name]
    assert sha(here/proof)==sha(base/'obj'/name)
assert json.loads((here/'device-feature.json').read_text())['preimage_identical']
assert sha(here/'graphics_system.proof.o')==sha(root/'build/canary-ps5/core/src/xenia/gpu/CMakeFiles/xenia-gpu.dir/graphics_system.cc.o')
def cmd(command,source,obj,extra=()):
    c=list(command); c[1:1]=list(extra); c[c.index('-c')+1]=str(source);c[c.index('-o')+1]=str(obj);return c
presenter_build=cmd(base_record['commands']['presenter'],here/'presenter/vulkan_presenter.cc',out/'obj/vulkan_presenter.cc.o',['-I'+str(here)])
flow_build=cmd(base_record['commands']['presenter'],here/'vendor/ps5_framegen.cpp',out/'obj/ps5_framegen.cpp.o',['-I'+str(here/'vendor'),'-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"','-Wno-missing-field-initializers'])
cp_build=cmd(base_record['commands']['command_processor'],here/'cp/xenia/gpu/vulkan/vulkan_command_processor.cc',out/'obj/vulkan_command_processor.cc.o')
launcher_build=base_record['commands']['launcher']
launcher_build=[f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in launcher_build]
launcher_build=cmd(launcher_build,root/'build/kinect-native-20261009/launcher.cpp',out/'obj/launcher.cpp.o')
target='core/src/xenia/gpu/CMakeFiles/xenia-gpu.dir/graphics_system.cc.o'
gs_build=cmd(shlex.split(subprocess.check_output(['ninja','-t','commands',target],cwd=root/'build/canary-ps5',text=True)),here/'graphics_system.cc',out/'obj/graphics_system.cc.o',['-I'+str(here)])
# Re-link the complete, verified set and execute the original version/ELF checks.
subprocess.run(['bash',str(root/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(root),str(out)],check=True)
script=(here/'build.py').read_text()
exec(compile(script[script.index('# Display version'):],str(here/'build.py'),'exec'),globals())
record=json.loads((out/'build.json').read_text())
record['graphics_system_preimage_identical']=True
record['device_feature']=json.loads((here/'device-feature.json').read_text())
record['upstream']=json.loads((here/'PROVENANCE.json').read_text())
record['source_sha256']={str(p.relative_to(here)):sha(p) for p in here.rglob('*') if p.is_file() and p.suffix in {'.cc','.cpp','.hpp','.h','.inc'} and 'native' not in p.parts}
(out/'build.json').write_text(json.dumps(record,indent=2))
