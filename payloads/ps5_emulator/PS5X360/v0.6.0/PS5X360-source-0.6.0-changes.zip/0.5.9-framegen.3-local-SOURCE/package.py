from pathlib import Path
import json,hashlib,shutil,zipfile
h=Path(__file__).resolve().parent; root=h.parents[1]
record=json.loads((h/'native/build.json').read_text()); version=record['version']
out=root/'dist/local'/version; out.mkdir(parents=True,exist_ok=True)
title=out/'PPSA50011';title.mkdir(exist_ok=True)
shutil.copy2(h/'native/eboot.bin',title/'eboot.bin')
(title/'VERSION').write_text(version+'\n')
(out/'README.txt').write_text('LOCAL UPDATE ONLY — retain your existing PPSA50011 installation. Copy eboot.bin and VERSION into its root with PS5X360 fully closed. Games, saves, profiles and settings are not included. Frame generation is experimental; console gameplay validation is pending. See SOURCE/README.md for the changes and tests.\n',encoding='utf-8')
extensions={'.py','.hpp','.h','.cpp','.cc','.md','.json','.inc','.hlsl','.glsl','.txt','.sh'}
for p in h.rglob('*'):
    rel=p.relative_to(h)
    if not p.is_file() or any(x in {'native','console-logs','console-backups','scenes','scenes-dispatch','__pycache__'} for x in rel.parts):continue
    if p.name=='COPYING' or p.suffix in extensions:
        dest=out/'SOURCE'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
shutil.copy2(h/'native/build.json',out/'BUILD.json')
assert hashlib.sha256((title/'eboot.bin').read_bytes()).hexdigest()==record['native_sha256']
with zipfile.ZipFile(out/'PS5X360-local-update.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in out.rglob('*'):
        if p.is_file() and p.suffix!='.zip':z.write(p,p.relative_to(out))
with zipfile.ZipFile(out/'PS5X360-local-update.zip') as z: assert z.testzip() is None
desktop=Path.home()/'Desktop/Xbox360PS5-source/framegen-sword-20261010'
for p in (out/'SOURCE').rglob('*'):
    if p.is_file():
        dest=desktop/p.relative_to(out/'SOURCE');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
print(out)
