from pathlib import Path
import ftplib,re,json,socket
h=Path(__file__).resolve().parent; dest=h/'console-logs'; dest.mkdir(exist_ok=True)
with ftplib.FTP() as f:
    f.connect('192.168.0.19',2121,timeout=20); f.login()
    rows=[]; f.retrlines('LIST /data/homebrew/PPSA50011/logs',rows.append)
    names=['/data/homebrew/PPSA50011/logs/'+row.split(None,8)[8] for row in rows if len(row.split(None,8))==9]
    gta=[n for n in names if 'GTA' in n.upper() and re.search(r'-2026\d{4}-\d{6}-UTC',n)]
    gta.sort(key=lambda n:re.search(r'-(2026\d{4}-\d{6})-UTC',n).group(1))
    for name in gta[-3:]:
        with (dest/Path(name).name).open('wb') as out: f.retrbinary('RETR '+name,out.write)
    sandbox=[]; f.retrlines('LIST /mnt/sandbox',sandbox.append)
    print('mounted',any('PPSA50011' in row for row in sandbox))
    print('latest_logs', [Path(n).name for n in gta[-3:]])
    print('settings_ports',[port for port in range(8360,8368) if check(port)]) if False else None
