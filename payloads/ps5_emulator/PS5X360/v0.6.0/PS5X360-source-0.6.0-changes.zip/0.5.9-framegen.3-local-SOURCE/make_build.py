from pathlib import Path
h=Path(__file__).resolve().parent
old=h.parent/'framegen-fsr3-20261010'
s=(old/'build.py').read_text()
s=s.replace("base = root / 'build/kinect-native-20261009/native'", "base = root / 'build/framegen-fsr3-20261010/native'")
s=s.replace("VERSION = '0.5.9-framegen.2-local'", "VERSION = '0.5.9-framegen.3-local'")
s=s.replace('0735a1cfdbb99cb7aa079a3fa427ce7623f40c58aeefe2aab90a269a347f2282','cc81cf3b35ed75de4d4c0a251a373218a96d58a691347a877a4fd6a807d78bad')
s=s.replace("for p in (base / 'obj').glob('*.o'):\n    shutil.copy2(p, out / 'obj' / p.name)","for p in (base / 'obj').glob('*.o'):\n    if p.name != 'fsr3_flow.cpp.o': shutil.copy2(p, out / 'obj' / p.name)")
s=s.replace("presenter_cmd = json.loads((counter / 'build.json').read_text())['command']", "presenter_cmd = base_record['commands']['presenter']")
s=s.replace("counter / 'vulkan_presenter.cc', here / 'presenter.proof.o'", "root / 'build/framegen-fsr3-20261010/presenter/vulkan_presenter.cc', here / 'presenter.proof.o'")
s=s.replace("flow_build = compile_with(presenter_cmd, here / 'fsr3_flow.cpp', out / 'obj/fsr3_flow.cpp.o', ['-I' + str(here)])", "flow_build = compile_with(presenter_cmd, here / 'vendor/ps5_framegen.cpp', out / 'obj/ps5_framegen.cpp.o', ['-I' + str(here / 'vendor'), '-DPS5_FRAMEGEN_VULKAN_HEADER=\"sword_dispatch.hpp\"', '-Wno-missing-field-initializers'])")
s=s.replace("cp_record = json.loads((root / 'build/performance-refine-20261008/scheduling-candidate/build.json').read_text())['commands'][1]", "cp_record = base_record['commands']['command_processor']")
s=s.replace("root / 'build/performance-refine-20261008/scheduling-candidate/src/xenia/gpu/vulkan/vulkan_command_processor.cc'", "root / 'build/framegen-fsr3-20261010/cp/xenia/gpu/vulkan/vulkan_command_processor.cc'")
pos=s.index("subprocess.run(['bash',")
gs='''# Source clock: compile its original with the archive's original recipe first.
import shlex
gs_target='core/src/xenia/gpu/CMakeFiles/xenia-gpu.dir/graphics_system.cc.o'
gs_cmd=shlex.split(subprocess.check_output(['ninja','-t','commands',gs_target],cwd=root/'build/canary-ps5',text=True).strip())
def compile_gs(source,obj):
    cmd=list(gs_cmd); cmd[1:1]=['-I'+str(here)]
    cmd[cmd.index('-c')+1]=str(source); cmd[cmd.index('-o')+1]=str(obj)
    subprocess.run(cmd,cwd=root/'build/canary-ps5',check=True)
    return cmd
compile_gs(here/'graphics_system.original.cc',here/'graphics_system.proof.o')
assert sha(here/'graphics_system.proof.o') == sha(root/'build/canary-ps5'/gs_target), 'graphics system inputs drifted'
gs_build=compile_gs(here/'graphics_system.cc',out/'obj/graphics_system.cc.o')
'''
s=s[:pos]+gs+s[pos:]
s=s.replace("if p.name not in changed}","if p.name not in changed and p.name != 'fsr3_flow.cpp.o'}")
s=s.replace("[*retained, *changed, 'fsr3_flow.cpp.o']", "[*retained, *changed, 'ps5_framegen.cpp.o', 'graphics_system.cc.o']")
s=s.replace("b'Framegen: FSR3 optical flow ready' in image and b'Framegen enabled (FSR3 optical flow)' in image", "b'Framegen: Sword FSR3 ready' in image and b'Framegen enabled (Sword FSR3 optical flow)' in image")
s=s.replace("b'not mapped at A0000000'", "b'not inspected (diagnostic only)'")
s=s.replace("'fsr3_flow.cpp.o', 'launcher.cpp.o'", "'ps5_framegen.cpp.o', 'graphics_system.cc.o', 'launcher.cpp.o'")
s=s.replace("'fsr3_flow': flow_build", "'sword_framegen': flow_build, 'source_clock': gs_build")
(h/'build.py').write_text(s)
print('build recipe prepared')
