# PS5X360 0.5.9-framegen.3-local

Local candidate based on the preserved Kinect/DLC build and Claude's framegen.2 sources. Uses Swordpdf/ps5-framegen commit `64362101757cdd6f7df9eeb984cb53f03f1fbfca` (GPL-3.0-or-later; AMD notices retained).

## Changes

- Replaces the previous custom midpoint pass with Sword's FSR3 optical-flow interpolator, including still-pixel HUD handling and scene-change detection.
- Publishes atomic guest vblank ticks on the graphics producer, before present waits. Uses the upstream steady-frame pacer to admit interpolation; repeats do not consume additional display slots while it is engaged.
- Uses an independent producer-cadence estimate for the pacer's slowdown safety gate. This is not a CPU emulation-speed measurement. Source-clock pacing is limited to the upstream supported clock range; gameplay testing is required to assess latency and cadence on the PS5.
- Stops interpolation compute work when the pacer does not engage. Maintains immutable private snapshots and retires their GPU users before resize/destruction.
- Draws the emulator UI on both real and generated pictures.
- Removes the optional readback diagnostic's guest-alias comparison entirely. The recorded GTA IV fault was a read of an unmapped alias at `0x10A6730000`; functional GPU readback remains enabled according to the user's settings.
- Enables supported `shaderStorageImageExtendedFormats` at device creation for the interpolator's storage images, without changing the frozen VulkanDevice class layout.
- Preserves all unrelated override objects, including the read-only file pool used by Bully, Kinect, DLC and multidisc features.

## Evidence and limitations

Native ELF image verification passed. Presenter, command processor, launcher, graphics-system and Vulkan-device original objects reproduced byte for byte before their edits. Upstream pacing: 911/911 checks. Synthetic Vulkan scenes, including HUD, moving objects, x2/x3/x4 and BGRA: passed on lavapipe. The same scenes also passed with the private dispatch used by the integration. Adapter tests: 60 to 60 stays off, 30 to 60, 60 to 120, irregular frames, load gaps, missing source stamps and delayed paint arrival.

The runtime exposes x2 only. The x3/x4 host checks validate upstream shader behavior, not selectable console modes. Present counters measure accepted pictures, not physical TV scanout. This does not make a game simulate at 60 FPS; it adds an intermediate picture when capacity and steady pacing permit it. Optical flow cannot guarantee artifact-free particles, disocclusions or moving HUDs.

Console installation is recorded in `deployment.json`; console gameplay remains pending until the user tests GTA IV reaching the same map with frame generation on. Do not describe host image tests as a console benchmark.

## Build

The isolated build needs the existing repository's SDK, driver archives and frozen baseline objects. In `xbox360ps5-radv-buildenv`, with `C:/Users/bruno/Documents/PS5,` mounted at `/ws`:

```sh
python3 /ws/Xbox360PS5/build/framegen-sword-20261010/build.py
```

`prepare.py`, `adapt.py` and `make_build.py` document the initial adaptation. They are setup scripts, not part of a repeat build: rerunning them overwrites later reviewed edits. `build.py` is the authoritative build recipe. `native/build.json` pins source/object hashes; `PROVENANCE.json` identifies the upstream source; `COPYING` contains GPL terms. Upstream shader sources are in `upstream-shaders` and the embedded SPIR-V and notices in `vendor/framegen/fg_shaders.inc`.

## Console test

1. Open PS5X360; verify the menu says `0.5.9-framegen.3`.
2. Keep detailed logging off. Enable frame generation in settings and restart if requested.
3. Load GTA IV's same save and enter the street. Compare game FPS versus accepted output/FG counters; FG may wait while cadence is irregular.
4. Check stationary HUD text, camera movement, loading transitions and the guide menu.
5. Logs are under `/data/homebrew/PPSA50011/logs`; look for `Sword FSR3 ready`, `Framegen first admission` and bounded `Framegen GPU cost` lines.

The deploy tool validates the installed framegen.1 image, saves a local and console rollback copy, checks that the title is not active, uploads to a temporary name and verifies mapped ELF bytes before swapping it. Settings, games and saves are not replaced.
