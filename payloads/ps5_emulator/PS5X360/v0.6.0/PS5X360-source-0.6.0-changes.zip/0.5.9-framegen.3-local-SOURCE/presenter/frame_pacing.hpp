// SPDX-License-Identifier: BSD-3-Clause
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace ps5x360::framegen {
// When to show a generated picture. Emulated games deliver frames unevenly, so this follows the
// average time between new frames instead of asking for strict regularity: a generated picture
// is shown when a game frame lasts about two display refreshes or more (a 30 FPS game on a 60 Hz
// output), so the generated picture and the real one both get a refresh.
// Times are monotonic nanoseconds; serial identifies NEW guest refreshes.
class Pacing {
 public:
  bool Observe(uint64_t time, uint64_t serial, uint32_t width, uint32_t height, double actual_display_hz,
               bool caller_permits, bool enabled = false) {
    // caller_permits is only an external veto, NOT a speed measurement.
    if (!enabled || !caller_permits || !width || !height || !std::isfinite(actual_display_hz) ||
        actual_display_hz < 30 || actual_display_hz > 240) {
      Reset();
      return false;
    }
    if (serial == serial_ && width == width_ && height == height_) return false;
    const bool restart = !last_time_ || time <= last_time_ || serial <= serial_ || width != width_ ||
                         height != height_ || actual_display_hz != display_hz_;
    const double interval = restart ? 0 : double(time - last_time_);
    last_time_ = time;
    serial_ = serial;
    width_ = width;
    height_ = height;
    display_hz_ = actual_display_hz;
    // A pause (loading, a menu that stops drawing) starts over.
    if (restart || interval > 250e6) {
      average_ = 0;
      seen_ = 0;
      return false;
    }
    average_ = average_ ? average_ * 0.8 + interval * 0.2 : interval;
    if (seen_ < 3) ++seen_;
    const double refresh = 1e9 / actual_display_hz;
    // A single short frame (they follow long ones) does not switch generation off.
    return seen_ >= 3 && average_ >= 1.75 * refresh && interval >= 1.2 * refresh;
  }
  // How long the generated picture stays before the real one: half a game frame in whole
  // refreshes, at least one (one at 30 FPS on 60 Hz, two at 30 FPS on 120 Hz).
  double HoldNanoseconds() const {
    if (!display_hz_ || !average_) return 0;
    const double refresh = 1e9 / display_hz_;
    return refresh * std::max(1.0, std::round(average_ * 0.5 / refresh));
  }
  void Reset() {
    last_time_ = serial_ = 0;
    width_ = height_ = seen_ = 0;
    average_ = display_hz_ = 0;
  }

 private:
  uint64_t last_time_ = 0, serial_ = 0;
  uint32_t width_ = 0, height_ = 0, seen_ = 0;
  double average_ = 0, display_hz_ = 0;
};
}  // namespace ps5x360::framegen
