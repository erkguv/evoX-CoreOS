# Verification

- Upstream pacing: **911/911 checks passed**.
- Integration adapter: 60→60 stays off; 30→60; 60→120; irregular source frames; source gap; missing source stamp; delayed paint arrivals; paused-source guide repaint: passed.
- Original upstream Vulkan scenes: pan, HUD, moving head, combined objects, x3 and x4, BGRA equivalence: passed on lavapipe.
- The private-dispatch module actually linked into the candidate: same scene checks passed.
- Candidate's `A2B10G10R10_UNORM_PACK32` snapshot format: same motion/HUD scenes passed with packed 10-bit input. Combined scene mean absolute error 0.23/255, HUD 0.73/255; pan 0.00/255. The BGRA-labelled final case in this packed-input run still uses RGB10 because the RGB10 switch overrides the format; the separate ordinary dispatch run tests true BGRA.
- Original presenter, command processor, launcher, graphics-system and Vulkan-device objects reproduced byte for byte before edits. All unrelated baseline override objects remain unchanged.
- Native image check passed: 11 sections, 5 disjoint/congruent mapped segments; relocation targets mapped. Version edits restricted to read-only literals.
- Installed native SHA256: `ba3cec85171cef8c8376dfacea445abf42d6a515b9dd3637d5816befbd66fff8`.
- PS5 FTP verification compared mapped ELF/dynamic segments. The server strips two unmapped metadata sections, so its whole-file checksum is not used as a substitute for segment verification.
- Local update ZIP CRC and packaged executable SHA passed. Installation receipt: `deployment.json`.
- **Console gameplay pending**: user must open GTA IV and enter the map with framegen enabled. Host tests do not establish PS5 performance or artifact-free gameplay.
