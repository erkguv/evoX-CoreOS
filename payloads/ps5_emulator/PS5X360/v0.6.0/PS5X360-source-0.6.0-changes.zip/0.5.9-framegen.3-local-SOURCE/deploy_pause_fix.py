from pathlib import Path
import shutil
h=Path(__file__).resolve().parent
backup=h/'installed-before-pause-fix';backup.mkdir(exist_ok=True)
shutil.copy2(h/'installed-1431.bin',backup/'eboot.bin')
shutil.copy2(h/'installed-1431.elf',backup/'eboot.elf')
s=(h/'deploy.py').read_text()
s=s.replace("base = root / 'build/framegen-fsr3-20261010/native-framegen1'", "base = here / 'installed-before-pause-fix'")
exec(compile(s,str(h/'deploy.py'),'exec'),{'__file__':str(h/'deploy.py'),'__name__':'__main__'})
