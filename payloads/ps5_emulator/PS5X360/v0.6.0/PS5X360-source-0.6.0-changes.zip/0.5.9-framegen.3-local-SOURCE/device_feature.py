from pathlib import Path
import subprocess,shlex,hashlib,json
root=Path('/ws/Xbox360PS5'); here=Path(__file__).resolve().parent
build=root/'build/canary-ps5'
target='core/src/xenia/ui/vulkan/CMakeFiles/xenia-ui-vulkan.dir/vulkan_device.cc.o'
original=root/'.deps/xenia-canary/src/xenia/ui/vulkan/vulkan_device.cc'
lines=subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True).splitlines()
command=shlex.split(next(line for line in reversed(lines) if ' -c ' in line and 'vulkan_device.cc' in line))
def compile(source,dest):
    cmd=list(command); cmd[cmd.index('-c')+1]=str(source); cmd[cmd.index('-o')+1]=str(dest)
    subprocess.run(cmd,cwd=build,check=True); return cmd
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
compile(original,here/'vulkan_device.proof.o')
assert sha(here/'vulkan_device.proof.o')==sha(build/target),'device preimage drifted'
s=original.read_text(); needle='  device_create_info.pEnabledFeatures = &enabled_features;'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n  // Sword FSR3 uses R8_UINT / R16G16_SINT storage images.\n  enabled_features.shaderStorageImageExtendedFormats = supported_features.shaderStorageImageExtendedFormats;')
edited=here/'vulkan_device.cc'; edited.write_text(s)
cmd=compile(edited,here/'native/obj/vulkan_device.cc.o')
(here/'device-feature.json').write_text(json.dumps({'preimage_identical':True,'original_object_sha256':sha(build/target),'object_sha256':sha(here/'native/obj/vulkan_device.cc.o'),'command':cmd},indent=2))
