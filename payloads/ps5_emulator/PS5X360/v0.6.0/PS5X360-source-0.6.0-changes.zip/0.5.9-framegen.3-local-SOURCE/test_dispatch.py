from pathlib import Path
import subprocess,os
h=Path(__file__).resolve().parent; root=h.parents[1]; upstream=root/'build/ps5-framegen-upstream-20261010'
s=(upstream/'tools/fg-test.cpp').read_text()
s='#include "sword_loader.hpp"\n'+s
needle='\tif (!fg.create(g.physical, g.device,'
assert s.count(needle)==1
s=s.replace(needle,'\tif (!ps5x360::sword_dispatch::Bind(g.instance,g.device,vkGetInstanceProcAddr)) return 2;\n'+needle)
s=s.replace('const bool bgra = bgra_env', 'const bool rgb10 = std::getenv("FG_TEST_RGB10") != nullptr;\n\tconst bool bgra = bgra_env')
s=s.replace('error, bgra ? VK_FORMAT_B8G8R8A8_UNORM', 'error, rgb10 ? VK_FORMAT_A2B10G10R10_UNORM_PACK32 : bgra ? VK_FORMAT_B8G8R8A8_UNORM')
s=s.replace('\t\tif (bgra)\n\t\t{', '''\t\tif (rgb10) {
      auto* packed = static_cast<uint32_t*>(map);
      for (size_t pixel=0;pixel<bytes/4;++pixel) {
        const auto* p=cur.rgba.data()+pixel*4;
        packed[pixel]=uint32_t((p[0]*1023+127)/255) |
                      (uint32_t((p[1]*1023+127)/255)<<10) |
                      (uint32_t((p[2]*1023+127)/255)<<20) | 0xc0000000u;
      }
    } else if (bgra)
    {''')
(h/'test_dispatch.cpp').write_text(s)
ws='/ws/Xbox360PS5/build/framegen-sword-20261010'
cmd=['docker','run','--rm','-v',str(root.parent)+':/ws','xbox360ps5-canary','clang++-18','-std=c++17','-O2','-Wno-missing-field-initializers','-I'+ws+'/vendor','-I/ws/Xbox360PS5/build/ps5-framegen-upstream-20261010/tools/stb','-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"',ws+'/test_dispatch.cpp',ws+'/vendor/ps5_framegen.cpp','-lvulkan','-ldl','-o',ws+'/fg-test-dispatch']
# Test translation unit needs global Vulkan entry points. Compile it separately.
module=cmd.copy(); module=module[:module.index(ws+'/test_dispatch.cpp')]+[ws+'/vendor/ps5_framegen.cpp','-c','-o',ws+'/dispatch-host.o']
subprocess.run(module,check=True)
test=cmd.copy(); test.remove('-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"');test[test.index(ws+'/vendor/ps5_framegen.cpp')]=ws+'/dispatch-host.o'
subprocess.run(test,check=True)
result=subprocess.run(['docker','run','--rm','-v',str(root.parent)+':/ws','xbox360ps5-canary','python3','/ws/Xbox360PS5/build/ps5-framegen-upstream-20261010/tools/check-scenes.py',ws+'/fg-test-dispatch',ws+'/scenes-dispatch'],capture_output=True,text=True)
(h/'tests-dispatch.txt').write_text(result.stdout+result.stderr)
print(result.stdout+result.stderr); raise SystemExit(result.returncode)
