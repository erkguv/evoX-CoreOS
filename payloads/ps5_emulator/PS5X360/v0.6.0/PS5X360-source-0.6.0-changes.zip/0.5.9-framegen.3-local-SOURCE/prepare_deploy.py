from pathlib import Path
h=Path(__file__).resolve().parent
root=h.parents[1]
s=(root/'build/framegen-fsr3-20261010/deploy.py').read_text()
s=s.replace("base = here / 'native-framegen1'", "base = root / 'build/framegen-fsr3-20261010/native-framegen1'")
start=s.index('    now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)')
end=s.index('    f.cwd(',start)
reference=(root/'build/bully-loading-20261009/file-limit-trace/deploy-ready.py').read_text()
a=reference.index('        clock_name = '); b=reference.index('        f.cwd(',a)
safe='\n'.join(line[4:] if line.startswith('    ') else line for line in reference[a:b].splitlines())+'\n'
s=s[:start]+safe+s[end:]
(h/'deploy.py').write_text(s)
print('safe deployment prepared')
