from pathlib import Path
import json
h = Path(__file__).resolve().parent
names = json.loads((h/'dispatch_names.json').read_text())
(h/'vendor/sword_loader.hpp').write_text('#pragma once\n#include <vulkan/vulkan_core.h>\nnamespace ps5x360::sword_dispatch { bool Bind(VkInstance, VkDevice, PFN_vkGetInstanceProcAddr); }\n')
loader = '\nnamespace ps5x360::sword_dispatch {\nbool Bind(VkInstance instance, VkDevice device, PFN_vkGetInstanceProcAddr get) {\n'
loader += 'auto gd = reinterpret_cast<PFN_vkGetDeviceProcAddr>(get(instance,"vkGetDeviceProcAddr")); if (!gd) return false;\n'
for n in names:
    src = 'get(instance,' if n.startswith('vkGetPhysical') or n=='vkGetDeviceProcAddr' else 'gd(device,'
    loader += f'{n} = reinterpret_cast<PFN_{n}>({src}"{n}")); if (!{n}) return false;\n'
loader += 'return true;\n}\n}\n'
(h/'vendor/ps5_framegen.cpp').write_text((h/'vendor/ps5_framegen.cpp').read_text()+loader)
p = h/'presenter/presenter_sidecar.hpp'
s=p.read_text().replace('SPDX-License-Identifier: BSD-3-Clause','SPDX-License-Identifier: GPL-3.0-or-later')
s=s.replace('#include "frame_pacing.hpp"\n#include "fsr3_flow.hpp"','#include "pacing_adapter.hpp"\n#include "vendor/ps5_framegen.h"\n#include "vendor/sword_loader.hpp"')
s=s.replace('  ps5x360::fsr3::OpticalFlow flow;  // FSR3 optical flow between the two snapshots\n  ps5x360::fsr3::Midpoint midpoint_pass;', '  ps5::framegen::interpolator interpolation;')
s=s.replace('    midpoint_pass.Destroy();\n    flow.Destroy();','    interpolation.destroy();')
start=s.index('    for (auto& i : images) {')
end=s.index('    initialized = history', start)
s=s[:start]+'    for (auto& i : images) i = {}; // Owned by the interpolator.\n'+s[end:]
start=s.index('    for (uint32_t index = 0; index < 3; ++index)')
end=s.index('    VkDescriptorPoolSize counts[]', start)
s=s[:start]+'''    const auto& ifn = dev->vulkan_instance()->functions();
    auto instance = dev->vulkan_instance()->instance();
    auto loader = reinterpret_cast<PFN_vkGetDeviceProcAddr>(ifn.vkGetInstanceProcAddr(instance,"vkGetDeviceProcAddr"));
    if (!loader || !ps5x360::sword_dispatch::Bind(instance,d,ifn.vkGetInstanceProcAddr)) return fail();
    copy_image = reinterpret_cast<PFN_vkCmdCopyImage>(loader(d,"vkCmdCopyImage"));
    if (!copy_image) return fail();
    std::string error;
    if (!interpolation.create(dev->physical_device(),d,size.width,size.height,error,source_format)) {
      XELOGE("Framegen: Sword interpolator setup failed: {}",error);
      return fail();
    }
    images[0].image=interpolation.frame_image(); images[0].view=interpolation.frame_view();
    interpolation.advance();
    images[1].image=interpolation.frame_image(); images[1].view=interpolation.frame_view();
    interpolation.advance();
    images[2].image=interpolation.output_image(); images[2].view=interpolation.output_view();
    XELOGW("Framegen: Sword FSR3 ready for {}x{} (6436210, x2)",size.width,size.height);
''' + s[end:]
# Upstream initializes ALL its resources and owns the private history parity.
start=s.index('    if (!history) {',s.index('  bool Record('))
end=s.index('    VkImageMemoryBarrier b{};',start)
s=s[:start]+'''    interpolation.prepare(command);
    uint32_t next = interpolation.frame_image() == images[0].image ? 0u : 1u;
''' + s[end:]
start=s.index('    // The flow runs for every new frame')
end=s.index('    return generated;',start)
s=s[:start]+'''    // Maintain luma/scene history, but don't interpolate unless pacing permits.
    const bool made = interpolation.record(command, !history || !generate);
    const bool generated = generate && history && made;
    current = next; history = true;
    interpolation.advance();
    if ((new_frames % 120) == 0) {
      double mean=0,max=0,flow_mean=0; uint32_t count=0;
      if (interpolation.take_gpu_time(mean,max,count,flow_mean))
        XELOGW("Framegen GPU cost: mean={}ms max={}ms flow={}ms samples={}",mean,max,flow_mean,count);
    }
''' + s[end:]
s=s.replace('Framegen enabled (FSR3 optical flow)', 'Framegen enabled (Sword FSR3 optical flow)')
# Upstream output is RGBA8, not the old half-float midpoint.
s=s.replace('VK_FORMAT_R16G16B16A16_SFLOAT','ps5::framegen::interpolator::k_format')
p.write_text(s)
p=h/'presenter/vulkan_presenter.cc'
s=p.read_text()
s=s.replace('  ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, midpoint);','  ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, midpoint);\n  if (fg) fg->pacing.Presented(succeeded(result) && guest_picture_drawn);')
# Both occurrences must track the real and generated presents.
p.write_text(s)
print('adapted')
