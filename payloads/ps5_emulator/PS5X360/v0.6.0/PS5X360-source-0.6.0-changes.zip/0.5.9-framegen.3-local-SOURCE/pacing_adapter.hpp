// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <algorithm>
#include <cmath>
#include "source_clock.hpp"
#include "vendor/ps5_framegen_pacing.h"
namespace ps5x360::framegen {
class Pacing {
  ps5::framegen::pacer pacer_;
  Stamp previous_{};
  double baseline_ns_ = 0, display_ = 0;
  uint32_t width_ = 0, height_ = 0, already_ = 0, presents_ = 0;
  bool engaged_ = false;
 public:
  bool Observe(uint64_t, uint64_t serial, uint32_t w, uint32_t h, double display,
               bool permit, bool enabled, const void* owner) {
    Stamp s;
    if (!permit || !enabled || !w || !h || !std::isfinite(display) || display < 30 ||
        !Lookup(owner, serial, s)) { Reset(); return false; }
    if (w != width_ || h != height_ || display != display_ || s.hz != previous_.hz) {
      Reset(); width_=w; height_=h; display_=display;
    }
    if (!previous_.ns || s.ns <= previous_.ns || s.ticks <= previous_.ticks) {
      previous_=s; engaged_=false; return false;
    }
    const uint64_t ticks = s.ticks - previous_.ticks;
    const double dt = double(s.ns - previous_.ns);
    previous_=s;
    if (ticks > ps5::framegen::pacer::kGapTicks) baseline_ns_=0;
    // Independent producer cadence estimate, not a claim of measured CPU speed.
    // Freeze the reference during generation so present waits cannot redefine it.
    if (!baseline_ns_) baseline_ns_=dt;
    const double speed = std::min(100.0, baseline_ns_ / dt * 100.0);
    const auto d = pacer_.frame(uint32_t(std::min<uint64_t>(ticks,UINT32_MAX)), already_,
                              s.hz,display,double(s.ns)*1e-9,speed,true);
    already_=0; engaged_=d.engaged; presents_=d.presents;
    if (!engaged_ && ticks <= ps5::framegen::pacer::kGapTicks)
      baseline_ns_=baseline_ns_*0.9 + dt*0.1;
    return engaged_ && presents_ != 0;
  }
  void Presented(bool success) { if(success) ++already_; }
  bool Engaged() {
    const uint64_t tick = source_ticks.load(std::memory_order_relaxed);
    // A paused game must not suppress guide/UI paints indefinitely.
    if (engaged_ && tick >= previous_.ticks &&
        tick - previous_.ticks > ps5::framegen::pacer::kGapTicks) Reset();
    return engaged_;
  }
  double HoldNanoseconds() const { return display_ > 0 ? 1e9 * presents_ / display_ : 0; }
  void Reset() { pacer_={}; previous_={}; baseline_ns_=display_=0; width_=height_=already_=presents_=0; engaged_=false; }
};
}
