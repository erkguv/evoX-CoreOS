from pathlib import Path
import re, shutil, json
here = Path(__file__).resolve().parent
root = here.parents[1]
old = root / 'build/framegen-fsr3-20261010'
upstream = root / 'build/ps5-framegen-upstream-20261010'
vendor = here / 'vendor'
shutil.copytree(upstream / 'src', vendor, dirs_exist_ok=True)
for name in ('LICENSE', 'COPYING'):
    if (upstream / name).exists(): shutil.copy2(upstream / name, here / name)
shutil.copytree(upstream / 'shaders', here / 'upstream-shaders', dirs_exist_ok=True)
header = vendor / 'ps5_framegen.h'
s = header.read_text().replace('VkImage output_image() const { return m_output.image; }',
 'VkImage output_image() const { return m_output.image; }\n\t\tVkImageView output_view() const { return m_output.view; }')
header.write_text(s)
# Private dispatch names avoid global loader symbols and keep Xenia's dispatch untouched.
s = (vendor / 'ps5_framegen.cpp').read_text()
names = sorted(set(re.findall(r'\b(vk[A-Z]\w*)\s*\(', s)))
decl = '#pragma once\n#include <vulkan/vulkan_core.h>\nnamespace ps5x360::sword_dispatch {\n'
decl += ''.join('inline PFN_'+n+' '+n+' = nullptr;\n' for n in names)
decl += '}\n' + ''.join('#define '+n+' ps5x360::sword_dispatch::'+n+'\n' for n in names)
(vendor / 'sword_dispatch.hpp').write_text(decl)
(here / 'dispatch_names.json').write_text(json.dumps(names))
shutil.copytree(old / 'shared', here / 'shared', dirs_exist_ok=True)
shutil.copytree(old / 'cp', here / 'cp', dirs_exist_ok=True)
cp = here / 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc'
s = cp.read_text()
start = s.index('          // What the game will read:')
end = s.index('          XELOGW(', start)
s = s[:start] + '          // Diagnostics must never dereference an optional guest alias.\n          const char* guest_view = "not inspected (diagnostic only)";\n' + s[end:]
cp.write_text(s)
shutil.copytree(old / 'presenter', here / 'presenter', dirs_exist_ok=True)
# Use independent atomic guest vblank ticks, published before any present waits.
gs = root / '.deps/xenia-canary/src/xenia/gpu/graphics_system.cc'
s = gs.read_text()
(here / 'graphics_system.original.cc').write_text(s)
s = '#include "source_clock.hpp"\n' + s
s = s.replace('void GraphicsSystem::MarkVblank() {', 'void GraphicsSystem::MarkVblank() {\n  ps5x360::framegen::Tick(double(cvars::framerate_limit ? cvars::framerate_limit : 60));')
(here / 'graphics_system.cc').write_text(s)
presenter = here / 'presenter/vulkan_presenter.cc'
s = presenter.read_text()
needle = '  return refresher_succeeded;\n}'
assert s.count(needle) == 1
s = s.replace(needle, '  if (refresher_succeeded && submit_result == VK_SUCCESS)\n    ps5x360::framegen::Publish(this, image_instance.last_refresher_submission);\n'+needle)
s = s.replace('fg->pacing.Observe(now, serial,', 'fg->pacing.Observe(now, serial,')
s = s.replace('            true, true);', '            true, true, this);')
s = s.replace('        // Arrival cadence only; no claim that emulator speed is measured here.', '        // Guest vblank intervals were captured on the producer, before paint waits.')
s = s.replace('emulator speed UNMEASURED;', 'producer cadence safety gate;')
# Don't spend additional display slots repeating a picture while generating.
needle = '  bool midpoint = false;'
s = s.replace(needle, '  if (fg && pinned && !new_frame && fg->pacing.Engaged()) {\n    if (fg_consumer_lock.owns_lock()) fg_consumer_lock.unlock();\n    return PaintResult::kNotPresented;\n  }\n'+needle)
presenter.write_text(s)
(here / 'PROVENANCE.json').write_text(json.dumps({'upstream':'https://github.com/Swordpdf/ps5-framegen', 'commit':'64362101757cdd6f7df9eeb984cb53f03f1fbfca', 'license':'GPL-3.0-or-later; AMD shader notices retained', 'local_change':'read-only output_view accessor, private Vulkan dispatch'}, indent=2))
print('prepared', here)
