// SPDX-License-Identifier: BSD-3-Clause
#pragma once
#include <atomic>
#include <cstdint>
namespace ps5x360::output_metrics {
inline std::atomic<uint64_t> accepted{0}, generated{0};
inline std::atomic<bool> enabled{false};
inline std::atomic<int> fallback{0};
inline void Present(bool success, bool guest, bool midpoint) {
  if (!success || !guest) return;
  accepted.fetch_add(1, std::memory_order_relaxed);
  if (midpoint) generated.fetch_add(1, std::memory_order_relaxed);
}
}
