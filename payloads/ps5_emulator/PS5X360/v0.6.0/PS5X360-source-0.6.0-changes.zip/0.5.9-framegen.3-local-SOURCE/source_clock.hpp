// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <atomic>
#include <array>
#include <chrono>
#include <mutex>
namespace ps5x360::framegen {
inline std::atomic<uint64_t> source_ticks{0};
inline std::atomic<double> source_hz{60};
inline void Tick(double hz) { source_hz.store(hz, std::memory_order_relaxed); source_ticks.fetch_add(1, std::memory_order_relaxed); }
struct Stamp { const void* owner{}; uint64_t serial{}, ticks{}, ns{}; double hz{}; };
inline std::mutex stamps_mutex;
inline std::array<Stamp, 64> stamps{};
inline size_t next_stamp = 0;
inline void Publish(const void* owner, uint64_t serial) {
  const auto now = uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());
  const Stamp value{owner,serial,source_ticks.load(std::memory_order_relaxed),now,source_hz.load(std::memory_order_relaxed)};
  std::lock_guard<std::mutex> lock(stamps_mutex);
  stamps[next_stamp++ % stamps.size()] = value;
}
inline bool Lookup(const void* owner, uint64_t serial, Stamp& value) {
  std::lock_guard<std::mutex> lock(stamps_mutex);
  for (size_t i=0; i<stamps.size(); ++i) {
    const auto& s = stamps[(next_stamp + stamps.size() - 1 - i) % stamps.size()];
    if (s.owner == owner && s.serial == serial) { value = s; return true; }
  }
  return false;
}
}
