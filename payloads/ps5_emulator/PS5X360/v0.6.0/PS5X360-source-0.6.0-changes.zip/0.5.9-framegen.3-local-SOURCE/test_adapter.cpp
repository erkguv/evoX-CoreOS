// SPDX-License-Identifier: GPL-3.0-or-later
#include "pacing_adapter.hpp"
#include <cassert>
#include <iostream>
using namespace ps5x360::framegen;
static const void* owner = reinterpret_cast<void*>(0x1234);
static void stamp(uint64_t serial,uint64_t ticks,uint64_t ns) {
  std::lock_guard<std::mutex> lock(stamps_mutex);
  stamps[next_stamp++%stamps.size()]={owner,serial,ticks,ns,60};
}
static bool step(Pacing& p,uint64_t serial,uint64_t ticks,uint64_t ns,double hz) {
  stamp(serial,ticks,ns);
  bool generate=p.Observe(ns+1000000000,serial,1280,720,hz,true,true,owner);
  p.Presented(true); return generate;
}
int main() {
  Pacing sixty;
  for(uint64_t i=1;i<40;++i) assert(!step(sixty,i,i,i*16666667,60));
  Pacing thirty; bool generated=false;
  for(uint64_t i=1;i<40;++i) generated=step(thirty,100+i,i*2,i*33333334,60)||generated;
  assert(generated); assert(thirty.Engaged());
  assert(thirty.HoldNanoseconds()>16000000 && thirty.HoldNanoseconds()<17000000);
  source_ticks.store(1000); assert(!thirty.Engaged()); source_ticks.store(0);
  // Paint timestamps are intentionally one second late: admission uses producer ticks.
  assert(!step(thirty,200,200,4000000000,60)); assert(!thirty.Engaged());
  Pacing high; generated=false;
  for(uint64_t i=1;i<40;++i) generated=step(high,300+i,i,i*16666667,120)||generated;
  assert(generated);
  Pacing variable;
  uint64_t tick=0;
  for(uint64_t i=1;i<80;++i) {tick+=(i%2)+1; assert(!step(variable,400+i,tick,tick*16666667,60));}
  assert(!variable.Observe(1,9999,1280,720,60,true,true,owner));
  std::cout << "PASS: adapter 60->60, 30->60, 60->120, unsteady, load gap, missing stamp, delayed paints\n";
}
