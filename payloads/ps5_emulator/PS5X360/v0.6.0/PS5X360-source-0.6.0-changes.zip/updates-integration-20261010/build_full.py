"""Builds 0.5.9-updates.4-local on the framegen.4 objects: everything of updates.3-safe plus the
frame generation modes of build/framegen-modes-20261010.
  - launcher: Updates tab, update installed on Play, log line (build/title-updates-20261010),
    then the frame generation mode and output rate rows (apply_modes.py of the modes folder,
    run here on the launcher source that has the log line);
  - presenter: modes, output rate request, loop over generated pictures (modes folder);
  - command processor: a draw waits for its real pipeline only in the full readback mode
    (build/stutter-wait-20261010).
Every other object is checked by hash against build/framegen-stutter-20261010/native.
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/updates-integration-20261010/build_full.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct  # used by the validation step taken from the framegen.3 recipe
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
stutter = root / 'build/framegen-stutter-20261010'
base = stutter / 'native'
updates = root / 'build/title-updates-20261010'
modes = root / 'build/framegen-modes-20261010'
kinect = root / 'build/kinect-native-20261009'
out = here / 'native-full'
record = json.loads((base / 'build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base / 'eboot.bin') == record['native_sha256'] == '09224f0f1f06224d6acf21f9bc6d39f95c8bb8fe5d35d785fd065f96e11f2914'
VERSION = '0.5.9-updates.4-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')
proofs = here / 'proofs'
proofs.mkdir(exist_ok=True)

# The modes folder's sources are the ones its own build and tests used.
tested = json.loads((modes / 'native/build.json').read_text())['source_sha256']
for name in ('presenter/vulkan_presenter.cc', 'presenter/presenter_sidecar.hpp', 'pacing_adapter.hpp',
             'framegen_config.hpp', 'apply_modes.py'):
    assert sha(modes / name) == tested[name], name + ' changed after the modes build'

# The launcher: the modes script, unchanged, on the source that also has the update log line.
script = (modes / 'apply_modes.py').read_text(encoding='utf-8')
reads = "source = here.parent / 'title-updates-20261010/launcher.cpp'\n"
writes = "(here / 'launcher.cpp').write_text(text, encoding='utf-8', newline='\\n')\n"
assert script.count(reads) == 1 and script.count(writes) == 1
script = script.replace(reads, 'source = LAUNCHER_SOURCE\n').replace(
    writes, "LAUNCHER_TARGET.write_text(text, encoding='utf-8', newline='\\n')\n")
launcher_source = here / 'launcher-full.cpp'
exec(compile(script, str(modes / 'apply_modes.py'), 'exec'),
     {'__file__': str(modes / 'apply_modes.py'), '__name__': 'apply_modes',
      'LAUNCHER_SOURCE': here / 'launcher-updates.cpp', 'LAUNCHER_TARGET': launcher_source})
text = launcher_source.read_text(encoding='utf-8')
assert 'LAUNCHER title update for' in text and 'framegen_config.hpp' in text

(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    c = list(command)
    c[1:1] = extra
    c[c.index('-c') + 1] = str(source)
    c[c.index('-o') + 1] = str(obj)
    subprocess.run(c, cwd=root, check=True)
    return c


# The unchanged sources still give the installed framegen.4 objects, byte for byte.
cp_source = 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc'
for key, source, name in (('presenter', stutter / 'presenter/vulkan_presenter.cc', 'vulkan_presenter.cc.o'),
                          ('launcher', kinect / 'launcher.cpp', 'launcher.cpp.o'),
                          ('command_processor', root / 'build/framegen-sword-20261010' / cp_source, 'vulkan_command_processor.cc.o')):
    compile_with(record['commands'][key], source, proofs / (key + '.o'))
    assert sha(proofs / (key + '.o')) == sha(base / 'obj' / name), key + ' preimage drift'

presenter_build = compile_with(record['commands']['presenter'], modes / 'presenter/vulkan_presenter.cc',
                               out / 'obj/vulkan_presenter.cc.o', ['-I' + str(modes)])
launcher_cmd = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a
                for a in record['commands']['launcher']]
launcher_build = compile_with(launcher_cmd, launcher_source, out / 'obj/launcher.cpp.o',
                              ['-I' + str(modes), '-I' + str(updates), '-I' + str(kinect)])
cp_build = compile_with(record['commands']['command_processor'], root / 'build/stutter-wait-20261010' / cp_source,
                        out / 'obj/vulkan_command_processor.cc.o')
changed = {'vulkan_presenter.cc.o', 'launcher.cpp.o', 'vulkan_command_processor.cc.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / name) == value for name, value in retained.items())
assert all(sha(out / 'obj' / name) != sha(base / 'obj' / name) for name in changed)
# Same sources, same commands: the presenter object is the one the modes folder built and tested with.
assert sha(out / 'obj/vulkan_presenter.cc.o') == sha(modes / 'native/obj/vulkan_presenter.cc.o'), 'presenter differs from the modes build'
assert sha(out / 'obj/vulkan_command_processor.cc.o') == sha(here / 'native-safe/obj/vulkan_command_processor.cc.o')
assert {p.name for p in (out / 'obj').glob('*.o')} == set(record['objects'])
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)

# Display version, image verification and signing: the reviewed step of the framegen.3 recipe.
s = (root / 'build/framegen-sword-20261010/build.py').read_text()
validation = s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation, 'framegen-sword build.py', 'exec'), globals())
image = (out / 'llvm-pie.elf').read_bytes()
for needle in (b'PPSA50011/updates', b'000B0000-off', b'LAUNCHER title update for', b'Framegen: Sword FSR3 ready',
               b'shader-trace.conf', b'Framegen mode: ', b'Framegen output: asked for', b'ps5_frame_multiplier=',
               b'ps5_frame_output_hz=', b'ps5_frame_interpolation=true'):
    assert needle in image, needle
commands = dict(record['commands'])
commands.update(presenter=presenter_build, launcher=launcher_build, command_processor=cp_build)
(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'presenter_preimage_identical': True, 'launcher_preimage_identical': True, 'command_processor_preimage_identical': True,
    'presenter_object_equals_modes_build': True, 'unchanged_objects': retained,
    'objects': {p.name: sha(p) for p in (out / 'obj').glob('*.o')}, 'commands': commands, 'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
