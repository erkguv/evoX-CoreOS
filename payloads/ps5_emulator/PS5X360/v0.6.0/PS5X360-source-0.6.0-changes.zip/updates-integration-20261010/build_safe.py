"""Builds 0.5.9-updates.3-safe-local on the installed framegen.4 executable:
  - launcher: Updates tab, update installed on Play, log line (build/title-updates-20261010);
  - command processor: a draw waits for its real pipeline only in the full readback mode
    (build/stutter-wait-20261010).
The presenter and frame generation are those of framegen.4, untouched. Every other object is
checked by hash against build/framegen-stutter-20261010/native.
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/updates-integration-20261010/build_safe.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct  # used by the validation step taken from the framegen.3 recipe
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/framegen-stutter-20261010/native'
updates = root / 'build/title-updates-20261010'
out = here / 'native-safe'
record = json.loads((base / 'build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base / 'eboot.bin') == record['native_sha256'] == '09224f0f1f06224d6acf21f9bc6d39f95c8bb8fe5d35d785fd065f96e11f2914'
VERSION = '0.5.9-updates.3-safe-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')
proofs = here / 'proofs'
proofs.mkdir(exist_ok=True)
(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    c = list(command)
    c[1:1] = extra
    c[c.index('-c') + 1] = str(source)
    c[c.index('-o') + 1] = str(obj)
    subprocess.run(c, cwd=root, check=True)
    return c


def versioned(command, label):
    return [f'-DXBOX360PS5_VERSION="{label}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in command]


# The unchanged sources still give the installed objects, byte for byte.
kinect = root / 'build/kinect-native-20261009'
compile_with(record['commands']['launcher'], kinect / 'launcher.cpp', proofs / 'launcher.o')
assert sha(proofs / 'launcher.o') == sha(base / 'obj/launcher.cpp.o'), 'launcher preimage drift'
cp_source = 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc'
compile_with(record['commands']['command_processor'], root / 'build/framegen-sword-20261010' / cp_source, proofs / 'command_processor.o')
assert sha(proofs / 'command_processor.o') == sha(base / 'obj/vulkan_command_processor.cc.o'), 'command processor preimage drift'
# And the launcher source that build/framegen-modes-20261010 starts from is still the one
# updates.1 was built from.
compile_with(versioned(record['commands']['launcher'], '0.5.9-updates.1'), updates / 'launcher.cpp',
             proofs / 'launcher-updates1.o', ['-I' + str(kinect)])
assert sha(proofs / 'launcher-updates1.o') == sha(updates / 'native/obj/launcher.cpp.o'), 'updates.1 launcher source changed'

includes = ['-I' + str(updates), '-I' + str(kinect)]
launcher_build = compile_with(versioned(record['commands']['launcher'], LABEL), here / 'launcher-updates.cpp',
                              out / 'obj/launcher.cpp.o', includes)
cp_build = compile_with(record['commands']['command_processor'], root / 'build/stutter-wait-20261010' / cp_source,
                        out / 'obj/vulkan_command_processor.cc.o')
changed = {'launcher.cpp.o', 'vulkan_command_processor.cc.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / name) == value for name, value in retained.items())
assert {p.name for p in (out / 'obj').glob('*.o')} == set(record['objects'])
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)

# Display version, image verification and signing: the reviewed step of the framegen.3 recipe.
s = (root / 'build/framegen-sword-20261010/build.py').read_text()
validation = s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation, 'framegen-sword build.py', 'exec'), globals())
image = (out / 'llvm-pie.elf').read_bytes()
for needle in (b'PPSA50011/updates', b'000B0000-off', b'LAUNCHER title update for', b'Framegen: Sword FSR3 ready', b'shader-trace.conf'):
    assert needle in image, needle
commands = dict(record['commands'])
commands.update(launcher=launcher_build, command_processor=cp_build)
(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'launcher_preimage_identical': True, 'command_processor_preimage_identical': True, 'unchanged_objects': retained,
    'objects': {p.name: sha(p) for p in (out / 'obj').glob('*.o')}, 'commands': commands, 'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
