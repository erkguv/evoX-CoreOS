"""Refresh the Desktop source copy (C:/Users/bruno/Desktop/Xbox360PS5-source) with the work folders
of the title-update, stutter and frame-generation-mode candidates: sources, scripts and notes
only (no images, objects, eboots, backups or keys).
usage: python sync_desktop.py
"""
from pathlib import Path
import shutil

root = Path(__file__).resolve().parents[2]
desktop = Path.home() / 'Desktop/Xbox360PS5-source'
FOLDERS = ['title-updates-20261010', 'stutter-wait-20261010', 'updates-integration-20261010', 'framegen-modes-20261010',
           'framegen-adaptive-20261010', 'framegen-always-20261010']
KEEP = {'.py', '.cpp', '.hpp', '.h', '.cc', '.comp', '.md', '.txt', '.json', '.sh'}
SKIP_DIRS = {'native', 'native-safe', 'obj', 'proofs', 'console-backups', '__pycache__', 'preview', 'vendor', 'shared'}
assert desktop.is_dir(), desktop
copied = 0
for folder in FOLDERS:
    source = root / 'build' / folder
    if not source.is_dir():
        continue
    for path in source.rglob('*'):
        relative = path.relative_to(source)
        if not path.is_file() or any(part in SKIP_DIRS for part in relative.parts[:-1]):
            continue
        if path.suffix.lower() not in KEEP or path.stat().st_size > 1_000_000:
            continue
        destination = desktop / folder / relative
        if destination.exists() and destination.read_bytes() == path.read_bytes():
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        copied += 1
print(f'{copied} files refreshed in {desktop}')
