"""Waits until PS5X360 is closed on the console, then installs a candidate with
build/title-updates-20261010/deploy.py and, if frame generation is switched on there, sets its
mode to Automatic (the mode in which the adaptive pacing works).

The settings file keeps its first line; its previous content is saved beside the receipt.
usage: python deploy_when_closed.py <candidate native folder> <native folder expected on the console> [hours to wait]
"""
from pathlib import Path
import ftplib
import io
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
root = here.parents[1]
candidate, expected = sys.argv[1], sys.argv[2]
limit = time.time() + float(sys.argv[3] if len(sys.argv) > 3 else 3) * 3600
deploy = [sys.executable, str(root / 'build/title-updates-20261010/deploy.py'), candidate, expected]
attempt = 0
while True:
    attempt += 1
    run = subprocess.run(deploy, capture_output=True, text=True)
    if run.returncode == 0:
        print(run.stdout.strip())
        break
    reason = (run.stderr.strip() or run.stdout.strip()).splitlines()[-1:] or ['?']
    waiting = any(word in reason[0] for word in ('close it first', 'still mounted', 'still active', 'timed out', 'refused', 'unreachable'))
    if not waiting or time.time() > limit:
        print(f'NOT INSTALLED after {attempt} attempts: {reason[0]}')
        print(run.stderr.strip()[-1500:])
        sys.exit(1)
    time.sleep(45)

# Frame generation: Automatic when it is on, so that it also works at uneven frame rates.
with ftplib.FTP() as f:
    f.connect('192.168.0.19', 2121, timeout=30)
    f.login()
    f.cwd('/data/homebrew/PPSA50011')
    buffer = io.BytesIO()
    try:
        f.retrbinary('RETR framegen.conf', buffer.write)
        before = buffer.getvalue().decode('utf-8', 'replace')
    except ftplib.error_perm:
        before = ''
    lines = [line.strip() for line in before.splitlines() if line.strip()]
    (root / 'build' / candidate).parent.joinpath('framegen.conf.before.txt').write_text(before, encoding='utf-8')
    if lines[:1] == ['ps5_frame_interpolation=true']:
        kept = [line for line in lines[1:] if not line.startswith('ps5_frame_multiplier=')]
        if not any(line.startswith('ps5_frame_output_hz=') for line in kept):
            kept.insert(0, 'ps5_frame_output_hz=60')
        after = '\n'.join(['ps5_frame_interpolation=true', 'ps5_frame_multiplier=auto'] + kept) + '\n'
        f.storbinary('STOR framegen.conf', io.BytesIO(after.encode()))
        check = io.BytesIO()
        f.retrbinary('RETR framegen.conf', check.write)
        assert check.getvalue().decode() == after
        print('framegen.conf set to Automatic:', after.strip().replace('\n', ' | '))
    else:
        print('framegen.conf left as it was (frame generation is off there):', before.strip() or '(no file)')
print(f'INSTALLED after {attempt} attempt(s)')
