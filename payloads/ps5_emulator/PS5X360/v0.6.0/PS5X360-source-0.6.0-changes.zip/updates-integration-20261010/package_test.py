"""Assembles the tester package of 0.5.9-updates.3-safe-local: a complete PPSA50011 folder as a ZIP.

Base: the support files of the previous tester package (Desktop/PS5X360-TEST-0.5.9/PPSA50011.zip:
fonts, patches, sounds, licences, system files, documents). Replaced or added here: the
executable (exactly the one installed and opened on the developer's PS5), VERSION, RELEASE.json,
RELEASE_NOTES.md, the presets and the one patch file added on the console since, the Kinect
camera page the executable serves from assets/kinect, the updates folder, licence texts of the
frame generation module, MANIFEST.json. Also writes a ZIP with the sources of the changes.
No games, saves, logs, settings, certificates or keys.
usage: python package_test.py
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

here = Path(__file__).resolve().parent
root = here.parents[1]
native = here / 'native-safe'
record = json.loads((native / 'build.json').read_text())
deployment = json.loads((here / 'deployment-native-safe.json').read_text())
assert deployment['installed'] and deployment['native_sha256'] == record['native_sha256']
NAME = 'TEST 0.5.9-updates.3'
MENU = record['version'].removesuffix('-local')  # what the menu shows
sha = lambda data: hashlib.sha256(data).hexdigest()
# A key with its body, or a webhook address with its number: never in a package or a source archive.
SECRET = re.compile(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s*[A-Za-z0-9+/=\s]{60,}|discord(?:app)?\.com/api/webhooks/\d{6,}')

previous = Path.home() / 'Desktop/PS5X360-TEST-0.5.9/PPSA50011.zip'
stage = root / 'dist/local' / record['version'] / 'tester'
shutil.rmtree(stage, ignore_errors=True)
title = stage / 'PPSA50011'
with zipfile.ZipFile(previous) as z:
    assert z.testzip() is None
    z.extractall(stage)
assert (title / 'eboot.bin').is_file() and (title / 'sce_sys/param.json').is_file()

# The executable and what names it.
image = (native / 'eboot.bin').read_bytes()
assert sha(image) == record['native_sha256']
(title / 'eboot.bin').write_bytes(image)
(title / 'VERSION').write_text(MENU + '\n', encoding='utf-8', newline='\n')
(title / 'RELEASE.json').write_text(json.dumps({
    'version': NAME, 'menu_version': MENU, 'channel': 'test', 'native_sha256': record['native_sha256'],
    'base_version': '0.5.9-framegen.4-local', 'base_native_sha256': record['baseline_native_sha256'],
    'executable_is_the_one_run_on_the_developer_console': True,
    'hardware_validation': 'Opened on the developer PS5 (firmware 13.60) on 2026-10-10; GTA IV started and ran about a '
                           'minute. Title updates were not tried with a real update; the shader-wait change was not '
                           'measured (that session had readback off).',
}, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copy2(here / 'tester/RELEASE_NOTES.md', title / 'RELEASE_NOTES.md')

# Support files that changed on the developer console since the previous package.
shutil.copy2(here / 'console-assets/presets.txt', title / 'assets/presets.txt')
for patch in (here / 'console-assets/patches').iterdir():
    shutil.copy2(patch, title / 'assets/patches' / patch.name)
# The Kinect camera page: the executable serves it from assets/kinect.
(title / 'assets/kinect').mkdir(exist_ok=True)
for name in ('index.html', 'pose.mjs', 'kinect_tracker.mjs', 'demo_body.mjs'):
    shutil.copy2(root / 'tools/kinect-phone' / name, title / 'assets/kinect' / name)
# Where a title update is copied to.
(title / 'updates').mkdir(exist_ok=True)
shutil.copy2(here / 'tester/updates-README.md', title / 'updates/README.md')
# Frame generation module: its licence and the licence of the shaders compiled into it.
upstream = root / 'build/ps5-framegen-upstream-20261010'
shutil.copy2(upstream / 'COPYING', title / 'licenses/PS5-FRAMEGEN-GPL-3.txt')
shutil.copy2(upstream / 'shaders/LICENSE.txt', title / 'licenses/AMD-FIDELITYFX-SDK-MIT.txt')
credits = (title / 'CREDITS.md').read_text(encoding='utf-8')
addition = ('\n## Frame generation\n\nFrame generation uses [ps5-framegen](https://github.com/Swordpdf/ps5-framegen) by '
            'Swordpdf (commit 6436210, GPL-3.0-or-later), built on the optical flow shaders of the AMD FidelityFX SDK '
            '(MIT). Licence texts: `licenses/PS5-FRAMEGEN-GPL-3.txt`, `licenses/AMD-FIDELITYFX-SDK-MIT.txt`.\n')
if 'ps5-framegen' not in credits:
    (title / 'CREDITS.md').write_text(credits.rstrip('\n') + '\n' + addition, encoding='utf-8', newline='\n')
assert (title / 'framegen.conf').read_text().strip() == 'ps5_frame_interpolation=false'  # off until switched on

# Nothing private or personal: only known kinds of files, none of the console's own state.
allowed_top = {'AUTOLOG.md', 'CREDITS.md', 'INSTALLATION.md', 'LICENSE', 'MANIFEST.json', 'MULTI-DISC.md', 'RELEASE.json',
               'RELEASE_NOTES.md', 'VERSION', 'assets', 'dlc', 'eboot.bin', 'framegen.conf', 'licenses', 'sce_module',
               'sce_sys', 'updates'}
assert {p.name for p in title.iterdir()} <= allowed_top, {p.name for p in title.iterdir()} - allowed_top
forbidden = ('.key', '.pem', '.crt', '.der', '.p12', '.log', '.bak', '.iso', '.xex')
files = sorted(p for p in title.rglob('*') if p.is_file())
assert not [p for p in files if p.suffix.lower() in forbidden], [p for p in files if p.suffix.lower() in forbidden]
assert {p.name for p in (title / 'assets').iterdir()} == {'fonts', 'kinect', 'patches', 'presets.txt', 'roms', 'sounds'}
assert [p.name for p in (title / 'assets/roms').rglob('*')] == ['README.txt']  # the games folder ships empty
for p in files:
    if p.suffix.lower() in {'.md', '.txt', '.json', '.toml', '.html', '.mjs', '.conf'}:
        text = p.read_bytes()
        assert not SECRET.search(text), p

manifest = {p.relative_to(title).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in files if p.name != 'MANIFEST.json'}
(title / 'MANIFEST.json').write_text(json.dumps(manifest, indent=1) + '\n', encoding='utf-8', newline='\n')

out = Path.home() / 'Desktop/PS5X360-TEST-0.5.9-updates.3'
out.mkdir(exist_ok=True)
package = out / 'PPSA50011.zip'
with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(title.rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(stage).as_posix())
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None
    assert sha(z.read('PPSA50011/eboot.bin')) == record['native_sha256']
    packed = json.loads(z.read('PPSA50011/MANIFEST.json'))
    assert all(sha(z.read('PPSA50011/' + name)) == entry['sha256'] for name, entry in packed.items())
    count = len(z.namelist())
digest = sha(package.read_bytes())
(out / 'PPSA50011.zip.sha256').write_text(f'{digest}  PPSA50011.zip\n', encoding='utf-8', newline='\n')

# Sources of what changed since the previous tester package (the frame generation module is GPL).
sources = out / 'PS5X360-TEST-source-changes.zip'
KEEP = {'.py', '.cpp', '.hpp', '.h', '.cc', '.inc', '.comp', '.hlsl', '.glsl', '.md', '.json', '.txt', '.sh', '.toml'}
SKIP = {'native', 'native-safe', 'native-dlc1', 'native-dlc2', 'obj', 'proofs', 'console-backups', 'console-logs',
        'console-assets', '__pycache__', 'preview', 'video', 'tester', 'scenes', 'scenes-dispatch'}
picked = {}
for folder in ('dist/local/0.5.9-framegen.3-local/SOURCE', 'dist/local/0.5.9-framegen.4-local/SOURCE',
               'build/kinect-native-20261009', 'build/title-updates-20261010', 'build/stutter-wait-20261010',
               'build/updates-integration-20261010'):
    base = root / folder
    label = folder.split('/')[-2] + '-SOURCE' if folder.endswith('SOURCE') else folder.split('/')[-1]
    for p in base.rglob('*'):
        relative = p.relative_to(base)
        if not p.is_file() or any(part in SKIP for part in relative.parts[:-1]):
            continue
        if not (p.name == 'COPYING' or p.suffix.lower() in KEEP) or p.stat().st_size > 1_500_000:
            continue
        if p.name.startswith(('deployment', 'agent-')) or p.name in ('build.json', 'log-evidence.json', 'package.json'):
            continue  # local paths, the console address, research notes and log extracts; recipes are the .py files
        data = p.read_bytes()
        assert not SECRET.search(data), p
        picked[f'{label}/{relative.as_posix()}'] = data
picked['README.md'] = (here / 'tester/SOURCE-README.md').read_bytes()
with zipfile.ZipFile(sources, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(picked):
        z.writestr(name, picked[name])
with zipfile.ZipFile(sources) as z:
    assert z.testzip() is None

for name in ('DISCORD-PT.md', 'DISCORD-EN.md'):
    shutil.copy2(here / 'tester' / name, out / name)
(here / 'tester/package.json').write_text(json.dumps({
    'package': str(package), 'bytes': package.stat().st_size, 'sha256': digest, 'entries': count,
    'native_sha256': record['native_sha256'], 'source_changes_zip_bytes': sources.stat().st_size,
    'source_changes_files': len(picked)}, indent=2) + '\n', encoding='utf-8', newline='\n')
print(package, package.stat().st_size, 'bytes', count, 'entries')
print('sha256', digest)
print(sources, sources.stat().st_size, 'bytes', len(picked), 'files')
