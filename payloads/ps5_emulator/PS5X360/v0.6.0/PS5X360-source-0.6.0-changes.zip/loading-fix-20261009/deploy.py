from pathlib import Path
import datetime,ftplib,hashlib,importlib.util,io,json,socket,zipfile
root=Path(__file__).resolve().parents[2];work=Path(__file__).resolve().parent
proof=json.loads((work/'native/build.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(work/'package/PPSA50011.zip') as z:
    updates={n:z.read('PPSA50011/'+n) for n in ('eboot.bin','VERSION','RELEASE.json','RELEASE_NOTES.md','MANIFEST.json','assets/presets.txt')}
assert sha(updates['eboot.bin'])==proof['native_sha256']
spec=importlib.util.spec_from_file_location('verify',root/'tools/deploy-native-probe.py')
verify=importlib.util.module_from_spec(spec);spec.loader.exec_module(verify)
def closed(f):
    for port in range(8360,8368):
        with socket.socket() as s:
            s.settimeout(.3)
            if s.connect_ex(('192.168.0.19',port))==0:raise RuntimeError('Emulator still active')
    lines=[];f.retrlines('LIST /mnt/sandbox',lines.append)
    if any('PPSA50011' in s for s in lines):raise RuntimeError('Title still mounted')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup=work/'console-backups'/stamp;backup.mkdir(parents=True,exist_ok=False)
remote='eboot-before-loading-fix-'+stamp+'.bak';temp='eboot-loading-'+stamp+'.new'
with ftplib.FTP() as f:
    f.connect('192.168.0.19',2121,timeout=30);f.login();closed(f);f.cwd('/data/homebrew/PPSA50011')
    def read(n):
        b=io.BytesIO();f.retrbinary('RETR '+n,b.write,blocksize=1024*1024);return b.getvalue()
    previous={n:read(n) for n in updates}
    verify.verify_eboot(previous['eboot.bin'],(root/'build/version-label-fix-20261009/eboot.bin').read_bytes(),(root/'build/version-label-fix-20261009/eboot.elf').read_bytes())
    assert previous['assets/presets.txt']==(work/'state-review/installed-presets-snapshot.txt').read_bytes(),'Preset changed since inspection'
    for n,b in previous.items():
        p=backup/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    f.storbinary('STOR '+temp,io.BytesIO(updates['eboot.bin']),blocksize=1024*1024)
    verify.verify_eboot(read(temp),updates['eboot.bin'],(work/'native/eboot.elf').read_bytes())
    closed(f);f.rename('eboot.bin',remote)
    try:
        f.rename(temp,'eboot.bin')
        for n,b in updates.items():
            if n!='eboot.bin':f.storbinary('STOR '+n,io.BytesIO(b))
        result=verify.verify_eboot(read('eboot.bin'),updates['eboot.bin'],(work/'native/eboot.elf').read_bytes())
        for n,b in updates.items():
            if n!='eboot.bin':assert read(n)==b,n
    except Exception:
        try:f.rename('eboot.bin','eboot-rejected-loading-'+stamp+'.bak')
        except ftplib.error_perm:pass
        f.rename(remote,'eboot.bin')
        for n,b in previous.items():
            if n!='eboot.bin':f.storbinary('STOR '+n,io.BytesIO(b))
        raise
receipt=dict(installed=True,version='0.5.9-loading.1-local',native_sha256=proof['native_sha256'],backup=remote,local_backup=str(backup),verification=result,hardware_gameplay='pending',save_and_camera_configuration_changed=False)
(work/'deployment.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
