from pathlib import Path
import hashlib,json,shutil,subprocess,struct
root=Path('/ws/Xbox360PS5')
work=root/'build/loading-fix-20261009'
base=root/'build/kinect-update-20261008/final-native'
out=work/'native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base/'eboot.bin')=='c500380836132fdab06d8998fe316606074ca3b89d27993b4e2944feeb121c04'
receipt=json.loads((base/'build.json').read_text())
checked={}
for name,expected in receipt['baseline_inputs'].items():
    p=Path(name)
    if p.suffix in ('.o','.a'):
        assert sha(p)==expected, name
        checked[name]=expected
candidate=root/'build/loading-20261008/agent-iamalive/candidate/threading-native-candidate.o'
assert sha(candidate)=='8fa68f51f9ac26b4544e4f7fcf535a53b8818c57362e8d7681a461d36e50a786'
original=root/'build/canary-ps5/core/src/xenia/base/CMakeFiles/xenia-base.dir/threading_posix.cc.o'
assert sha(original)=='e615310bd98d51394a3f388b9c63e611a0716b601662cc501b3553f3516bb28f'
(out/'obj').mkdir(parents=True,exist_ok=True)
retained={p.name:sha(p) for p in (base/'obj').glob('*.o')}
for p in (base/'obj').glob('*.o'):shutil.copy2(p,out/'obj'/p.name)
shutil.copy2(candidate,out/'obj/threading_posix.cc.o')
command=['bash',str(root/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(root),str(out)]
subprocess.run(command,check=True)
assert all(sha(out/'obj'/n)==v for n,v in retained.items())
# Preserve the tested short release label without recompiling title/UI objects.
old=b'PS5X360 v0.5.8-vulkan.4';new=b'PS5X360 v0.5.9'
for name in ('llvm-pie.elf','eboot.elf'):
    data=(out/name).read_bytes();assert data.count(old+b'\0')==1
    offset=data.index(old+b'\0'); phoff=struct.unpack_from('<Q',data,32)[0]
    size,count=struct.unpack_from('<HH',data,54)
    ph=[struct.unpack_from('<IIQQQQQQ',data,phoff+i*size) for i in range(count)]
    assert any(p[0]==1 and p[1]==4 and p[2]<=offset and offset+len(old)+1<=p[2]+p[5] for p in ph)
    result=data[:offset]+new+b'\0'*(len(old)+1-len(new))+data[offset+len(old)+1:]
    assert len(result)==len(data)
    for p in ph:
        if p[0]==1 and p[1]&1:assert data[p[2]:p[2]+p[5]]==result[p[2]:p[2]+p[5]]
    (out/name).write_bytes(result)
subprocess.run(['python3',str(root/'build/native-runtime-stage/tools/verify-image.py'),str(out/'llvm-pie.elf'),str(out/'eboot.elf')],check=True)
subprocess.run([str(root/'build/canary-game/host/ps5-native-tool'),'self','--sign','--in',str(out/'eboot.elf'),'--out',str(out/'eboot.bin'),'--magic','0x1D3D154F'],check=True)
proof={'baseline_native_sha256':receipt['native_sha256'],'native_sha256':sha(out/'eboot.bin'),'new_object_sha256':sha(candidate),'unchanged_override_objects':retained,'checked_original_inputs':checked,'command':command,'hardware':'pending','deployed':False}
(out/'build.json').write_text(json.dumps(proof,indent=2))
print('PASS: isolated synchronization change, previous objects preserved, native image verified')
