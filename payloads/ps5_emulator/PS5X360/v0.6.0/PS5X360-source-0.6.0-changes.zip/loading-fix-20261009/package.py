from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path(__file__).resolve().parents[2];work=Path(__file__).resolve().parent
native=work/'native';proof=json.loads((native/'build.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(root/'build/version-label-fix-20261009/artifacts/PPSA50011.zip') as z:
    files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
preset=(work/'state-review/installed-presets-snapshot.txt').read_text(encoding='utf-8-sig')
assert '[584111E8]' not in preset
preset+='\n# State of Decay: readable guest zero page, per-title only.\n# Explicit per-game overrides retain priority. Requires process restart.\n# https://github.com/xenia-project/game-compatibility/issues/899\n[584111E8]\nzero_page=1\n'
files['PPSA50011/assets/presets.txt']=preset.encode()
version='0.5.9-loading.1-local'
notes='''# Loading compatibility candidate

Private candidate based on the working v0.5.9 Fix 1 native build.
The existing Kinect, renderer and title/UI objects are retained unchanged.

- General POSIX wait/suspend correction: finish native condition-variable
  bookkeeping before delivering a requested guest suspension. No fabricated
  successful I/O, global timeouts, or ignored suspension requests.
- State of Decay (584111E8): per-title readable zero-page preset, matching the
  upstream compatibility requirement. Explicit per-game settings take priority;
  the general default remains protected. Full process restart is required.

These address identified loading mechanisms; they are not a universal loading
fix. Console loading/gameplay verification remains pending for both games.
The public release is unchanged. The retained UI displays PS5X360 v0.5.9;
VERSION and RELEASE.json identify this private candidate.
'''
image=(native/'eboot.bin').read_bytes();assert sha(image)==proof['native_sha256']
files['PPSA50011/eboot.bin']=image
files['PPSA50011/VERSION']=(version+'\n').encode()
files['PPSA50011/RELEASE.json']=json.dumps(dict(proof,version=version),indent=2).encode()
files['PPSA50011/RELEASE_NOTES.md']=notes.encode()
files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=work/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
    assert z.testzip() is None
    for n,p in manifest.items():assert sha(z.read('PPSA50011/'+n))==p['sha256']
(out/'README.md').write_text(notes)
(out/'proof.json').write_text(json.dumps(dict(version=version,native_sha256=sha(image),zip_sha256=sha((out/'PPSA50011.zip').read_bytes()),verified_manifest_files=len(manifest),hardware='pending'),indent=2))
desktop=Path.home()/'Desktop/PS5X360-loading-test-20261009';desktop.mkdir(exist_ok=True)
for n in ('PPSA50011.zip','README.md','proof.json'):shutil.copy2(out/n,desktop/n)
delta=Path.home()/'Desktop/Xbox360PS5-source/loading-fix-20261009';delta.mkdir(parents=True,exist_ok=True)
for p in (root/'build/loading-20261008/agent-iamalive/candidate').glob('*'):
    if p.name in ('threading_posix-native.cc','native.patch','native-object-build.json'):shutil.copy2(p,delta/p.name)
for p in (work/'link.py',work/'package.py',native/'build.json',work/'state-review/VERDICT.md'):shutil.copy2(p,delta/p.name)
print(json.dumps({'folder':str(desktop),'native_sha256':sha(image),'manifest_files':len(manifest)}))
