"""Decode IO_TRACE lines of a PS5X360 game log into one row per call."""
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
calls = {}
order = []
for line in open(sys.argv[1], encoding="utf-8", errors="replace"):
    if "IO_TRACE" not in line:
        continue
    m = re.search(r"IO_TRACE (\w+) id=(\d+)(.*)", line)
    if not m:
        print("OTHER", line.strip()[:200])
        continue
    kind, cid, rest = m.group(1), int(m.group(2)), m.group(3)
    fields = dict(re.findall(r"(\w+)=(\S*)", rest))
    if cid not in calls:
        calls[cid] = {}
        order.append(cid)
    for k, v in fields.items():
        if k.endswith("_hex") and v:
            try:
                v = bytes.fromhex(v).decode("latin-1")
            except ValueError:
                pass
        calls[cid][kind + "." + k] = v

for cid in order:
    c = calls[cid]
    name = c.get("path.translated_hex") or c.get("path.raw_hex") or ""
    print(f"{cid:3} {c.get('enter.export','?'):26} thr={c.get('enter.thread','?')} root={c.get('enter.root','?')}"
          f"/{c.get('enter.root_kind','')} rootpath={c.get('root.absolute_hex','')!r} name={name!r}"
          f" -> status={c.get('exit.status', c.get('exit.result','?'))} found={c.get('exit.actual_found','?')}"
          f" abs={c.get('exit.actual_absolute_hex', c.get('exit.absolute_hex',''))!r}"
          f" cmp={c.get('comparison_readonly.attempted','')}/{c.get('comparison_readonly.found', c.get('comparison_readonly.applied',''))}"
          f" {c.get('comparison_readonly.absolute_hex','')!r}")
