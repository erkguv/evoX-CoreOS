from pathlib import Path
p = Path(__file__).resolve().parent / 'presenter/vulkan_presenter.cc'
s = p.read_text()
a = s.index('    if (pinned && serial != fg->serial) {')
b = s.index('  bool midpoint = false;', a)
s = s[:a] + '''    if (pinned && serial != fg->serial) {
      ++fg->new_frames;
      const uint64_t now = uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(
          std::chrono::steady_clock::now().time_since_epoch()).count());
      // Observe every source arrival, including warmup. History is independent
      // of cadence and may be invalidated while the generator is dormant.
      const bool admitted = fg->pacing.Observe(now, serial,
          pinned->extent().width, pinned->extent().height, fg->display_hz,
          true, true, this);
      if (!fg->pacing.Engaged()) {
        // No extra picture can be emitted: use the normal late mailbox consume.
        // Retain pending GPU leases/allocations; clear only snapshot validity.
        fg->serial = serial;
        fg->history = false;
        fg->interpolation_history = false;
        pinned.reset();
        if (fg_consumer_lock.owns_lock()) fg_consumer_lock.unlock();
        fg->Fallback(4, "cadence/capacity gate; normal presentation without snapshot wait");
      } else {
        // The active backend shares its history images. Retire readers before
        // reuse; removing this wait requires tracking every GPU reader.
        paint_context_.completion_timeline.AwaitAllSubmissions();
        if (fg->RetireSource(paint_context_.completion_timeline.UpdateAndGetCompletedSubmission()) &&
            fg->Prepare(vulkan_device_, pinned->extent(), kGuestOutputFormat,
                        guest_output_paint_image_descriptor_set_layout_)) {
          new_frame = true;
          generate = fg->history && admitted;
          if (generate) {
            ++fg->admitted;
            if (!fg->admission_logged) {
              fg->admission_logged = true;
              XELOGW("Framegen first admission: stable arrivals have two selected-refresh slots; "
                     "producer cadence safety gate; selected_hz={}", fg->display_hz);
            }
          }
        } else {
          fg->failed = true;
          ++fg->failures;
          fg->Fallback(8, "format/allocation/pipeline preparation failed");
          pinned.reset();
        }
      }
    }
  }
  if (fg && pinned && !fg->failed && !new_frame && fg->pacing.Engaged()) {
    if (fg_consumer_lock.owns_lock()) fg_consumer_lock.unlock();
    return PaintResult::kNotPresented;
  }
''' + s[b:]
p.write_text(s)
