from pathlib import Path
import json,subprocess,hashlib
h=Path(__file__).resolve().parent;root=h.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=root/'build/framegen-sword-20261010/native'
assert sha(h/'presenter.proof.o')==sha(base/'obj/vulkan_presenter.cc.o')
c=json.loads((h/'native/build.json').read_text())['commands']['presenter']
subprocess.run(c,cwd=root,check=True)
subprocess.run(['python3',str(h/'finish_trace.py')],check=True)
