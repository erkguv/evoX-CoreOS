from pathlib import Path
import ftplib,re,json
h=Path(__file__).resolve().parent; dest=h/'console-logs';dest.mkdir(exist_ok=True)
with ftplib.FTP() as f:
    f.connect('192.168.0.19',2121,timeout=20);f.login()
    rows=[];f.retrlines('LIST /data/homebrew/PPSA50011/logs',rows.append)
    names=[row.split(None,8)[8] for row in rows if len(row.split(None,8))==9 and row.startswith('-')]
    games=[n for n in names if re.search(r'-2026\d{4}-\d{6}-UTC',n)]
    games.sort(key=lambda n:re.search(r'-(2026\d{4}-\d{6})-UTC',n).group(1))
    for name in games[-7:]:
        with (dest/name).open('wb') as out:f.retrbinary('RETR /data/homebrew/PPSA50011/logs/'+name,out.write)
    for name in ('VERSION','framegen.conf'):
        with (dest/(name+'.txt')).open('wb') as out:f.retrbinary('RETR /data/homebrew/PPSA50011/'+name,out.write)
    sandbox=[];f.retrlines('LIST /mnt/sandbox',sandbox.append)
    print(json.dumps({'mounted':any('PPSA50011' in s for s in sandbox),'games':games[-7:]},indent=2))
