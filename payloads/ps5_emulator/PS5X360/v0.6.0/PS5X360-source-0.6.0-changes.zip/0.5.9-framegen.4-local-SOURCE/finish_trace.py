from pathlib import Path
import hashlib,json,shutil,subprocess,struct
root=Path('/ws/Xbox360PS5');here=Path(__file__).resolve().parent
base=root/'build/framegen-sword-20261010/native';out=here/'native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
VERSION='0.5.9-framegen.4-local';LABEL=VERSION.removesuffix('-local');SHORT=LABEL.removeprefix('0.5.9-')
record=json.loads((out/'build.json').read_text())
assert sha(here/'shader-agent/obj/baseline-vulkan_pipeline_cache.cc.o')==sha(base/'obj/vulkan_pipeline_cache.cc.o')
shutil.copy2(here/'shader-agent/obj/vulkan_pipeline_cache.cc.o',out/'obj/vulkan_pipeline_cache.cc.o')
subprocess.run(['bash',str(root/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(root),str(out)],check=True)
s=(root/'build/framegen-sword-20261010/build.py').read_text()
exec(compile(s[s.index('# Display version'):s.index("(out / 'build.json').write_text")],'<validation>','exec'),globals())
record['unchanged_objects'].pop('vulkan_pipeline_cache.cc.o')
assert all(sha(out/'obj'/n)==v for n,v in record['unchanged_objects'].items())
record['objects']={p.name:sha(p) for p in (out/'obj').glob('*.o')}
record['native_sha256']=sha(out/'eboot.bin');record['shader_cache_preimage_identical']=True
record['commands']['pipeline_cache']=json.loads((here/'shader-agent/compile-commands.json').read_text())['candidate']
(out/'build.json').write_text(json.dumps(record,indent=2))
print('PASS integrated bounded shader trace',record['native_sha256'])
