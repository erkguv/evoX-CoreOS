from pathlib import Path
import hashlib,json,shutil,subprocess,struct
root=Path('/ws/Xbox360PS5'); here=Path(__file__).resolve().parent
base=root/'build/framegen-sword-20261010/native'; out=here/'native'
record=json.loads((base/'build.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base/'eboot.bin')==record['native_sha256']=='ba3cec85171cef8c8376dfacea445abf42d6a515b9dd3637d5816befbd66fff8'
VERSION='0.5.9-framegen.4-local'; LABEL=VERSION.removesuffix('-local'); SHORT=LABEL.removeprefix('0.5.9-')
(out/'obj').mkdir(parents=True,exist_ok=True)
for p in (base/'obj').glob('*.o'): shutil.copy2(p,out/'obj'/p.name)
def compile_with(command,source,obj,extra=()):
    c=list(command); c[1:1]=extra
    c[c.index('-c')+1]=str(source); c[c.index('-o')+1]=str(obj)
    subprocess.run(c,cwd=root,check=True); return c
old=root/'build/framegen-sword-20261010'
for key,source,name in [('presenter',old/'presenter/vulkan_presenter.cc','vulkan_presenter.cc.o'),('launcher',root/'build/kinect-native-20261009/launcher.cpp','launcher.cpp.o')]:
    compile_with(record['commands'][key],source,here/(key+'.proof.o'))
    assert sha(here/(key+'.proof.o'))==sha(base/'obj'/name),key+' preimage drift'
presenter_build=compile_with(record['commands']['presenter'],here/'presenter/vulkan_presenter.cc',out/'obj/vulkan_presenter.cc.o',['-I'+str(here)])
launcher_cmd=[f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in record['commands']['launcher']]
launcher_build=compile_with(launcher_cmd,root/'build/kinect-native-20261009/launcher.cpp',out/'obj/launcher.cpp.o')
changed={'vulkan_presenter.cc.o','launcher.cpp.o'}
retained={p.name:sha(p) for p in (base/'obj').glob('*.o') if p.name not in changed}
assert all(sha(out/'obj'/name)==value for name,value in retained.items())
assert {p.name for p in (out/'obj').glob('*.o')}==set(record['objects'])
subprocess.run(['bash',str(root/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(root),str(out)],check=True)
# Reuse the reviewed read-only metadata patch and ELF/signing validation only.
s=(old/'build.py').read_text()
validation=s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation,str(old/'build.py'),'exec'),globals())
commands=dict(record['commands']);commands.update(presenter=presenter_build,launcher=launcher_build)
(out/'build.json').write_text(json.dumps({'version':VERSION,'baseline_native_sha256':sha(base/'eboot.bin'),'native_sha256':sha(out/'eboot.bin'),'presenter_preimage_identical':True,'launcher_preimage_identical':True,'unchanged_objects':retained,'objects':{p.name:sha(p) for p in (out/'obj').glob('*.o')},'commands':commands,'hardware':'pending'},indent=2))
print('PASS',VERSION,sha(out/'eboot.bin'))
