from pathlib import Path
import json,subprocess,hashlib
h=Path(__file__).resolve().parent; a=h/'shader-agent'
c=json.loads((a/'compile-commands.json').read_text())['candidate']
subprocess.run(c,cwd=h.parents[1],check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=h.parents[1]/'build/framegen-sword-20261010/native/obj/vulkan_pipeline_cache.cc.o'
assert sha(base)==sha(a/'obj/baseline-vulkan_pipeline_cache.cc.o')
(a/'parent-trace-proof.json').write_text(json.dumps({'baseline_sha256':sha(base),'candidate_sha256':sha(a/'obj/vulkan_pipeline_cache.cc.o'),'opt_in':'shader-trace.conf: enabled=true','default':'off','hardware':'pending'},indent=2))
