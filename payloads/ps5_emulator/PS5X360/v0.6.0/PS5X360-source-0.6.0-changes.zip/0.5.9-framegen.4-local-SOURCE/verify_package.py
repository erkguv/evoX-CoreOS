from pathlib import Path
import hashlib,json,subprocess
h=Path(__file__).resolve().parent;root=h.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=h/'native/build.json';r=json.loads(p.read_text())
assert sha(h/'native/eboot.bin')==r['native_sha256']
assert all(sha(h/'native/obj'/n)==v for n,v in r['objects'].items())
baseline=json.loads((root/'build/framegen-sword-20261010/native/build.json').read_text())
changed=[n for n,v in r['objects'].items() if baseline['objects'][n]!=v]
assert set(changed)=={'vulkan_presenter.cc.o','vulkan_pipeline_cache.cc.o','launcher.cpp.o'}
r['source_sha256']={str(p.relative_to(h)):sha(p) for p in h.rglob('*') if p.is_file() and p.suffix in {'.h','.hpp','.cc','.cpp','.inc','.py'} and not any(x in {'native','obj','console-logs','console-backups','__pycache__'} for x in p.relative_to(h).parts)}
p.write_text(json.dumps(r,indent=2))
deployment=json.loads((h/'deployment.json').read_text()) if (h/'deployment.json').exists() else None
tests={'pacing':'PASS parent rerun with clang++-18 -O2 -Wall -Wextra -Werror; agent ASan/UBSan PASS','trace':'PASS threshold, concurrent quotas, disabled/exhausted clock reads and exceptions','preimages':['presenter','launcher','pipeline_cache'],'unchanged_objects':len(r['unchanged_objects']),'changed_objects':changed,'elf':'PASS mapped segments and relocation targets; signed native','console_install':deployment or 'not attempted','hardware_performance':'pending'}
(h/'TESTS.json').write_text(json.dumps(tests,indent=2))
print(json.dumps(tests,indent=2))
