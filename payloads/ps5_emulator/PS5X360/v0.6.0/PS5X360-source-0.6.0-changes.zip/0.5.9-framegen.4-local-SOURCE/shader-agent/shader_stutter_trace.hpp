#pragma once
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace shader_stutter {
enum class Stage : size_t {
  kTranslate, kDriverCreate, kTargetWait, kGlobalWait,
  kStorageInit, kStorageTranslate, kSnapshot, kCount
};
inline constexpr const char* kStageNames[] = {
  "translate", "driver-create", "target-wait", "global-wait",
  "storage-init", "storage-translate", "snapshot"
};
// Separate budgets keep startup events from exhausting runtime wait samples.
// Budgets last for the process lifetime; no unsynchronized per-title reset.
class Budget {
 public:
  bool Exhausted(Stage stage) const noexcept {
    return count_[size_t(stage)].load(std::memory_order_relaxed) >= 16;
  }
  bool Claim(Stage stage) noexcept {
    auto& counter = count_[size_t(stage)];
    unsigned value = counter.load(std::memory_order_relaxed);
    while (value < 16) {
      if (counter.compare_exchange_weak(value, value + 1,
              std::memory_order_relaxed, std::memory_order_relaxed)) return true;
    }
    return false;
  }
 private:
  std::array<std::atomic<unsigned>, size_t(Stage::kCount)> count_{};
};

// Hooks provides Now(), Frequency(), Report(stage, milliseconds, key).
// Disabled or exhausted scopes perform no clock reads or logging.
template <typename Hooks>
class Scope {
 public:
  Scope(Budget& budget, bool enabled, Stage stage, uint64_t key = 0)
      : budget_(budget), stage_(stage), key_(key),
        enabled_(enabled && !budget.Exhausted(stage)),
        start_(enabled_ ? Hooks::Now() : 0) {}
  Scope(const Scope&) = delete;
  Scope& operator=(const Scope&) = delete;
  ~Scope() noexcept {
    if (!enabled_) return;
    try {
      uint64_t end = Hooks::Now();
      uint64_t frequency = Hooks::Frequency();
      if (end < start_ || !frequency) return;
      double ms = double(end - start_) * 1000.0 / double(frequency);
      if (ms >= 8.0 && budget_.Claim(stage_)) Hooks::Report(stage_, ms, key_);
    } catch (...) {
      // Diagnostics must not change compilation, wait, or persistence outcomes.
    }
  }
 private:
  Budget& budget_;
  Stage stage_;
  uint64_t key_;
  bool enabled_;
  uint64_t start_;
};
}  // namespace shader_stutter
