from pathlib import Path
import hashlib, json, re, subprocess, shlex
out=Path(__file__).resolve().parent
root=out.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
provenance=json.loads((out/'provenance.json').read_text())
for name,digest in provenance['inputs'].items():
 assert sha(root/name)==digest,name
baseline_digest=provenance['inputs']['build/framegen-sword-20261010/native/obj/vulkan_pipeline_cache.cc.o']
assert sha(out/'obj/baseline-vulkan_pipeline_cache.cc.o')==baseline_digest
receipt=json.loads((root/'build/framegen-sword-20261010/native/build.json').read_text())
for name,digest in receipt['objects'].items():
 assert sha(root/'build/framegen-sword-20261010/native/obj'/name)==digest,name
target=out/'src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc'
assert sha(target)==provenance['candidate_source_sha256']
assert sha(out/'shader_stutter_trace.hpp')==provenance['helper_sha256']
test_cmd=['C:/Program Files/LLVM/bin/clang++.exe','-std=c++20','-O2','-Wall','-Wextra',str(out/'test-trace.cpp'),'-o',str(out/'test-trace.exe')]
compile_test=subprocess.run(test_cmd,text=True,capture_output=True,check=True)
test=subprocess.run([str(out/'test-trace.exe')],text=True,capture_output=True,check=True)
(out/'test-results.json').write_text(json.dumps({'command':test_cmd,'compile_output':compile_test.stdout+compile_test.stderr,'output':test.stdout,'exit_code':test.returncode},indent=2))
logs=[]
for p in sorted((root/'build/framegen-sword-20261010/console-logs').glob('*.log')):
 text=p.read_text(errors='replace')
 stats=[]
 for line_no,line in enumerate(text.splitlines(),1):
  m=re.search(r'Performance stage pipeline: calls (\d+) total ([\d.]+) ms worst ([\d.]+) ms errors (\d+)',line)
  if m: stats.append({'line':line_no,'calls':int(m[1]),'total_ms':float(m[2]),'worst_ms':float(m[3]),'errors':int(m[4])})
 key_lines=[{'line':n,'text':line} for n,line in enumerate(text.splitlines(),1) if 'EXPERIMENT cache:' in line or 'exit checkpoint' in line or 'shaders still compiling' in line]
 logs.append({'path':str(p.relative_to(root)),'sha256':sha(p),'header':text.splitlines()[:6],'pipeline_intervals':stats,'pipeline_calls_sum':sum(s['calls'] for s in stats),'pipeline_inclusive_ms_sum':sum(s['total_ms'] for s in stats),'max_pipeline_ms':max((s['worst_ms'] for s in stats),default=None),'key_lines':key_lines})
(out/'log-evidence.json').write_text(json.dumps(logs,indent=2))
result={'native_compile_exit':0,'native_compiler_warning':'one inherited -Wswitch in user_data.h per translation unit','baseline_replay_matches':True,'baseline_object_sha256':baseline_digest,'candidate_object_sha256':sha(out/'obj/vulkan_pipeline_cache.cc.o'),'baseline_objects_verified_unchanged':len(receipt['objects']),'frozen_input_hashes_verified':len(provenance['inputs']),'hardware':'not run','performance_fix':'none; bounded telemetry fallback'}
(out/'verification.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
print(test.stdout.strip())
print(json.dumps([{'version':l['header'][0],'path':l['path'],'calls':l['pipeline_calls_sum'],'inclusive_ms':l['pipeline_inclusive_ms_sum'],'max_ms':l['max_pipeline_ms']} for l in logs],indent=2))
