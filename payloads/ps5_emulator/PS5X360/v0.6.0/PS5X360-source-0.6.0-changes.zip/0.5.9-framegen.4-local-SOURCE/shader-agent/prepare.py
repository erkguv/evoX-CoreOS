from pathlib import Path
import hashlib, json, shlex, difflib
out=Path(__file__).resolve().parent
root=out.parents[2]
old=root/'build/performance-refine-20261008/scheduling-candidate'
source=old/'src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((root/'build/framegen-sword-20261010/native/build.json').read_text())
assert sha(root/'build/framegen-sword-20261010/native/obj/vulkan_pipeline_cache.cc.o') == receipt['objects']['vulkan_pipeline_cache.cc.o'] == sha(old/'obj/vulkan_pipeline_cache.cc.o')
proof=json.loads((old/'SOURCE-PROOF.json').read_text())
assert sha(source)==proof['source_hashes']['src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc']
src=source.read_text()
original=src
src=src.replace('#include <cstdint>', '#include "shader_stutter_trace.hpp"\n\n#include <cstdint>',1)
anchor='DECLARE_bool(spirv_disable_rounding_mode_rte);'
src=src.replace(anchor, '''DEFINE_bool(vulkan_shader_stutter_trace, false,
            "Bounded shader/cache timing samples >= 8 ms (16 per stage per "
            "process). Inclusive wall time, diagnostic only.", "Vulkan");

'''+anchor+'''

namespace {
shader_stutter::Budget shader_trace_budget;
struct ShaderTraceHooks {
  static uint64_t Now() { return xe::Clock::QueryHostTickCount(); }
  static uint64_t Frequency() { return xe::Clock::QueryHostTickFrequency(); }
  static void Report(shader_stutter::Stage stage, double ms, uint64_t key) {
    XELOGW("SHADER-STUTTER stage={} wall_ms={:.3f} key={:016X}; "
           "inclusive CPU wall time, max 16/stage/process",
           shader_stutter::kStageNames[size_t(stage)], ms, key);
  }
};
using ShaderTraceScope = shader_stutter::Scope<ShaderTraceHooks>;
}  // namespace
''',1)
def add(anchor,stage,key='0'):
 global src
 assert src.count(anchor)==1,anchor
 src=src.replace(anchor,anchor+'\n  ShaderTraceScope shader_trace(shader_trace_budget,\n      cvars::vulkan_shader_stutter_trace, shader_stutter::Stage::'+stage+',\n      '+key+');',1)
add('void VulkanPipelineCache::AwaitPipelineCompletion() {','kGlobalWait')
add('void VulkanPipelineCache::AwaitPipelineCompletion(const Pipeline& pipeline) {','kTargetWait')
add('    SpirvShaderTranslator& translator,\n    VulkanShader::VulkanTranslation& translation) {','kTranslate','translation.shader().ucode_data_hash()')
add('    bool edram_fsi_used) {\n  uint64_t translation_start', 'INVALID') if False else None
add('    const std::set<std::pair<uint64_t, uint64_t>>& translations_needed,\n    bool edram_fsi_used) {','kStorageTranslate','translations_needed.size()')
add('    std::function<void()> completion_callback) {','kStorageInit','title_id')
add('bool VulkanPipelineCache::SavePipelineCacheSnapshot() noexcept try {','kSnapshot','shader_storage_title_id_')
anchor='''  VkResult result = PS5X360_VK_CALL(pipeline, dfn.vkCreateGraphicsPipelines, 
      device, vk_pipeline_cache_, 1, &pipeline_create_info, nullptr, &pipeline);'''
assert src.count(anchor)==1
src=src.replace(anchor,'''  VkResult result;
  {
    ShaderTraceScope shader_trace(shader_trace_budget,
        cvars::vulkan_shader_stutter_trace,
        shader_stutter::Stage::kDriverCreate,
        creation_arguments.vertex_shader->shader().ucode_data_hash());
    result = PS5X360_VK_CALL(pipeline, dfn.vkCreateGraphicsPipelines,
        device, vk_pipeline_cache_, 1, &pipeline_create_info, nullptr, &pipeline);
  }''')
target=out/'src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc'
target.parent.mkdir(parents=True,exist_ok=True)
target.write_text(src,newline='\n')
(out/'baseline').mkdir(exist_ok=True)
(out/'baseline/vulkan_pipeline_cache.cc').write_bytes(source.read_bytes())
(out/'shader-telemetry.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),src.splitlines(True),fromfile='a/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc',tofile='b/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc')),newline='\n')
cmd=json.loads((old/'commands.json').read_text())[0]
assert cmd[cmd.index('-c')+1].endswith('/scheduling-candidate/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc')
ws='/ws/Xbox360PS5/'+str(out.relative_to(root)).replace('\\','/')
baseline_cmd=cmd.copy(); baseline_cmd[baseline_cmd.index('-o')+1]=ws+'/obj/baseline-vulkan_pipeline_cache.cc.o'
patched_cmd=cmd.copy(); patched_cmd.insert(1,'-I'+ws)
patched_cmd[patched_cmd.index('-c')+1]=ws+'/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc'
patched_cmd[patched_cmd.index('-o')+1]=ws+'/obj/vulkan_pipeline_cache.cc.o'
(out/'compile-commands.json').write_text(json.dumps({'baseline_recorded':cmd,'baseline_replay':baseline_cmd,'candidate':patched_cmd},indent=2))
(out/'compile.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\ncd /ws/Xbox360PS5/build/canary-ps5\nmkdir -p '+shlex.quote(ws+'/obj')+'\n'+shlex.join(baseline_cmd)+'\n'+shlex.join(patched_cmd)+'\n',newline='\n')
inputs=[source, old/'commands.json', old/'SOURCE-PROOF.json',root/'build/framegen-sword-20261010/native/build.json', root/'build/framegen-sword-20261010/native/obj/vulkan_pipeline_cache.cc.o',old/'src/xenia/gpu/vulkan/vulkan_pipeline_cache.h',root/'build/mw3-graphics-20261008/cache-io-native/include/xenia/gpu/shader_storage.h']
(out/'provenance.json').write_text(json.dumps({'inputs':{p.relative_to(root).as_posix():sha(p) for p in inputs},'candidate_source_sha256':sha(target),'helper_sha256':sha(out/'shader_stutter_trace.hpp'),'baseline_version':receipt['version'],'status':'telemetry only; no performance fix justified'},indent=2))
print('Prepared private telemetry source, patch and exact compile commands')
