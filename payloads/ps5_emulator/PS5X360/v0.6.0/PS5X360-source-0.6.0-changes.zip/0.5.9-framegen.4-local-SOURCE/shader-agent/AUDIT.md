# Shader/pipeline stutter audit — 2026-10-10

## Outcome and scope

**Bounded telemetry fallback; no stutter fix is claimed.** The available evidence demonstrates expensive compilation in an older session, but does not justify changing worker counts, compilation correctness, cache format or readiness in the working framegen.3 build. Deliverables and all host writes are restricted to `build/framegen-stutter-20261010/shader-agent/`. No link, package, console operation, network publication, production edit or Desktop refresh was performed. Parent integration owns presenter/pacing and any resulting build.

Repository `AGENTS.md`, `skill-discovery` and `systematic-debugging` were read. This is a performance timing investigation of local frozen artifacts. Historical community text was treated as evidence only. Host checks do not establish console performance.

## Exact frozen provenance

Repository: `C:\Users\bruno\Documents\PS5,\Xbox360PS5`.

Baseline receipt: `build/framegen-sword-20261010/native/build.json`, version `0.5.9-framegen.3-local`.

Selected frozen object: `build/framegen-sword-20261010/native/obj/vulkan_pipeline_cache.cc.o`.

Object SHA-256: `efc00700224e5b8c470091dbdd1b1669349180bfde4c6298d69aedc56a9bd0f9`.

It is byte identical to `build/performance-refine-20261008/scheduling-candidate/obj/vulkan_pipeline_cache.cc.o`. The preserved source is `build/performance-refine-20261008/scheduling-candidate/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc`.

Source SHA-256: `dbf9b1c255c870d5bbf715ea7caddb45c220a0599ff17397e8b91aba0703b276`.

`scheduling-candidate/SOURCE-PROOF.json` records that exact source hash. `scheduling-candidate/commands.json` supplies the recorded compile argv. Replaying that command with only the output path changed produced **exactly the frozen object hash**. This establishes source/compile provenance more strongly than inspecting source filenames or embedded strings. The byte-for-byte source copy is `baseline/vulkan_pipeline_cache.cc`.

Frozen pipeline header: `scheduling-candidate/src/xenia/gpu/vulkan/vulkan_pipeline_cache.h`. The original scheduling include remains first among Xenia source overlays. The private `cache-io-native/include/xenia/gpu/shader_storage.h` remains ahead of historical headers. No live main header is promoted ahead of these frozen overlays. `provenance.json` records seven input hashes including both headers, receipts and source; `compile-commands.json` records all flags and include ordering.

## Findings and quantitative evidence

`log-evidence.json` records complete log hashes, session headers and exact lines; these are local captures, not newly observed console behavior.

| Preserved GTA IV session | Logged build | Driver pipeline calls | Inclusive summed wall time | Worst call |
| --- | --- | ---: | ---: | ---: |
| 20261009-181804-UTC | 0.5.8-vulkan.4 | 319 | 113360.095 ms | 1951.610 ms |
| 20261010-134951-UTC | framegen.1 | 327 | 12.836 ms | 0.106 ms |
| 20261010-135211-UTC | framegen.1 | no post-startup interval | unavailable | unavailable |

The old session includes three nonzero pipeline intervals: 9 calls / 473.250 ms / 124.352 ms worst; 187 / 47854.989 / 1254.088; 123 / 65031.856 / 1951.610. These are inclusive times across potentially concurrent workers, not elapsed gameplay stalls, FPS or GPU utilization. Its final explicit exit checkpoint timed out after 1500 ms. That is an exit observation, not evidence of a periodic gameplay save.

The later two sessions report complete reads of **3280332 bytes** from `/app0/cache/core/shaders/local/545407F2.vk.bin`. A complete read does not establish a cache hit for each new pipeline or absence of later compilation. The later session has startup counters reporting zero calls; this measures an early snapshot and is not proof of zero runtime work.

All three captures identify title `545407F2` and `/app0/assets/roms/GTA 4 PT-BR/default.xex`; patch logs identify executable hash `4CBE7EEB2455A159`. Firmware is not established by these captures. None is a framegen.3 timing validation. Readback diagnostics cover sampled draws and cannot be extrapolated to all gameplay draws.

### Disk cache and compilation workers

- Runtime pipeline descriptions and stored descriptions check `pipelines_` before enqueueing. Shader prewarm uses a set and filters already translated variants. No duplicate real-pipeline enqueue or repeated completed-variant translation was established. Placeholder plus real pipeline compilation is intentional and does not prove redundant real work.
- Creation workers are bounded by logical CPU count: auto mode is `max(3 * logical / 4, 1)` with a fallback logical count of six. Explicit counts are clamped. For a detected 16 logical CPUs this formula produces 12 creation workers; this is an arithmetic example, **not a measured console thread count**. Translation workers use a similar limit, additionally clamped to remaining translations, and the calling thread participates. They can coexist with sleeping creation workers. There is no evidence supporting a blind count increase or a new clamp for the current build.
- Scheduling baseline already includes target-specific readiness waits, publication/failure notifications, `EndSubmission(false)` and stable linear deferred retirement. The framegen command processor uses that coordinated maintenance. Reapplying the earlier fixes would be redundant.
- Cache initialization reads through the bounded-size and short-read checks, validates compatibility against the current driver header, recreates the driver cache using accepted initial bytes, then queues stored descriptions. Writer initialization precedes this; a writer initialization failure returns before driver-cache loading. No current failure of that path was demonstrated.
- `SavePipelineCacheSnapshot()` bounds allocation and retries to four attempts, retries `VK_INCOMPLETE`, and writes atomically only after complete data. `ShutdownShaderStorage()` saves; the framegen command processor exposes an explicitly queued snapshot request. No periodic save timer or redundant repeated-save trigger was established in these frozen paths. The exit timeout alone does not justify changing persistence scheduling or removing the snapshot.
- Newly encountered variants still translate synchronously before pipeline configuration. Driver calls can occur synchronously (including placeholders) or on creation workers. Existing aggregate driver timings do not separate translation, target readiness wait, cache initialization and snapshots. This missing separation motivates the telemetry.

## Delivered patch

`src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc` is a copy of the exact frozen source with diagnostics only. `shader-telemetry.patch` contains its unified diff. `shader_stutter_trace.hpp` is the companion standalone helper; copy it or retain the private include path when compiling the copied source. The patch file alone does not embed the companion helper.

New opt-in cvar: `vulkan_shader_stutter_trace`, default **false**. In a controlled diagnostic configuration use:

```toml
[Vulkan]
vulkan_shader_stutter_trace = true
```

No preset or production configuration was edited. Logs use warning level so a normal warning-level capture can see them. Search for `SHADER-STUTTER`.

Seven independent process-lifetime budgets record at most **16 samples each**, **112 total**. Each sample must have inclusive wall duration **>= 8 ms**. Stages: `translate`, `driver-create`, `target-wait`, `global-wait`, `storage-init`, `storage-translate`, `snapshot`. Disabled or exhausted scopes perform no clock reads and produce no logs. Saturating atomic compare/exchange prevents quota overflow under concurrent compilation. Logging exceptions are contained. Target-wait diagnostics run after releasing the creation mutex. Driver-create diagnostics cover only the driver call; translation includes shader module/binding setup. Other stages are intentionally inclusive and can overlap.

Keys: translation and driver creation carry the shader/vertex microcode hash; storage initialization and snapshot carry title ID; storage translation carries requested variant count; waits use zero. The existing logger's thread ID helps distinguish worker and command-processor activity. A vertex hash alone is not a unique pipeline description. This telemetry must not be used to infer duplicate compilation solely from repeated keys. No cache-hit measurement, queue-depth measurement or full trace is claimed. Legacy blocking `EndSubmission(true)` is not separately timed by this patch; explicit no-argument completion waits are timed.

The helper and scope objects do not modify Xenia class fields, virtual layout, readiness predicates, locks, texture bindings, worker counts, async shader policy, pipeline flags, cache contents or persistence semantics.

## Validation and integration

Native compilation completed successfully for the baseline replay and candidate using the existing PS5 toolchain and image `xbox360ps5-canary:latest`. Each had one inherited `-Wswitch` warning in frozen `user_data.h`, unrelated to this patch. No whole-program rebuild was used.

Candidate object: `obj/vulkan_pipeline_cache.cc.o`.

Candidate object SHA-256: `15fec3e9463395dfb448d78351ff3b146d75b546c00a360d7ddeb85a62a21d03`.

The Windows host test compiled with LLVM `clang++.exe`, assertions enabled. It passed disabled clock/log checks, the 7999/8000 us threshold boundary, backward-clock handling, 32 concurrent claimers with 1000 attempts each, the 16-sample cap, seven independent quotas, no clock reads after saturation and exception containment. It tests the actual helper included by the native source. `test-results.json` records its exact command and output.

`verify.py` also verified all **173** baseline object hashes against `native/build.json`, seven provenance inputs, candidate source/helper hashes and the exact baseline replay hash. `verification.json` contains these results. Verification does not execute the PS5 object or validate gameplay.

Parent integration may replace only `vulkan_pipeline_cache.cc.o` with the delivered object in its own private object set, retaining every other frozen override. It must keep its coordinated pipeline-header/command-processor baseline. No new command-processor object or layout change is required. This diagnostic object adds a cvar and standalone helper code; link, symbol selection and hardware verification remain parent work.

Risks: enabled tracing adds two clock reads per unsaturated stage invocation and bounded warning logging on the invoking thread. Log I/O can perturb timing; nested inclusive scopes can overlap. First 16 slow samples are retained per stage, so later slow events after exhaustion are intentionally invisible; budgets reset only with process restart. Default-off still adds a cvar read, scope bookkeeping and inexpensive key access. This is a diagnostic candidate, not a release optimization, and no FPS/stutter improvement is asserted.

For a future controlled run, retain the same game/cache/config and capture the new stage samples alongside frame/pacing timing. Compare command-processor translation/wait/cache samples against worker driver calls. Only then choose a behavior change if a specific avoidable blocking path is demonstrated. No console or network publication was performed by this worker.

## Reproducible commands

From the repository directory, mount all existing inputs read-only and only this worker directory writable:

```powershell
docker run --rm -v 'C:\Users\bruno\Documents\PS5,:/ws:ro' -v 'C:\Users\bruno\Documents\PS5,\Xbox360PS5\build\framegen-stutter-20261010\shader-agent:/ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent:rw' -w /ws/Xbox360PS5 xbox360ps5-canary:latest bash /ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent/compile.sh
python build/framegen-stutter-20261010/shader-agent/verify.py
```

The script uses `/ws/Xbox360PS5/build/canary-ps5` as the recorded compilation working directory. Exact shell compiler invocations follow (generated directly from the preserved argv; no omitted flags).

Baseline replay:

~~~bash
/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk/toolchain/../bin/prospero-clang++ -I/ws/Xbox360PS5/build/performance-refine-20261008/scheduling-candidate/src -I/ws/Xbox360PS5/build/mw3-graphics-20261008/cache-io-native/include -I/ws/Xbox360PS5/build/baseline-cache-20261008/historical/src -I/ws/Xbox360PS5/build/baseline-cache-20261008/include -I/ws/Xbox360PS5/build/dual-renderer-worktree/.deps/xenia-canary/src -I/ws/Xbox360PS5/build/dual-renderer-worktree/include -I/ws/Xbox360PS5/build/dual-renderer-worktree/research/dual-renderer -I/ws/Xbox360PS5/build/dual-renderer/namespaced-gl-sdk-all/include -I/ws/Xbox360PS5/build/dual-renderer/deps/SPIRV-Cross -I/ws/Xbox360PS5/.deps/xenia-canary/third_party/glslang --sysroot=/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk/toolchain/../target -DNDEBUG -DXBOX360PS5_CANARY=1 -DZSTD_TRACE=0 -I/ws/Xbox360PS5/canary/../include -I/ws/Xbox360PS5/canary/../.deps/xenia-canary -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/src -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party/fmt/include -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party/Vulkan-Headers/include -isystem /ws/Xbox360PS5/canary/../platform/ps5/compat -O3 -DNDEBUG -std=gnu++20 -fPIC -march=znver2 -fno-stack-protector -O2 -mavx -DVULKAN_HPP_NO_TO_STRING -DGL_GLEXT_PROTOTYPES=1 -DDUAL_RENDERER_NATIVE_GL=1 -DPS5X360_OPENGL_GAME_RENDERER=1 '-DXBOX360PS5_VERSION="0.5.8-vulkan.4"' -c /ws/Xbox360PS5/build/performance-refine-20261008/scheduling-candidate/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc -o /ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent/obj/baseline-vulkan_pipeline_cache.cc.o
~~~

Candidate:

~~~bash
/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk/toolchain/../bin/prospero-clang++ -I/ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent -I/ws/Xbox360PS5/build/performance-refine-20261008/scheduling-candidate/src -I/ws/Xbox360PS5/build/mw3-graphics-20261008/cache-io-native/include -I/ws/Xbox360PS5/build/baseline-cache-20261008/historical/src -I/ws/Xbox360PS5/build/baseline-cache-20261008/include -I/ws/Xbox360PS5/build/dual-renderer-worktree/.deps/xenia-canary/src -I/ws/Xbox360PS5/build/dual-renderer-worktree/include -I/ws/Xbox360PS5/build/dual-renderer-worktree/research/dual-renderer -I/ws/Xbox360PS5/build/dual-renderer/namespaced-gl-sdk-all/include -I/ws/Xbox360PS5/build/dual-renderer/deps/SPIRV-Cross -I/ws/Xbox360PS5/.deps/xenia-canary/third_party/glslang --sysroot=/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk/toolchain/../target -DNDEBUG -DXBOX360PS5_CANARY=1 -DZSTD_TRACE=0 -I/ws/Xbox360PS5/canary/../include -I/ws/Xbox360PS5/canary/../.deps/xenia-canary -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/src -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party/fmt/include -I/ws/Xbox360PS5/canary/../.deps/xenia-canary/third_party/Vulkan-Headers/include -isystem /ws/Xbox360PS5/canary/../platform/ps5/compat -O3 -DNDEBUG -std=gnu++20 -fPIC -march=znver2 -fno-stack-protector -O2 -mavx -DVULKAN_HPP_NO_TO_STRING -DGL_GLEXT_PROTOTYPES=1 -DDUAL_RENDERER_NATIVE_GL=1 -DPS5X360_OPENGL_GAME_RENDERER=1 '-DXBOX360PS5_VERSION="0.5.8-vulkan.4"' -c /ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent/src/xenia/gpu/vulkan/vulkan_pipeline_cache.cc -o /ws/Xbox360PS5/build/framegen-stutter-20261010/shader-agent/obj/vulkan_pipeline_cache.cc.o
~~~
