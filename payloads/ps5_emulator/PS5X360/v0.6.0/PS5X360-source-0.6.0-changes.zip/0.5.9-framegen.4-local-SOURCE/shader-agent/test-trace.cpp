#include "shader_stutter_trace.hpp"
#include <cassert>
#include <thread>
#include <vector>
#include <iostream>
using namespace shader_stutter;
struct Fake {
  static inline uint64_t now = 0, reads = 0;
  static inline std::atomic<unsigned> reports{0};
  static uint64_t Now() { ++reads; return now; }
  static uint64_t Frequency() { return 1000000; }
  static void Report(Stage, double, uint64_t) { ++reports; }
};
int main() {
  Budget budget;
  { Scope<Fake> s(budget, false, Stage::kTranslate, 1); Fake::now=10000; }
  assert(Fake::reads==0 && Fake::reports==0);
  Fake::now=0;
  { Scope<Fake> s(budget, true, Stage::kTranslate, 1); Fake::now=7999; }
  assert(Fake::reports==0);
  Fake::now=0;
  { Scope<Fake> s(budget, true, Stage::kTranslate, 1); Fake::now=8000; }
  assert(Fake::reports==1);
  Fake::now=10;
  { Scope<Fake> s(budget, true, Stage::kTranslate, 1); Fake::now=9; }
  assert(Fake::reports==1);
  std::atomic<unsigned> accepted{0};
  std::vector<std::thread> threads;
  for(unsigned i=0;i<32;++i) threads.emplace_back([&] {
    for(unsigned j=0;j<1000;++j) if(budget.Claim(Stage::kTranslate)) ++accepted;
  });
  for(auto& t:threads) t.join();
  assert(accepted==15 && budget.Exhausted(Stage::kTranslate));
  auto reads=Fake::reads;
  { Scope<Fake> s(budget, true, Stage::kTranslate, 1); Fake::now=90000; }
  assert(Fake::reads==reads);
  for(size_t i=1;i<size_t(Stage::kCount);++i) {
    for(unsigned j=0;j<16;++j) assert(budget.Claim(Stage(i)));
    assert(!budget.Claim(Stage(i)));
  }
  struct Throwing : Fake {
    static void Report(Stage,double,uint64_t) { throw 1; }
  };
  Budget separate;
  Fake::now=0;
  { Scope<Throwing> s(separate,true,Stage::kSnapshot,0); Fake::now=10000; }
  std::cout << "PASS disabled=0 clock reads; threshold=8ms; concurrent cap=16/stage; saturated=0 clock reads; exception contained; 7 independent stages\n";
}
