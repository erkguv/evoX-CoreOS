# Presenter / framegen GPU wait audit — 2026-10-10

Scope: static review of frozen `build/framegen-sword-20261010/presenter/vulkan_presenter.cc` and `presenter_sidecar.hpp`, their producer, backend and actual build dependency contracts. No console access, compilation, source modification or performance measurement. Parent owns implementation, including the dormant-FG change. No duplicate implementation diff is supplied because that change alters the same control flow; recommendations below specify its required invariants.

## Findings for the dormant-FG change (review first)

**Bypassing allocation, copy and drain while the pacer is dormant can remove actual work and waits. Approve only with source consumption and snapshot validity handled separately.**

1. **Observe cadence unconditionally on each newly observed producer serial.** Frozen presenter line 1497 evaluates `fg->history && fg->pacing.Observe(...)`. Moving that expression intact before preparation means a fresh or cleared history never calls Observe and can never engage. Compute `engaged/admitted = Observe(...)` first; apply snapshot-history gating only when deciding whether a midpoint is valid. Observe once per new source serial, including dormant frames, not every repaint of the same serial. Preserve producer stamps as the cadence source.
2. **A pinned shared_ptr is a lifetime lease, not an immutable frame.** Frozen lines 1473–1480 acquire a mailbox slot early. Lines 1557–1560 release its consumer lock under the assumption that a private copy is already queued. That assumption is false in the dormant branch. A later consumer (including a UI callback) can acquire another slot and release this slot, allowing a producer write before the delayed ordinary paint is submitted. Keeping `pinned` alive does not stop this.
3. **Recommended dormant fallback:** clear `pinned`, set `snapshot_ready=false`, and unlock `fg_consumer_lock` before entering `paint_one`; let its existing ordinary `ConsumeGuestOutput` path at lines 1686–1705 consume the latest source after acquisition/waits. Do not clear pinned while retaining the consumer lock: that path would lock it again. The observed cadence serial may differ from the later painted serial; record it as a cadence observation, never evidence of a successful snapshot. This restores the normal source path and avoids widening its consume-to-submit window with early FG waits. It does **not** upgrade the existing normal path to immutable-frame semantics.
4. **Clear both validity flags, not only `interpolation_history`.** Set `history=false` as well while dormant (without destroying images). Otherwise assigning `fg->serial` to a dormant source leaves `history` describing an older snapshot; frozen line 1554 can then set `snapshot_ready` for a repeat and sample stale private contents. Alternatively use a distinct snapshot serial/validity flag and require it in every sample-selection path. On re-engagement the first new snapshot establishes history and resets backend flow; only a subsequent valid pair can generate a midpoint. Audit the no-new-serial re-engagement case too.
5. **Retain pending GPU leases and allocations.** Dormancy must not reset `source_keepalive`, `source_copy_submission`, or destroy image/view/descriptor/backend resources without completion. It is safe to clear CPU eligibility flags while prior work completes. On re-entry, retire the old copy lease and all relevant sidecar users before Prepare/Record. Retaining one completed lease until re-entry/teardown is bounded; optional nonblocking `RetireSource(UpdateAndGetCompletedSubmission())` can release it, but do not wait merely to enter dormancy. Preserve `failed` on failed recording/submission; do not revive uncertain tracked layouts by clearing it here.

### Actual producer and normal-path protection

- Actual build header `build/framegen-20261008/include/xenia/ui/vulkan/vulkan_presenter.h:80–95` requires the source's internal state to be fragment shader read / `SHADER_READ_ONLY_OPTIMAL`, and **graphics+compute queue 0** for callbacks.
- `build/dual-renderer-worktree/.deps/xenia-canary/src/xenia/ui/presenter.cc:354–419` refreshes only the writable mailbox slot, publishes after the callback, and chooses the next writable slot excluding the acquired and ready slots. `ConsumeGuestOutput:596–650` holds the consumer mutex; other consumers cannot change acquired while that lock is held. The producer itself does not take that mutex; the acquired-index exclusion supplies its protection.
- Frozen CP `cp/xenia/gpu/vulkan/vulkan_command_processor.cc:1888–1907` inserts the prior-fragment-read → color-attachment-write overwrite barrier for a reused image; lines 1992–2007 restore shader-read layout and call `EndSubmission(true)` before returning it. `EndSubmission:5131–5132` submits on graphics+compute queue 0. Frozen `RefreshGuestOutputImpl:930–955` appends a fence on that same queue and publishes the cadence stamp after successful refresh/signal.
- Frozen ordinary paint `vulkan_presenter.cc:1747–1815,1984–1989,2190–2207` retains `guest_output_image_paint_refs` with paint submission indices, waits before replacing descriptors, and releases obsolete references only after completion. CP cached swap framebuffers likewise track CP submission usage before destruction/replacement. These protect **object and descriptor lifetime**; they do not force producer overwrite to wait for a paint that has not yet been submitted.
- Queue-0 barriers protect an earlier **queued** read against a later queued overwrite. They cannot protect a read recorded/submitted after an intervening producer write. Normal Consume releases its lock before UI callbacks and final submit too. Its current code does not prove immunity to a callback that consumes a newer source before submission. Late ordinary Consume is the conservative compatibility fallback, not proof that callbacks cannot reorder ownership. For a guaranteed exact frame, retain the existing queued snapshot strategy or introduce a separately reviewed producer/consumer handoff; do not hold the mailbox mutex through callbacks that can Consume.

## Wait inventory and bounded recommendations

| Location in frozen presenter | Reason | Recommendation / likely benefit |
|---|---|---|
| 1488: AwaitAll on every new serial | Retire sidecar users, source copy, and implicitly the snapshot command-pool slot | Dormant bypass is the first useful change. Engaged path remains serialized unless explicit tracking replaces this wait. |
| 1568: AwaitMax pending | Command-pool, command buffer and acquire-semaphore ring reuse | Keep. Snapshot submission consumes a ring index too; a targeted drain must also guard the snapshot slot before its reset at 1534. |
| 1610–1613: configurable queue idle | Historical present-semaphore workaround | Cvar defaults **false** at 55–59; no evidence it is currently enabled. If enabled, try false locally: this source already has per-image present semaphores. Keep the override available for driver trouble. |
| 1786,1849,1963 | Descriptor, intermediate-image and pipeline replacement | Keep their resource-specific thresholds; no unconditional safe deletion is shown. |
| 607,1335–1341,159–160 | Resize/reconnect/destruction and ancillary timelines | Preserve lifecycle drains. Not the same as a steady-state frame stall. |
| 1618: AcquireNextImage UINT64_MAX; 2392–2394 sleep_until | FIFO capacity / deliberate midpoint hold | These may still block after other waits disappear. Removing them is a separate pacing/latency change. |

### Safe targeted threshold for an engaged snapshot

The available API is `GPUCompletionTimeline::AwaitSubmissionAndUpdateCompleted(uint64_t) -> bool`, inline in the actual dependency `build/dual-renderer-worktree/.deps/xenia-canary/src/xenia/ui/gpu_completion_timeline.h:55–74`. It polls completion first, waits only if necessary, and rechecks for failed waits. This is a fence-backed CPU submission counter, **not** a Vulkan timeline semaphore; no new device extension or frozen class member is required.

For upcoming paint-timeline submission `U` and `N` paint ring entries, require:

```
C = last successfully submitted snapshot copy/compute
R = last successfully submitted draw actually sampling any private sidecar image
B = U - min(U, N)                 // previous submission using slot U % N
T = max(C, R, B)
```

Wait for `T` before snapshot command-pool reset, mapped-constant writes, overwrite or same-size preparation. Include `source_copy_submission` explicitly as a lease bound if it is not identical to C. Every bound must be 0 or a **successfully submitted** index `< U`; a retained lease for an aborted upcoming submission is not a legal wait target. Abort/fail the FG path without reusing resources if the bool wait fails. Distinguish a lost device from a recoverable wait failure using available `VulkanDevice::IsLost()`.

Proof: submission indices increase only after successful AcquireFenceAndSubmit. All these commands are on queue 0. Completed >= C retires copy/compute, the old source lease, and all backend constants/query/image users in that recording. Completed >= R retires all private-image paint readers; R must advance for midpoint, ordinary real, **and repeats**, even when new_frame=false. Completed >= B retires the prior command pool/acquire-semaphore ring occupant. Resource dependencies/barriers still stay in Record; host completion is not a replacement for memory dependencies. Reallocation may conservatively keep AwaitAll; retain full lifecycle drains.

Track R from the actual `!i && snapshot_ready` descriptor selection at lines 2083–2088, publish its captured submission index only after successful paint submit (2280–2297), and never infer it from `new_frame`, `effect_count`, present acceptance or the next upcoming index. Track C after successful copy submit (1541–1547), independently of effect_count. Add fields only to the serial sidecar, reset them only after retirement. A single combined last-sidecar-use field is also sufficient if every successful copy/compute and every actual sampling draw updates it.

This is a **conservative sufficient resource threshold**, not the mathematically minimal per-image/UBO threshold. It may exclude a UI-only tail, but when the latest paint samples the snapshots, R=U-1 and it equals AwaitAll. Do not claim this alone eliminates engaged-path stutter. Since dormant bypass removes the common idle path entirely, defer this tracking change unless measured waits justify it.

Fallback if the reviewed dependency API is absent in another build, tracking coverage cannot be proved, or the queue-0 contract changes: retain AwaitAll for engaged reuse. For a failed wait, stopping safely is the fallback; blindly attempting the same overwrite after another wait is not. A producer on another queue needs explicit semaphore synchronization and possibly ownership transfer; a queue-0 refresher fence cannot certify it.

### Present idle workaround

Connection creates one present semaphore per swapchain image (858–882). Each submit selects it by acquired image index (2268–2278), waits the acquire semaphore, then passes that same present semaphore to QueuePresent (2315–2327). Thus the normal reuse mechanism is already implemented for both paints. It needs no maintenance1 or timeline extension and also works with a different present queue family.

[The Khronos reuse guide](https://docs.vulkan.org/guide/latest/swapchain_semaphore_reuse.html) confirms that reacquisition plus the acquire wait makes per-image present-semaphore reuse safe. A render fence alone does not certify presentation completion. Disable an enabled steady-state workaround through the existing cvar first; preserve its driver fallback. Do not remove lifecycle idle waits as part of that change: unextended presentation-resource teardown has separate limitations described in the same guide. No runtime config was read and no active queue-idle cost was measured.

## Repeat UI and independent pacer waiting

- Frozen lines 1516–1519 drop **all** same-serial paints while Engaged, including execute_ui_drawers=true. FramegenDrawUI returns requested (sidecar:17), so overlays on a generated new frame execute, but an explicit same-serial UI request is dropped. Gate repeat suppression on `!execute_ui_drawers`; allow a single ordinary repaint for an explicit UI request, with normal ownership and successful-real-present accounting. UI repaints spend refresh budget; do not reset the producer pacer or generate a new midpoint for them. Track their sidecar sampling if using the threshold optimization. `ui_skips`/`deferred_ui` names are stale relative to the helper's current behavior.
- `pacing_adapter.hpp:45–50` resets Engaged after source tick gap > 8. At source 60 Hz this is >133 ms in source-clock terms, not a guaranteed wall-clock deadline. `vendor/ps5_framegen_pacing.h:101–102,139–148,172–183` clears its interval window on gaps and needs 8 new **intervals** before engagement; the adapter also needs an initial stamp. Rate/extent changes, missing stamp (64-entry retention in source_clock.hpp), inactive mailbox and explicit Reset restart warmup independently of GPU waits.
- Consequently retaining the existing source 8-tick gap/reset policy can still produce waiting for cadence qualification and temporary ordinary-only output after pause/load, even if every GPU drain is optimized. Do not conflate that with a GPU fence stall or shorten it without reviewing its cadence and UI purpose. The upstream safety pause (10–160 seconds) is a third independent mechanism.

## Review gates for the parent

1. Dormant first frame, steady no-room game, dormant repeat, dormant → engaged → dormant → engaged: Observe progresses; no stale snapshot descriptor selected; first engaged pair bootstraps correctly.
2. UI callback consumes a newer mailbox slot during a dormant repaint: ordinary fallback uses baseline handoff; no assertion that the early pinned picture is immutable. GPU source refs survive completion and zero-effect paints do not create untracked GPU uses.
3. Resize/inactive mailbox/failed copy or submit with an old source lease pending: no release or reuse of pending resources; lifecycle retirement still runs.
4. If targeted threshold is later added, cover snapshot ring wrap, midpoint and real draws, same-serial UI repeats, and a UI-only tail. Never reset a pending pool or an aborted-submission lease.

Evidence is static only. No claim of measured improvement, hardware correctness or full build compatibility.

## Frozen source identity

- `vulkan_presenter.cc` SHA-256: `39815d82c7dcf1bcd94cc45049bd55867ad58128618eded3a2ac46a23809a580`
- `presenter_sidecar.hpp` SHA-256: `6c5aa45f60d1c37bf0d3190417d5d2d3f758b1d0249cd0b234a1474846a51c3c`
