"""Install the stutter/pacing local candidate (native/build.json) on the PS5 (192.168.0.19) over FTP.

Refuses while PS5X360 is open. Backs up the installed eboot.bin and VERSION, checks that the
installed image is the verified working framegen.3 baseline, then uploads the eboot (temporary
name, verified, renamed) and VERSION.
usage: python deploy.py
"""
from pathlib import Path
import datetime
import ftplib
import hashlib
import importlib.util
import io
import json
import socket

HOST = '192.168.0.19'
here = Path(__file__).resolve().parent
root = here.parents[1]
native = here / 'native'
base = root / 'build/framegen-sword-20261010/native'  # user-confirmed working baseline
proof = json.loads((native / 'build.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()

spec = importlib.util.spec_from_file_location('verify', root / 'tools/deploy-native-probe.py')
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)
image = (native / 'eboot.bin').read_bytes()
assert sha(image) == proof['native_sha256']

for port in range(8360, 8368):
    with socket.socket() as s:
        s.settimeout(.3)
        if s.connect_ex((HOST, port)) == 0:
            raise SystemExit('PS5X360 is open (settings page answering): close it first')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
with ftplib.FTP() as f:
    f.connect(HOST, 2121, timeout=30)
    f.login()
    sandbox = []
    f.retrlines('LIST /mnt/sandbox', sandbox.append)
    if any('PPSA50011' in line for line in sandbox):
        raise SystemExit('PS5X360 is still mounted: close it first')
    logs = []
    f.retrlines('LIST /data/homebrew/PPSA50011/logs', logs.append)
    clock_name = '/data/homebrew/PPSA50011/.deploy-clock-' + stamp
    f.storbinary('STOR ' + clock_name, io.BytesIO(b'clock probe\n'))
    try:
        clock_rows = []
        f.retrlines('LIST /data/homebrew/PPSA50011', clock_rows.append)
        clock_parts = next(s.split(None, 8) for s in clock_rows if len(s.split(None, 8)) == 9 and s.split(None, 8)[8] == clock_name.rsplit('/', 1)[1])
        if ':' not in clock_parts[7]:
            raise RuntimeError('Cannot determine console clock')
        pc_now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
        now = datetime.datetime.strptime(f'{pc_now.year} {clock_parts[5]} {clock_parts[6]} {clock_parts[7]}', '%Y %b %d %H:%M')
        console_clock_offset = (now - pc_now).total_seconds()
    finally:
        f.sendcmd('DELE ' + clock_name)
    for entry in logs:
        parts = entry.split(None, 8)
        if len(parts) < 9 or not parts[0].startswith('-') or ':' not in parts[7]:
            continue
        when = datetime.datetime.strptime(f'{now.year} {parts[5]} {parts[6]} {parts[7]}', '%Y %b %d %H:%M')
        if abs((now - when).total_seconds()) < 150:
            raise RuntimeError(f'Emulator still active (log {parts[8]} written at {parts[7]} UTC)')
    f.cwd('/data/homebrew/PPSA50011')

    def read(name):
        b = io.BytesIO()
        f.retrbinary('RETR ' + name, b.write, blocksize=1024 * 1024)
        return b.getvalue()

    previous = {'eboot.bin': read('eboot.bin'), 'VERSION': read('VERSION')}
    verify.verify_eboot(previous['eboot.bin'], (base / 'eboot.bin').read_bytes(), (base / 'eboot.elf').read_bytes())
    backup = here / 'console-backups' / stamp
    backup.mkdir(parents=True)
    for name, data in previous.items():
        (backup / name).write_bytes(data)

    temporary, kept = f'eboot-framegen-{stamp}.new', f'eboot-before-framegen-{stamp}.bak'
    f.storbinary('STOR ' + temporary, io.BytesIO(image), blocksize=1024 * 1024)
    verify.verify_eboot(read(temporary), image, (native / 'eboot.elf').read_bytes())
    f.rename('eboot.bin', kept)
    try:
        f.rename(temporary, 'eboot.bin')
        f.storbinary('STOR VERSION', io.BytesIO((proof['version'] + '\n').encode()))
        result = verify.verify_eboot(read('eboot.bin'), image, (native / 'eboot.elf').read_bytes())
    except Exception:
        try:
            f.rename('eboot.bin', f'eboot-rejected-framegen-{stamp}.bak')
        except ftplib.error_perm:
            pass
        f.rename(kept, 'eboot.bin')
        f.storbinary('STOR VERSION', io.BytesIO(previous['VERSION']))
        raise
    try:
        setting = read('framegen.conf').decode(errors='replace').strip()
    except ftplib.error_perm:
        setting = '(no framegen.conf: frame generation off until switched on in Settings)'
receipt = dict(installed=True, version=proof['version'], native_sha256=proof['native_sha256'], console_backup=kept,
               local_backup=str(backup), verification=result, framegen_setting=setting, hardware='pending')
(here / 'deployment.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
