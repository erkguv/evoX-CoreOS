# Performance findings, 2026-10-10

## Evidence and limits

The user's PC reports an AMD Ryzen 9 3900X, 12 cores and 24 logical processors. Sony specifies the original PS5 CPU as Zen 2, 8 cores/16 threads, up to 3.5 GHz: https://blog.playstation.com/archive/2020/03/18/unveiling-new-details-of-playstation-5-hardware-technical-specs/ . Core counts alone do not predict an emulator benchmark; actual clocks, driver, rendering backend, settings and scenes must be controlled.

The port translates Xbox 360 CPU instructions and Xenos GPU behavior, compiles shaders, manages guest/host memory and uses a console-adapted Vulkan driver. Native PS5 game throughput or GPU TFLOPS cannot establish Xenia performance. The current evidence does not identify a single bottleneck for every title.

Recent framegen.3 Bully logs contain average measured frame-generation GPU costs around 0.53–1.07 ms across reported sample windows. This does not include CPU compilation or CPU fence/presentation waits. Consequently these samples do not prove that interpolation arithmetic alone explains all stutter.

The shader audit found an older GTA IV capture with 319 driver creation calls totalling 113360 ms of inclusive wall time and a worst call of 1952 ms. Workers can overlap, so this total is not gameplay stall duration. A later framegen.1 capture reports 327 calls totalling 12.836 ms, demonstrating that earlier timing cannot be assumed for today's cache. These are different historical sessions, not a controlled before/after benchmark. See shader-agent/AUDIT.md.

## Implemented changes

1. Remove snapshot allocation/copies and paint-timeline drains when automatic frame generation is dormant.
2. Reject new serials without refresh credit before optical flow or real presentation.
3. Keep sparse compensated jitter engaged; qualify slower game modes using two stable dormant windows and a frozen throughput reference.
4. Preserve safety backoff across missing telemetry and inactive mailboxes.
5. Add bounded timing that distinguishes active snapshot waits, shader translation, driver creation, target/global waits, initialization, prewarm and snapshot persistence.

These changes target demonstrated code paths. They do not bypass necessary GPU ownership/barriers, discard shaders or remove game timing limits. Active snapshot retirement remains conservative until measurements justify a separately tracked resource ring.

## Hardware comparison still required

Use the same save, camera, scene, renderer settings and framegen setting. Keep detailed logs disabled. Compare game FPS, output/generated counters and frame-time spikes separately. Compare first-pass shader compilation with repeated traversal after cache warming. Use optional bounded shader tracing for one reproduction, then remove shader-trace.conf and restart.

The local candidate was installed after the user closed the emulator and the inactivity checks passed. Mapped ELF/dynamic segments were verified over FTP; framegen.3 is preserved in a console and local rollback backup. Gameplay and performance validation remain pending.
