# PS5X360 0.5.9-framegen.4-local

Local candidate based on the user-confirmed framegen.3 executable. Not a public release.

## Changes

- Automatic frame generation sustains sparse, compensated one-tick jitter after strict cadence qualification. Irregular motion, stopped producers and genuine slowdown still fall back to normal presentation.
- Warmup and dormant presentation no longer allocate/copy frame-generation snapshots or drain the paint GPU timeline. They use the existing late mailbox consumption path.
- Frame-generation image recreation preserves the already qualified producer cadence; visual history still resets. Pending GPU leases and active-path retirement remain intact.
- New submissions with no refresh credit skip both presentation and interpolation, instead of spending extra GPU work. A fresh visual pair is required on resumption.
- Menu-to-game cadence changes can qualify after 16 stable dormant intervals meeting the frozen producer-throughput reference. Missing timestamps and inactive mailboxes suspend admission while retaining the slowdown backoff.
- One presentation timing summary per 600 source arrivals separates dormant frames and active snapshot waits. These are CPU wall-time waits, not game CPU utilization or physical scanout measurements.
- Optional shader timing identifies translation, driver creation, pipeline waits, storage initialization/prewarm and cache snapshots. Disabled by default; it reports operations lasting at least 8 ms with a maximum of 16 records per stage, 112 per process.

## Validation

The original presenter, launcher and pipeline-cache source/recipes reproduce the baseline objects byte for byte. Other object hashes are checked against the working executable. Native ELF segment/relocation checks and signing are required by the build scripts.

Pacing host tests cover compensated jitter, strict admission, repeated/zero ticks, actual refresh budgets, failed presents, 30-to-60, 60-to-60, 60-to-120, irregular cadence, gaps, rollback, missing stamps, slowdown and preserved/doubled safety backoff. Tests also passed ASan/UBSan in the pacing agent's run.

Installed on the user's PS5 with mapped ELF/dynamic segment verification and a rollback backup; see deployment.json. Console gameplay and performance validation are pending. No universal stutter elimination or 60 FPS gameplay result is claimed. Kinect, Bully file pooling, DLC and multidisc objects are retained from the working baseline.

## Local update

This package contains an executable update, not a fresh complete installation. Close PS5X360 fully before copying `PPSA50011/eboot.bin` and `PPSA50011/VERSION` into the existing installation. Preserve the working executable for rollback. Games, profiles, saves and caches are not included.

Frame generation still uses the existing `framegen.conf` setting. Optional shader capture: create `/data/homebrew/PPSA50011/shader-trace.conf` containing exactly `enabled=true`, restart, reproduce a stutter, then remove the file. Timings appear in the normal per-game logs; detailed logging is not required. Timing can perturb execution while the bounded capture is active.

## Rebuild

With the repository parent mounted at `/ws` in `xbox360ps5-radv-buildenv`, run `build.py`, `compile_trace.py`, then `finish_trace.py`. The last step integrates the optional trace object and relinks/signs the candidate. `build.py` alone produces the pacing/presentation candidate without shader capture.

Upstream optical-flow shaders and the frame-generation module are unchanged. GPL and embedded AMD notices are retained; see COPYING and PROVENANCE.json.
