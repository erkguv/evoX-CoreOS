"""Move the frame generation row from the General settings page into the Performance sub-page.

Edits build/menu-perf-20261009/launcher.cpp in place (a copy of the Codex candidate
build/continuation-20261009/menu/launcher.cpp). No Settings field or Launcher member is added:
the row is a sentinel entry (-1) in category_rows_, so main and launcher keep their ABI.
"""
from pathlib import Path

path = Path(__file__).resolve().parent / 'launcher.cpp'
s = path.read_text(encoding='utf-8')


def replace(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:80], s.count(old))
    s = s.replace(old, new)


# Startup value of the switch, read before anything writes the file.
replace('''bool FramegenRequested() { return FramegenChoice(); }
bool SetFramegenRequested(bool enabled) {
''', '''bool FramegenRequested() { return FramegenChoice(); }
// What the presenter of this process read: a different choice restarts on close.
bool FramegenAtStart() {
  static const bool at_start = FramegenChoice();
  return at_start;
}
// The Performance page shows this sentinel row after the table's own options.
constexpr int kFramegenRow = -1;
bool SetFramegenRequested(bool enabled) {
  FramegenAtStart();
''')

# General page: back to its 13 rows.
replace('      const int rows = 14;\n', '      const int rows = 13;\n')
replace('''      if (settings_row_ == 13 && (key == Key::cross || key == Key::left || key == Key::right)) {
        if (SetFramegenRequested(!FramegenRequested())) restart_ = true;
        else message_ = FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.", "No se pudo guardar la configuración.");
      }
''', '')
replace('''      {Tr("Reiniciar o emulador"), "", Tr("Fecha e abre o emulador de novo.")},
      {FramegenText("Geração de frames (teste)", "Frame generation (test)", "Generación de fotogramas (prueba)"),
       FramegenRequested() ? FramegenText("Ligada", "On", "Activada") : FramegenText("Desligada", "Off", "Desactivada"),
       FramegenText("Reinicia o emulador. Teste para jogos estáveis a 30 FPS em tela de 60 Hz. Adiciona latência; não acelera a simulação do jogo.",
                    "Restarts the emulator. Test for steady 30 FPS games on a 60 Hz display. Adds latency; does not speed up game simulation.",
                    "Reinicia el emulador. Prueba para juegos estables a 30 FPS en una pantalla de 60 Hz. Añade latencia; no acelera la simulación.")}};
  for (int n = 0; n < 14; ++n) {''', '''      {Tr("Reiniciar o emulador"), "", Tr("Fecha e abre o emulador de novo.")}};
  for (int n = 0; n < 13; ++n) {''')
replace('  c.Wrapped(rows[settings_row_].about, x + 56, 728, 20, kBody, 750);\n'
        '  if (!message_.empty()) c.Text(message_, x + 56, 786, 18, kWarning, 1, 0, 750);\n',
        '  c.Wrapped(rows[settings_row_].about, x + 56, 684, 20, kBody, 750);\n')

# Performance sub-page: append the sentinel row.
replace('''              if (Options()[size_t(n)].category == category_) category_rows_.push_back(n);
''', '''              if (Options()[size_t(n)].category == category_) category_rows_.push_back(n);
            if (category_ == 1) category_rows_.push_back(kFramegenRow);
''')
replace('''      if ((key == Key::left || key == Key::right || key == Key::cross) && rows)
        ChangeOption(Options()[size_t(category_rows_[size_t(option_row_)])], key == Key::left ? -1 : 1);
''', '''      if ((key == Key::left || key == Key::right || key == Key::cross) && rows) {
        if (category_rows_[size_t(option_row_)] == kFramegenRow) {
          if (!SetFramegenRequested(!FramegenRequested()))
            SetMessage(FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.",
                                    "No se pudo guardar la configuración."));
        } else {
          ChangeOption(Options()[size_t(category_rows_[size_t(option_row_)])], key == Key::left ? -1 : 1);
        }
      }
''')
replace('''  if (StartOptionsDiffer(settings_, started_)) restart_ = true;
''', '''  if (StartOptionsDiffer(settings_, started_) || FramegenRequested() != FramegenAtStart()) restart_ = true;
''')

# Drawing the Performance sub-page.
replace('''  for (int n = first; n < rows && n < first + shown; ++n) {
    const Option& option = options[size_t(category_rows_[size_t(n)])];
    const float y = 156 + (n - first) * 48.0f;
    const bool focused = n == option_row_;
    c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);
    if (focused) c.Edge(x + 40, y, 780, 44, kAccent, 0.9f, 10, 2.0f);
''', '''  for (int n = first; n < rows && n < first + shown; ++n) {
    const float y = 156 + (n - first) * 48.0f;
    const bool focused = n == option_row_;
    if (category_rows_[size_t(n)] == kFramegenRow) {
      c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);
      if (focused) c.Edge(x + 40, y, 780, 44, kAccent, 0.9f, 10, 2.0f);
      c.Text(FramegenText("Geração de frames (teste)", "Frame generation (test)", "Generación de fotogramas (prueba)"),
             x + 64, y + 10, 22, focused ? kText : kBody, 1.0f, 0, 440);
      const bool on = FramegenRequested();
      c.Text(on ? FramegenText("Ligada", "On", "Activada") : FramegenText("Desligada", "Off", "Desactivada"),
             x + 796, y + 10, 22, focused ? kAccent : on ? kWarning : kMuted, 1.0f, 2, 320);
      continue;
    }
    const Option& option = options[size_t(category_rows_[size_t(n)])];
    c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);
    if (focused) c.Edge(x + 40, y, 780, 44, kAccent, 0.9f, 10, 2.0f);
''')
replace('''  const Option& option = options[size_t(category_rows_[size_t(option_row_)])];
  c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
''', '''  if (category_rows_[size_t(option_row_)] == kFramegenRow) {
    c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
    c.Wrapped(FramegenText(
        "Cria um quadro intermediário entre dois quadros do jogo: um jogo estável a 30 FPS aparece a 60 numa tela de 60 Hz. Não acelera o jogo, acrescenta cerca de um quadro de atraso e pode borrar o HUD e movimentos rápidos. O contador de FPS mostra Game, Output e FG.",
        "Creates an in-between frame from two game frames: a steady 30 FPS game is shown at 60 on a 60 Hz display. It does not speed up the game, adds about one frame of latency and can blur the HUD and fast motion. The FPS counter shows Game, Output and FG.",
        "Crea un fotograma intermedio entre dos fotogramas del juego: un juego estable a 30 FPS se muestra a 60 en una pantalla de 60 Hz. No acelera el juego, añade cerca de un fotograma de latencia y puede difuminar el HUD y los movimientos rápidos. El contador de FPS muestra Game, Output y FG."),
        x + 56, 632, 20, kBody, 750);
    c.Text(std::string(Tr("Recomendado: ")) + FramegenText("Desligada", "Off", "Desactivada"), x + 56, 860, 20, kAccent, 1.0f, 0, 750);
    c.Text(Tr("O emulador reinicia para aplicar, ao fechar as configurações."), x + 56, 892, 20, kMuted, 1.0f, 0, 750);
    float hint = c.Hint('x', Tr("Alterar"), x + 56, 1004);
    hint = c.Hint('o', Tr("Voltar"), hint, 1004);
    c.Hint('v', Tr("Mover"), hint, 1004);
    return;
  }
  const Option& option = options[size_t(category_rows_[size_t(option_row_)])];
  c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
''')

path.write_text(s, encoding='utf-8')
print('edited', path)
