"""Read-only audit of local candidate, package and current PS5 image."""
from pathlib import Path
import datetime, ftplib, hashlib, importlib.util, io, json, zipfile

work = Path(__file__).resolve().parent
root = work.parents[1]
sha = lambda b: hashlib.sha256(b).hexdigest()
proof = json.loads((work / 'native/build.json').read_text())
report = {'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'expected_version': proof['version'], 'console_mutated': False}
image = (work / 'native/eboot.bin').read_bytes()
assert sha(image) == proof['native_sha256']
assert sha((work / 'launcher.cpp').read_bytes()) == proof['launcher_source_sha256']
assert sha((work / 'native/obj/launcher.cpp.o').read_bytes()) == proof['launcher_object_sha256']
for name, digest in proof['unchanged_objects'].items():
    assert sha((work / 'native/obj' / name).read_bytes()) == digest, name
report['local_image_sha256'] = sha(image)
report['retained_objects_verified'] = len(proof['unchanged_objects'])
with zipfile.ZipFile(work / 'package/PPSA50011.zip') as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('PPSA50011/MANIFEST.json'))
    for name, entry in manifest.items():
        data = z.read('PPSA50011/' + name)
        assert sha(data) == entry['sha256'] and len(data) == entry['bytes'], name
    assert z.read('PPSA50011/eboot.bin') == image
    assert z.read('PPSA50011/VERSION').decode().strip() == proof['version']
report['package_manifest_verified_files'] = len(manifest)
spec = importlib.util.spec_from_file_location('image_verify', root / 'tools/deploy-native-probe.py')
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)
try:
    with ftplib.FTP() as ftp:
        ftp.connect('192.168.0.19', 2121, timeout=15)
        ftp.login()
        ftp.cwd('/data/homebrew/PPSA50011')
        def read(name):
            out = io.BytesIO()
            ftp.retrbinary('RETR ' + name, out.write, blocksize=1024 * 1024)
            return out.getvalue()
        report['remote_version'] = read('VERSION').decode().strip()
        report['remote_release_version'] = json.loads(read('RELEASE.json'))['version']
        remote = read('eboot.bin')
        report['console_image_verification'] = verify.verify_eboot(
            remote, image, (work / 'native/eboot.elf').read_bytes())
        report['remote_bytes_sha256'] = sha(remote)
        report['remote_matches_expected_version'] = report['remote_version'] == proof['version']
        for name in ('framegen.conf', 'render-target-fsi.conf'):
            try:
                report[name] = read(name).decode().strip()
            except ftplib.error_perm as exc:
                report[name] = 'absent' if str(exc).startswith('550') else str(exc)
        try:
            lines = []
            ftp.retrlines('LIST /data/homebrew/PPSA50011/logs', lines.append)
            report['listed_game_log_name_sample'] = sorted([line.split(maxsplit=8)[-1] for line in lines
                if len(line.split(maxsplit=8)) == 9 and 'Game-' in line])[-10:]
        except ftplib.Error as exc:
            report['log_listing_error'] = str(exc)
except (OSError, ftplib.Error) as exc:
    report['console_access_error'] = str(exc)
(work / 'current-verification.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
