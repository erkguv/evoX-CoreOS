"""Add an "Accurate render targets (FSI)" switch to Settings > Performance (after frame generation).

Xenia's Vulkan "fsi" render-target path (fragment shader interlock; "ROV" on Direct3D 12) emulates the
Xbox 360 EDRAM in shaders: slower, more exact blending and formats. Kept outside Settings (shipped ABI):
the choice lives in /app0/render-target-fsi.conf and Settings::Apply sets cvars::render_target_path_vulkan
from the value read when the process started (the render target cache reads it once, at GPU setup).
Edits build/menu-perf-20261009/launcher.cpp in place; run after apply_edit.py.
"""
from pathlib import Path

path = Path(__file__).resolve().parent / 'launcher.cpp'
s = path.read_text(encoding='utf-8')


def replace(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:80], s.count(old))
    s = s.replace(old, new)


replace('DECLARE_string(readback_resolve);\n',
        'DECLARE_string(readback_resolve);\nDECLARE_string(render_target_path_vulkan);\n')

# Helpers before Settings::Apply.
replace('const char* const kHeadingFont = "/app0/assets/fonts/NotoSans-SemiBold.ttf";\n',
        '''const char* const kHeadingFont = "/app0/assets/fonts/NotoSans-SemiBold.ttf";
// Accurate render targets: Xenia's Vulkan "fsi" path. Kept outside Settings to
// preserve the shipped title and launcher ABI; read once per process, before
// the GPU is set up (the render target cache takes the path at that point).
const char* const kFsiFile = "/app0/render-target-fsi.conf";
bool& FsiChoice() {
  static bool requested = [] {
    std::ifstream input(kFsiFile);
    std::string line;
    if (!std::getline(input, line)) return false;
    if (!line.empty() && line.back() == '\\r') line.pop_back();
    return line == "render_target_path_vulkan=fsi";
  }();
  return requested;
}
bool FsiAtStart() {
  static const bool at_start = FsiChoice();
  return at_start;
}
bool SetFsiRequested(bool enabled) {
  FsiAtStart();
  const char* temporary = "/app0/render-target-fsi.conf.new";
  std::ofstream output(temporary, std::ios::trunc);
  output << "render_target_path_vulkan=" << (enabled ? "fsi" : "fbo") << "\\n";
  output.close();
  if (!output) { std::remove(temporary); return false; }
  if (std::rename(temporary, kFsiFile) != 0) { std::remove(temporary); return false; }
  XELOGW("Accurate render targets (FSI) requested={} (restart required)", enabled);
  FsiChoice() = enabled;
  return true;
}
''')

replace('  cvars::clear_memory_page_state = clear_pages != 0;\n',
        '''  cvars::clear_memory_page_state = clear_pages != 0;
  // The core falls back to host render targets by itself when the device lacks
  // fragment shader interlock; the pipeline storage then keeps its .fbo name.
  cvars::render_target_path_vulkan = FsiAtStart() ? "fsi" : "";
''')

replace('constexpr int kFramegenRow = -1;\n', 'constexpr int kFramegenRow = -1;\nconstexpr int kFsiRow = -2;\n')
replace('|| FramegenRequested() != FramegenAtStart()) restart_ = true;',
        '|| FramegenRequested() != FramegenAtStart() ||\n      FsiChoice() != FsiAtStart()) restart_ = true;')
replace('            if (category_ == 1) category_rows_.push_back(kFramegenRow);\n',
        '            if (category_ == 1) { category_rows_.push_back(kFramegenRow); category_rows_.push_back(kFsiRow); }\n')
replace('''        if (category_rows_[size_t(option_row_)] == kFramegenRow) {
          if (!SetFramegenRequested(!FramegenRequested()))''',
        '''        if (category_rows_[size_t(option_row_)] == kFsiRow) {
          if (!SetFsiRequested(!FsiChoice()))
            SetMessage(FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.",
                                    "No se pudo guardar la configuración."));
        } else if (category_rows_[size_t(option_row_)] == kFramegenRow) {
          if (!SetFramegenRequested(!FramegenRequested()))''')

# Drawing: the row and its description.
replace('''    if (category_rows_[size_t(n)] == kFramegenRow) {
      c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);''',
        '''    if (category_rows_[size_t(n)] == kFsiRow) {
      c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);
      if (focused) c.Edge(x + 40, y, 780, 44, kAccent, 0.9f, 10, 2.0f);
      c.Text(FramegenText("Renderização precisa (FSI, teste)", "Accurate render targets (FSI, test)",
                          "Renderizado preciso (FSI, prueba)"),
             x + 64, y + 10, 22, focused ? kText : kBody, 1.0f, 0, 440);
      const bool on = FsiChoice();
      c.Text(on ? FramegenText("Ligada", "On", "Activada") : FramegenText("Desligada", "Off", "Desactivada"),
             x + 796, y + 10, 22, focused ? kAccent : on ? kWarning : kMuted, 1.0f, 2, 320);
      continue;
    }
    if (category_rows_[size_t(n)] == kFramegenRow) {
      c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);''')
replace('''  if (category_rows_[size_t(option_row_)] == kFramegenRow) {
    c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);''',
        '''  if (category_rows_[size_t(option_row_)] == kFsiRow) {
    c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
    c.Wrapped(FramegenText(
        "Emula a memória de imagem do Xbox 360 dentro dos shaders (o modo ROV do Xenia no PC). Mais fiel em partículas, transparências e formatos de cor raros; mais pesada. Vale para todos os jogos enquanto estiver ligada; se o vídeo do PS5 não tiver o recurso, o modo normal continua.",
        "Emulates the Xbox 360 image memory inside the shaders (Xenia's ROV mode on PC). More faithful particles, transparency and rare color formats; heavier. Applies to every game while on; if the PS5 video driver lacks the feature, the normal mode stays.",
        "Emula la memoria de imagen de la Xbox 360 dentro de los shaders (el modo ROV de Xenia en PC). Más fiel en partículas, transparencias y formatos de color raros; más pesado. Vale para todos los juegos mientras esté activado; si el vídeo de la PS5 no tiene la función, sigue el modo normal."),
        x + 56, 632, 20, kBody, 750);
    c.Text(std::string(Tr("Recomendado: ")) + FramegenText("Desligada", "Off", "Desactivada"), x + 56, 860, 20, kAccent, 1.0f, 0, 750);
    c.Text(Tr("O emulador reinicia para aplicar, ao fechar as configurações."), x + 56, 892, 20, kMuted, 1.0f, 0, 750);
    float hint = c.Hint('x', Tr("Alterar"), x + 56, 1004);
    hint = c.Hint('o', Tr("Voltar"), hint, 1004);
    c.Hint('v', Tr("Mover"), hint, 1004);
    return;
  }
  if (category_rows_[size_t(option_row_)] == kFramegenRow) {
    c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);''')

path.write_text(s, encoding='utf-8')
print('edited', path)
