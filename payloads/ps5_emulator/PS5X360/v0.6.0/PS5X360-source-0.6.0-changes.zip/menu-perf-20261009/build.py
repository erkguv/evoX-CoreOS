"""0.5.9-perf-menu.1: prince-io.1 with the frame generation switch moved to Settings > Performance.

- launcher.cpp.o: recompiled from build/menu-perf-20261009/launcher.cpp with the exact command that
  produced the installed object (build/continuation-20261009/menu/build.json candidate_command);
  the unmodified Codex source is first rebuilt and must match the installed object byte for byte.
- xboxkrnl_io.cc.o (Prince I/O trace) is dropped: the kernel archive's original member links again.
Run in xbox360ps5-radv-buildenv with the parent folder mounted at /ws.
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
import tempfile

root = Path('/ws/Xbox360PS5')
work = Path(__file__).resolve().parent
base = root / 'build/prince-loading-20261009/native'
out = work / 'native'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

assert sha(base / 'eboot.bin') == '5182a5c6cdbae132ca1628925d1e7268a5150ffd8eae7e228e47d43a0bf5e44c'
receipt = json.loads((root / 'build/kinect-update-20261008/final-native/build.json').read_text())
for n, h in receipt['baseline_inputs'].items():
    if Path(n).suffix in ('.o', '.a'):
        assert sha(Path(n)) == h, n

menu = json.loads((root / 'build/continuation-20261009/menu/build.json').read_text())
command = [str(a) for a in menu['candidate_command']]
src_i, obj_i = command.index('-c') + 1, command.index('-o') + 1
installed = sha(base / 'obj/launcher.cpp.o')
with tempfile.TemporaryDirectory() as tmp:
    proof = list(command)
    proof[obj_i] = str(Path(tmp) / 'proof.o')
    subprocess.run(proof, cwd=root, check=True)
    assert sha(proof[obj_i]) == installed == menu['candidate_object_sha256'], 'launcher inputs drifted'

if out.exists():
    shutil.rmtree(out)
(out / 'obj').mkdir(parents=True)
retained = {}
for p in sorted((base / 'obj').glob('*.o')):
    if p.name in ('launcher.cpp.o', 'xboxkrnl_io.cc.o'):
        continue
    shutil.copy2(p, out / 'obj' / p.name)
    retained[p.name] = sha(p)
build = list(command)
build[src_i] = str(work / 'launcher.cpp')
build[obj_i] = str(out / 'obj/launcher.cpp.o')
subprocess.run(build, cwd=root, check=True)

link = ['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)]
subprocess.run(link, check=True)
assert all(sha(out / 'obj' / n) == h for n, h in retained.items())

old, new = b'PS5X360 v0.5.8-vulkan.4', b'PS5X360 v0.5.9'
for name in ('llvm-pie.elf', 'eboot.elf'):
    data = (out / name).read_bytes()
    assert data.count(old + b'\0') == 1, name
    offset = data.index(old + b'\0')
    phoff = struct.unpack_from('<Q', data, 32)[0]
    size, count = struct.unpack_from('<HH', data, 54)
    ph = [struct.unpack_from('<IIQQQQQQ', data, phoff + i * size) for i in range(count)]
    assert any(p[0] == 1 and p[1] == 4 and p[2] <= offset and offset + len(old) + 1 <= p[2] + p[5] for p in ph)
    result = data[:offset] + new + b'\0' * (len(old) + 1 - len(new)) + data[offset + len(old) + 1:]
    for p in ph:
        if p[0] == 1 and p[1] & 1:
            assert result[p[2]:p[2] + p[5]] == data[p[2]:p[2] + p[5]]
    (out / name).write_bytes(result)
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'),
                str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)
image = (out / 'llvm-pie.elf').read_bytes()
assert b'IO_TRACE' not in image, 'the Prince trace object is still linked'
assert 'Geração de frames (teste)'.encode() in image

(out / 'build.json').write_text(json.dumps({
    'version': '0.5.9-perf-menu.2-local',
    'baseline_native_sha256': sha(base / 'eboot.bin'),
    'native_sha256': sha(out / 'eboot.bin'),
    'launcher_source_sha256': sha(work / 'launcher.cpp'),
    'launcher_preimage_object_sha256': installed,
    'launcher_object_sha256': sha(out / 'obj/launcher.cpp.o'),
    'dropped_override': 'xboxkrnl_io.cc.o (Prince I/O trace; archive member links again)',
    'unchanged_objects': retained, 'compile': build, 'link': link, 'hardware': 'pending'}, indent=2))
print('PASS', sha(out / 'eboot.bin'))
