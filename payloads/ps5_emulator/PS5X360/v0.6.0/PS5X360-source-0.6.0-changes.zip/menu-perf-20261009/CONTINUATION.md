# Verified continuation baseline: 0.5.9-perf-menu.2-local

Reviewed on 2026-10-09. This private candidate is the current PS5 installation,
independently checked by downloading its executable and comparing ELF mapped
and dynamic segments against the preserved local image. The FTP service strips
two unmapped metadata segments, so remote and local whole-file hashes differ.
See current-verification.json for the fresh checks and configuration snapshot.

## Canonical artifacts

- Project: `C:\Users\bruno\Documents\PS5,\Xbox360PS5`
- Candidate: `build/menu-perf-20261009/native`
- Executable SHA256: `9d729e2494b30b876521af2e69b32c9f8ba7d8559313d441d61099d3f8dfcb6e`
- Packaged title: `build/menu-perf-20261009/package/PPSA50011.zip`
- Tester folder: `C:\Users\bruno\Desktop\PS5X360-perf-menu2-test-20261009`
- Candidate launcher source: `build/menu-perf-20261009/launcher.cpp`
- Local rollback and deployment receipt: `build/menu-perf-20261009/deployment.json`

The top-level VERSION still says 0.5.8 and the repository has substantial
uncommitted changes. Neither is a reliable description of this private native
candidate. Preserve the candidate's frozen inputs and object lineage; do not
rebuild or publish the mutable root sources as if they reproduce this binary.

## Changes confirmed from candidate source and artifact receipts

- Frame-generation switch is under Settings > Performance. Changing it takes
  effect after the emulator restarts when settings close.
- Game, accepted output presentations and generated-frame counters are retained.
  Repeated presentations of a frozen game image do not establish game progress.
- Accurate render targets (FSI, test) is now selectable under Performance. It
  requests Xenia's fragment-shader-interlock path through a separate config file.
  It is not a general FPS optimization or a proven fix for every texture bug.
- The temporary Prince file-operation diagnostic override was removed; the
  original archive member is used again. 53 other override objects were checked
  against the retained-object hashes.
- Local package CRC, manifest hashes and lengths for all 563 files were checked.

## Current PS5 configuration at the audit

- Installed metadata: `0.5.9-perf-menu.2-local`.
- Frame generation: enabled in `framegen.conf`.
- FSI configuration file: absent, corresponding to the candidate's off default.

## Remaining evidence boundaries and pending work

Installation and package checks do not prove gameplay improvements. FSI rendering
and generated output still need console comparisons in the same scenes.

Additional work exists under `build/prince-fix-20261009` (audio-lock patch and
captured file-operation trace) and `build/bayonetta-host-20261009` (host runner
work). The audit did not establish that these separate artifacts are included
or active in the installed candidate. Review their evidence before integration.
MW3 texture corruption and title loading/input reports remain separate tasks.

No PS5 file was changed and no public release was created during this audit.
