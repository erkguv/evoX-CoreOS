// Host check of dlc_manager.hpp with the four real Battle of Z packages (title 4E4D0860).
// Run by dlc_test.py in xbox360ps5-canary.
#include "dlc_manager.hpp"
#include <cassert>
#include <chrono>
#include <cstdio>
#include <thread>

using namespace xbox360ps5::dlc2;
int main(int argc, char** argv) {
  const fs::path root = argv[1], inbox = argv[2];
  const uint32_t title = 0x4E4D0860;
  // Two installed, the other two only in the inbox (plus inbox copies of the installed ones).
  Found found = Find(title, root, {inbox});
  int active = 0, available = 0;
  for (const auto& item : found.items) {
    std::printf("%-34s %-10s %llu\n", item.name.c_str(),
                item.state == State::active ? "active" : item.state == State::disabled ? "disabled" : "available",
                (unsigned long long)item.bytes);
    active += item.state == State::active;
    available += item.state == State::available;
  }
  std::printf("ignored: other game %d, not DLC %d, not package %d\n", found.other_game, found.not_dlc, found.not_package);
  assert(found.items.size() == 4 && active == 2 && available == 2);
  assert(found.other_game == 1 && found.not_dlc == 1 && found.not_package == 1);
  assert(found.items[0].name == "Goku (Naruto Sage Mode Costume)" || found.items[0].name == "Super Vegito");

  // Disable the first active one, then enable it again.
  const Item first = found.items[0];
  assert(Move(first, root, title, false));
  found = Find(title, root, {inbox});
  int disabled = 0;
  for (const auto& item : found.items) disabled += item.state == State::disabled && item.file == first.file;
  assert(disabled == 1 && !fs::exists(ActiveFolder(root, title) / first.file));
  for (const auto& item : found.items)
    if (item.file == first.file) assert(Move(item, root, title, true));
  assert(fs::exists(ActiveFolder(root, title) / first.file));

  // Install the available ones with the copier.
  found = Find(title, root, {inbox});
  for (const auto& item : found.items) {
    if (item.state != State::available) continue;
    assert(copier().Start(item, root, title));
    while (copier().Busy()) std::this_thread::sleep_for(std::chrono::milliseconds(5));
    assert(copier().TakeResult() == 1);
  }
  found = Find(title, root, {inbox});
  for (const auto& item : found.items) assert(item.state == State::active);
  assert(found.items.size() == 4);
  // Installing again refuses an existing file.
  Item again = found.items[0];
  again.state = State::available;
  again.path = inbox / again.file;
  assert(copier().Start(again, root, title));
  while (copier().Busy()) std::this_thread::sleep_for(std::chrono::milliseconds(5));
  assert(copier().TakeResult() == -1);
  std::puts("PASS dlc manager: list, ignore reasons, disable/enable, install with copy check, no overwrite");
  return 0;
}
