"""0.5.9-kinect-native.1: the installed 0.5.9-readonly-pool.1 build plus the console-hosted
phone camera (HTTPS camera page served by the emulator, Kinect QR code in the settings).

Run in xbox360ps5-radv-buildenv with the parent folder at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-radv-buildenv \
      python3 -u /ws/Xbox360PS5/build/kinect-native-20261009/build.py
- launcher.cpp.o and web_settings.cpp.o: first their recorded sources are rebuilt with their
  recorded commands and must match the installed objects byte for byte; then the edited
  sources (apply_native.py) are compiled with the same commands.
- phone_camera_tls.cpp.o: new, compiled like web_settings.cpp (same headers, so the same
  motion receiver state); mbedTLS 3.6.7 is compiled for the console with
  mbedtls_ps5x360_config.h into mbedtls_*.c.o objects.
- Every other object is the readonly-pool one, unchanged. The display version is patched the
  way the TEST 0.5.9 package was (read-only literals only).
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct
import subprocess
from concurrent.futures import ThreadPoolExecutor

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/bully-loading-20261009/readonly-pool/native'
out = here / 'native'
mbed = root / '.deps/autolog/mbedtls-3.6.7'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
VERSION = '0.5.9-kinect-dlc.3-local'
# Shown in the menu's corner (PS5X360 v<LABEL>) and in the image's version literals, so each
# installed test build can be told apart on the console.
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')

assert sha(base / 'eboot.bin') == json.loads((base / 'build.json').read_text())['native_sha256']
if out.exists():
    shutil.rmtree(out)
(out / 'obj').mkdir(parents=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def with_paths(command, source, obj, extra=()):
    cmd = list(command)
    cmd[1:1] = list(extra)
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(obj)
    for flag in ('-MT', '-MF'):
        if flag in cmd:
            i = cmd.index(flag)
            del cmd[i:i + 2]
    for flag in ('-MD', '-MMD'):
        while flag in cmd:
            cmd.remove(flag)
    return cmd


# Launcher: proof, then the edited source.
launcher_cmd = json.loads((root / 'build/bully-loading-20261009/candidate/native/build.json').read_text())['commands'][1]
assert launcher_cmd[launcher_cmd.index('-c') + 1].endswith('candidate/launcher.cpp'), launcher_cmd
subprocess.run(with_paths(launcher_cmd, root / 'build/bully-loading-20261009/candidate/launcher.cpp', here / 'launcher.proof.o'),
               cwd=root, check=True)
assert sha(here / 'launcher.proof.o') == sha(base / 'obj/launcher.cpp.o'), 'launcher inputs drifted'
launcher_build = with_paths(launcher_cmd, here / 'launcher.cpp', out / 'obj/launcher.cpp.o')
launcher_build = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a for a in launcher_build]
assert f'-DXBOX360PS5_VERSION="{LABEL}"' in launcher_build
subprocess.run(launcher_build, cwd=root, check=True)

# Web settings: proof, then the edited source with the new headers first on the path.
web_cmd = json.loads((root / 'build/kinect-update-20261008/web/compile-receipt.json').read_text())['commands'][1]
subprocess.run(with_paths(web_cmd, root / 'build/kinect-update-20261008/web/web_settings.cpp', here / 'web_settings.proof.o'),
               cwd=root / 'build/canary-ps5', check=True)
assert sha(here / 'web_settings.proof.o') == sha(base / 'obj/web_settings.cpp.o'), 'web settings inputs drifted'
mbed_flags = ['-DMBEDTLS_USER_CONFIG_FILE="mbedtls_ps5x360_config.h"', f'-I{mbed}/include']
web_build = with_paths(web_cmd, here / 'web_settings.cpp', out / 'obj/web_settings.cpp.o', ['-I' + str(here)])
subprocess.run(web_build, cwd=root / 'build/canary-ps5', check=True)
tls_build = with_paths(web_cmd, here / 'phone_camera_tls.cpp', out / 'obj/phone_camera_tls.cpp.o', ['-I' + str(here), *mbed_flags])
subprocess.run(tls_build, cwd=root / 'build/canary-ps5', check=True)

# mbedTLS for the console: the web object's target flags, as C.
cxx = web_cmd[0]
cc = cxx[:-2] if cxx.endswith('++') else cxx
keep = []
i = 1
while i < len(web_cmd):
    a = web_cmd[i]
    if a.startswith('--sysroot') or a.startswith('-march') or a in ('-fPIC', '-fno-stack-protector', '-mavx', '-O2', '-O3', '-DNDEBUG'):
        keep.append(a)
    elif a == '-isystem':
        keep += [a, web_cmd[i + 1]]
        i += 1
    i += 1
c_flags = [cc, '-std=gnu11', *keep, '-I' + str(here), *mbed_flags]
sources = sorted((mbed / 'library').glob('*.c'))


def compile_c(source):
    return subprocess.run([*c_flags, '-c', str(source), '-o', str(out / 'obj' / f'mbedtls_{source.stem}.c.o')],
                          capture_output=True, text=True)


with ThreadPoolExecutor(8) as pool:
    results = list(pool.map(compile_c, sources))
failed = [r.stderr for r in results if r.returncode]
assert not failed, failed[0][-3000:]
print('mbedTLS:', len(sources), 'objects')

subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)
changed = {'launcher.cpp.o', 'web_settings.cpp.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / n) == h for n, h in retained.items())

# Display version as in the TEST 0.5.9 package (read-only literals; code unchanged).
for name in ('llvm-pie.elf', 'eboot.elf'):
    data = bytearray((out / name).read_bytes())
    original = bytes(data)
    phoff = struct.unpack_from('<Q', original, 32)[0]
    size, count = struct.unpack_from('<HH', original, 54)
    headers = [struct.unpack_from('<IIQQQQQQ', original, phoff + n * size) for n in range(count)]
    for old, new in ((b'PS5X360 v0.5.8-vulkan.4', f'PS5X360 {SHORT}'.encode()), (b'BOOT version 0.5.8-vulkan.4', f'BOOT version {SHORT}'.encode()),
                     (b'0.5.8-vulkan.4', SHORT.encode())):
        assert len(new) <= len(old), (old, new)
        needle = b'\0' + old + b'\0'
        assert data.count(needle) == 1, (name, old)
        at = data.index(needle) + 1
        assert any(h[0] == 1 and h[1] == 4 and h[2] <= at and at + len(old) < h[2] + h[5] for h in headers)
        data[at:at + len(old)] = new + b'\0' * (len(old) - len(new))
    for h in headers:
        if h[0] == 1 and h[1] & 1:
            assert data[h[2]:h[2] + h[5]] == original[h[2]:h[2] + h[5]], 'code changed'
    (out / name).write_bytes(bytes(data))
subprocess.run(['python3', str(root / 'build/native-runtime-stage/tools/verify-image.py'), str(out / 'llvm-pie.elf'), str(out / 'eboot.elf')], check=True)
subprocess.run([str(root / 'build/canary-game/host/ps5-native-tool'), 'self', '--sign', '--in', str(out / 'eboot.elf'),
                '--out', str(out / 'eboot.bin'), '--magic', '0x1D3D154F'], check=True)
image = (out / 'llvm-pie.elf').read_bytes()
# The menu builds its label from immediates in code, so look for it in the launcher object.
assert f'PS5X360 v{LABEL}'.encode() in (out / 'obj/launcher.cpp.o').read_bytes(), 'menu version label'
assert b'PS5X360 Kinect camera (this console)' in image and b'camera?k=' in image and b'web-settings.key' in image

(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'launcher_preimage_identical': True, 'web_settings_preimage_identical': True,
    'objects': {n: sha(out / 'obj' / n) for n in ('launcher.cpp.o', 'web_settings.cpp.o', 'phone_camera_tls.cpp.o')},
    'mbedtls_objects': len(sources), 'unchanged_objects': retained,
    'commands': {'launcher': launcher_build, 'web_settings': web_build, 'phone_camera_tls': tls_build, 'mbedtls_c': c_flags},
    'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
