// Host check of phone_camera_tls.cpp: serves on 127.0.0.1 with key "abc123", motion enabled.
// host_test.py drives it as a phone would (TLS trusting only the console authority).
#include "phone_camera_tls.hpp"
#include "xbox360ps5/motion_input.hpp"
#include <chrono>
#include <cstdio>
#include <thread>

int main(int argc, char** argv) {
  xbox360ps5::motion::SetEnabled(true);
  const char* address = argc > 1 ? argv[1] : "127.0.0.1";
  if (!xbox360ps5::phone_tls::Start("/tmp/phone-tls", [address] { return std::string(address); }, "abc123")) {
    std::puts("START FAILED");
    return 1;
  }
  for (int n = 0; n < 200 && xbox360ps5::phone_tls::Url().empty(); ++n) std::this_thread::sleep_for(std::chrono::milliseconds(50));
  std::printf("URL %s\n", xbox360ps5::phone_tls::Url().c_str());
  std::fflush(stdout);
  for (int n = 0; n < 600; ++n) {
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    if (std::FILE* stop = std::fopen("/tmp/phone-tls-stop", "r")) { std::fclose(stop); break; }
  }
  const auto pose = xbox360ps5::motion::Snapshot();
  std::printf("SNAPSHOT tracked=%d session=%u sequence=%u\n", int(pose.tracked), pose.session, pose.sequence);
  return 0;
}
