"""Host check of the console's phone camera HTTPS server (phone_camera_tls.cpp) with mbedTLS.

Run in xbox360ps5-canary with the parent folder at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-canary:latest python3 -u /ws/Xbox360PS5/build/kinect-native-20261009/host_test.py
Builds mbedTLS and the server for the host, then talks to it as a phone would: TLS trusting only
the authority the server made, by IP address; page, modules, probe, key check, pose frames,
keep-alive, parallel connections, certificate reuse and renewal on an address change.
"""
from pathlib import Path
import http.client
import json
import shutil
import ssl
import struct
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
mbed = root / '.deps/autolog/mbedtls-3.6.7'
work = Path('/tmp/host-tls')
shutil.rmtree(work, ignore_errors=True)
(work / 'obj').mkdir(parents=True)
config = ['-DMBEDTLS_USER_CONFIG_FILE="mbedtls_ps5x360_config.h"', f'-I{here}', f'-I{mbed}/include']
sources = sorted((mbed / 'library').glob('*.c'))
with ThreadPoolExecutor(16) as pool:
    results = list(pool.map(lambda c: subprocess.run(['clang-18', '-O1', '-c', str(c), '-o', str(work / 'obj' / (c.stem + '.o')), *config],
                                                     capture_output=True, text=True), sources))
bad = [r.stderr for r in results if r.returncode]
assert not bad, bad[0][:2000]
include = root / 'build/kinect-update-20261008/native/include'
build = subprocess.run(['clang++-18', '-std=gnu++20', '-O1', '-pthread', *config, f'-I{include}', str(here / 'host_test.cpp'),
                        str(here / 'phone_camera_tls.cpp'), *map(str, sorted((work / 'obj').glob('*.o'))), '-o', str(work / 'server')],
                       capture_output=True, text=True)
assert build.returncode == 0, build.stderr[-4000:]
print('built mbedTLS', len(sources), 'files and the server')

assets = Path('/app0/assets/kinect')
assets.mkdir(parents=True, exist_ok=True)
for name in ('index.html', 'pose.mjs', 'kinect_tracker.mjs', 'demo_body.mjs'):
    shutil.copy2(root / 'tools/kinect-phone' / name, assets / name)
shutil.rmtree('/tmp/phone-tls', ignore_errors=True)


def run(address):
    Path('/tmp/phone-tls-stop').unlink(missing_ok=True)
    process = subprocess.Popen([str(work / 'server'), address], stdout=subprocess.PIPE, text=True)
    line = process.stdout.readline().strip()
    assert line.startswith('URL https://' + address + ':'), line
    return process, int(line.rsplit(':', 1)[1].strip('/'))


def stop(process):
    Path('/tmp/phone-tls-stop').write_text('x')
    out = process.communicate(timeout=20)[0]
    return out


def client(address, port):
    trust = ssl.create_default_context(cafile='/tmp/phone-tls/authority.crt')
    return http.client.HTTPSConnection(address, port, context=trust, timeout=10)


def frame(session, sequence, tracked=True):
    values = []
    for n in range(20):
        values += [0.01 * n, 0.02 * n, -0.01 * n, 0.9]
    return b'XMP1' + struct.pack('<III80f', sequence, session, int(tracked), *values)


process, port = run('127.0.0.1')
try:
    c = client('127.0.0.1', port)
    c.request('GET', '/')
    r = c.getresponse(); page = r.read()
    assert r.status == 200 and b'<meta name="ps5x360-host" content="ps5">' in page, (r.status, page[:200])
    for name in ('kinect_tracker.mjs', 'pose.mjs', 'demo_body.mjs'):
        c.request('GET', f'/{name}?v=x'); r = c.getresponse(); body = r.read()
        assert r.status == 200 and r.getheader('Content-Type').startswith('text/javascript') and len(body) > 1000, name
    c.request('GET', '/ping'); r = c.getresponse(); r.read(); assert r.status == 204
    c.request('GET', '/api/motion/status'); r = c.getresponse(); r.read(); assert r.status == 403
    c.request('GET', '/api/motion/status', headers={'X-Key': 'abc123'}); r = c.getresponse()
    status = json.loads(r.read()); assert r.status == 200 and status['enabled'] is True, status
    c.request('POST', '/api/motion/frame', frame(7, 1), {'X-Key': 'abc123', 'Content-Type': 'application/octet-stream'})
    r = c.getresponse(); r.read(); assert r.status == 200
    c.request('POST', '/api/motion/frame', frame(7, 1), {'X-Key': 'abc123'}); r = c.getresponse(); r.read(); assert r.status == 409
    c.request('POST', '/api/motion/frame', b'XMP1short', {'X-Key': 'abc123'}); r = c.getresponse(); r.read(); assert r.status == 400
    c.request('GET', '/../authority.crt'); r = c.getresponse(); r.read(); assert r.status in (403, 404)
    peer = c.sock.getpeercert()
    assert ('IP Address', '127.0.0.1') in peer['subjectAltName'], peer
    print('one connection: page, modules, probe, key check, frames (accept/replay/malformed), IP certificate; TLS', c.sock.version(), c.sock.cipher()[0])
    # 30 frames on the same connection, timed.
    start = time.perf_counter()
    for n in range(2, 32):
        c.request('POST', '/api/motion/frame', frame(7, n), {'X-Key': 'abc123'}); r = c.getresponse(); r.read(); assert r.status == 200
    per_frame = (time.perf_counter() - start) / 30 * 1000
    c.close()

    def parallel(n):
        k = client('127.0.0.1', port)
        k.request('GET', '/api/motion/status', headers={'X-Key': 'abc123'}); r = k.getresponse(); r.read(); k.close()
        return r.status
    with ThreadPoolExecutor(6) as pool:
        assert all(s == 200 for s in pool.map(parallel, range(12)))
    print(f'keep-alive: 30 frames, {per_frame:.2f} ms each; 12 connections, 6 at a time: ok')
    untrusted = http.client.HTTPSConnection('127.0.0.1', port, context=ssl.create_default_context(), timeout=5)
    try:
        untrusted.request('GET', '/'); raise AssertionError('trusted without the authority')
    except ssl.SSLCertVerificationError:
        print('a phone without the authority installed is refused (the landing page detects this)')
finally:
    out = stop(process)
assert 'tracked=1 session=7 sequence=31' in out, out
authority = Path('/tmp/phone-tls/authority.crt').read_text()

process, port = run('127.0.0.1')  # same address: the certificate is reused
stop(process)
assert Path('/tmp/phone-tls/authority.crt').read_text() == authority
process, port = run('127.0.0.2')  # new address: a new authority and certificate
try:
    c = client('127.0.0.2', port)
    c.request('GET', '/ping'); r = c.getresponse(); r.read(); assert r.status == 204
    assert ('IP Address', '127.0.0.2') in c.sock.getpeercert()['subjectAltName']
finally:
    stop(process)
assert Path('/tmp/phone-tls/authority.crt').read_text() != authority
key_mode = oct(Path('/tmp/phone-tls/server.key').stat().st_mode & 0o777)
print('certificate reused for the same address, renewed for a new one; server key mode', key_mode)
print('PASS host phone camera TLS server')
