"""Kinect page v5: works when the console itself serves it (no PC relay).

- <meta name="ps5x360-host"> is "relay" in the file; the console's HTTPS server rewrites it to
  "ps5". On the console the page talks to /api/motion/* directly (X-Key header, binary XMP1
  frames, as the relay did upstream).
- The key can arrive in the address (#k=KEY, from the TV's QR code): the page fills it in and
  connects by itself, in both modes.
- On the console the key no longer changes between restarts, so a lost connection (the
  emulator restarting into a game) reconnects by itself every two seconds.
Edits tools/kinect-phone/index.html in place.
"""
from pathlib import Path

p = Path(__file__).resolve().parents[2] / 'tools/kinect-phone/index.html'
s = p.read_text(encoding='utf-8')


def rep(a, b, count=1):
    global s
    assert s.count(a) == count, (a[:90], s.count(a))
    s = s.replace(a, b)


rep('<title>PS5X360 Kinect</title>', '<meta name="ps5x360-host" content="relay">\n<title>PS5X360 Kinect</title>')

# Texts for reconnecting and the console mode.
rep("""  slow:'Slow tracking: choose Fast quality',""", """  slow:'Slow tracking: choose Fast quality',
  reconnecting:'Reconnecting to the PS5...', reconnect_hint:'The emulator is probably restarting (for example opening a game). This page reconnects by itself.',
  banner_wrong_key:'Wrong PS5 key: scan the QR code on the PS5 again', motion_off:'Camera motion is off for this game on the PS5.',""")
rep("""  slow:'Rastreamento lento: escolha a qualidade Rápida',""", """  slow:'Rastreamento lento: escolha a qualidade Rápida',
  reconnecting:'Reconectando ao PS5...', reconnect_hint:'O emulador provavelmente está reiniciando (por exemplo, abrindo um jogo). Esta página reconecta sozinha.',
  banner_wrong_key:'Chave do PS5 errada: leia de novo o QR code do PS5', motion_off:'O Movimento por câmera está desligado neste jogo no PS5.',""")
rep("""  slow:'Seguimiento lento: elige la calidad Rápida',""", """  slow:'Seguimiento lento: elige la calidad Rápida',
  reconnecting:'Reconectando con la PS5...', reconnect_hint:'El emulador probablemente se está reiniciando (por ejemplo, al abrir un juego). Esta página se reconecta sola.',
  banner_wrong_key:'Clave de la PS5 incorrecta: escanea de nuevo el código QR de la PS5', motion_off:'El Movimiento por cámara está desactivado en este juego en la PS5.',""")

# Mode and key from the address.
rep("""const GRACE_MS = 1000;
let lastGood = null, pairing = 'none', sentTimes = [];""", """const GRACE_MS = 1000;
let lastGood = null, pairing = 'none', sentTimes = [];
// Served by the console itself (its HTTPS server marks the page), or by the PC relay.
const onConsole = document.querySelector('meta[name="ps5x360-host"]')?.content === 'ps5';
const addressKey = new URLSearchParams(location.hash.slice(1)).get('k');
if (addressKey && /^[0-9a-f]{6}$/i.test(addressKey)) $('key').value = addressKey.toLowerCase();
let consoleKey = '';
// One pose frame as the console's motion receiver takes it (XMP1, 336 bytes, little-endian).
function packFrame(session, sequence, tracked, joints) {
  const buffer = new ArrayBuffer(336), view = new DataView(buffer);
  [88, 77, 80, 49].forEach((c, i) => view.setUint8(i, c));
  view.setUint32(4, sequence, true); view.setUint32(8, session, true); view.setUint32(12, tracked ? 1 : 0, true);
  joints.forEach((j, n) => {
    const at = 16 + n * 16;
    view.setFloat32(at, j.x, true); view.setFloat32(at + 4, j.y, true); view.setFloat32(at + 8, j.z, true);
    view.setFloat32(at + 12, Math.max(0, Math.min(1, j.confidence)), true);
  });
  return buffer;
}""")

# Status poll: console route on the console.
rep("""    const response = await fetch('/relay/status'); if (!response.ok) return;""",
    """    const response = onConsole ? await fetch('/api/motion/status', {headers: {'X-Key': consoleKey}, cache: 'no-store'}) :
      await fetch('/relay/status'); if (!response.ok) return;""")

# Frames: binary to the console, JSON to the relay.
rep("""    const response = await fetch('/relay/frame', {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({session: target.session, sequence: target.sequence, tracked: !!pose, joints})});
    if (!response.ok) {
      const result = await response.json().catch(() => ({}));
      if (response.status === 403 && target === motionSession) pairing = 'expired';
      throw Error(response.status === 403 ? T('pairing_expired') : response.status === 502 ? T('ps5_lost') : result.error || T('rejected', response.status));
    }""", """    const response = onConsole ?
      await fetch('/api/motion/frame', {method: 'POST', headers: {'X-Key': consoleKey, 'Content-Type': 'application/octet-stream'},
        body: packFrame(target.session, target.sequence, !!pose, joints)}) :
      await fetch('/relay/frame', {method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({session: target.session, sequence: target.sequence, tracked: !!pose, joints})});
    if (!response.ok) {
      const result = await response.json().catch(() => ({}));
      if (onConsole && response.status === 409 && result.error === 'disabled') { relay.textContent = T('motion_off'); return; }
      if (onConsole && (response.status === 409 || response.status === 400)) return;  // an older or odd frame: skip it
      if (response.status === 403 && target === motionSession) pairing = 'expired';
      throw Error(response.status === 403 ? T('pairing_expired') : response.status === 502 ? T('ps5_lost') : result.error || T('rejected', response.status));
    }""")

# Connecting: the console checks the key with its status route.
rep("""$('connect').onclick = async () => {
  try {
    const response = await fetch('/relay/connect', {method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({key: $('key').value.trim().toLowerCase()})});
    const result = await response.json();
    if (!response.ok) throw Error(result.error || T('pairing_expired'));
    if (!result.enabled) throw Error(T('enable_motion'));""", """async function connect(quiet = false) {
  try {
    const typed = $('key').value.trim().toLowerCase();
    let result;
    if (onConsole) {
      const response = await fetch('/api/motion/status', {headers: {'X-Key': typed}, cache: 'no-store'});
      if (response.status === 403) { pairing = 'wrong_key'; throw Error(T('banner_wrong_key')); }
      if (!response.ok) throw Error(T('ps5_lost'));
      result = await response.json();
      consoleKey = typed;
    } else {
      const response = await fetch('/relay/connect', {method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({key: typed})});
      result = await response.json();
      if (!response.ok) throw Error(result.error || T('pairing_expired'));
    }
    if (!result.enabled) throw Error(T('enable_motion'));""")
rep("""    paired = true; pairing = 'paired'; nextSend = 0; lastGood = null; relay.textContent = T('paired');
  } catch (e) { paired = false; relay.textContent = e.message; }
};""", """    paired = true; pairing = 'paired'; nextSend = 0; lastGood = null; relay.textContent = T('paired');
  } catch (e) {
    paired = false;
    if (!quiet || pairing !== 'lost') relay.textContent = e.message;
    if (quiet && pairing === 'lost') relay.textContent = T('reconnecting');
  }
}
$('connect').onclick = () => connect();
// On the console the key stays the same across restarts: after a lost connection (the
// emulator restarting into a game) try again every two seconds, without any typing.
setInterval(() => {
  if (onConsole && !paired && (pairing === 'lost' || pairing === 'expired') && $('key').value.trim()) connect(true);
}, 2000);
if ($('key').value.trim()) setTimeout(() => connect(), 0);""")

# Banner: on the console a lost connection is a reconnection, not a key to type.
rep("""    const text = pairing === 'expired' ? T('banner_expired') : T('banner_unpaired');""",
    """    const text = onConsole && (pairing === 'lost' || pairing === 'expired') ? T('reconnecting') :
      pairing === 'wrong_key' ? T('banner_wrong_key') : pairing === 'expired' ? T('banner_expired') : T('banner_unpaired');""")
rep("""    ctx.fillText(T('banner_hint'), w / 2, h * .42 + unit * 11.5, w - unit * 10);""",
    """    ctx.fillText(onConsole ? T('reconnect_hint') : T('banner_hint'), w / 2, h * .42 + unit * 11.5, w - unit * 10);""")
# A connection lost on the console means "reconnect", whatever the error said.
rep("""    if (target === motionSession) { paired = false; if (pairing !== 'expired') pairing = 'lost'; }""",
    """    if (target === motionSession) { paired = false; if (onConsole || pairing !== 'expired') pairing = 'lost'; }""")

for old, new in (("./kinect_tracker.mjs?v=kinect4", "./kinect_tracker.mjs?v=kinect5"),
                 ("./pose.mjs?v=kinect4", "./pose.mjs?v=kinect5"),
                 ("./demo_body.mjs?v=kinect4", "./demo_body.mjs?v=kinect5")):
    rep(old, new)
p.write_text(s, encoding='utf-8')
print('page v5')
