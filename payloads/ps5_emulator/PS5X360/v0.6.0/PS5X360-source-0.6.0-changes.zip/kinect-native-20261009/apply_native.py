"""Make the native sources of the console-hosted phone camera, from the sources of the objects
in the installed 0.5.9-readonly-pool.1 build:

- web_settings.cpp  <- build/kinect-update-20261008/web/web_settings.cpp (object f432e119...)
  * the settings key is kept in <app>/web-settings.key, so it survives restarts;
  * starts the console's HTTPS camera server (phone_camera_tls.cpp);
  * /camera opens the console landing (certificate check, then the camera page) when the
    HTTPS server runs, else the earlier PC-relay landing; /phone-camera-ca.crt serves the
    console's authority first;
  * the settings page's Camera tab says what it now does.
- launcher.cpp      <- build/bully-loading-20261009/candidate/launcher.cpp (object b6c12870...)
  * focusing "Camera motion" (general or per-game settings) shows the Kinect QR code: the
    settings server's /camera address with the key.
"""
from pathlib import Path

here = Path(__file__).resolve().parent
root = here.parents[1]


def edit(source, target, edits):
    s = source.read_text(encoding='utf-8')
    for old, new in edits:
        assert s.count(old) == 1, (target.name, old[:90], s.count(old))
        s = s.replace(old, new)
    target.write_text(s, encoding='utf-8')
    print('wrote', target)


edit(root / 'build/kinect-update-20261008/web/web_settings.cpp', here / 'web_settings.cpp', [
    ('#include "phone_camera.hpp"\n',
     '#include "phone_camera.hpp"\n#include "phone_camera_console.hpp"\n#include "phone_camera_tls.hpp"\n'),
    # Camera tab text.
    ("""(cameraPT?'Abra a página de pareamento para usar o serviço HTTPS local de câmera.':'Open the pairing page to use your local HTTPS camera service.')""",
     """(cameraPT?'Use a câmera deste celular como sensor Kinect, direto pelo PS5. Na primeira vez, o celular instala o certificado do PS5.':'Use this phone\\'s camera as the Kinect sensor, straight from the PS5. The first time, the phone installs the PS5 certificate.')"""),
    # The console's authority first; the PC relay's as before when the console has none.
    ("""    const auto certificate = phone_camera::ReadPublicCA();
    if (certificate.empty()) { Send(client, "404 Not Found", "text/plain", "certificate unavailable"); return; }
    Send(client, "200 OK", "application/x-x509-ca-cert", certificate,
         "Content-Disposition: attachment; filename=\\"phone-camera-ca.crt\\"\\r\\nReferrer-Policy: no-referrer\\r\\n");""",
     """    auto certificate = phone_tls::AuthorityPem();
    if (certificate.empty()) certificate = phone_camera::ReadPublicCA();
    if (certificate.empty()) { Send(client, "404 Not Found", "text/plain", "certificate unavailable"); return; }
    Send(client, "200 OK", "application/x-x509-ca-cert", certificate,
         "Content-Disposition: attachment; filename=\\"ps5x360-camera.crt\\"\\r\\nReferrer-Policy: no-referrer\\r\\n");"""),
    # /camera: the console landing while the console serves the camera page itself.
    ("""    std::string page = phone_camera::kLanding;
    const auto marker = page.find("__CAMERA_BOOT__");
    page.replace(marker, sizeof("__CAMERA_BOOT__") - 1,
                 "{\\"key\\":" + JsonText(key) + ",\\"relay\\":" + JsonText(phone_camera::ReadRelay()) +
                 ",\\"ca\\":" + (phone_camera::ReadPublicCA().empty() ? "false" : "true") + "}");""",
     """    const std::string secure = phone_tls::Url();
    std::string page = secure.empty() ? phone_camera::kLanding : phone_camera::kConsoleLanding;
    const auto marker = page.find("__CAMERA_BOOT__");
    page.replace(marker, sizeof("__CAMERA_BOOT__") - 1,
                 secure.empty() ? "{\\"key\\":" + JsonText(key) + ",\\"relay\\":" + JsonText(phone_camera::ReadRelay()) +
                                      ",\\"ca\\":" + (phone_camera::ReadPublicCA().empty() ? "false" : "true") + "}"
                                : "{\\"key\\":" + JsonText(key) + ",\\"https\\":" + JsonText(secure) + "}");"""),
    # A key that survives restarts, and the HTTPS camera server.
    ("""  std::random_device random;
  char text[8];
  std::snprintf(text, sizeof(text), "%06x", unsigned(random()) & 0xFFFFFFu);
  key = text;
  address = LocalAddress();""",
     """  // The key is kept beside the logs, so it stays the same across restarts: a phone that
  // paired once (the camera page included) reconnects by itself after the emulator restarts
  // into a game. Delete web-settings.key to make a new one.
  const fs::path key_file = logs.parent_path() / "web-settings.key";
  {
    std::ifstream saved(key_file);
    std::string line;
    if (saved && std::getline(saved, line) && line.size() == 6 &&
        std::all_of(line.begin(), line.end(), [](unsigned char c) { return std::isdigit(c) || (c >= 'a' && c <= 'f'); }))
      key = line;
  }
  if (key.empty()) {
    std::random_device random;
    char text[8];
    std::snprintf(text, sizeof(text), "%06x", unsigned(random()) & 0xFFFFFFu);
    key = text;
    std::ofstream(key_file, std::ios::trunc) << key << "\\n";
  }
  address = LocalAddress();"""),
    ("""  pthread_detach(thread);
  return true;
}
std::string WebSettingsPlainAddress() {""",
     """  pthread_detach(thread);
  // The phone camera page over HTTPS, served by the console itself.
  phone_tls::Start((logs.parent_path() / "phone-camera").string(), [] { return LocalAddress(); }, key);
  return true;
}
std::string WebSettingsPlainAddress() {"""),
])

edit(root / 'build/bully-loading-20261009/candidate/launcher.cpp', here / 'launcher.cpp', [
    # Helpers after FramegenText.
    ("""const char* FramegenText(const char* pt, const char* en, const char* es) {""",
     """const char* FramegenText(const char* pt, const char* en, const char* es);
// The Kinect QR code: the settings server's /camera page with the key. It opens the camera page
// served by the console itself (after a one-time certificate install on a new phone).
const QrCode& CameraQr(const std::string& plain, const std::string& key) {
  static std::string url;
  static QrCode qr;
  const std::string now = plain.empty() || key.empty() ? std::string() : plain + "camera?k=" + key;
  if (now != url) { url = now; qr = now.empty() ? QrCode() : MakeQrCode(now); }
  return qr;
}
const char* CameraQrText() {
  return FramegenText(
      "Aponte a câmera do celular para o código: ele vira o sensor Kinect, sem PC. Na primeira vez, o celular instala o certificado do PS5 (a página explica).",
      "Point the phone's camera at the code: the phone becomes the Kinect sensor, no PC needed. The first time, the phone installs the PS5 certificate (the page explains).",
      "Apunta la cámara del móvil al código: el móvil será el sensor Kinect, sin PC. La primera vez, el móvil instala el certificado de la PS5 (la página lo explica).");
}
const char* FramegenText(const char* pt, const char* en, const char* es) {"""),
    # The QR card drawing, where Canvas is known (just before the per-game options page).
    ('''void Launcher::DrawGameOptions(Canvas& c, float x) {''',
     '''template <class Surface>  // Launcher::Canvas is private to the class
void DrawQrCard(Surface& c, const QrCode& qr, float qx, float qy, float card) {
  const float module = float(int((card - 16) / float(qr.size))), inset = (card - module * float(qr.size)) / 2;
  c.Fill(qx, qy, card, card, kWhite, 1.0f, 8);
  for (int my = 0; my < qr.size; ++my) {
    for (int mx = 0; mx < qr.size;) {
      if (!qr.At(mx, my)) { ++mx; continue; }
      int run = 1;
      while (mx + run < qr.size && qr.At(mx + run, my)) ++run;
      c.Fill(qx + inset + float(mx) * module, qy + inset + float(my) * module, float(run) * module, module, 0x000000);
      mx += run;
    }
  }
}
void Launcher::DrawGameOptions(Canvas& c, float x) {'''),
    # DLC: a package copied into a dlc folder is enough. Before a game starts, the DLC folders
    # are scanned for it (as the DLCs tab does) and new packages are installed one by one, with
    # the progress on the loading screen; then the game starts. TakeLaunch serves every launch.
    ('''bool Launcher::TakeLaunch(GameEntry& game) {
  if (!launch_pending_ || (dlc_hooks_.status && dlc_hooks_.status().busy)) return false;
  launch_pending_ = false;
  game = launch_;
  return true;
}''',
     '''bool Launcher::TakeLaunch(GameEntry& game) {
  if (!launch_pending_ || (dlc_hooks_.status && dlc_hooks_.status().busy)) return false;
  static std::string checked;          // the launch whose DLC folders were looked at
  static std::vector<DlcEntry> waiting;  // its packages not installed yet
  static size_t found = 0;
  static uint32_t title = 0;
  const std::string current = launch_.path.string();
  if (checked != current) {
    checked = current;
    waiting.clear();
    found = 0;
    title = uint32_t(std::strtoul(launch_.title_id.c_str(), nullptr, 16));
    if (launch_.title_id.size() == 8 && title && dlc_hooks_.scan && dlc_hooks_.install) {
      std::vector<std::filesystem::path> roots = {"/app0/dlc", launch_.path.parent_path() / "dlc"};
      for (const auto& root : settings_.game_paths) roots.emplace_back(std::filesystem::path(root) / "dlc");
      for (const auto& entry : dlc_hooks_.scan(title, roots))
        if (!entry.installed) waiting.push_back(entry);
      found = waiting.size();
    }
  }
  while (!waiting.empty()) {
    const DlcEntry next = waiting.front();
    waiting.erase(waiting.begin());
    loading_ = launch_.name + "  \\u00b7  DLC " + std::to_string(found - waiting.size()) + "/" + std::to_string(found) +
               ": " + next.name;
    if (dlc_hooks_.install(title, next)) return false;  // copying; asked again next frame
  }
  checked.clear();
  loading_ = launch_.name;
  launch_pending_ = false;
  game = launch_;
  return true;
}'''),
    # The DLCs tab says that installing is now automatic.
    ('''  c.Wrapped(Tr("Copie os pacotes para PPSA50011/dlc ou para a pasta dlc do jogo. Só aparecem DLCs com o mesmo ID do título."), x + 56, 340, 22, kMuted, 740);''',
     '''  c.Wrapped(FramegenText("Copie os pacotes para PPSA50011/dlc ou para a pasta dlc do jogo: as DLCs novas são instaladas sozinhas quando você aperta Jogar. Só aparecem DLCs com o mesmo ID do título.",
                         "Copy the packages to PPSA50011/dlc or to the game's dlc folder: new DLCs install by themselves when you press Play. Only DLCs with the same title ID appear.",
                         "Copia los paquetes en PPSA50011/dlc o en la carpeta dlc del juego: los DLC nuevos se instalan solos al pulsar Jugar. Solo aparecen DLC con el mismo ID de título."),
            x + 56, 340, 22, kMuted, 740);'''),
    # Per-game settings: QR card beside the description.
    ("""  c.list->PushClipRect(c.At(x + 40, 780), c.At(x + 820, 930), true);
  c.Wrapped(Tr(option.about), x + 56, 786, 20, kBody, 750);
  c.list->PopClipRect();""",
     """  c.list->PushClipRect(c.At(x + 40, 780), c.At(x + 820, 930), true);
  const QrCode& camera_qr = std::string_view(option.key) == "motion_phone" ? CameraQr(web_plain_, web_key_) : QrCode();
  if (camera_qr.size) {
    DrawQrCard(c, camera_qr, x + 56, 786, 138);
    c.Wrapped(CameraQrText(), x + 212, 786, 20, kBody, 594);
  } else {
    c.Wrapped(Tr(option.about), x + 56, 786, 20, kBody, 750);
  }
  c.list->PopClipRect();"""),
    # General settings: QR card under the description.
    ("""  c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
  c.Wrapped(Tr(option.about), x + 56, 632, 20, kBody, 750);
  // What is recommended, and when a change takes effect.""",
     """  c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
  const QrCode& camera_qr = std::string_view(option.key) == "motion_phone" ? CameraQr(web_plain_, web_key_) : QrCode();
  if (camera_qr.size) {
    DrawQrCard(c, camera_qr, x + 56, 632, 200);
    c.Wrapped(CameraQrText(), x + 276, 632, 20, kBody, 530);
  } else {
    c.Wrapped(Tr(option.about), x + 56, 632, 20, kBody, 750);
  }
  // What is recommended, and when a change takes effect."""),
])
