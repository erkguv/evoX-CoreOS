"""Build and run dlc_test.cpp with the real Battle of Z packages, in xbox360ps5-canary:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-canary:latest python3 -u /ws/Xbox360PS5/build/kinect-native-20261009/dlc_test.py
"""
from pathlib import Path
import shutil
import subprocess

here = Path(__file__).resolve().parent
packages = here.parents[0] / 'dlc-battlez-20261009/packages'
work = Path('/tmp/dlc-test')
shutil.rmtree(work, ignore_errors=True)
root, inbox = work / 'saves', work / 'dlc'
active = root / '0000000000000000/4E4D0860/00000002'
active.mkdir(parents=True)
(inbox / '4E4D0860/00000002').mkdir(parents=True)
files = sorted(packages.iterdir())
for f in files[:2]:
    shutil.copy2(f, active / f.name)
for f in files:
    shutil.copy2(f, inbox / '4E4D0860/00000002' / f.name)
# Not used, each for its own reason: another game's package, a title update, a text file.
other = bytearray(files[0].read_bytes()); other[0x360:0x364] = bytes.fromhex('4D530000')
(inbox / 'OTHERGAME0000000000000000000000000000000').write_bytes(other)
update = bytearray(files[0].read_bytes()); update[0x344:0x348] = bytes.fromhex('000B0000')
(inbox / 'TU_4E4D0860').write_bytes(update)
(inbox / 'readme.txt').write_text('not a package')
(inbox / '.hidden').mkdir()
shutil.copy2(files[0], inbox / '.hidden' / 'ignored-hidden')
binary = work / 'dlc_test'
subprocess.run(['clang++-18', '-std=gnu++20', '-O1', '-g', '-fsanitize=address,undefined', '-pthread', f'-I{here}',
                str(here / 'dlc_test.cpp'), '-o', str(binary)], check=True)
subprocess.run([str(binary), str(root), str(inbox)], check=True)
