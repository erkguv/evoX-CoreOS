"""DLC page v2 for the launcher made by apply_native.py (run that first; edits launcher.cpp here).

The DLCs tab lists every DLC of the game: active (the game sees it), disabled (kept aside) and
not installed (in a dlc folder), using dlc_manager.hpp's own header reader. Cross enables,
disables or installs (copy with progress); a summary says how many files in the dlc folders
were ignored and why. Play installs new DLCs for that game first, with progress on the loading
screen. The core DlcInstaller (its validator dropped Battle of Z's valid packages without a
reason on the console) is no longer used by the page.
"""
from pathlib import Path

p = Path(__file__).resolve().parent / 'launcher.cpp'
s = p.read_text(encoding='utf-8')


def rep(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


def between(start, end_marker, new):
    """Replace from `start` (inclusive) up to the first `end_marker` after it (exclusive)."""
    global s
    a = s.index(start)
    b = s.index(end_marker, a + len(start))
    s = s[:a] + new + s[b:]


rep('#include "disc_library.hpp"\n', '#include "disc_library.hpp"\n#include "dlc_manager.hpp"\n')

# Play: install the game's new DLCs first (TakeLaunch serves every launch).
between('bool Launcher::TakeLaunch(GameEntry& game) {', '\nvoid Launcher::OpenGameSheet(', '''dlc2::Found& DlcPage();  // the DLCs tab's list, defined with RefreshDlcs
bool Launcher::TakeLaunch(GameEntry& game) {
  if (!launch_pending_ || (dlc_hooks_.status && dlc_hooks_.status().busy)) return false;
  static std::string checked, label;      // the launch whose dlc folders were looked at
  static std::vector<dlc2::Item> waiting;  // its DLCs not installed yet
  static size_t found = 0;
  static uint32_t title = 0;
  auto& copier = dlc2::copier();
  if (copier.Busy()) {
    if (!label.empty()) loading_ = label + "  " + std::to_string(int(copier.Progress() * 100)) + "%";
    return false;
  }
  const std::string current = launch_.path.string();
  if (checked != current) {
    checked = current;
    waiting.clear();
    found = 0;
    title = uint32_t(std::strtoul(launch_.title_id.c_str(), nullptr, 16));
    if (launch_.title_id.size() == 8 && title && !save_root_.empty()) {
      std::vector<std::filesystem::path> inboxes = {"/app0/dlc", launch_.path.parent_path() / "dlc"};
      for (const auto& root : settings_.game_paths) inboxes.emplace_back(std::filesystem::path(root) / "dlc");
      for (const auto& item : dlc2::Find(title, save_root_, inboxes).items)
        if (item.state == dlc2::State::available) waiting.push_back(item);
      found = waiting.size();
    }
  }
  copier.TakeResult();
  while (!waiting.empty()) {
    const dlc2::Item next = waiting.front();
    waiting.erase(waiting.begin());
    label = launch_.name + "  \\u00b7  DLC " + std::to_string(found - waiting.size()) + "/" + std::to_string(found) + ": " + next.name;
    loading_ = label;
    if (copier.Start(next, save_root_, title)) return false;  // copying; asked again next frame
  }
  checked.clear();
  label.clear();
  loading_ = launch_.name;
  launch_pending_ = false;
  game = launch_;
  return true;
}
''')

# The tab's keys.
rep('''        const bool busy = dlc_hooks_.status && dlc_hooks_.status().busy;
        const int rows = int(dlcs_.size());
        if (!busy && key == Key::up && rows) dlc_row_ = (dlc_row_ + rows - 1) % rows;
        if (!busy && key == Key::down && rows) dlc_row_ = (dlc_row_ + 1) % rows;
        if (!busy && key == Key::square) RefreshDlcs();
        if (!busy && key == Key::cross && rows && !dlcs_[size_t(dlc_row_)].installed && dlc_hooks_.install) {
          dlc_result_.clear(); dlc_was_busy_ = dlc_hooks_.install(SelectedTitleId(), dlcs_[size_t(dlc_row_)]);
        }''', '''        const bool busy = dlc2::copier().Busy();
        const int rows = int(DlcPage().items.size());
        if (key == Key::up && rows) dlc_row_ = (dlc_row_ + rows - 1) % rows;
        if (key == Key::down && rows) dlc_row_ = (dlc_row_ + 1) % rows;
        if (!busy && key == Key::square) RefreshDlcs();
        if (!busy && key == Key::cross && rows && !save_root_.empty()) {
          const dlc2::Item item = DlcPage().items[size_t(dlc_row_)];
          const uint32_t title = SelectedTitleId();
          std::string result;
          if (item.state == dlc2::State::available) {
            result = dlc2::copier().Start(item, save_root_, title) ? "" : "start-failed";
          } else {
            const bool enable = item.state == dlc2::State::disabled;
            result = dlc2::Move(item, save_root_, title, enable) ? (enable ? "enabled" : "disabled") : "move-failed";
            RefreshDlcs();
          }
          dlc_result_ = result;
        }''')
# Play waits for a DLC being installed from the tab.
rep('''          if (dlc_hooks_.status && dlc_hooks_.status().busy) { message_ = Tr("Aguarde a instalação do DLC terminar."); break; }''',
    '''          if ((dlc_hooks_.status && dlc_hooks_.status().busy) || dlc2::copier().Busy()) { message_ = Tr("Aguarde a instalação do DLC terminar."); break; }''')

# Refresh: the page's own scan.
between('void Launcher::RefreshDlcs() {', '\nnamespace {', '''// The DLCs tab's list (one game at a time; the launcher draws on one thread).
dlc2::Found& DlcPage() {
  static dlc2::Found page;
  return page;
}
void Launcher::RefreshDlcs() {
  if (dlc2::copier().Busy()) return;
  dlcs_.clear();
  dlc_result_.clear();
  DlcPage() = {};
  const auto* game = Selected();
  const uint32_t title = SelectedTitleId();
  if (game && title) {
    std::vector<std::filesystem::path> inboxes = {"/app0/dlc", game->path.parent_path() / "dlc"};
    for (const auto& root : settings_.game_paths) inboxes.emplace_back(std::filesystem::path(root) / "dlc");
    DlcPage() = dlc2::Find(title, save_root_, inboxes);
  }
  dlc_row_ = std::clamp(dlc_row_, 0, std::max(0, int(DlcPage().items.size()) - 1));
}
''')

# The page.
between('void Launcher::DrawDlcs(Canvas& c, float x) {', '\ntemplate <class Surface>', '''void Launcher::DrawDlcs(Canvas& c, float x) {
  auto& copier = dlc2::copier();
  const bool busy = copier.Busy();
  if (!busy) {
    if (const int result = copier.TakeResult()) {
      RefreshDlcs();
      dlc_result_ = result > 0 ? "installed" : "copy-failed:" + std::to_string(-result);
    }
  }
  c.Wrapped(FramegenText(
      "Ativada: o jogo encontra a DLC. Desativada: fica guardada, mas o jogo não a vê. Copie pacotes novos para PPSA50011/dlc ou para a pasta dlc do jogo: eles são instalados sozinhos quando você aperta Jogar (ou aqui, com X).",
      "On: the game finds the DLC. Off: kept, but the game does not see it. Copy new packages to PPSA50011/dlc or to the game's dlc folder: they install by themselves when you press Play (or here, with X).",
      "Activada: el juego encuentra el DLC. Desactivada: se guarda, pero el juego no lo ve. Copia paquetes nuevos en PPSA50011/dlc o en la carpeta dlc del juego: se instalan solos al pulsar Jugar (o aquí, con X)."),
    x + 56, 330, 21, kMuted, 740);
  const auto& page = DlcPage();
  const int rows = int(page.items.size());
  const int first = std::clamp(dlc_row_ - 3, 0, std::max(0, rows - 6));
  for (int n = first; n < std::min(rows, first + 6); ++n) {
    const auto& item = page.items[size_t(n)];
    const float y = 440 + (n - first) * 56.0f;
    const bool selected = n == dlc_row_;
    if (selected) c.Fill(x + 48, y, 768, 50, kSurfaceHigh, 1, 8);
    c.Text(item.name, x + 64, y + 10, 22, selected ? kText : kBody, 1, 0, 560);
    const bool on = item.state == dlc2::State::active, off = item.state == dlc2::State::disabled;
    c.Text(on ? FramegenText("Ativada", "On", "Activada") : off ? FramegenText("Desativada", "Off", "Desactivada")
                                                          : FramegenText("Não instalada", "Not installed", "No instalada"),
           x + 796, y + 12, 20, on ? kAccent : off ? kMuted : kBody, 1, 2);
  }
  if (!rows)
    c.Wrapped(SelectedTitleId() ? FramegenText("Nenhuma DLC deste jogo encontrada.", "No DLC for this game found.", "No se encontraron DLC de este juego.")
                                : Tr("Abra o jogo uma vez para identificar o título."),
              x + 56, 440, 24, kMuted, 730);
  if (page.other_game || page.not_dlc || page.not_package) {
    char ignored[320];
    std::snprintf(ignored, sizeof(ignored),
                  FramegenText("Ignorados nas pastas dlc: %d de outro jogo (outro ID), %d que não são DLC (ex.: atualização de título), %d que não são pacotes do Xbox 360.",
                               "Ignored in the dlc folders: %d of another game (other ID), %d not DLC (e.g. title updates), %d not Xbox 360 packages.",
                               "Ignorados en las carpetas dlc: %d de otro juego (otro ID), %d que no son DLC (p. ej. actualizaciones), %d que no son paquetes de Xbox 360."),
                  page.other_game, page.not_dlc, page.not_package);
    c.Wrapped(ignored, x + 56, 780, 19, kFaint, 740);
  }
  if (busy) {
    const float progress = float(std::clamp(copier.Progress(), 0.0, 1.0));
    c.Text(std::string(FramegenText("Instalando ", "Installing ", "Instalando ")) + copier.Name() + "  " +
               std::to_string(int(progress * 100)) + "%", x + 56, 840, 22, kAccent, 1, 0, 740);
    c.Fill(x + 56, 876, 740, 5, kSurfaceHigh); c.Fill(x + 56, 876, 740 * progress, 5, kAccent);
  } else if (!dlc_result_.empty()) {
    const char* text = dlc_result_ == "enabled" ? FramegenText("DLC ativada: o jogo vai encontrá-la.", "DLC on: the game will find it.", "DLC activada: el juego la encontrará.")
      : dlc_result_ == "disabled" ? FramegenText("DLC desativada: o jogo não a vê, e o arquivo continua guardado.", "DLC off: the game does not see it; the file is kept.", "DLC desactivada: el juego no la ve; el archivo se conserva.")
      : dlc_result_ == "installed" ? FramegenText("DLC instalada e ativada.", "DLC installed and on.", "DLC instalada y activada.")
      : dlc_result_ == "move-failed" ? FramegenText("Não foi possível mover o arquivo da DLC.", "Could not move the DLC file.", "No se pudo mover el archivo del DLC.")
      : FramegenText("A instalação falhou: confira o espaço livre e o arquivo.", "Installing failed: check free space and the file.", "La instalación falló: revisa el espacio libre y el archivo.");
    c.Wrapped(std::string(text) + (dlc_result_.rfind("copy-failed", 0) == 0 ? " (" + dlc_result_.substr(12) + ")" : ""),
              x + 56, 840, 22, kBody, 740);
  }
  c.Text(Tr("Destino: ") + save_root_.string(), x + 56, 928, 20, kFaint, 1, 0, 740);
  float hint = x + 56;
  if (!busy && rows) {
    const auto state = page.items[size_t(std::clamp(dlc_row_, 0, rows - 1))].state;
    hint = c.Hint('x', state == dlc2::State::active ? FramegenText("Desativar", "Turn off", "Desactivar")
                     : state == dlc2::State::disabled ? FramegenText("Ativar", "Turn on", "Activar") : Tr("Instalar"), hint, 1004);
  }
  if (!busy) hint = c.Hint('s', Tr("Recarregar lista"), hint, 1004);
  c.Hint('o', Tr("Voltar"), hint, 1004);
}
''')
p.write_text(s, encoding='utf-8')
print('DLC page v2 applied')
