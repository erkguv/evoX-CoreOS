"""Byte-identical frozen main reconstruction. No mutable main source writes."""
from pathlib import Path
import json
import hashlib
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = json.loads((root / 'build/vulkan-refine4/game-candidate/build.json').read_text())
command = list(json.loads((root / 'build/net-fix-20261009/menu/compile.json').read_text())['canary_game_main.cpp']['command'])
source = Path(command[command.index('-c') + 1])
assert sha(source) == receipt['sources'][str(source)] == '1484c9ad528fe38090adbb045a8b40ba2c24a57213d69655c82d82bb327c0a04'
frozen = root / 'build/continuation-20261009/menu/frozen'
header_proof = json.loads((root / 'build/continuation-20261009/menu/reproduce.json').read_text())
for name, expected in header_proof['headers'].items():
    assert sha(frozen / name) == expected, name
command[1:1] = ['-I' + str(frozen / 'include'), '-I' + str(frozen / 'src')]
# Preserve ORIGINAL source path (__FILE__) and change only output and include
# precedence to recover the same frozen headers used by the shipped object.
command[command.index('-o') + 1] = str(here / 'baseline-main.o')
p = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / 'baseline-compile.log').write_text(p.stdout)
if p.returncode: raise RuntimeError(p.stdout)
target = root / 'build/continuation-20261009/native/obj/canary_game_main.cpp.o'
assert sha(target) == '3ced40313b24497c59c03ffbc3dce89965ff5283c7b7fb9859b18675a83e1add'
assert sha(here / 'baseline-main.o') == sha(target), 'Baseline must reproduce byte for byte'
(here / 'baseline-main.cpp').write_bytes(source.read_bytes())
proof = {'command': command, 'source': str(source), 'source_sha256': sha(source),
         'baseline_object': str(target), 'baseline_object_sha256': sha(target),
         'rebuilt_object_sha256': sha(here / 'baseline-main.o'),
         'frozen_headers': header_proof['headers']}
(here / 'reproduce.json').write_text(json.dumps(proof, indent=2) + '\n')
print('PASS exact main baseline', proof['rebuilt_object_sha256'])
