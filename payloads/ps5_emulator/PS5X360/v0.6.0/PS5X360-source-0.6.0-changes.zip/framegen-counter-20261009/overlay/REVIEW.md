# Accepted output FPS overlay

Only `build/framegen-counter-20261009/overlay` was changed. The native
continuation main was reproduced exactly before modifying a private copy.
Original source: `/ws/Xbox360PS5/build/dual-renderer-worktree/src/canary_game_main.cpp`,
SHA-256 `1484c9ad528fe38090adbb045a8b40ba2c24a57213d69655c82d82bb327c0a04`.
Rebuilt object: `3ced40313b24497c59c03ffbc3dce89965ff5283c7b7fb9859b18675a83e1add`,
matching `build/continuation-20261009/native/obj/canary_game_main.cpp.o` byte for byte.

The reference command preserves the original source path for `__FILE__` and
uses the frozen headers from the successful continuation menu reconstruction.
No mutable main or frozen/shared header was edited.

## Display behavior

The existing `FpsOverlay` is the overlay over the running game. It now draws:

```
Game 30 FPS
Output (present) 60 FPS | FG 30 FPS | FG active
```

The old game FPS reference is unchanged. The second row measures deltas of the
shared present counters divided by the overlay's own `steady_clock` elapsed
time. These are accepted guest-picture presents, **not physical TV scanout**.
Generated FPS measures successfully presented midpoints; it is not estimated by
doubling game FPS. The example above is illustrative, not a console benchmark.

`FG Off` follows `enabled=false`. `FG waiting` follows `enabled=true` and a zero
measured generated rate. `FG active` requires a positive measured generated
rate. The opaque fallback code is loaded but no unprovided code meanings are
invented. Actual mode must be published by the presenter; a saved config alone
does not establish generation activity.

The sampler runs on every `OnDraw`, even while the FPS setting hides its text.
It establishes a baseline on the first draw and refreshes displayed rates every
0.5 seconds or later using actual elapsed time. It resets on time reversal,
counter decrease/wrap, or mode change. No new traffic produces zero rates after
the next sampling window, clearing stale activity. Elapsed zero never divides.
Mode transitions clear the old rates; the first fresh window may show waiting.
Independent relaxed counter snapshots may straddle a presenter increment, so
generated delta is capped to accepted delta for display. There is no writer,
lock, artificial input, console action or config edit in the overlay.

The box width follows the actual font measurement of both rows, including the
longer waiting text. Existing motion drawing, stalled-game warning and show-FPS
setting behavior are retained.

## Integration

Use `build.json` and its hashes. Replace only `canary_game_main.cpp.o` in the
continuation's object set; do not link both original and replacement main objects.
Integrate alongside the presenter's instrumented object using the **same exact**
`shared/output_metrics.hpp` hash. Inline atomics provide the shared contract;
there is no shared layout/vtable change. The presenter task owns counting,
actual-mode publication, `/app0` config precedence and fallbacks.

The native compiler adds only our two include locations and private source/output
paths to the byte-proven baseline command. The changed source area is exactly
the main-local `FpsOverlay` plus its two includes. `Rates` is main-local state;
no existing cross-object header was changed.

## Verification and limits

- Native baseline SHA equality and candidate compilation passed.
- 29 deterministic rate/status/count assertions passed using `/usr/bin/clang++-18`.
  They cover elapsed zero, time reversal, first-draw history, irregular timing,
  independent/reset/wrapped counters, no traffic clearing stale FPS, mode changes,
  Off/waiting/active labels, safe formatting and successful two-output/one-generated
  counting through the actual shared helper.
- The supplied read-only `tests/counts.cpp` passed in the same host image.
- Shared header hash, frozen-header hashes, compiler commands and Docker image
  identities are preserved in the receipts. Native atomics symbol/reference
  checks are in `build.json`.

This task did not link or package the combined presenter/main candidate, deploy,
run native `OnDraw` on the console, test physical scanout, or claim a performance
improvement. Host tests exercise the exact production rate/label helper, not a
running PS5 presenter. The existing `user_data.h` incomplete-switch warning is
present in both native baseline and candidate; no frozen header was repaired.
