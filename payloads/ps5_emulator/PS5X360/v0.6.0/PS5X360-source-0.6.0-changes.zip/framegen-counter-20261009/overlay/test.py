"""Host tests using the same rate/label helper that FpsOverlay calls."""
from pathlib import Path
import subprocess
import json
import hashlib

here = Path(__file__).resolve().parent
shared = here.parent / 'shared/output_metrics.hpp'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
command = ['/usr/bin/clang++-18', '-std=c++20', '-O2', '-Wall', '-Wextra',
           '-I' + str(here.parent / 'shared'), str(here / 'test_rates.cpp'),
           '-o', str(here / 'test-rates')]
p = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / 'host-compile.log').write_text(p.stdout)
if p.returncode: raise RuntimeError(p.stdout)
run = subprocess.run([str(here / 'test-rates')], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / 'host-test.log').write_text(run.stdout)
if run.returncode: raise RuntimeError(run.stdout)
# Run the supplied branch test read-only; all artifacts remain in our folder.
counts = here.parent / 'tests/counts.cpp'
counts_command = ['/usr/bin/clang++-18', '-std=c++20', '-O2', str(counts), '-o', str(here / 'test-counts')]
p = subprocess.run(counts_command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / 'counts-compile.log').write_text(p.stdout)
if p.returncode: raise RuntimeError(p.stdout)
subprocess.run([str(here / 'test-counts')], check=True)
proof = {'passed': True, 'command': command, 'stdout': run.stdout.strip(),
         'supplied_counts_test_passed': True, 'supplied_counts_command': counts_command,
         'shared_header_sha256': sha(shared), 'overlay_rates_sha256': sha(here / 'overlay_rates.hpp'),
         'test_rates_sha256': sha(here / 'test_rates.cpp'), 'supplied_counts_sha256': sha(counts),
         'limits': 'Deterministic host sampling/label/count tests. Does not run the native main, real presenter or physical display.'}
(here / 'tests.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2))
