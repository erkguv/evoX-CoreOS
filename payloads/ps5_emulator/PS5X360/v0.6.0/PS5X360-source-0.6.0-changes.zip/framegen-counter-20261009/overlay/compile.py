"""Compile only the overlay main object with the exact reconstructed baseline flags."""
from pathlib import Path
import hashlib
import json
import subprocess

here = Path(__file__).resolve().parent
root = Path('/ws/Xbox360PS5')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = json.loads((here / 'reproduce.json').read_text())
shared = json.loads((here / 'shared-interface.json').read_text())
assert sha(shared['path']) == shared['sha256'], 'Shared interface changed; regenerate and compile against new interface'
command = list(baseline['command'])
command[1:1] = ['-I' + str(here.parent / 'shared'), '-I' + str(here)]
command[command.index('-c') + 1] = str(here / 'canary_game_main.cpp')
command[command.index('-o') + 1] = str(here / 'canary_game_main.cpp.o')
p = subprocess.run(command, cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here / 'candidate-compile.log').write_text(p.stdout)
if p.returncode: raise RuntimeError(p.stdout)
assert sha(baseline['source']) == baseline['source_sha256']
proof = {'command': command, 'source_sha256': sha(here / 'canary_game_main.cpp'),
         'object_sha256': sha(here / 'canary_game_main.cpp.o'),
         'shared': shared, 'overlay_rates_sha256': sha(here / 'overlay_rates.hpp'),
         'baseline_object_sha256': baseline['baseline_object_sha256'],
         'original_source_unchanged': True, 'linked': False, 'deployed': False}
(here / 'compile.json').write_text(json.dumps(proof, indent=2) + '\n')
print('PASS native overlay', proof['object_sha256'])
