"""Change only FpsOverlay in a private copy of the reproduced main."""
from pathlib import Path
import difflib
import hashlib
import json

here = Path(__file__).resolve().parent
shared = here.parent / 'shared/output_metrics.hpp'
assert shared.exists()
before = (here / 'baseline-main.cpp').read_text()
source = before.replace('#include <chrono>', '#include <chrono>\n#include "output_metrics.hpp"\n#include "overlay_rates.hpp"', 1)
start = source.index('class FpsOverlay final')
end = source.index('// The emulator\'s guide', start)
body = source[start:end]
body = body.replace('  void OnDraw(ImGuiIO& io) override {', '''  void OnDraw(ImGuiIO& io) override {
    // Sample on every overlay draw, including when its FPS setting is hidden.
    // The presenter owns these counters; this overlay only loads them.
    output_rates_.Update(std::chrono::steady_clock::now(),
        ps5x360::output_metrics::accepted.load(std::memory_order_relaxed),
        ps5x360::output_metrics::generated.load(std::memory_order_relaxed),
        ps5x360::output_metrics::enabled.load(std::memory_order_relaxed),
        ps5x360::output_metrics::fallback.load(std::memory_order_relaxed));''', 1)
body = body.replace('char text[32];', 'char text[32], output_text[128];', 1)
body = body.replace('"%.0f FPS", fps_);', '"Game %.0f FPS", fps_);\n    output_rates_.Label(output_text, sizeof(output_text));', 1)
old = '''    list->AddRectFilled(ImVec2(24 * scale, 24 * scale), ImVec2(150 * scale, 64 * scale), IM_COL32(0, 0, 0, 150), 8 * scale);
    list->AddText(ImGui::GetFont(), 28 * scale, ImVec2(36 * scale, 30 * scale), IM_COL32(120, 230, 140, 255), text);'''
new = '''    const ImVec2 game_size = ImGui::GetFont()->CalcTextSizeA(28 * scale, 4096, 0, text);
    const ImVec2 output_size = ImGui::GetFont()->CalcTextSizeA(22 * scale, 4096, 0, output_text);
    const float width = std::max(game_size.x, output_size.x) + 24 * scale;
    list->AddRectFilled(ImVec2(24 * scale, 24 * scale), ImVec2(24 * scale + width, 94 * scale), IM_COL32(0, 0, 0, 150), 8 * scale);
    list->AddText(ImGui::GetFont(), 28 * scale, ImVec2(36 * scale, 30 * scale), IM_COL32(120, 230, 140, 255), text);
    list->AddText(ImGui::GetFont(), 22 * scale, ImVec2(36 * scale, 65 * scale), IM_COL32(220, 230, 240, 255), output_text);'''
assert old in body
body = body.replace(old, new, 1)
body = body.replace(' private:\n', ' private:\n  ps5x360::overlay::Rates output_rates_;\n', 1)
source = source[:start] + body + source[end:]
(here / 'canary_game_main.cpp').write_text(source)
(here / 'overlay.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True), source.splitlines(keepends=True), fromfile='frozen/canary_game_main.cpp', tofile='overlay/canary_game_main.cpp')))
(here / 'shared-interface.json').write_text(json.dumps({'path': str(shared), 'sha256': hashlib.sha256(shared.read_bytes()).hexdigest()}, indent=2) + '\n')
print('PASS prepared private overlay source')
