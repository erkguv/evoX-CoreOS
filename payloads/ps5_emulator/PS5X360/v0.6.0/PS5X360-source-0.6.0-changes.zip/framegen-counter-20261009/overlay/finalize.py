"""Publish only an overlay object integration receipt; no linking/deployment."""
from pathlib import Path
import json
import hashlib
import subprocess
from datetime import datetime, timezone

here = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = json.loads((here / 'reproduce.json').read_text())
candidate = json.loads((here / 'compile.json').read_text())
tests = json.loads((here / 'tests.json').read_text())
shared = here.parent / 'shared/output_metrics.hpp'
assert baseline['rebuilt_object_sha256'] == baseline['baseline_object_sha256'] == sha(here / 'baseline-main.o')
assert candidate['source_sha256'] == sha(here / 'canary_game_main.cpp')
assert candidate['object_sha256'] == sha(here / 'canary_game_main.cpp.o')
assert candidate['shared']['sha256'] == tests['shared_header_sha256'] == sha(shared)
assert candidate['overlay_rates_sha256'] == tests['overlay_rates_sha256'] == sha(here / 'overlay_rates.hpp')
assert tests['passed'] and tests['supplied_counts_test_passed']
assert sha(baseline['source']) == baseline['source_sha256']

before = (here / 'baseline-main.cpp').read_text()
after = (here / 'canary_game_main.cpp').read_text().replace('#include "output_metrics.hpp"\n#include "overlay_rates.hpp"\n', '')
start = before.index('class FpsOverlay final')
end = before.index('// The emulator\'s guide', start)
new_end = after.index('// The emulator\'s guide', start)
assert before[:start] == after[:start] and before[end:] == after[new_end:], 'Change escaped FpsOverlay'

nm = '/ws/Castation/native-ps5/.deps/native/ps5-payload-sdk/bin/llvm-nm'
def symbols(path, *flags):
    return subprocess.check_output([nm, *flags, str(path)], text=True)
defined = symbols(here / 'canary_game_main.cpp.o', '--defined-only', '--demangle')
for name in ('accepted', 'generated', 'enabled', 'fallback'):
    assert 'ps5x360::output_metrics::' + name in defined, name
undefined = {}
for name, path in [('baseline', here / 'baseline-main.o'), ('candidate', here / 'canary_game_main.cpp.o')]:
    text = symbols(path, '--undefined-only')
    (here / (name + '-undefined.txt')).write_text(text)
    undefined[name] = set(line.split()[-1] for line in text.splitlines() if line.strip())
added = sorted(undefined['candidate'] - undefined['baseline'])
assert not added, added
(here / 'candidate-symbols.txt').write_text(defined)
images = json.loads((here / 'docker-images.json').read_text(encoding='utf-8-sig'))
proof = {
    'approved_for_integration': True,
    'scope': 'Only replacement main object with accepted-present FPS overlay; integrate together with the instrumented presenter using the identical shared header.',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'object': str(here / 'canary_game_main.cpp.o'),
    'object_windows': r'C:\Users\bruno\Documents\PS5,\Xbox360PS5\build\framegen-counter-20261009\overlay\canary_game_main.cpp.o',
    'object_sha256': candidate['object_sha256'],
    'source': str(here / 'canary_game_main.cpp'), 'source_sha256': candidate['source_sha256'],
    'baseline_object_sha256': baseline['baseline_object_sha256'],
    'baseline_source_sha256': baseline['source_sha256'],
    'baseline_reproduced_byte_identical': True,
    'shared_header': str(shared), 'shared_header_sha256': sha(shared),
    'existing_headers_changed': False, 'mutable_main_source_changed': False,
    'output_metric': 'Successful guest-picture accepted presents; not physical display scanout',
    'generated_metric': 'Successful midpoint accepted presents; not game FPS x 2',
    'labels': ['Game %.0f FPS', 'Output (present) %.0f FPS | FG %.0f FPS | FG Off/FG waiting/FG active'],
    'sampling': 'steady_clock per OnDraw, rates refreshed every >=0.5s; initialize/rebase on first draw, reversed time, counter decrease or mode change; zero traffic clears stale FPS',
    'shared_atomic_symbols_defined': True, 'added_undefined_symbols': added,
    'tests': tests, 'native_compile': candidate['command'], 'images': images,
    'checksums': {name: sha(here / name) for name in ['baseline-main.cpp', 'baseline-main.o',
        'canary_game_main.cpp', 'canary_game_main.cpp.o', 'overlay_rates.hpp', 'overlay.patch',
        'reproduce.json', 'compile.json', 'shared-interface.json', 'tests.json', 'test_rates.cpp',
        'test.py', 'reproduce.py', 'prepare.py', 'compile.py', 'finalize.py', 'REVIEW.md',
        'docker-images.json']},
    'linked': False, 'packaged': False, 'deployed': False, 'hardware': 'not tested',
    'limits': 'Host production-helper/count tests and native object compilation only. Combined presenter/main linking, UI rendering and console output must be checked by the main task.'
}
(here / 'build.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({k: proof[k] for k in ('approved_for_integration', 'object_sha256', 'source_sha256', 'baseline_object_sha256', 'shared_header_sha256', 'added_undefined_symbols')}, indent=2))
