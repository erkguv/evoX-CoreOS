// SPDX-License-Identifier: MIT
#include "overlay_rates.hpp"
#include "output_metrics.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>

using ps5x360::overlay::Rates;
namespace metrics = ps5x360::output_metrics;
unsigned cases = 0;
void Check(bool result, const char* label) {
  ++cases;
  if (!result) { std::fprintf(stderr, "FAIL %s\n", label); std::exit(1); }
}
auto Time(double seconds) {
  return Rates::Clock::time_point{} + std::chrono::duration_cast<Rates::Clock::duration>(std::chrono::duration<double>(seconds));
}
bool Near(double a, double b) { return std::abs(a - b) < .000001; }
int main() {
  Rates rates;
  rates.Update(Time(0), 0, 0, true, 0);
  Check(rates.waiting() && !rates.output_fps() && !rates.generated_fps(), "first draw establishes baseline, FG waiting");
  rates.Update(Time(0), 2, 1, true, 0);
  Check(!rates.output_fps() && !rates.generated_fps(), "elapsed zero never divides");
  rates.Update(Time(1), 2, 1, true, 0);
  Check(Near(rates.output_fps(), 2) && Near(rates.generated_fps(), 1), "two accepted output and one generated over one second");
  Check(!rates.waiting() && !std::strcmp(rates.status(), "FG active"), "activity requires delivered generated frames");
  rates.Update(Time(2), 2, 1, true, 3);
  Check(!rates.output_fps() && !rates.generated_fps() && rates.waiting(), "no traffic clears stale FPS to zero");
  Check(rates.fallback() == 3, "fallback sampled as opaque value");
  rates.Update(Time(3), 32, 1, true, 3);
  Check(Near(rates.output_fps(), 30) && rates.waiting(), "enabled without midpoint remains waiting");
  rates.Update(Time(4), 92, 31, true, 0);
  Check(Near(rates.output_fps(), 60) && Near(rates.generated_fps(), 30), "actual accepted and generated deltas independent of game FPS");
  char label[128]; rates.Label(label, sizeof(label));
  Check(!std::strcmp(label, "Output (present) 60 FPS | FG 30 FPS | FG active"), "accepted present label and active status");
  rates.Update(Time(4), 92, 31, true, 0);
  Check(std::isfinite(rates.output_fps()) && Near(rates.output_fps(), 60), "duplicate draw timestamps preserve finite latest rate");
  rates.Update(Time(4.25), 107, 38, true, 0);
  Check(Near(rates.output_fps(), 60) && Near(rates.generated_fps(), 30), "half-second display interval");
  rates.Update(Time(5), 107, 38, true, 0);
  Check(Near(rates.output_fps(), 15) && Near(rates.generated_fps(), 7), "irregular draw timing uses elapsed seconds");
  rates.Update(Time(4), 107, 38, true, 0);
  Check(!rates.output_fps() && !rates.generated_fps(), "backwards timestamp resets");
  rates.Update(Time(5), 0, 0, true, 0);
  Check(!rates.output_fps() && !rates.generated_fps(), "counter reset avoids unsigned spike");
  rates.Update(Time(6), 60, 30, true, 0);
  rates.Update(Time(7), 61, 29, true, 0);
  Check(!rates.output_fps() && !rates.generated_fps(), "generated counter alone reset avoids stale rate");
  rates.Update(Time(8), 60, 29, true, 0);
  Check(!rates.output_fps(), "accepted counter alone reset");
  rates.Update(Time(9), 120, 59, false, 0);
  Check(!std::strcmp(rates.status(), "FG Off") && !rates.generated_fps(), "disable clears generated history");
  rates.Update(Time(10), 150, 59, false, 0);
  Check(Near(rates.output_fps(), 30) && !rates.generated_fps(), "off mode counts real guest presents");
  rates.Label(label, sizeof(label));
  Check(!std::strcmp(label, "Output (present) 30 FPS | FG 0 FPS | FG Off"), "off label");
  rates.Update(Time(11), 180, 59, true, 1);
  Check(rates.waiting() && !rates.generated_fps(), "enable cannot claim pre-enable activity");
  rates.Label(label, sizeof(label));
  Check(std::strstr(label, "FG waiting") != nullptr, "waiting label");
  rates.Update(Time(12), 182, 69, true, 1);
  Check(Near(rates.output_fps(), 2) && Near(rates.generated_fps(), 2), "independent snapshot cannot exceed accepted output");
  Rates history;
  history.Update(Time(100), 100000, 50000, true, 0);
  Check(!history.output_fps() && !history.generated_fps(), "new overlay excludes lifetime history");
  history.Update(Time(101), std::numeric_limits<uint64_t>::max(), std::numeric_limits<uint64_t>::max(), true, 0);
  history.Update(Time(102), 0, 0, true, 0);
  Check(!history.output_fps() && !history.generated_fps(), "counter wrap rebases safely");
  char tiny[4] = {1,1,1,1}; rates.Label(tiny, sizeof(tiny));
  Check(tiny[3] == '\0', "bounded label formatting");

  metrics::accepted.store(0, std::memory_order_relaxed);
  metrics::generated.store(0, std::memory_order_relaxed);
  metrics::Present(false, true, true); metrics::Present(true, false, true);
  Check(metrics::accepted.load(std::memory_order_relaxed) == 0 && metrics::generated.load(std::memory_order_relaxed) == 0,
        "failure and non-guest branches count neither counter");
  Rates actual; actual.Update(Time(0), 0, 0, true, 0);
  metrics::Present(true, true, true); metrics::Present(true, true, false);
  Check(metrics::accepted.load(std::memory_order_relaxed) == 2 && metrics::generated.load(std::memory_order_relaxed) == 1,
        "midpoint plus current guest picture: accepted2 generated1");
  actual.Update(Time(1), metrics::accepted.load(std::memory_order_relaxed), metrics::generated.load(std::memory_order_relaxed), true, 0);
  Check(Near(actual.output_fps(), 2) && Near(actual.generated_fps(), 1), "shared helper results reach real overlay sampler");
  actual.Update(Time(2), 2, 1, true, 0);
  Check(!actual.output_fps() && !actual.generated_fps(), "zero traffic after activity does not retain stale estimate");
  std::printf("PASS %u overlay rate/status/marker-free shared-count assertions\n", cases);
}
