from pathlib import Path
import hashlib,json,shutil,subprocess,struct
root=Path('/ws/Xbox360PS5');work=Path(__file__).resolve().parent
base=root/'build/continuation-20261009/native';out=work/'native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(base/'eboot.bin')=='de31ed8775fcb4dad2bef6d9537edead81b065367e1f438f5193ebcbcd3d2ef9'
receipt=json.loads((root/'build/kinect-update-20261008/final-native/build.json').read_text())
for n,h in receipt['baseline_inputs'].items():assert sha(Path(n))==h,n
(out/'obj').mkdir(parents=True,exist_ok=True)
replacements={'vulkan_presenter.cc.o':work/'presenter/vulkan_presenter.cc.o',
              'canary_game_main.cpp.o':work/'overlay/canary_game_main.cpp.o'}
for folder,obj in (('presenter','vulkan_presenter.cc.o'),('overlay','canary_game_main.cpp.o')):
    receipt_name='build.json' if folder=='presenter' else 'compile.json'
    proof=json.loads((work/folder/receipt_name).read_text())
    assert sha(work/folder/obj)==proof['object_sha256']
retained={}
for p in (base/'obj').glob('*.o'):
    if p.name in replacements:continue
    shutil.copy2(p,out/'obj'/p.name);retained[p.name]=sha(p)
for n,p in replacements.items():shutil.copy2(p,out/'obj'/n)
subprocess.run(['bash',str(root/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(root),str(out)],check=True)
for name in ('llvm-pie.elf','eboot.elf'):
    data=(out/name).read_bytes();old=b'PS5X360 v0.5.8-vulkan.4';new=b'PS5X360 v0.5.9'
    assert data.count(old+b'\0')<=1
    if old+b'\0' in data:
        offset=data.index(old+b'\0');phoff=struct.unpack_from('<Q',data,32)[0];size,count=struct.unpack_from('<HH',data,54)
        ph=[struct.unpack_from('<IIQQQQQQ',data,phoff+i*size) for i in range(count)]
        assert any(p[0]==1 and p[1]==4 and p[2]<=offset and offset+len(old)+1<=p[2]+p[5] for p in ph)
        result=data[:offset]+new+b'\0'*(len(old)+1-len(new))+data[offset+len(old)+1:]
        assert len(result)==len(data)
        for p in ph:
            if p[0]==1 and p[1]&1:assert result[p[2]:p[2]+p[5]]==data[p[2]:p[2]+p[5]]
        (out/name).write_bytes(result)
subprocess.run(['python3',str(root/'build/native-runtime-stage/tools/verify-image.py'),str(out/'llvm-pie.elf'),str(out/'eboot.elf')],check=True)
subprocess.run([str(root/'build/canary-game/host/ps5-native-tool'),'self','--sign','--in',str(out/'eboot.elf'),'--out',str(out/'eboot.bin'),'--magic','0x1D3D154F'],check=True)
assert all(sha(out/'obj'/n)==h for n,h in retained.items())
(out/'build.json').write_text(json.dumps({'version':'0.5.9-counter.1-local','baseline_native_sha256':sha(base/'eboot.bin'),'native_sha256':sha(out/'eboot.bin'),'replaced_objects':{n:sha(p) for n,p in replacements.items()},'unchanged_objects':retained,'hardware':'pending'},indent=2))
print('PASS native link and retained objects')
