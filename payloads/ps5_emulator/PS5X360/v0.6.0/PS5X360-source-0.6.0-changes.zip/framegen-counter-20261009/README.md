# Output FPS counter candidate, 2026-10-09

Private 0.5.9-counter.1-local based on verified 0.5.9-menu.1-local.
Only presenter and main overlay objects replaced. Their original objects were
reproduced byte for byte before modification; other objects retained unchanged.

Game: guest swap FPS. Output (present): successfully accepted guest-picture
Vulkan presentations per second. FG: successful midpoint presentations per second.
Counts actual success, not multiplication. Failed/UI-only presents excluded.
This does not measure physical television scanout or unique simulation frames.

The overlay computes deltas using steady clock, updates each >=0.5s, resets when
mode/counters/time change and reports zero if traffic stops. FG off/waiting/active
reflect actual config and interpolated-present activity in that sampling window.

Configuration loader now tries /app0/framegen.conf (the Settings path) before
/data/homebrew/PPSA50011/framegen.conf. Prior path mismatch is a suspected reason
for no generation; actual hardware admission is not yet confirmed.

Tests: presenter/main baseline reproduction, 29 host sampling/status checks,
failed/UI-only/ordinary/midpoint counting, native link/image validation,
package CRC/manifest checks, single linked counter-symbol definitions.
Hardware counter appearance and generated output require console validation.

Rollback: deployment.json records the exact backup. No GitHub release made.
