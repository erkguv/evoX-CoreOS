from pathlib import Path
import hashlib,json,subprocess
root=Path('/ws/Xbox360PS5');w=root/'build/framegen-counter-20261009';old=root/'build/framegen-20261008'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=next(x for x in json.loads((old/'compile-receipt.json').read_text())['objects'] if x['source'].endswith('/vulkan_presenter.cc'))
c=list(r['command']); c=c[:c.index('-MMD')]
for key,name in (('-c','baseline.cc'),('-o','baseline.o')): c[c.index(key)+1]=str(w/'presenter'/name)
(w/'presenter/baseline.cc').write_bytes(Path(r['source']).read_bytes())
c[c.index('-c')+1]=r['source']
subprocess.run(c,check=True)
assert sha(w/'presenter/baseline.o')==r['object_sha256'],'baseline drift'
side=(old/'src/presenter_sidecar.hpp').read_text()
side=side.replace('  const char* path = "/data/homebrew/PPSA50011/framegen.conf";\n  std::FILE* file = std::fopen(path, "rb");\n  if (!file) return;  // Missing file preserves the false cvar default.', '''  const char* path = "/app0/framegen.conf";
  std::FILE* file = std::fopen(path, "rb");
  if (!file) {
    path = "/data/homebrew/PPSA50011/framegen.conf";
    file = std::fopen(path, "rb");
  }
  if (!file) {
    XELOGW("Framegen config unavailable in /app0 or installation root; disabled");
    return;
  }''')
(w/'presenter/presenter_sidecar.hpp').write_text(side)
s=(w/'presenter/baseline.cc').read_text()
s=s.replace('#include "presenter_sidecar.hpp"','#include "presenter_sidecar.hpp"\n#include "../shared/output_metrics.hpp"',1)
s=s.replace('  FramegenSidecar* fg = nullptr;', '  ps5x360::output_metrics::enabled.store(bool(cvars::ps5_frame_interpolation), std::memory_order_relaxed);\n  FramegenSidecar* fg = nullptr;',1)
s=s.replace('  if (fg && succeeded(result)) {','  ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, midpoint);\n  if (fg && succeeded(result)) {',1)
s=s.replace('    if (succeeded(result)) ++fg->ordinary_present_ok;', '    ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, false);\n    if (succeeded(result)) ++fg->ordinary_present_ok;',1)
(w/'presenter/vulkan_presenter.cc').write_text(s)
c[c.index('-c')+1]=str(w/'presenter/vulkan_presenter.cc');c[c.index('-o')+1]=str(w/'presenter/vulkan_presenter.cc.o')
subprocess.run(c,check=True)
(w/'presenter/build.json').write_text(json.dumps({'baseline_reproduced':True,'command':c,'object_sha256':sha(w/'presenter/vulkan_presenter.cc.o'),'source_sha256':sha(w/'presenter/vulkan_presenter.cc'),'abi_changed':False,'semantics':'successful guest picture QueuePresent acceptance, not physical scanout'},indent=2))
print('PASS presenter baseline reproduced; counted successful guest paints only')
