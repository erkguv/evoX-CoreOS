from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path(__file__).resolve().parents[2];work=Path(__file__).resolve().parent
proof=json.loads((work/'native/build.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(root/'build/continuation-20261009/package/PPSA50011.zip') as z:
    files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
notes="""# PS5X360 output counter private test

- Separate game FPS and output (successful guest-picture presents) FPS.
- FG FPS counts successfully presented interpolated frames, never FPS x2.
- FG Off / waiting / active indicate observed generation in the latest window.
- Failed presents and launcher-only UI paints are excluded.
- Read framegen.conf from the /app0 path used by Settings, with installation-root fallback.

Accepted presents are not a measurement of TV scanout or unique game simulation frames.
The original game FPS remains visible. Preserve existing config when installing.
No public release or hardware FPS validation is claimed.
"""
image=(work/'native/eboot.bin').read_bytes();assert sha(image)==proof['native_sha256']
files['PPSA50011/eboot.bin']=image;files['PPSA50011/VERSION']=b'0.5.9-counter.1-local\n'
files['PPSA50011/RELEASE.json']=json.dumps(proof,indent=2).encode()
files['PPSA50011/RELEASE_NOTES.md']=notes.encode()
files['PPSA50011/framegen.conf']=b'ps5_frame_interpolation=false\n'
files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=work/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
    assert z.testzip() is None
    for n,p in manifest.items():assert sha(z.read('PPSA50011/'+n))==p['sha256']
(out/'README.md').write_text(notes)
(out/'proof.json').write_text(json.dumps({'native_sha256':sha(image),'zip_sha256':sha((out/'PPSA50011.zip').read_bytes()),'crc':'pass','manifest_files':len(manifest),'hardware':'pending'},indent=2))
desktop=Path.home()/'Desktop/PS5X360-framegen-counter-test-20261009';desktop.mkdir(exist_ok=True)
for n in ('PPSA50011.zip','README.md','proof.json'):shutil.copy2(out/n,desktop/n)
delta=Path.home()/'Desktop/Xbox360PS5-source/framegen-counter-20261009';delta.mkdir(parents=True,exist_ok=True)
for folder in ('presenter','overlay','shared','tests'):
    for p in (work/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.cpp','.hpp','.py','.json','.md','.patch'):
            target=delta/p.relative_to(work);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
for p in (work/'link.py',work/'package.py',work/'native/build.json'):
    shutil.copy2(p,delta/p.name)
print('PASS package CRC, manifest; Desktop package and source delta refreshed')
