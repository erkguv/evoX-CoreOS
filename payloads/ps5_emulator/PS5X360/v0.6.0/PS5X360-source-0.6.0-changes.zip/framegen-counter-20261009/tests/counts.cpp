#include "../shared/output_metrics.hpp"
#include <cassert>
int main(){using namespace ps5x360::output_metrics;
Present(false,true,true);Present(true,false,true);
assert(accepted==0 && generated==0);
Present(true,true,false);assert(accepted==1 && generated==0);
Present(true,true,true);Present(true,true,false);
assert(accepted==3 && generated==1);
}
