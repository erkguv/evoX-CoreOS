// SPDX-License-Identifier: GPL-3.0-or-later
// The frame generation settings file (/app0/framegen.conf), shared by the launcher (which
// writes it), the presenter (which reads it once, before the swapchain) and the host test.
//
//   ps5_frame_interpolation=true     line 1, exactly this or "=false": the switch of the builds
//                                    before modes, which read nothing else
//   ps5_frame_multiplier=auto        optional: auto, 2, 3 or 4. Missing or unknown: 2
//   ps5_frame_output_hz=60           optional: auto, 60 or 120. Missing or unknown: 60
//   ps5_frame_pacing=auto            optional: auto or strict. Missing or unknown: auto.
//                                    auto: in the Automatic mode, pictures are also generated
//                                    when the game's frames are not of one length (adaptive
//                                    pacing). strict: only the pacing of the builds before it.
//
// With lines 2 and 3 missing, the settings are the ones of the builds before modes: one
// generated picture between two of the game's, on the 60 Hz output.
#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>

namespace ps5x360::framegen {
struct Config {
  bool valid = false;        // line 1 is one of its two exact forms
  bool enabled = false;      // line 1 is ps5_frame_interpolation=true
  uint32_t multiplier = 2;   // 0: automatic; 2, 3 or 4
  uint32_t output_hz = 60;   // 0: automatic; 60 or 120
  bool has_multiplier = false, has_output = false;  // the line was there, with a known value
  bool unknown_value = false;                       // a known key with a value that is not one of its own
  std::string output_text;   // the output line's value as written: a writer that did not set it keeps it
  bool adaptive_pacing = true;  // ps5_frame_pacing is not "strict"
  bool has_pacing = false;      // the line was there, with a known value
  std::string pacing_text;      // its value as written, kept by a writer the same way
};

constexpr const char* kSwitchOn = "ps5_frame_interpolation=true";
constexpr const char* kSwitchOff = "ps5_frame_interpolation=false";
constexpr const char* kMultiplierKey = "ps5_frame_multiplier=";
constexpr const char* kOutputKey = "ps5_frame_output_hz=";
constexpr const char* kPacingKey = "ps5_frame_pacing=";

inline const char* MultiplierText(uint32_t multiplier) {
  return multiplier == 0 ? "auto" : multiplier == 3 ? "3" : multiplier == 4 ? "4" : "2";
}
inline const char* OutputText(uint32_t output_hz) {
  return output_hz == 0 ? "auto" : output_hz == 120 ? "120" : "60";
}
// For the log: x2, x3, x4 or auto.
inline const char* ModeText(uint32_t multiplier) {
  return multiplier == 0 ? "auto" : multiplier == 3 ? "x3" : multiplier == 4 ? "x4" : "x2";
}

// The whole file's text. Line 1 is compared as the builds before modes compared it: up to the
// first line break, carriage returns at its end dropped, nothing else forgiven.
inline Config ParseConfig(const std::string& file) {
  Config config;
  const std::string text(file.c_str());  // as a C string: nothing after a NUL
  size_t at = 0;
  for (unsigned number = 0; at < text.size() && number < 16; ++number) {
    const size_t end = std::min(text.find('\n', at), text.size());
    std::string line = text.substr(at, end - at);
    at = end + 1;
    while (!line.empty() && line.back() == '\r') line.pop_back();
    if (number == 0) {
      config.valid = line == kSwitchOn || line == kSwitchOff;
      config.enabled = line == kSwitchOn;
      continue;
    }
    while (!line.empty() && (line.back() == ' ' || line.back() == '\t')) line.pop_back();
    if (line.rfind(kMultiplierKey, 0) == 0) {
      const std::string value = line.substr(std::strlen(kMultiplierKey));
      const bool known = value == "auto" || value == "2" || value == "3" || value == "4";
      if (known) {
        config.multiplier = value == "auto" ? 0 : uint32_t(value[0] - '0');
        config.has_multiplier = true;
      } else {
        config.unknown_value = true;
      }
    } else if (line.rfind(kOutputKey, 0) == 0) {
      const std::string value = line.substr(std::strlen(kOutputKey));
      config.output_text = value;
      const bool known = value == "auto" || value == "60" || value == "120";
      if (known) {
        config.output_hz = value == "auto" ? 0 : value == "120" ? 120 : 60;
        config.has_output = true;
      } else {
        config.unknown_value = true;
      }
    } else if (line.rfind(kPacingKey, 0) == 0) {
      const std::string value = line.substr(std::strlen(kPacingKey));
      config.pacing_text = value;
      if (value == "auto" || value == "strict") {
        config.adaptive_pacing = value == "auto";
        config.has_pacing = true;
      } else {
        config.unknown_value = true;
      }
    }
  }
  return config;
}

// What the launcher writes: always the three lines, line 1 first for the builds before modes.
// `output_text` is written as it is when not empty (a value the launcher did not set). The
// pacing line is written only when the file had one (`pacing_text` not empty), as it was.
inline std::string FormatConfig(bool enabled, uint32_t multiplier, const std::string& output_text,
                                const std::string& pacing_text = std::string()) {
  std::string text = enabled ? kSwitchOn : kSwitchOff;
  text += "\n";
  text += kMultiplierKey;
  text += MultiplierText(multiplier);
  text += "\n";
  text += kOutputKey;
  text += output_text.empty() ? "60" : output_text;
  text += "\n";
  if (!pacing_text.empty()) {
    text += kPacingKey;
    text += pacing_text;
    text += "\n";
  }
  return text;
}

// The refresh asked of the display, in millihertz: the surface's own request (60000) unless the
// file asks for more. Automatic and 120 ask for 120000; the mode nearest to it that the driver
// lists is taken, so a console or a display without 120 Hz stays at 59.94 Hz by itself.
inline uint32_t RequestedRefreshMillihertz(const Config& config, uint32_t surface_request) {
  return config.output_hz == 60 ? surface_request : 120000u;
}

// Whether adaptive pacing may be used at all: frame generation on, the Automatic mode, and the
// pacing line not "strict". The fixed 2x, 3x and 4x modes are paced strictly, as before.
// The most pictures the adaptive path makes between two frames of the game: the mode's limit
// (2x: one, 3x: two, 4x and Automatic: three).
inline uint32_t AdaptiveCap(const Config& config) {
  return config.multiplier == 2 ? 1u : config.multiplier == 3 ? 2u : 3u;
}
// Every mode: the path takes over whenever strict pacing is not engaged, unless the file says
// ps5_frame_pacing=strict.
inline bool AdaptivePacingEnabled(const Config& config) {
  return config.valid && config.enabled && config.adaptive_pacing;
}
}  // namespace ps5x360::framegen
