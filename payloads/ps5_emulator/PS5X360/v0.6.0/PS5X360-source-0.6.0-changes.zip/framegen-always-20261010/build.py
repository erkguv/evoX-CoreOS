"""Builds 0.5.9-updates.5-local, the complete candidate, on the framegen.4 objects: updates.4 with
the adaptive pacing in every mode (apply_always.py; this file is written by make_build.py).

Three objects change; every other one is checked by hash against
build/framegen-stutter-20261010/native:
  - presenter: frame generation modes (build/framegen-modes-20261010) and, new here, adaptive
    pacing for games whose frame rate is uneven (this folder's sources, written by
    apply_adaptive.py from the modes folder's);
  - launcher: the Updates tab and its log line (build/updates-integration-20261010/
    launcher-updates.cpp), the mode and output rate rows (the modes folder's apply_modes.py,
    unchanged), the pacing line kept and the help text (apply_launcher.py);
  - command processor: a draw waits for its real pipeline only in the full readback mode
    (build/stutter-wait-20261010); its object must be the one of updates.3-safe.
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/framegen-always-20261010/build.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct  # used by the validation step taken from the framegen.3 recipe
import subprocess
import sys

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
stutter = root / 'build/framegen-stutter-20261010'
base = stutter / 'native'
modes = root / 'build/framegen-modes-20261010'
updates = root / 'build/title-updates-20261010'
integration = root / 'build/updates-integration-20261010'
kinect = root / 'build/kinect-native-20261009'
out = here / 'native'
record = json.loads((base / 'build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base / 'eboot.bin') == record['native_sha256'] == '09224f0f1f06224d6acf21f9bc6d39f95c8bb8fe5d35d785fd065f96e11f2914'
VERSION = '0.5.9-updates.5-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')
proofs = here / 'proofs'
proofs.mkdir(exist_ok=True)

# The modes folder's sources are the ones its own build and tests used.
tested = json.loads((modes / 'native/build.json').read_text())['source_sha256']
for name in ('presenter/vulkan_presenter.cc', 'presenter/presenter_sidecar.hpp', 'pacing_adapter.hpp',
             'framegen_config.hpp', 'shared/output_metrics.hpp', 'test_adapter.cpp', 'test_modes.inc', 'apply_modes.py'):
    assert sha(modes / name) == tested[name], name + ' changed after the modes build'

# This folder's sources: those the adaptive folder's build and tests used, changed by apply_always.py.
adaptive = root / 'build/framegen-adaptive-20261010'
built = json.loads((adaptive / 'native/build.json').read_text())['source_sha256']
for name in ('adaptive_pacing.hpp', 'framegen_config.hpp', 'pacing_adapter.hpp', 'presenter/presenter_sidecar.hpp',
             'presenter/vulkan_presenter.cc', 'launcher.cpp', 'test_adaptive.inc'):
    assert sha(adaptive / name) == built[name], name + ' changed after the adaptive build'
subprocess.run([sys.executable, str(here / 'apply_always.py')], check=True)
# The presenter's own file and the strict adapter are untouched: only the sidecar, the
# scheduler and the settings reader differ from updates.4.
assert sha(here / 'presenter/vulkan_presenter.cc') == sha(adaptive / 'presenter/vulkan_presenter.cc')
assert sha(here / 'pacing_adapter.hpp') == sha(adaptive / 'pacing_adapter.hpp')
assert sha(here / 'launcher.cpp') == sha(adaptive / 'launcher.cpp')
# Headers shared with objects that are not rebuilt stay the base's: the one copy this folder
# needs is identical, and the others are not here at all, so they are found in the base.
assert sha(here / 'shared/output_metrics.hpp') == sha(stutter / 'shared/output_metrics.hpp')
assert not (here / 'vendor').exists() and not (here / 'source_clock.hpp').exists()
assert sha(stutter / 'vendor/ps5_framegen.h') == sha(root / 'build/framegen-sword-20261010/vendor/ps5_framegen.h')
assert sha(stutter / 'source_clock.hpp') == sha(root / 'build/framegen-sword-20261010/source_clock.hpp')

(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    c = list(command)
    c[1:1] = extra
    c[c.index('-c') + 1] = str(source)
    c[c.index('-o') + 1] = str(obj)
    subprocess.run(c, cwd=root, check=True)
    return c


# The unchanged sources still give the installed framegen.4 objects, byte for byte.
cp_source = 'cp/xenia/gpu/vulkan/vulkan_command_processor.cc'
for key, source, name in (('presenter', stutter / 'presenter/vulkan_presenter.cc', 'vulkan_presenter.cc.o'),
                          ('launcher', kinect / 'launcher.cpp', 'launcher.cpp.o'),
                          ('command_processor', root / 'build/framegen-sword-20261010' / cp_source, 'vulkan_command_processor.cc.o')):
    compile_with(record['commands'][key], source, proofs / (key + '.o'))
    assert sha(proofs / (key + '.o')) == sha(base / 'obj' / name), key + ' preimage drift'

presenter_build = compile_with(record['commands']['presenter'], here / 'presenter/vulkan_presenter.cc',
                               out / 'obj/vulkan_presenter.cc.o', ['-I' + str(here)])
launcher_cmd = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a
                for a in record['commands']['launcher']]
launcher_build = compile_with(launcher_cmd, here / 'launcher.cpp', out / 'obj/launcher.cpp.o',
                              ['-I' + str(here), '-I' + str(updates), '-I' + str(kinect)])
cp_build = compile_with(record['commands']['command_processor'], root / 'build/stutter-wait-20261010' / cp_source,
                        out / 'obj/vulkan_command_processor.cc.o')
changed = {'vulkan_presenter.cc.o', 'launcher.cpp.o', 'vulkan_command_processor.cc.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / name) == value for name, value in retained.items())
assert all(sha(out / 'obj' / name) != sha(base / 'obj' / name) for name in changed)
# The command processor is the object of updates.3-safe, which ran on the console.
assert sha(out / 'obj/vulkan_command_processor.cc.o') == sha(integration / 'native-safe/obj/vulkan_command_processor.cc.o')
assert {p.name for p in (out / 'obj').glob('*.o')} == set(record['objects'])
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)

# Display version, image verification and signing: the reviewed step of the framegen.3 recipe.
s = (root / 'build/framegen-sword-20261010/build.py').read_text()
validation = s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation, 'framegen-sword build.py', 'exec'), globals())
image = (out / 'llvm-pie.elf').read_bytes()
for needle in (b'PPSA50011/updates', b'000B0000-off', b'LAUNCHER title update for', b'Framegen: Sword FSR3 ready',
               b'shader-trace.conf', b'Framegen mode: ', b'Framegen output: asked for', b'ps5_frame_multiplier=',
               b'ps5_frame_output_hz=', b'ps5_frame_interpolation=true', b'ps5_frame_pacing=',
               b'Framegen adaptive: started', b'Framegen adaptive: stopped', b'outputs_per_source='):
    assert needle in image, needle
commands = dict(record['commands'])
commands.update(presenter=presenter_build, launcher=launcher_build, command_processor=cp_build)
(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'presenter_preimage_identical': True, 'launcher_preimage_identical': True, 'command_processor_preimage_identical': True,
    'command_processor_object_equals_updates3_safe': True, 'unchanged_objects': retained,
    'objects': {p.name: sha(p) for p in (out / 'obj').glob('*.o')}, 'commands': commands,
    'source_sha256': {str(p.relative_to(here)): sha(p) for p in sorted(here.rglob('*'))
                      if p.is_file() and p.suffix in ('.py', '.hpp', '.cc', '.cpp', '.inc', '.sh')
                      and not {'preview', 'native', 'proofs'} & set(p.parts)},
    'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
