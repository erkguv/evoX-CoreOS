// SPDX-License-Identifier: GPL-3.0-or-later
// Adaptive frame generation pacing: generated pictures for a game whose frame rate is not an
// exact divisor of the display rate (40 FPS on 60 Hz, a rate that moves between 31 and 47).
//
// The strict path (pacing_adapter.hpp and the upstream pacer) shows one or more pictures at
// fixed fractions between two frames and needs the game's frames to have one length. This path
// is used only while that one is not engaged. It runs a content clock instead:
//   D     one display refresh
//   T     the game's frame interval, the median of the last 8 arrivals
//   dphi  D / T: how far the content moves in one refresh
//   c     the content position of the next output inside the current span, the previous frame A
//         at 0 and the new frame B at 1
// When B arrives, outputs are made at c, c + dphi, ... while they are not past B, and c then
// moves into the next span (c -= 1). An output within 1/8 of B is B itself; any other is the
// generated picture at the nearest fraction the interpolator offers (1/4, 1/3, 1/2, 2/3, 3/4).
// So the display gets a new picture every refresh and the content advances by the same amount
// each time, whatever the game's rate:
//   40 FPS on 60 Hz   spans of {2/3} and {1/3, B} in turn: 1.5 outputs per game frame
//   45 FPS on 60 Hz   3/4, 1/2, {1/4, B} over three spans
//   30 FPS on 60 Hz   {1/2, B}
// Header-only and free of Vulkan: test_adaptive.inc runs it on a PC.
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace ps5x360::framegen {
struct AdaptiveOutput {
  int8_t picture = -1;    // -1: the game's frame B; 0 to 2: the generated picture of that index
  uint8_t refreshes = 1;  // the refreshes it is shown before the next output is queued
};

enum class AdaptiveReason : uint8_t {
  Running,      // pictures are generated for this span
  Seeding,      // the interpolator has no previous frame yet: the game's frame alone, this once
  Backlog,      // outputs were still waiting to be shown: the game's frame alone, this once
  NotAllowed,   // strict pacing is engaged, or the settings or the safety pause forbid it
  Warming,      // fewer than kMinSamples intervals since the start or a gap
  Gap,          // a frame took over 2.5 intervals, or frames were lost: the estimate starts again
  TooSlow,      // the game is below kMinFps
  TooFast,      // the game is within kHeadroomFps of the display rate, or above it
  NoClock,      // no usable arrival time or display rate
};

struct AdaptivePlan {
  bool active = false;          // this span is paced here: the snapshot and the optical flow run
  AdaptiveReason reason = AdaptiveReason::NotAllowed;
  uint32_t generated = 1;       // the pictures the interpolator is set to make (1 to 3)
  uint32_t count = 0;           // outputs of this span, in order
  std::array<AdaptiveOutput, 4> outputs{};  // at most three generated pictures and the frame
  uint32_t refreshes() const {
    uint32_t total = 0;
    for (uint32_t i = 0; i < count; ++i) total += outputs[i].refreshes;
    return total;
  }
  uint32_t pictures() const {
    uint32_t total = 0;
    for (uint32_t i = 0; i < count; ++i) total += outputs[i].picture >= 0;
    return total;
  }
};

class AdaptivePacing {
 public:
  static constexpr uint32_t kWindow = 8;        // intervals the median is taken over
  static constexpr uint32_t kMinSamples = 5;    // intervals before the first generated picture
  static constexpr double kMinFps = 10.0;       // below it the pictures are too far apart to join
  static constexpr double kHeadroomFps = 3.0;   // the game has to be this far under the display
  static constexpr double kHysteresisFps = 1.0; // ...and stays on this much further out
  static constexpr double kGapIntervals = 2.5;  // a longer wait is a load or a pause
  static constexpr double kGapNs = 400e6;       // ...and so is this, whatever the estimate
  static constexpr double kSnap = 0.125;        // an output this near B is B
  static constexpr double kMargin = 0.002;      // outputs a hair under the display rate, so the
                                                // swapchain's queue drains instead of filling
  static constexpr double kBacklogRefreshes = 1.25; // outputs still waiting: none are added
  static constexpr uint32_t kMaxPhases = 16;    // 10 FPS on 120 Hz is 12 refreshes a frame

  // One new frame of the game.
  //   arrival_ns   when the game handed it over (any steady clock)
  //   now_ns       when the presenter picked it up, on the same clock
  //   step         frames since the last one given here: 1, or 2 when the presenter missed one;
  //                0 when that is not known (the first frame, a new swapchain)
  //   display_hz   the refresh rate of the display mode in use
  //   allowed      this path may pace the span: it is switched on, strict pacing is not engaged
  //                and its safety pause is not running
  //   history      the interpolator holds the previous frame, so pictures can be made
  //   cap          the most pictures made between two frames (1 to 3): the mode's limit. What
  //                the clock asks beyond it is shown by holding a picture for more refreshes
  // The arrival is always taken into the estimate, so the path can start at once when strict
  // pacing lets go of a single frame.
  AdaptivePlan Arrive(uint64_t arrival_ns, uint64_t now_ns, uint64_t step, double display_hz,
                      bool allowed, bool history, uint32_t cap = 3) {
    AdaptivePlan plan;
    if (!std::isfinite(display_hz) || display_hz < 30 || display_hz > 250 || !arrival_ns) {
      Reset();
      return Off(plan, AdaptiveReason::NoClock);
    }
    if (display_hz != display_hz_) {
      Reset();
      display_hz_ = display_hz;
    }
    seen_ns_ = now_ns;
    if (!arrival_ns_ || arrival_ns <= arrival_ns_ || step == 0) {
      // The first frame, or a clock that went back: nothing to measure yet.
      ClearEstimate();
      arrival_ns_ = arrival_ns;
      return Off(plan, AdaptiveReason::Warming);
    }
    const double span = double(arrival_ns - arrival_ns_);
    arrival_ns_ = arrival_ns;
    if (step > 2 || span > kGapNs || (interval_ns_ > 0 && span > kGapIntervals * interval_ns_)) {
      ClearEstimate();
      return Off(plan, AdaptiveReason::Gap);
    }
    intervals_[next_] = span / double(step);
    next_ = (next_ + 1) % kWindow;
    count_ = std::min(count_ + 1, kWindow);
    interval_ns_ = Median();

    if (!allowed) return Off(plan, AdaptiveReason::NotAllowed);
    if (count_ < kMinSamples) return Off(plan, AdaptiveReason::Warming);
    const double rate = 1e9 / interval_ns_;
    const double slack = active_ ? kHysteresisFps : 0.0;
    if (rate < kMinFps - slack) return Off(plan, AdaptiveReason::TooSlow);
    if (rate > display_hz - kHeadroomFps + slack) return Off(plan, AdaptiveReason::TooFast);

    // The span is paced here.
    const double refresh_ns = 1e9 / display_hz;
    const uint64_t start = std::max(busy_until_ns_, now_ns);
    plan.active = active_ = true;
    if (!history) {
      // No previous frame in the interpolator: this frame becomes it.
      return Alone(plan, AdaptiveReason::Seeding, start, refresh_ns);
    }
    // Outputs made before are still waiting for their refresh, or the presenter picked this
    // frame up a whole interval late: nothing is added to the queue but the frame itself.
    if (double(start - now_ns) > kBacklogRefreshes * refresh_ns ||
        double(now_ns) > double(arrival_ns) + interval_ns_) {
      ++backlogs_;
      return Alone(plan, AdaptiveReason::Backlog, start, refresh_ns);
    }

    const double dphi = refresh_ns * (1.0 + kMargin) / interval_ns_;
    if (!clock_valid_) {
      // The frame before this span was shown as it is: the next output is one step after it.
      content_ = dphi;
      clock_valid_ = true;
    }
    double phases[kMaxPhases];
    uint32_t n = 0;
    // Never more outputs than the refreshes a frame lasts. The earliest are the ones left out:
    // they are the nearest to the frame already on screen.
    const uint32_t most = std::min<uint32_t>(kMaxPhases, uint32_t(std::ceil(interval_ns_ / refresh_ns)));
    while (content_ <= 1.0 + kSnap) {
      if (n == most) {
        for (uint32_t i = 1; i < n; ++i) phases[i - 1] = phases[i];
        --n;
      }
      phases[n++] = content_;
      content_ += dphi;
    }
    content_ -= 1.0;
    if (n == 0) return Alone(plan, AdaptiveReason::Seeding, start, refresh_ns);  // cannot happen: dphi < 1

    // Which fractions: the number of pictures (1 to 3) whose fractions lie nearest the phases.
    uint32_t wanted = 0;
    for (uint32_t i = 0; i < n; ++i) wanted += phases[i] < 1.0 - kSnap;
    uint32_t best = 1;
    double best_error = 1e30;
    for (uint32_t pictures = 1; pictures <= std::clamp<uint32_t>(cap, 1, 3) && wanted; ++pictures) {
      double error = 0;
      for (uint32_t i = 0; i < n; ++i) {
        if (phases[i] >= 1.0 - kSnap) continue;
        const double distance = phases[i] - Fraction(Index(phases[i], pictures), pictures);
        error += distance * distance;
      }
      if (error < best_error - 1e-12) {
        best_error = error;
        best = pictures;
      }
    }
    plan.generated = best;
    plan.reason = AdaptiveReason::Running;
    for (uint32_t i = 0; i < n; ++i) {
      const int8_t picture = phases[i] >= 1.0 - kSnap ? int8_t(-1) : int8_t(Index(phases[i], best));
      if (plan.count && plan.outputs[plan.count - 1].picture == picture) {
        ++plan.outputs[plan.count - 1].refreshes;  // the same picture again: it stays up
      } else {
        plan.outputs[plan.count++] = {picture, 1};
      }
    }
    busy_until_ns_ = start + uint64_t(double(n) * refresh_ns);
    ++spans_;
    return plan;
  }

  // The presenter could not show what a plan asked for (no picture made, a full queue found at
  // the first acquire, a failed present): the frame was shown alone, the clock starts after it.
  void ShownAlone(uint64_t now_ns) {
    clock_valid_ = false;
    busy_until_ns_ = display_hz_ > 0 ? now_ns + uint64_t(1e9 / display_hz_) : 0;
  }
  // While this path paces, the presenter shows nothing between two frames of the game: every
  // refresh has its output already. That ends when no frame came for over 2.5 intervals (a
  // pause, a load), so that the menu and the guide are painted again.
  bool Holding(uint64_t now_ns) {
    if (!active_) return false;
    if (interval_ns_ > 0 && double(now_ns) <= double(seen_ns_) + kGapIntervals * interval_ns_) return true;
    Stop();
    return false;
  }
  // The path lets go: strict pacing took over, the mailbox went away, a present failed.
  void Stop() {
    active_ = false;
    clock_valid_ = false;
    busy_until_ns_ = 0;
  }
  void Reset() {
    Stop();
    ClearEstimate();
    arrival_ns_ = seen_ns_ = 0;
    display_hz_ = 0;
  }

  bool active() const { return active_; }
  // The game's rate by the estimate, 0 before the first interval.
  double fps() const { return interval_ns_ > 0 ? 1e9 / interval_ns_ : 0.0; }
  double interval_ns() const { return interval_ns_; }
  double content() const { return content_; }
  uint64_t spans() const { return spans_; }        // spans with generated pictures planned
  uint64_t backlogs() const { return backlogs_; }  // spans cut to the frame alone by a backlog

  // The fraction of picture `index` (0-based) when `pictures` are generated: (index + 1) / (pictures + 1).
  static double Fraction(uint32_t index, uint32_t pictures) { return double(index + 1) / double(pictures + 1); }
  // The picture nearest a phase.
  static uint32_t Index(double phase, uint32_t pictures) {
    const long nearest = std::lround(phase * double(pictures + 1)) - 1;
    return uint32_t(std::clamp<long>(nearest, 0, long(pictures) - 1));
  }

 private:
  AdaptivePlan& Off(AdaptivePlan& plan, AdaptiveReason reason) {
    Stop();
    plan.active = false;
    plan.reason = reason;
    plan.count = 0;
    return plan;
  }
  AdaptivePlan& Alone(AdaptivePlan& plan, AdaptiveReason reason, uint64_t start, double refresh_ns) {
    plan.reason = reason;
    plan.generated = 1;
    plan.count = 1;
    plan.outputs[0] = {int8_t(-1), 1};
    clock_valid_ = false;
    busy_until_ns_ = start + uint64_t(refresh_ns);
    return plan;
  }
  void ClearEstimate() {
    intervals_ = {};
    next_ = count_ = 0;
    interval_ns_ = 0;
    Stop();
  }
  double Median() const {
    std::array<double, kWindow> sorted{};
    for (uint32_t i = 0; i < count_; ++i) sorted[i] = intervals_[(next_ + kWindow - 1 - i) % kWindow];
    std::sort(sorted.begin(), sorted.begin() + count_);
    return count_ & 1 ? sorted[count_ / 2] : (sorted[count_ / 2 - 1] + sorted[count_ / 2]) / 2.0;
  }

  std::array<double, kWindow> intervals_{};
  uint32_t next_ = 0, count_ = 0;
  double interval_ns_ = 0, display_hz_ = 0, content_ = 0;
  uint64_t arrival_ns_ = 0, seen_ns_ = 0, busy_until_ns_ = 0, spans_ = 0, backlogs_ = 0;
  bool active_ = false, clock_valid_ = false;
};
}  // namespace ps5x360::framegen
