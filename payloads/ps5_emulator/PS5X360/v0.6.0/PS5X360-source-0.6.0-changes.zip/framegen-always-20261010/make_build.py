"""Writes this folder's build.py from the recipe of build/framegen-adaptive-20261010 (updates.4):
the same steps and checks, with this folder's sources (apply_always.py) and version.
usage: python make_build.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
text = (here.parent / 'framegen-adaptive-20261010/build.py').read_text(encoding='utf-8')


def swap(old, new):
    global text
    assert text.count(old) == 1, (old[:70], text.count(old))
    text = text.replace(old, new)


swap('"""Builds 0.5.9-updates.4-local, the complete candidate, on the framegen.4 objects.\n',
     '"""Builds 0.5.9-updates.5-local, the complete candidate, on the framegen.4 objects: updates.4 with\n'
     'the adaptive pacing in every mode (apply_always.py; this file is written by make_build.py).\n')
swap("  python3 /ws/Xbox360PS5/build/framegen-adaptive-20261010/build.py\n",
     "  python3 /ws/Xbox360PS5/build/framegen-always-20261010/build.py\n")
swap("VERSION = '0.5.9-updates.4-local'\n", "VERSION = '0.5.9-updates.5-local'\n")
swap("# This folder's sources, from the modes folder's and the integration folder's launcher.\n"
     "for script in ('apply_adaptive.py', 'apply_launcher.py'):\n"
     "    subprocess.run([sys.executable, str(here / script)], check=True)\n",
     "# This folder's sources: those the adaptive folder's build and tests used, changed by apply_always.py.\n"
     "adaptive = root / 'build/framegen-adaptive-20261010'\n"
     "built = json.loads((adaptive / 'native/build.json').read_text())['source_sha256']\n"
     "for name in ('adaptive_pacing.hpp', 'framegen_config.hpp', 'pacing_adapter.hpp', 'presenter/presenter_sidecar.hpp',\n"
     "             'presenter/vulkan_presenter.cc', 'launcher.cpp', 'test_adaptive.inc'):\n"
     "    assert sha(adaptive / name) == built[name], name + ' changed after the adaptive build'\n"
     "subprocess.run([sys.executable, str(here / 'apply_always.py')], check=True)\n"
     "# The presenter's own file and the strict adapter are untouched: only the sidecar, the\n"
     "# scheduler and the settings reader differ from updates.4.\n"
     "assert sha(here / 'presenter/vulkan_presenter.cc') == sha(adaptive / 'presenter/vulkan_presenter.cc')\n"
     "assert sha(here / 'pacing_adapter.hpp') == sha(adaptive / 'pacing_adapter.hpp')\n"
     "assert sha(here / 'launcher.cpp') == sha(adaptive / 'launcher.cpp')\n")
(here / 'build.py').write_text(text, encoding='utf-8', newline='\n')
print('build.py written')
