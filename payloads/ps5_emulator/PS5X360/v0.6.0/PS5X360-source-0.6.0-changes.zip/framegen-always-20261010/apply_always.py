"""Frame generation paces adaptively in every mode, not only in Automatic.

Copies the sources of build/framegen-adaptive-20261010 (0.5.9-updates.4) into this folder and
changes three things; every anchor must match exactly once:
  - the adaptive path is allowed whenever frame generation is on and the settings file does not
    say ps5_frame_pacing=strict. The mode is the most pictures made between two frames
    (2x: one, 3x: two, 4x and Automatic: three); what the content clock asks beyond that is
    shown by holding a picture for more refreshes;
  - the lowest game rate paced goes from 18 to 10 FPS (room for 12 refreshes a frame at 120 Hz);
  - the tests follow, with new ones for the modes' limit and for slow games with held pictures.
Strict pacing, its engagement and the presenter's loop are not touched.
usage: python apply_always.py
"""
from pathlib import Path
import shutil

here = Path(__file__).resolve().parent
source = here.parent / 'framegen-adaptive-20261010'
FILES = ['adaptive_pacing.hpp', 'framegen_config.hpp', 'pacing_adapter.hpp', 'presenter/presenter_sidecar.hpp',
         'presenter/vulkan_presenter.cc', 'shared/output_metrics.hpp', 'launcher.cpp', 'test_adapter.cpp',
         'test_adaptive.inc', 'test_modes.inc', 'run_tests.sh']
for name in FILES:
    (here / name).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / name, here / name)


def edit(name, pairs):
    path = here / name
    text = path.read_text(encoding='utf-8')
    for old, new in pairs:
        assert text.count(old) == 1, (name, old[:70], text.count(old))
        text = text.replace(old, new)
    path.write_text(text, encoding='utf-8', newline='\n')


edit('framegen_config.hpp', [
    ('  return config.valid && config.enabled && config.multiplier == 0 && config.adaptive_pacing;\n',
     '  return config.valid && config.enabled && config.adaptive_pacing;\n'),
    ('inline bool AdaptivePacingEnabled(const Config& config) {\n',
     '// The most pictures the adaptive path makes between two frames of the game: the mode\'s limit\n'
     '// (2x: one, 3x: two, 4x and Automatic: three).\n'
     'inline uint32_t AdaptiveCap(const Config& config) {\n'
     '  return config.multiplier == 2 ? 1u : config.multiplier == 3 ? 2u : 3u;\n'
     '}\n'
     '// Every mode: the path takes over whenever strict pacing is not engaged, unless the file says\n'
     '// ps5_frame_pacing=strict.\n'
     'inline bool AdaptivePacingEnabled(const Config& config) {\n'),
])
edit('adaptive_pacing.hpp', [
    ('  static constexpr double kMinFps = 18.0;       // below it the pictures are too far apart to join\n',
     '  static constexpr double kMinFps = 10.0;       // below it the pictures are too far apart to join\n'),
    ('  static constexpr uint32_t kMaxPhases = 8;     // 18 FPS on 120 Hz is 7 refreshes a frame\n',
     '  static constexpr uint32_t kMaxPhases = 16;    // 10 FPS on 120 Hz is 12 refreshes a frame\n'),
    ('  //   history      the interpolator holds the previous frame, so pictures can be made\n',
     '  //   history      the interpolator holds the previous frame, so pictures can be made\n'
     '  //   cap          the most pictures made between two frames (1 to 3): the mode\'s limit. What\n'
     '  //                the clock asks beyond it is shown by holding a picture for more refreshes\n'),
    ('                      bool allowed, bool history) {\n',
     '                      bool allowed, bool history, uint32_t cap = 3) {\n'),
    ('    for (uint32_t pictures = 1; pictures <= 3 && wanted; ++pictures) {\n',
     '    for (uint32_t pictures = 1; pictures <= std::clamp<uint32_t>(cap, 1, 3) && wanted; ++pictures) {\n'),
])
edit('presenter/presenter_sidecar.hpp', [
    ('    plan = adaptive.Arrive(stamp.ns, now_ns, step, display_hz, !strict && !pacing.SafetyPaused(),\n'
     '                           history && interpolation_history);\n',
     '    plan = adaptive.Arrive(stamp.ns, now_ns, step, display_hz, !strict && !pacing.SafetyPaused(),\n'
     '                           history && interpolation_history,\n'
     '                           ps5x360::framegen::AdaptiveCap(FramegenConfig()));\n'),
    ('"game below 18 FPS"', '"game below 10 FPS"'),
])
edit('test_adaptive.inc', [
    ('    for (int i = 0; i < 100; ++i) CHECK(!sim.Frame(1e9 / 15.0).active);\n'
     '    CHECK(sim.Frame(1e9 / 15.0).reason == AdaptiveReason::TooSlow);\n',
     '    for (int i = 0; i < 100; ++i) CHECK(!sim.Frame(1e9 / 7.0).active);\n'
     '    CHECK(sim.Frame(1e9 / 7.0).reason == AdaptiveReason::TooSlow);\n'),
    ('  // The edges, with their hysteresis: on at 18 and at display - 3, kept to 17 and display - 2.\n'
     '  {\n'
     '    Sim sim = Steady(18.2, k5994);\n'
     '    for (int i = 0; i < 40; ++i) CHECK(sim.Frame(1e9 / 17.3).active);\n'
     '    for (int i = 0; i < 12; ++i) sim.Frame(1e9 / 16.5);\n'
     '    CHECK(!sim.pacing.active());\n'
     '    for (int i = 0; i < 40; ++i) CHECK(!sim.Frame(1e9 / 17.5).active);  // not back on before 18\n',
     '  // The edges, with their hysteresis: on at 10 and at display - 3, kept to 9 and display - 2.\n'
     '  {\n'
     '    Sim sim = Steady(10.2, k5994);\n'
     '    for (int i = 0; i < 40; ++i) CHECK(sim.Frame(1e9 / 9.3).active);\n'
     '    for (int i = 0; i < 12; ++i) sim.Frame(1e9 / 8.5);\n'
     '    CHECK(!sim.pacing.active());\n'
     '    for (int i = 0; i < 40; ++i) CHECK(!sim.Frame(1e9 / 9.5).active);  // not back on before 10\n'),
    (r'''  // The fixed modes, the old one-line file and the switch off stay strict.
  for (const char* text : {"ps5_frame_interpolation=true\n", "ps5_frame_interpolation=true\nps5_frame_multiplier=2\n",
                           "ps5_frame_interpolation=true\nps5_frame_multiplier=3\n",
                           "ps5_frame_interpolation=true\nps5_frame_multiplier=4\nps5_frame_pacing=auto\n",
                           "ps5_frame_interpolation=false\nps5_frame_multiplier=auto\n"}) {
    CHECK(!AdaptivePacingEnabled(ParseConfig(text)));
  }
''', r'''  // Every mode paces adaptively when its frames are uneven, the old one-line file included. The
  // mode is the most pictures made between two frames. Off stays off and strict stays strict.
  using ps5x360::framegen::AdaptiveCap;
  for (const char* text : {"ps5_frame_interpolation=true\n", "ps5_frame_interpolation=true\nps5_frame_multiplier=2\n",
                           "ps5_frame_interpolation=true\nps5_frame_multiplier=3\n",
                           "ps5_frame_interpolation=true\nps5_frame_multiplier=4\nps5_frame_pacing=auto\n"}) {
    CHECK(AdaptivePacingEnabled(ParseConfig(text)));
  }
  CHECK(AdaptiveCap(ParseConfig("ps5_frame_interpolation=true\n")) == 1);  // the old file: 2x
  CHECK(AdaptiveCap(ParseConfig("ps5_frame_interpolation=true\nps5_frame_multiplier=2\n")) == 1);
  CHECK(AdaptiveCap(ParseConfig("ps5_frame_interpolation=true\nps5_frame_multiplier=3\n")) == 2);
  CHECK(AdaptiveCap(ParseConfig("ps5_frame_interpolation=true\nps5_frame_multiplier=4\n")) == 3);
  CHECK(AdaptiveCap(ParseConfig(head)) == 3);
  CHECK(!AdaptivePacingEnabled(ParseConfig("ps5_frame_interpolation=false\nps5_frame_multiplier=auto\n")));
  CHECK(!AdaptivePacingEnabled(ParseConfig("ps5_frame_interpolation=true\nps5_frame_multiplier=2\nps5_frame_pacing=strict\n")));
  // The limit holds at every rate, and every refresh of a frame still has its output: a game
  // at 40, 24 or 12 FPS on a 60 or 120 Hz display, with one, two or three pictures allowed.
  for (double display : {59.94, 119.88}) {
    for (double fps : {40.0, 24.0, 12.0}) {
      for (uint32_t cap = 1; cap <= 3; ++cap) {
        ps5x360::framegen::AdaptivePacing pacing;
        uint64_t t = 1000000;
        uint32_t planned = 0, generated_spans = 0;
        double shown = 0;
        for (int i = 0; i < 600; ++i) {
          t += uint64_t(1e9 / fps);
          const auto plan = pacing.Arrive(t, t + 200000, 1, display, true, true, cap);
          if (!plan.active) continue;
          ++planned;
          shown += plan.refreshes();
          generated_spans += plan.pictures() != 0;
          CHECK(plan.generated >= 1 && plan.generated <= cap && plan.count >= 1 && plan.count <= cap + 1);
          for (uint32_t k = 0; k < plan.count; ++k) {
            CHECK(plan.outputs[k].picture < int8_t(plan.generated) && plan.outputs[k].refreshes >= 1);
            if (k) CHECK(plan.outputs[k].picture != plan.outputs[k - 1].picture);  // held, not repeated
          }
          CHECK(plan.outputs[plan.count - 1].picture == -1 || plan.count <= cap);  // B comes last when shown
        }
        CHECK(planned >= 590);                               // paced from the sixth frame on
        CHECK(generated_spans * 10 >= planned * 9);          // pictures in nearly every span
        const double per_frame = shown / double(planned);    // refreshes filled per game frame
        CHECK(per_frame > display / fps * 0.97 && per_frame < display / fps * 1.01);
      }
    }
  }
'''),
])
print('sources written in', here)
