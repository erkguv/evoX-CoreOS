from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
s=(w/'xam_ui.cc').read_text()
a=s.index('void XamShowDirtyDiscErrorUI_entry(')
b=s.index('DECLARE_XAM_EXPORT1(XamShowDirtyDiscErrorUI',a)
body=s[a:b].split('#else',1)[0]+'\n}\n'
body=body.replace('#if XE_PLATFORM_PS5','')
test=r'''
#include <cassert>
#include <chrono>
#include <cstdint>
#include <string>
#include <vector>
using dword_t=uint32_t;
struct Context { uint64_t lr; };
using ppc_context_t=Context*;
struct Kernel { uint32_t title_id(){return 0x5454081A;} } kernel;
Kernel* kernel_state(){return &kernel;}
int logs=0, launches=0, sleeps=0;
#define XELOGE(...) (++logs)
namespace xbox360ps5 {
bool RelaunchInto(const std::string& path, const std::vector<uint8_t>& data) {
  assert(path.empty()&&data.empty()); ++launches; return false;
}}
namespace xe::threading {
void Sleep(std::chrono::milliseconds delay){assert(delay.count()==1000);++sleeps;throw 42;}
}
'''+body+r'''
int main(){Context context{0x82812345};try{XamShowDirtyDiscErrorUI_entry(0,&context);assert(false);}catch(int e){assert(e==42);}assert(logs==2&&launches==1&&sleeps==1);}
'''
(w/'recovery-test.cpp').write_text(test)
subprocess.run(['clang++-18','-std=c++17','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-fsanitize=address,undefined',str(w/'recovery-test.cpp'),'-o',str(w/'recovery-test')],check=True)
subprocess.run([str(w/'recovery-test')],check=True)
(w/'test-results.txt').write_text('PASS: actual PS5 handler body, restart targets library; refused restart parks the guest thread; no libc exit. ASan/UBSan. Mocked platform restart; not PS5 gameplay validation.\n')
print((w/'test-results.txt').read_text())
