
#include <cassert>
#include <chrono>
#include <cstdint>
#include <string>
#include <vector>
using dword_t=uint32_t;
struct Context { uint64_t lr; };
using ppc_context_t=Context*;
struct Kernel { uint32_t title_id(){return 0x5454081A;} } kernel;
Kernel* kernel_state(){return &kernel;}
int logs=0, launches=0, sleeps=0;
#define XELOGE(...) (++logs)
namespace xbox360ps5 {
bool RelaunchInto(const std::string& path, const std::vector<uint8_t>& data) {
  assert(path.empty()&&data.empty()); ++launches; return false;
}}
namespace xe::threading {
void Sleep(std::chrono::milliseconds delay){assert(delay.count()==1000);++sleeps;throw 42;}
}
void XamShowDirtyDiscErrorUI_entry(dword_t user_index,
                                   const ppc_context_t& ctx) {

  // exit() runs global destructors while guest/GPU threads still use them.
  // LoadExec is the existing native title-switch path; retain the logger.
  XELOGE("Disc read failure: title={:08X} user={} guest_lr={:08X}; returning to library",
         kernel_state()->title_id(), uint32_t(user_index), uint32_t(ctx->lr));
  xbox360ps5::RelaunchInto(std::string(), {});
  // LoadExec only returns on failure. Never resume a fatal guest path and never
  // fall through to libc exit; park this thread so the platform menu can close it.
  XELOGE("Disc read failure: native restart refused; close the title from the PS5 menu");
  for (;;) xe::threading::Sleep(std::chrono::milliseconds(1000));

}

int main(){Context context{0x82812345};try{XamShowDirtyDiscErrorUI_entry(0,&context);assert(false);}catch(int e){assert(e==42);}assert(logs==2&&launches==1&&sleeps==1);}
