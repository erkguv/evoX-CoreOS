from pathlib import Path
import hashlib,json,subprocess
r=Path('/ws/Xbox360PS5');w=Path(__file__).resolve().parent
prior=r/'build/prince-loading-20261009/io-trace'
proof=json.loads((prior/'reproduce.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(proof['source'])==proof['source_sha256']
cmd=list(proof['command'])
subprocess.run(cmd+['-o',str(w/'io-preimage.o')],cwd=r/'build/canary-ps5',check=True)
assert sha(w/'io-preimage.o')==proof['archive_member_sha256'],'IO preimage mismatch'
s=Path(proof['source']).read_text()
s=s.replace('#include "xenia/base/logging.h"','#include "xenia/base/logging.h"\n#include <atomic>',1)
start=s.index('dword_result_t NtReadFile_entry(');end=s.index('DECLARE_XBOXKRNL_EXPORT2(NtReadFile,',start)
block=s[start:end]
marker='      if (io_status_block) {'
assert marker in block
diagnostic='''      // Capture failed or truncated reads without enabling per-call logging.
      // Keep the original result, APC ordering and guest-visible byte count.
      if (XFAILED(result) || bytes_read < uint32_t(buffer_length)) {
        static std::atomic<uint32_t> failures{0};
        const uint32_t number = failures.fetch_add(1, std::memory_order_relaxed);
        if (number < 32) {
          XELOGW("IO read diagnostic {}: path={} handle={:08X} offset={:016X} requested={} read={} status={:08X}",
                 number+1, file->entry()->absolute_path(), uint32_t(file_handle),
                 byte_offset_ptr ? uint64_t(*byte_offset_ptr) : uint64_t(-1),
                 uint32_t(buffer_length), bytes_read, uint32_t(result));
        }
      }
'''
block=block.replace(marker,diagnostic+marker,1)
s=s[:start]+block+s[end:]
target=w/'xboxkrnl_io.cc';target.write_text(s)
cmd[cmd.index('-c')+1]=str(target)
cmd[1:1]=['-fmacro-prefix-map='+str(target)+'='+proof['source']]
subprocess.run(cmd+['-o',str(w/'native/obj/xboxkrnl_io.cc.o')],cwd=r/'build/canary-ps5',check=True)
(w/'io-proof.json').write_text(json.dumps({'baseline_byte_identical':True,'baseline_object':proof['archive_member_sha256'],'compile':cmd,'scope':'32 failed/short read diagnostics, no IO behavior change'},indent=2))
subprocess.run(['bash',str(r/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(r),str(w/'native')],check=True)
p=json.loads((w/'native/build.json').read_text());p['native_sha256']=sha(w/'native/eboot.bin');p['io_diagnostic']=json.loads((w/'io-proof.json').read_text());p['scope']+='; bounded read diagnostics';p['hardware']='pending'
(w/'native/build.json').write_text(json.dumps(p,indent=2))
print('PASS native recovery plus bounded read diagnostics',p['native_sha256'])
