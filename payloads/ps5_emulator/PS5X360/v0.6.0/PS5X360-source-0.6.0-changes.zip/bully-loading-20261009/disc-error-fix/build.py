from pathlib import Path
import hashlib, json, shutil, subprocess

r = Path('/ws/Xbox360PS5')
w = Path(__file__).resolve().parent
base = w.parent / 'candidate/native'
out = w / 'native'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt = json.loads((r / 'build/vulkan-refine4/game-candidate/build.json').read_text())
cmd = next(list(c) for c in receipt['commands'] if '-c' in c and c[c.index('-c')+1].endswith('/xam_ui.cc'))
source_key = cmd[cmd.index('-c')+1]
source = w / 'preimage/xam_ui.cc'
source.parent.mkdir(exist_ok=True)
shutil.copy2(w/'xam_ui.preimage.cc', source)
assert sha(source) == receipt['sources'][source_key], 'Preserved XAM source drift'
cmd[cmd.index('-c')+1] = str(source)
frozen = r / 'build/continuation-20261009/menu/frozen'
cmd[1:1] = ['-I'+str(w/'legacy'), '-fmacro-prefix-map='+str(source)+'='+source_key]
cmd[cmd.index('-o')+1] = str(w / 'preimage.o')
subprocess.run(cmd, cwd=r / 'build/canary-ps5', check=True)
assert sha(w / 'preimage.o') == sha(base / 'obj/xam_ui.cc.o'), 'XAM preimage mismatch: stop'
s = source.read_text()
s = s.replace('#include "xenia/kernel/xam/xam_ui.h"', '#include "xenia/kernel/xam/xam_ui.h"\n#if XE_PLATFORM_PS5\n#include "xbox360ps5/title_switch.hpp"\n#endif', 1)
marker = 'void XamShowDirtyDiscErrorUI_entry(dword_t user_index) {\n'
assert s.count(marker) == 1
s = s.replace(marker, '''void XamShowDirtyDiscErrorUI_entry(dword_t user_index,
                                   const ppc_context_t& ctx) {
#if XE_PLATFORM_PS5
  // exit() runs global destructors while guest/GPU threads still use them.
  // LoadExec is the existing native title-switch path; retain the logger.
  XELOGE("Disc read failure: title={:08X} user={} guest_lr={:08X}; returning to library",
         kernel_state()->title_id(), uint32_t(user_index), uint32_t(ctx->lr));
  xbox360ps5::RelaunchInto(std::string(), {});
  // LoadExec only returns on failure. Never resume a fatal guest path and never
  // fall through to libc exit; park this thread so the platform menu can close it.
  XELOGE("Disc read failure: native restart refused; close the title from the PS5 menu");
  for (;;) xe::threading::Sleep(std::chrono::milliseconds(1000));
#else
''', 1)
marker = '  exit(1);\n}\nDECLARE_XAM_EXPORT1(XamShowDirtyDiscErrorUI'
assert s.count(marker) == 1
s = s.replace(marker, '  exit(1);\n#endif\n}\nDECLARE_XAM_EXPORT1(XamShowDirtyDiscErrorUI', 1)
(w / 'xam_ui.cc').write_text(s)
(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'): shutil.copy2(p, out / 'obj' / p.name)
cmd[cmd.index('-c')+1] = str(w / 'xam_ui.cc')
cmd[cmd.index('-o')+1] = str(out / 'obj/xam_ui.cc.o')
subprocess.run(cmd, cwd=r / 'build/canary-ps5', check=True)
subprocess.run(['bash', str(r / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(r), str(out)], check=True)
unchanged = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name != 'xam_ui.cc.o'}
assert all(sha(out / 'obj' / n) == h for n, h in unchanged.items())
proof = {'version': '0.5.9-loading-discs.2-local', 'baseline_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'), 'xam_preimage_sha256': sha(w / 'preimage.o'), 'compile': cmd, 'unchanged_objects': unchanged, 'hardware': 'pending', 'scope': 'Native disc-error recovery, not a Bully loading fix'}
(out / 'build.json').write_text(json.dumps(proof, indent=2))
print('PASS isolated disc-error candidate', proof['native_sha256'])
