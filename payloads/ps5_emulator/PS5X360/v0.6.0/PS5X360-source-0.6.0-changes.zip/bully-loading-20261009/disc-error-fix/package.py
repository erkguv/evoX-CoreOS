from pathlib import Path
import hashlib,json,zipfile,shutil
w=Path(__file__).resolve().parent;r=w.parents[2]
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((w/'native/build.json').read_text())
assert sha((w/'native/eboot.bin').read_bytes())==p['native_sha256']
notes='''# PS5X360 0.5.9-loading-discs.2 (private candidate)

- PS5 disc-read errors use native title restart into the library instead of
  libc exit from a guest thread. The original path could destroy shared state
  while worker threads still used it. Refused restarts park the failing thread.
- Record title ID and guest caller address when the disc-error UI is requested.
- Log at most 32 failed or short file reads per process in normal log mode.
  File paths, offsets, byte counts and statuses help diagnose loading failures
  without the timing impact of detailed logs. Guest IO behavior is unchanged.
- Keep loading-discs.1 memory release and four-disc library grouping fixes.

Evidence: matching Bully stack contains the disc-error handler exit return
address; XAM and IO baseline objects reproduced byte for byte before changes;
isolated native build/image validation; actual recovery handler body tested
with ASan/UBSan and mocked restart failure; package CRC and manifest checked.

User reports Lost Odyssey starts with detailed logging disabled. Bully loading
is NOT yet fixed or verified; next PS5 run must capture the failing read.
This package is private, not a GitHub release. Keep loading-discs.1 for rollback.
'''
with zipfile.ZipFile(w.parent/'candidate/package/PPSA50011.zip') as z:
 assert z.testzip() is None
 files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
files.update({'PPSA50011/eboot.bin':(w/'native/eboot.bin').read_bytes(),'PPSA50011/VERSION':(p['version']+'\n').encode(),'PPSA50011/RELEASE.json':json.dumps(p,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()})
files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=w/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
 assert z.testzip() is None
 for n,entry in manifest.items():assert sha(z.read('PPSA50011/'+n))==entry['sha256']
(out/'README.md').write_text(notes,encoding='utf-8')
desktop=Path.home()/'Desktop/PS5X360-disc-error-test-20261009';desktop.mkdir(exist_ok=True)
for n in ('PPSA50011.zip','README.md'):shutil.copy2(out/n,desktop/n)
mirror=Path.home()/'Desktop/Xbox360PS5-source/disc-error-20261009';mirror.mkdir(exist_ok=True)
for n in ('xam_ui.cc','xboxkrnl_io.cc','build.py','build_io.py','test.py','test-results.txt','package.py','io-proof.json'):shutil.copy2(w/n,mirror/n)
shutil.copy2(w/'native/build.json',mirror/'build.json')
print('PASS package CRC and',len(manifest),'manifest entries',desktop)
