# Bully loading and native process termination — 2026-10-09

## Observations

- User reports Lost Odyssey starts normally with detailed logging disabled.
- Bully Scholarship Edition (title 5454081A, executable hash
  0B2030C3D550882B), extracted PT-BR folder, still fails loading. Detailed
  logging changes its timing; this is not proof that logging causes the error.
- Captured build: loading-discs.1-local, native SHA256
  d6f81df24df51f653f6af572eed1c1e2ab5d2488db6ebe10e2cb1e029345ffe4.
- Screenshot: SYSTEM_XO_VIOLATION 0xa0020328, XThread0000; boot log has concurrent
  recursive_mutex/mutex EINVAL exceptions and fatal signal in native libc.
- The matching ELF maps stack-scanned return address 0x29931e to the headless
  XamShowDirtyDiscErrorUI exit(1) call. This is a stack scan, not a formal unwind.
  The compiled handler also contains libc exit in its normal dialog branch.
- Detailed session includes Cache1 access through NullDevice and unimplemented
  XFileXctdCompressionInformation queries. Neither is proven to cause this
  particular game's fatal disc-read request. Do not fake successful IO results.

## Candidate scope

Replace PS5 dirty-disc libc exit with existing native LoadExec library restart.
Log the guest caller and title ID. If the platform refuses restart, park only
the fatal caller rather than resume guest execution or invoke global teardown.
Add normal-mode logging for at most 32 failed/short NtReadFile operations;
preserve read results, byte counts, event signaling and APC behavior.

The XAM source was recovered from the original working source snapshot. Its
unmodified object reproduced byte for byte, after restoring the legacy UI
header and retaining the translation-unit basename. The IO baseline also
reproduced the original kernel archive member byte for byte.

The recovery handler body passed a host ASan/UBSan test with mocked native
restart refusal. Native ELF and package validation are separate from PS5
validation. All existing graphics/input/network override objects remain.

## Pending console evidence

Run Bully with detailed logging OFF; retrieve the normal game log, including
IO read diagnostic and Disc read failure messages. Check whether recovery
returns to the library. Bully loading/gameplay is still unverified and the
underlying file/cache/guest error remains open. Four-disc campaign transitions
also need hardware testing; Lost Odyssey startup success does not validate them.
