from pathlib import Path
import shutil
w=Path(__file__).resolve().parent/'file-limit-trace'
w.mkdir(exist_ok=True)
base=w.parent/'file-limit-fix'
s=(base/'build.py').read_text()
s=s.replace("base=w.parent/'host-open-trace/native'", "base=w.parent/'file-limit-fix/native'")
s=s.replace("(w.parent/'host-open-trace/host_path_entry.cc').read_text()", "(w.parent/'file-limit-fix/host_path_entry.cc').read_text()")
a=s.index("s=s.replace('#include <cstdio>'")
b=s.index("(w/'host_path_entry.cc').write_text(s)",a)
s=s[:a]+'''s=s.replace('#include <sys/resource.h>', '#include <sys/resource.h>\\n#include <fcntl.h>\\n#include <unistd.h>',1)
s=s.replace('static void EnsureHostFileBudget() {', 'static int budget_trace = -1;\\nstatic void EnsureHostFileBudget() {',1)
s=s.replace('  xbox360ps5::Stage(text);\\n}\\n\\nX_STATUS', '  xbox360ps5::Stage(text);\\n  budget_trace = open("/app0/logs/file-io-budget.log", O_WRONLY | O_CREAT | O_APPEND, 0644);\\n  if (budget_trace >= 0) { (void)!write(budget_trace, text, std::strlen(text)); (void)!write(budget_trace, "\\\\n", 1); fsync(budget_trace); }\\n}\\n\\nX_STATUS',1)
s=s.replace('#include <cstdio>', '#include <cstdio>\\n#include <cstring>',1)
s=s.replace('      xbox360ps5::Stage(text);', '      xbox360ps5::Stage(text);\\n      if (budget_trace >= 0) { (void)!write(budget_trace, text, std::strlen(text)); (void)!write(budget_trace, "\\\\n", 1); fsync(budget_trace); }',1)
'''+s[b:]
s=s.replace('0.5.9-file-limit-fix.1-local','0.5.9-file-limit-trace.1-local')
(w/'build.py').write_text(s)
shutil.copy2(base/'test.py',w/'test.py')
t=(w/'test.py').read_text().replace("a=s.index('static void EnsureHostFileBudget()')", "a=s.index('static int budget_trace')")
t=t.replace('#include <cstdio>','#include <cstdio>\n#include <cstring>')
(w/'test.py').write_text(t)
p=(base/'package.py').read_text().replace("base=w.parent/'host-open-trace'", "base=w.parent/'file-limit-fix'")
a=p.index('notes=');b=p.index('with zipfile.ZipFile',a)
p=p[:a]+'''notes="""# Persistent file-budget diagnostic (private candidate)

Keep the previous file-limit adjustment. Record its actual result and up to
32 failed native opens to logs/file-io-budget.log, which survives a return
to the library. This is a diagnostic, not a confirmed loading fix.
All other native override objects remain unchanged. No public release.
"""
'''+p[b:]
p=p.replace('file-limit-fix-20261009','file-limit-trace-20261009')
(w/'package.py').write_text(p)
d=(base/'deploy-ready.py').read_text().replace('eboot-before-file-limit-fix-','eboot-before-file-limit-trace-').replace('eboot-file-limit-fix-','eboot-file-limit-trace-')
(w/'deploy-ready.py').write_text(d)
(w/'INVESTIGATION.md').write_text('New sessions 230448 and 230533 still return through dirty-disc. Boot log was overwritten by restart. Actual FILELIMIT result is unavailable; persistent bounded native diagnostics required. Hardware resolution remains pending.\n')
print(w)
