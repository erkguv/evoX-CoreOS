#include <filesystem>
#include <memory>
#include <string>
#include <cassert>
#include <cstdio>
#include <vector>
#include <thread>
#include <sys/resource.h>
namespace xe::filesystem {
class FileHandle {
public:
  virtual ~FileHandle() = default;
  virtual bool Read(size_t, void*, size_t, size_t*) = 0;
  virtual bool Write(size_t, const void*, size_t, size_t*) = 0;
  virtual bool SetLength(size_t) = 0;
  virtual void Flush() = 0;
protected:
  explicit FileHandle(const std::filesystem::path& path):path_(path) {}
  std::filesystem::path path_;
}; }
#include "readonly_file_pool.hpp"
int main() {
  char directory[]="/tmp/ps5-pool-XXXXXX"; assert(mkdtemp(directory));
  auto root=std::filesystem::path(directory);
  for(int i=0;i<256;i++) { auto p=root/std::to_string(i); FILE* f=fopen(p.c_str(),"wb"); assert(f); fprintf(f,"bank-%03d-data",i); fclose(f); }
  rlimit limit; assert(getrlimit(RLIMIT_NOFILE,&limit)==0); auto hard=limit.rlim_max; limit.rlim_cur=96; assert(setrlimit(RLIMIT_NOFILE,&limit)==0);
  std::vector<std::unique_ptr<xe::filesystem::FileHandle>> handles;
  for(int i=0;i<2048;i++) { auto h=PooledReadOnlyFileHandle::Open(root/std::to_string(i%256)); assert(h); handles.push_back(std::move(h)); }
  auto check=[&](int worker) { for(int i=worker;i<2048;i+=8) { char buffer[32]{},expected[32]{}; size_t count=0; assert(handles[i]->Read(0,buffer,sizeof(buffer),&count)); snprintf(expected,sizeof(expected),"bank-%03d-data",i%256); assert(std::string(buffer,count)==expected); assert(handles[i]->Read(999,buffer,4,&count)&&count==0); assert(!handles[i]->Write(0,buffer,1,&count)&&count==0); } };
  std::vector<std::thread> workers; for(int i=0;i<8;i++)workers.emplace_back(check,i); for(auto& t:workers)t.join();
  assert(!PooledReadOnlyFileHandle::Open(root/"missing"));
  // Reopen an evicted path after replacement: old logical handle must fail.
  for(int i=1;i<256;i++)assert(PooledReadOnlyFileHandle::Open(root/std::to_string(i)));
  std::filesystem::rename(root/"0",root/"old"); FILE* f=fopen((root/"0").c_str(),"wb"); assert(f); fputs("replacement",f); fclose(f);
  char data[32]; size_t count; assert(!handles[0]->Read(0,data,sizeof(data),&count));
  assert(getrlimit(RLIMIT_NOFILE,&limit)==0&&limit.rlim_max==hard&&limit.rlim_cur==96);
  handles.clear(); std::filesystem::remove_all(root);
  puts("PASS 2048 logical handles / 256 files under soft limit 96; 8 concurrent readers, LRU reopen, exact bytes, EOF, missing and replaced files, write rejection; hard limit unchanged");
}
