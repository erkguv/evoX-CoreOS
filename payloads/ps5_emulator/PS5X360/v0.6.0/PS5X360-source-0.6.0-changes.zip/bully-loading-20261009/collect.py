from pathlib import Path
import ftplib, io, json, re, datetime

work = Path(__file__).resolve().parent
out = work / 'console'
out.mkdir(parents=True, exist_ok=True)
report = {'collected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'remote_writes': False}
with ftplib.FTP() as ftp:
    ftp.connect('192.168.0.19', 2121, timeout=20)
    ftp.login()
    def read(path):
        data = io.BytesIO()
        ftp.retrbinary('RETR ' + path, data.write, blocksize=1024 * 1024)
        return data.getvalue()
    base = '/data/homebrew/PPSA50011'
    report['version'] = read(base + '/VERSION').decode().strip()
    report['release'] = json.loads(read(base + '/RELEASE.json'))
    for name in ('framegen.conf', 'render-target-fsi.conf', 'assets/presets.txt'):
        try:
            data = read(base + '/' + name)
            (out / Path(name).name).write_bytes(data)
        except ftplib.error_perm as exc:
            report[name] = str(exc)
    listing = []
    ftp.retrlines('LIST ' + base + '/logs', listing.append)
    names = [s.split(maxsplit=8)[-1] for s in listing if len(s.split(maxsplit=8)) == 9]
    matches = [n for n in names if 'bully' in n.lower() and n.endswith('.log')]
    def stamp(name):
        found = re.search(r'(\d{8}-\d{6})-UTC', name)
        return found.group(1) if found else ''
    report['bully_log_names'] = sorted(matches, key=stamp)
    for name in sorted(matches, key=stamp)[-3:]:
        data = read(base + '/logs/' + name)
        (out / name).write_bytes(data)
    (out / 'boot.log').write_bytes(read(base + '/logs/boot.log'))
(work / 'collection.json').write_text(json.dumps(report, indent=2))
print(json.dumps({k: v for k, v in report.items() if k != 'release'}, indent=2))
