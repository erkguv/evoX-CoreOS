from pathlib import Path
import ftplib,json
w=Path(__file__).resolve().parent/'file-review'
with ftplib.FTP() as f:
 f.connect('192.168.0.19',2121,timeout=20);f.login();rows=[]
 root='/data/homebrew/PPSA50011/assets/roms/BULLY SCHOLARSHIP EDITION PT-BR RGH'
 def child(path,name):
  entries=[];f.retrlines('LIST '+path,entries.append)
  return path+'/'+next(r.split(maxsplit=8)[8] for r in entries if len(r.split(maxsplit=8))==9 and r.split(maxsplit=8)[8].lower()==name.lower())
 folder=child(child(root,'audio'),'xact')
 f.retrlines('LIST '+folder,rows.append)
 print(folder)
(w/'audio-listing.json').write_text(json.dumps(rows,indent=2))
print('entries',len(rows));print('\n'.join(r for r in rows if any(n.lower() in r.lower() for n in ('SCGATE','CARNCURT','INDUSTRY','BIRDS','AUDTEST','6_4PLYR'))))
