#include <algorithm>
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <vector>
namespace xbox360ps5 {void Stage(const char* text){std::puts(text);}}
static void EnsureHostFileBudget() {
  struct rlimit before{};
  if (getrlimit(RLIMIT_NOFILE, &before) != 0) {
    xbox360ps5::Stage("FILELIMIT query refused; keeping platform limit");
    return;
  }
  // Only raise the process soft limit, within its existing hard limit.
  // No privilege change, global system tuning or file-handle eviction.
  const rlim_t wanted = std::min<rlim_t>(4096, before.rlim_max);
  int result = 0;
  int error = 0;
  if (before.rlim_cur < wanted) {
    struct rlimit requested = before;
    requested.rlim_cur = wanted;
    result = setrlimit(RLIMIT_NOFILE, &requested);
    if (result != 0) error = errno;
  }
  struct rlimit after = before;
  if (getrlimit(RLIMIT_NOFILE, &after) != 0) after = before;
  char text[256];
  std::snprintf(text, sizeof(text), "FILELIMIT soft=%llu -> %llu hard=%llu target=%llu rc=%d errno=%d", static_cast<unsigned long long>(before.rlim_cur), static_cast<unsigned long long>(after.rlim_cur), static_cast<unsigned long long>(before.rlim_max), static_cast<unsigned long long>(wanted), result, error);
  xbox360ps5::Stage(text);
}


int main(){rlimit original;assert(getrlimit(RLIMIT_NOFILE,&original)==0);rlimit low=original;low.rlim_cur=64;assert(setrlimit(RLIMIT_NOFILE,&low)==0);
std::vector<int> fds;for(;;){int fd=open("/dev/null",O_RDONLY);if(fd<0)break;fds.push_back(fd);}assert(errno==EMFILE);EnsureHostFileBudget();rlimit after;assert(getrlimit(RLIMIT_NOFILE,&after)==0);assert(after.rlim_max==original.rlim_max&&after.rlim_cur==std::min<rlim_t>(4096,original.rlim_max));
for(int i=0;i<512;++i){int fd=open("/dev/null",O_RDONLY);assert(fd>=0);fds.push_back(fd);}for(int fd:fds)close(fd);std::puts("PASS real EMFILE reproduced, actual helper restores room for 512 further opens, hard limit preserved");}
