from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('/ws/Xbox360PS5');w=Path(__file__).resolve().parent;base=w.parent/'host-open-trace/native';out=w/'native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
shutil.copytree(base/'obj',out/'obj',dirs_exist_ok=True)
cmd=list(json.loads((base/'build.json').read_text())['compile']);cmd[cmd.index('-o')+1]=str(w/'preimage.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
assert sha(w/'preimage.o')==sha(base/'obj/host_path_entry.cc.o'),'Host-entry preimage mismatch'
s=(w.parent/'host-open-trace/host_path_entry.cc').read_text()
s=s.replace('#include <cstdio>','#include <cstdio>\n#include <mutex>\n#include <sys/resource.h>',1)
marker='X_STATUS HostPathEntry::Open(uint32_t desired_access, File** out_file) {\n'
assert s.count(marker)==1
helper='''static void EnsureHostFileBudget() {
  struct rlimit before{};
  if (getrlimit(RLIMIT_NOFILE, &before) != 0) {
    xbox360ps5::Stage("FILELIMIT query refused; keeping platform limit");
    return;
  }
  // Only raise the process soft limit, within its existing hard limit.
  // No privilege change, global system tuning or file-handle eviction.
  const rlim_t wanted = std::min<rlim_t>(4096, before.rlim_max);
  int result = 0;
  int error = 0;
  if (before.rlim_cur < wanted) {
    struct rlimit requested = before;
    requested.rlim_cur = wanted;
    result = setrlimit(RLIMIT_NOFILE, &requested);
    if (result != 0) error = errno;
  }
  struct rlimit after = before;
  if (getrlimit(RLIMIT_NOFILE, &after) != 0) after = before;
  char text[256];
  std::snprintf(text, sizeof(text), "FILELIMIT soft=%llu -> %llu hard=%llu target=%llu rc=%d errno=%d", static_cast<unsigned long long>(before.rlim_cur), static_cast<unsigned long long>(after.rlim_cur), static_cast<unsigned long long>(before.rlim_max), static_cast<unsigned long long>(wanted), result, error);
  xbox360ps5::Stage(text);
}

'''
s=s.replace(marker,helper+marker+'''  static std::once_flag budget_once;
  std::call_once(budget_once, EnsureHostFileBudget);
''',1)
(w/'host_path_entry.cc').write_text(s)
cmd[cmd.index('-c')+1]=str(w/'host_path_entry.cc');cmd[cmd.index('-o')+1]=str(out/'obj/host_path_entry.cc.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
subprocess.run(['python3',str(w/'test.py')],check=True)
subprocess.run(['bash',str(r/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(r),str(out)],check=True)
kept={p.name:sha(p) for p in (base/'obj').glob('*.o') if p.name!='host_path_entry.cc.o'}
assert all(sha(out/'obj'/n)==h for n,h in kept.items())
p={'version':'0.5.9-file-limit-fix.1-local','native_sha256':sha(out/'eboot.bin'),'baseline_sha256':sha(base/'eboot.bin'),'preimage_byte_identical':True,'compile':cmd,'unchanged_objects':kept,'scope':'Raise host-file soft descriptor limit to min(4096, existing hard limit), once; no hard-limit increase','hardware_gameplay':'pending'}
(out/'build.json').write_text(json.dumps(p,indent=2));print('PASS general file-limit candidate',p['native_sha256'])
