from pathlib import Path
import hashlib,json,zipfile,shutil
w=Path(__file__).resolve().parent;base=w.parent/'host-open-trace';p=json.loads((w/'native/build.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
notes="""# PS5X360 0.5.9-file-limit-fix.1 (private candidate)

- Before opening the first host-backed game/content file, raise the process
  soft RLIMIT_NOFILE to min(4096, its existing hard limit), once.
- Preserve the system hard limit. If the platform refuses the request,
  retain its limit and record the failure. No forced file closing, file
  substitution, altered game data or title-specific bypass.
- Keep safe disc-error return to the library, normal-mode failed-open
  diagnostics, EOF handling, graphics, audio, networking, DLC and controls.

Confirmed PS5 cause: existing Bully audio banks fail to open with errno 24,
EMFILE. The game subsequently calls its fatal dirty-disc handler. Native
imports getrlimit/setrlimit are present in the existing SDK kernel stubs.
Actual helper was tested with real descriptor exhaustion under ASan/UBSan:
soft limit 64 exhausted, helper raises it within the existing hard limit,
512 further opens succeed, hard limit remains unchanged.

Original host-entry object reproduced byte for byte. All other native
override objects are identical to the installed baseline. Native image
and package checks passed. PS5 limit adjustment/gameplay remain pending.
If the console hard limit is already too low, this adjustment alone cannot
resolve exhaustion; FILELIMIT in boot.log records the actual result.
No public release. Previous executable preserved for rollback.
"""
with zipfile.ZipFile(base/'package/PPSA50011.zip') as z:files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
image=(w/'native/eboot.bin').read_bytes();assert sha(image)==p['native_sha256']
files.update({'PPSA50011/eboot.bin':image,'PPSA50011/VERSION':(p['version']+'\n').encode(),'PPSA50011/RELEASE.json':json.dumps(p,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()});files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()};files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=w/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
 assert z.testzip() is None
 for n,e in manifest.items():assert sha(z.read('PPSA50011/'+n))==e['sha256']
(out/'README.md').write_text(notes,encoding='utf-8')
(w/'INVESTIGATION.md').write_text(notes,encoding='utf-8')
mirror=Path.home()/'Desktop/Xbox360PS5-source/file-limit-fix-20261009';mirror.mkdir(exist_ok=True)
for n in ('build.py','host_path_entry.cc','package.py','INVESTIGATION.md','prepare.py','test.py','test.cpp','test-results.txt'):shutil.copy2(w/n,mirror/n)
shutil.copy2(w/'native/build.json',mirror/'build.json')
s=(base/'deploy.py').read_text().replace("root / 'build/bully-loading-20261009/return-trace/native'","root / 'build/bully-loading-20261009/return-trace/native'")
s=s.replace('eboot-before-eof-fix-','eboot-before-file-errors-').replace('eboot-eof-fix-','eboot-file-errors-')
(w/'deploy.py').write_text(s,encoding='utf-8');print('PASS package CRC and',len(manifest),'manifest entries')
