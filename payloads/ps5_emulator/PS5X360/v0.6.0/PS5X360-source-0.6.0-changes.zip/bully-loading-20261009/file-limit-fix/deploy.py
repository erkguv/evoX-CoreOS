"""Package 0.5.9-perf-menu.1-local over the installed prince-io.1 package and install it on the PS5.

usage: python package_deploy.py package   -> package/PPSA50011.zip (+ Desktop copy)
       python package_deploy.py deploy    -> installs with a backup (refuses while the emulator runs)
Only eboot.bin, VERSION, RELEASE.json, RELEASE_NOTES.md and MANIFEST.json change on the console; the
Prince I/O trace marker is renamed so it cannot arm a later build.
"""
from pathlib import Path
import datetime
import ftplib
import hashlib
import importlib.util
import io
import json
import shutil
import socket
import sys
import zipfile

HOST = '192.168.0.19'
root = Path(__file__).resolve().parents[3]
work = Path(__file__).resolve().parent
native = work / 'native'
base = root / 'build/prince-loading-20261009'
proof = json.loads((native / 'build.json').read_text())
version = proof['version']
sha = lambda b: hashlib.sha256(b).hexdigest()
names = ('eboot.bin', 'VERSION', 'RELEASE.json', 'RELEASE_NOTES.md', 'MANIFEST.json')

notes = '''# PS5X360 0.5.9-perf-menu.2 (private test build)

Based on the installed 0.5.9-prince-io.1 build.

- Frame generation switch moved from Settings > General to Settings >
  Performance (last row). Changing it restarts the emulator when the settings
  close. The FPS counter shows Game, Output and FG.
- The Prince of Persia I/O trace object is removed again (its capture showed
  every file open succeeds; the loading stall is in the audio threads).
- New switch Settings > Performance > Accurate render targets (FSI, test):
  Xenia's Vulkan fragment-shader-interlock render-target path (ROV on D3D12).
  Off by default; restarts when the settings close.
- Everything else is unchanged: network, APC delivery, controller driver,
  version label, Kinect.
'''


def package():
    with zipfile.ZipFile(base / 'package/PPSA50011.zip') as z:
        files = {i.filename: z.read(i) for i in z.infolist() if not i.is_dir()}
    image = (native / 'eboot.bin').read_bytes()
    assert sha(image) == proof['native_sha256']
    files['PPSA50011/eboot.bin'] = image
    files['PPSA50011/VERSION'] = (version + '\n').encode()
    files['PPSA50011/RELEASE.json'] = json.dumps(proof, indent=2).encode()
    files['PPSA50011/RELEASE_NOTES.md'] = notes.encode()
    files.pop('PPSA50011/MANIFEST.json', None)
    manifest = {n.removeprefix('PPSA50011/'): {'sha256': sha(b), 'bytes': len(b)} for n, b in files.items()}
    files['PPSA50011/MANIFEST.json'] = json.dumps(manifest, indent=2).encode()
    out = work / 'package'
    out.mkdir(exist_ok=True)
    with zipfile.ZipFile(out / 'PPSA50011.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items():
            z.writestr(n, b)
    with zipfile.ZipFile(out / 'PPSA50011.zip') as z:
        assert z.testzip() is None
    (out / 'README.md').write_text(notes)
    desktop = Path.home() / 'Desktop/PS5X360-perf-menu2-test-20261009'
    desktop.mkdir(exist_ok=True)
    for n in ('PPSA50011.zip', 'README.md'):
        shutil.copy2(out / n, desktop / n)
    delta = Path.home() / 'Desktop/Xbox360PS5-source/menu-perf-20261009'
    delta.mkdir(parents=True, exist_ok=True)
    for p in (work / 'launcher.cpp', work / 'apply_edit.py', work / 'build.py', work / 'package_deploy.py',
              native / 'build.json'):
        shutil.copy2(p, delta / p.name)
    print('packaged', sha(image), len(manifest), 'files')


def deploy():
    spec = importlib.util.spec_from_file_location('verify', root / 'tools/deploy-native-probe.py')
    verify = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verify)
    with zipfile.ZipFile(work / 'package/PPSA50011.zip') as z:
        updates = {n: z.read('PPSA50011/' + n) for n in names}
    assert sha(updates['eboot.bin']) == proof['native_sha256']
    for port in range(8360, 8368):
        with socket.socket() as s:
            s.settimeout(.3)
            if s.connect_ex((HOST, port)) == 0:
                raise RuntimeError('Emulator still active (settings page answering)')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    remote, temp = 'eboot-before-file-errors-' + stamp + '.bak', 'eboot-file-errors-' + stamp + '.new'
    with ftplib.FTP() as f:
        f.connect(HOST, 2121, timeout=30)
        f.login()
        lines = []
        f.retrlines('LIST /mnt/sandbox', lines.append)
        if any('PPSA50011' in s for s in lines):
            raise RuntimeError('Title still mounted: close PS5X360 first')
        # The settings page is off during games and the sandbox listing missed a
        # running title once (17:17 UTC): a game writes its log every 30 s, so a
        # log touched in the last two minutes means the emulator is still open.
        logs = []
        f.retrlines('LIST /data/homebrew/PPSA50011/logs', logs.append)
        # Compare remote modification times with the remote clock. A console
        # clock ahead of the PC made a closed title look recently active.
        # The isolated non-log probe is removed before any executable swap.
        clock_name = '/data/homebrew/PPSA50011/.deploy-clock-' + stamp
        f.storbinary('STOR ' + clock_name, io.BytesIO(b'clock probe\n'))
        try:
            clock_rows = []
            f.retrlines('LIST /data/homebrew/PPSA50011', clock_rows.append)
            clock_parts = next(s.split(None, 8) for s in clock_rows if len(s.split(None, 8)) == 9 and s.split(None, 8)[8] == clock_name.rsplit('/', 1)[1])
            if ':' not in clock_parts[7]:
                raise RuntimeError('Cannot determine console clock')
            pc_now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
            now = datetime.datetime.strptime(f'{pc_now.year} {clock_parts[5]} {clock_parts[6]} {clock_parts[7]}', '%Y %b %d %H:%M')
            console_clock_offset = (now - pc_now).total_seconds()
        finally:
            f.sendcmd('DELE ' + clock_name)
        for entry in logs:
            parts = entry.split(None, 8)
            if len(parts) < 9 or not parts[0].startswith('-') or ':' not in parts[7]:
                continue
            when = datetime.datetime.strptime(f'{now.year} {parts[5]} {parts[6]} {parts[7]}', '%Y %b %d %H:%M')
            if abs((now - when).total_seconds()) < 150:
                raise RuntimeError(f'Emulator still active (log {parts[8]} written at {parts[7]} UTC)')
        f.cwd('/data/homebrew/PPSA50011')

        def read(n):
            b = io.BytesIO()
            f.retrbinary('RETR ' + n, b.write, blocksize=1024 * 1024)
            return b.getvalue()

        previous = {n: read(n) for n in names}
        installed = root / 'build/bully-loading-20261009/return-trace/native'  # 0.5.9-perf-menu.1-local, installed at 17:17 UTC
        verify.verify_eboot(previous['eboot.bin'], (installed / 'eboot.bin').read_bytes(),
                            (installed / 'eboot.elf').read_bytes())
        backup = work / 'console-backups' / stamp
        backup.mkdir(parents=True)
        for n, b in previous.items():
            (backup / n).write_bytes(b)
        f.storbinary('STOR ' + temp, io.BytesIO(updates['eboot.bin']), blocksize=1024 * 1024)
        verify.verify_eboot(read(temp), updates['eboot.bin'], (native / 'eboot.elf').read_bytes())
        f.rename('eboot.bin', remote)
        try:
            f.rename(temp, 'eboot.bin')
            for n, b in updates.items():
                if n != 'eboot.bin':
                    f.storbinary('STOR ' + n, io.BytesIO(b))
            result = verify.verify_eboot(read('eboot.bin'), updates['eboot.bin'], (native / 'eboot.elf').read_bytes())
        except Exception:
            try:
                f.rename('eboot.bin', 'eboot-rejected-disc-error-' + stamp + '.bak')
            except ftplib.error_perm:
                pass
            f.rename(remote, 'eboot.bin')
            for n, b in previous.items():
                if n != 'eboot.bin':
                    f.storbinary('STOR ' + n, io.BytesIO(b))
            raise
    receipt = dict(installed=True, version=version, native_sha256=proof['native_sha256'], backup=remote,
                   local_backup=str(backup), verification=result, console_clock_offset_seconds=console_clock_offset, hardware_gameplay='pending')
    (work / 'deployment.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt, indent=2))


deploy()

