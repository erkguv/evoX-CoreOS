from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent;s=(w/'host_path_entry.cc').read_text();a=s.index('static void EnsureHostFileBudget()');b=s.index('X_STATUS HostPathEntry::Open(',a);body=s[a:b]
prefix='''#include <algorithm>
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <sys/resource.h>
#include <fcntl.h>
#include <unistd.h>
#include <vector>
namespace xbox360ps5 {void Stage(const char* text){std::puts(text);}}
'''
test=prefix+body+'''
int main(){rlimit original;assert(getrlimit(RLIMIT_NOFILE,&original)==0);rlimit low=original;low.rlim_cur=64;assert(setrlimit(RLIMIT_NOFILE,&low)==0);
std::vector<int> fds;for(;;){int fd=open("/dev/null",O_RDONLY);if(fd<0)break;fds.push_back(fd);}assert(errno==EMFILE);EnsureHostFileBudget();rlimit after;assert(getrlimit(RLIMIT_NOFILE,&after)==0);assert(after.rlim_max==original.rlim_max&&after.rlim_cur==std::min<rlim_t>(4096,original.rlim_max));
for(int i=0;i<512;++i){int fd=open("/dev/null",O_RDONLY);assert(fd>=0);fds.push_back(fd);}for(int fd:fds)close(fd);std::puts("PASS real EMFILE reproduced, actual helper restores room for 512 further opens, hard limit preserved");}
'''
(w/'test.cpp').write_text(test)
subprocess.run(['clang++-18','-std=c++20','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',str(w/'test.cpp'),'-o',str(w/'test')],check=True)
p=subprocess.run([str(w/'test')],check=True,capture_output=True,text=True);(w/'test-results.txt').write_text(p.stdout);print(p.stdout)
