from pathlib import Path
w=Path(__file__).resolve().parent;base=w.parent/'host-open-trace'
s=(base/'package.py').read_text().replace("base=w.parent/'file-error-trace'", "base=w.parent/'host-open-trace'")
a=s.index('notes=');b=s.index('with zipfile.ZipFile',a)
s=s[:a]+'''notes="""# PS5X360 0.5.9-file-limit-fix.1 (private candidate)

- Before opening the first host-backed game/content file, raise the process
  soft RLIMIT_NOFILE to min(4096, its existing hard limit), once.
- Preserve the system hard limit. If the platform refuses the request,
  retain its limit and record the failure. No forced file closing, file
  substitution, altered game data or title-specific bypass.
- Keep safe disc-error return to the library, normal-mode failed-open
  diagnostics, EOF handling, graphics, audio, networking, DLC and controls.

Confirmed PS5 cause: existing Bully audio banks fail to open with errno 24,
EMFILE. The game subsequently calls its fatal dirty-disc handler. Native
imports getrlimit/setrlimit are present in the existing SDK kernel stubs.
Actual helper was tested with real descriptor exhaustion under ASan/UBSan:
soft limit 64 exhausted, helper raises it within the existing hard limit,
512 further opens succeed, hard limit remains unchanged.

Original host-entry object reproduced byte for byte. All other native
override objects are identical to the installed baseline. Native image
and package checks passed. PS5 limit adjustment/gameplay remain pending.
If the console hard limit is already too low, this adjustment alone cannot
resolve exhaustion; FILELIMIT in boot.log records the actual result.
No public release. Previous executable preserved for rollback.
"""
'''+s[b:]
s=s.replace("('build.py','host_path_entry.cc','package.py','INVESTIGATION.md','prepare.py')", "('build.py','host_path_entry.cc','package.py','INVESTIGATION.md','prepare.py','test.py','test.cpp','test-results.txt')")
s=s.replace('bully-host-open-20261009','file-limit-fix-20261009')
(w/'package.py').write_text(s)
s=(base/'deploy-ready.py').read_text().replace("root / 'build/bully-loading-20261009/file-error-trace/native'", "root / 'build/bully-loading-20261009/host-open-trace/native'")
s=s.replace('eboot-before-host-open-','eboot-before-file-limit-fix-').replace('eboot-host-open-','eboot-file-limit-fix-')
(w/'deploy-ready.py').write_text(s)
