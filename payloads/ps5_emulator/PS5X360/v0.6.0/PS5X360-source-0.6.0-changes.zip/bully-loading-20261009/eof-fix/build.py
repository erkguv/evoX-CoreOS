from pathlib import Path
import hashlib,json,shlex,shutil,subprocess
r=Path('/ws/Xbox360PS5');w=Path(__file__).resolve().parent
base=w.parent/'disc-error-fix/native';out=w/'native';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
target='core/src/xenia/vfs/CMakeFiles/xenia-vfs.dir/devices/host_path_file.cc.o'
cmd=shlex.split(subprocess.check_output(['ninja','-t','commands',target],cwd=r/'build/canary-ps5',text=True).strip())
source=Path(cmd[cmd.index('-c')+1]);s=source.read_text()
cmd[cmd.index('-o')+1]=str(w/'preimage.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
archive=r/'build/canary-ps5/obj/Linux/libxenia-vfs.a'
original=subprocess.check_output(['llvm-ar-18','p',str(archive),'host_path_file.cc.o'])
assert sha(w/'preimage.o')==hashlib.sha256(original).hexdigest(),'VFS preimage mismatch'
old='''    return X_STATUS_SUCCESS;
  } else {
    return X_STATUS_END_OF_FILE;
  }
}'''
new='''    // POSIX pread succeeds with zero bytes at EOF. The guest NT file
    // interface must distinguish EOF from a successful data transfer.
    // Preserve zero-length probes and successful partial reads.
    if (!buffer.empty() && *out_bytes_read == 0) {
      return X_STATUS_END_OF_FILE;
    }
    return X_STATUS_SUCCESS;
  } else {
    return X_STATUS_END_OF_FILE;
  }
}'''
assert old in s;s=s.replace(old,new,1)
patched=w/'host_path_file.cc';patched.write_text(s)
shutil.copytree(base/'obj',out/'obj',dirs_exist_ok=True)
cmd[cmd.index('-c')+1]=str(patched);cmd[cmd.index('-o')+1]=str(out/'obj/host_path_file.cc.o')
cmd[1:1]=['-fmacro-prefix-map='+str(patched)+'='+str(source)]
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
subprocess.run(['python3',str(w/'test.py')],check=True)
subprocess.run(['bash',str(r/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(r),str(out)],check=True)
kept={p.name:sha(p) for p in (base/'obj').glob('*.o')}
assert all(sha(out/'obj'/n)==h for n,h in kept.items())
p={'version':'0.5.9-loading-eof.1-local','baseline_sha256':sha(base/'eboot.bin'),'native_sha256':sha(out/'eboot.bin'),'preimage_byte_identical':True,'vfs_preimage_sha256':sha(w/'preimage.o'),'compile':cmd,'unchanged_objects':kept,'scope':'Host-backed regular-file EOF status; existing recovery preserved','hardware_gameplay':'pending'}
(out/'build.json').write_text(json.dumps(p,indent=2))
print('PASS isolated native candidate',p['native_sha256'])
