from pathlib import Path
import subprocess
w=Path(__file__).resolve().parent
s=(w/'host_path_file.cc').read_text();a=s.index('X_STATUS HostPathFile::ReadSync(');b=s.index('X_STATUS HostPathFile::WriteSync(',a)
body=s[a:b]
test=r'''
#include <cassert>
#include <cstdint>
#include <span>
#include <unistd.h>
#include <fcntl.h>
#include <cstdlib>
using X_STATUS=uint32_t;
constexpr X_STATUS X_STATUS_SUCCESS=0, X_STATUS_END_OF_FILE=0xC0000011, X_STATUS_ACCESS_DENIED=0xC0000022;
struct FileAccess {static constexpr uint32_t kGenericRead=1,kFileReadData=2;};
struct Handle {int fd; bool Read(size_t offset,void* buf,size_t len,size_t* bytes){auto n=pread(fd,buf,len,offset);*bytes=n<0?0:n;return n>=0;}};
struct HostPathFile {uint32_t file_access_;Handle* file_handle_;X_STATUS ReadSync(std::span<uint8_t>,size_t,size_t*);};
'''+body+r'''
int main(){char name[]="/tmp/xenia-eof-XXXXXX";int fd=mkstemp(name);assert(fd>=0);unlink(name);assert(write(fd,"abc",3)==3);Handle h{fd};HostPathFile f{1,&h};uint8_t buffer[8]{};size_t n=0;
assert(f.ReadSync(buffer,0,&n)==0&&n==3&&buffer[0]=='a');
assert(f.ReadSync(buffer,2,&n)==0&&n==1);
assert(f.ReadSync(buffer,3,&n)==X_STATUS_END_OF_FILE&&n==0);
assert(f.ReadSync(buffer,4096,&n)==X_STATUS_END_OF_FILE&&n==0);
assert(f.ReadSync(std::span<uint8_t>(buffer,0),3,&n)==0&&n==0);
f.file_access_=0;assert(f.ReadSync(buffer,0,&n)==X_STATUS_ACCESS_DENIED);f.file_access_=1;
assert(ftruncate(fd,0)==0);assert(f.ReadSync(buffer,0,&n)==X_STATUS_END_OF_FILE&&n==0);
close(fd);assert(f.ReadSync(buffer,0,&n)==X_STATUS_END_OF_FILE&&n==0);
}
'''
(w/'test.cpp').write_text(test)
subprocess.run(['clang++-18','-std=c++20','-Wall','-Wextra','-Werror','-fsanitize=address,undefined',str(w/'test.cpp'),'-o',str(w/'test')],check=True)
subprocess.run([str(w/'test')],check=True)
(w/'test-results.txt').write_text('PASS actual ReadSync body with real pread: full/partial read, EOF, beyond EOF, empty file, zero-length probe, permissions, bad descriptor. ASan/UBSan. Not PS5 gameplay validation.\n')
print((w/'test-results.txt').read_text())
