from pathlib import Path
import hashlib,json,zipfile,shutil
w=Path(__file__).resolve().parent;old=w.parent/'disc-error-fix'
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((w/'native/build.json').read_text())
notes='''# PS5X360 0.5.9-loading-eof.1 (private candidate)

- Host-backed file reads now return END_OF_FILE for a nonempty request that
  reads zero bytes. Preserve partial reads, zero-length requests, permissions
  and the existing backend read-error behavior. No title-specific bypass.
- Keep native disc-error recovery into the library and four-disc grouping.
- Keep all existing GPU, audio, network, controller, DLC and Kinect objects.

Evidence: the Bully capture repeatedly reads zero bytes from font.hdt with
SUCCESS. Act.dir has 479 entries whose maximum sector end equals Act.img's
2,461,696 bytes; this archive size alone is not evidence of corruption.
The original VFS object was reproduced byte for byte. Tests use the actual
ReadSync body with real pread calls under ASan/UBSan, covering partial reads,
EOF, empty files, zero-length requests, permissions and invalid descriptors.
Native image checks and the package manifest passed.

Bully gameplay remains unverified. This corrects a general EOF contract
inconsistency; it does not prove that EOF is the only cause of its loading
failure. Keep loading-discs.2 for rollback. No public GitHub release.

Reference: https://learn.microsoft.com/en-us/windows/win32/devnotes/ntreadfile
'''
with zipfile.ZipFile(old/'package/PPSA50011.zip') as z:
    assert z.testzip() is None
    files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
image=(w/'native/eboot.bin').read_bytes();assert sha(image)==p['native_sha256']
files.update({'PPSA50011/eboot.bin':image,'PPSA50011/VERSION':(p['version']+'\n').encode(),'PPSA50011/RELEASE.json':json.dumps(p,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()})
files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=w/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
    assert z.testzip() is None
    for n,e in manifest.items():assert sha(z.read('PPSA50011/'+n))==e['sha256']
(out/'README.md').write_text(notes,encoding='utf-8')
(w/'INVESTIGATION.md').write_text(notes,encoding='utf-8')
desktop=Path.home()/'Desktop/PS5X360-bully-eof-test-20261009';desktop.mkdir(exist_ok=True)
for n in ('PPSA50011.zip','README.md'):shutil.copy2(out/n,desktop/n)
mirror=Path.home()/'Desktop/Xbox360PS5-source/bully-eof-20261009';mirror.mkdir(exist_ok=True)
for n in ('build.py','test.py','test.cpp','test-results.txt','host_path_file.cc','INVESTIGATION.md','prepare_package.py'):shutil.copy2(w/n,mirror/n)
shutil.copy2(w/'native/build.json',mirror/'build.json')
s=(old/'deploy.py').read_text().replace("root / 'build/bully-loading-20261009/candidate/native'", "root / 'build/bully-loading-20261009/disc-error-fix/native'")
s=s.replace('eboot-before-disc-error-','eboot-before-eof-fix-').replace('eboot-disc-error-','eboot-eof-fix-')
(w/'deploy.py').write_text(s,encoding='utf-8')
print('PASS package CRC,',len(manifest),'manifest entries;',desktop)
