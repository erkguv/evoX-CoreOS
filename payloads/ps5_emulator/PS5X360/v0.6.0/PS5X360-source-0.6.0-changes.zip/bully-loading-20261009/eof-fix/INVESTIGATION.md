# PS5X360 0.5.9-loading-eof.1 (private candidate)

- Host-backed file reads now return END_OF_FILE for a nonempty request that
  reads zero bytes. Preserve partial reads, zero-length requests, permissions
  and the existing backend read-error behavior. No title-specific bypass.
- Keep native disc-error recovery into the library and four-disc grouping.
- Keep all existing GPU, audio, network, controller, DLC and Kinect objects.

Evidence: the Bully capture repeatedly reads zero bytes from font.hdt with
SUCCESS. Act.dir has 479 entries whose maximum sector end equals Act.img's
2,461,696 bytes; this archive size alone is not evidence of corruption.
The original VFS object was reproduced byte for byte. Tests use the actual
ReadSync body with real pread calls under ASan/UBSan, covering partial reads,
EOF, empty files, zero-length requests, permissions and invalid descriptors.
Native image checks and the package manifest passed.

Bully gameplay remains unverified. This corrects a general EOF contract
inconsistency; it does not prove that EOF is the only cause of its loading
failure. Keep loading-discs.2 for rollback. No public GitHub release.

Reference: https://learn.microsoft.com/en-us/windows/win32/devnotes/ntreadfile
