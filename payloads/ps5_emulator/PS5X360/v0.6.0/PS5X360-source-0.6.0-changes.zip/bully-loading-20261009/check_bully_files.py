from pathlib import Path
import ftplib, io, json, struct
w=Path(__file__).resolve().parent/'file-review'; w.mkdir(exist_ok=True)
base='/data/homebrew/PPSA50011/assets/roms/BULLY SCHOLARSHIP EDITION PT-BR RGH'
report={}
with ftplib.FTP() as f:
    f.connect('192.168.0.19',2121,timeout=20); f.login()
    for folder in ('Act','Config/hdt','Data/Shaders/Data/Fragments/Cached'):
        rows=[]; f.retrlines('LIST '+base+'/'+folder,rows.append); report[folder]=rows
    for name in ('Act/Act.dir','Config/hdt/font.hdt'):
        b=io.BytesIO();f.retrbinary('RETR '+base+'/'+name,b.write)
        (w/Path(name).name).write_bytes(b.getvalue())
(w/'listing.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
b=(w/'Act.dir').read_bytes(); print('DIR header',b[:128].hex())
