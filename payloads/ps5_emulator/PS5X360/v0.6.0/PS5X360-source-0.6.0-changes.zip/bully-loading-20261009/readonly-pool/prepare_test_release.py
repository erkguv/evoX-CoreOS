from pathlib import Path
import hashlib,json,struct,zipfile,shutil
w=Path(__file__).resolve().parent
out=w/'test-release';out.mkdir(exist_ok=True)
original=(w/'native/eboot.elf').read_bytes();data=bytearray(original)
phoff=struct.unpack_from('<Q',original,32)[0];size,count=struct.unpack_from('<HH',original,54)
headers=[struct.unpack_from('<IIQQQQQQ',original,phoff+i*size) for i in range(count)]
patches=[]
for old,new in [(b'PS5X360 v0.5.8-vulkan.4',b'PS5X360 TEST 0.5.9'),(b'BOOT version 0.5.8-vulkan.4',b'BOOT version TEST 0.5.9'),(b'0.5.8-vulkan.4',b'TEST 0.5.9')]:
    needle=b'\0'+old+b'\0'
    assert data.count(needle)==1,(old,data.count(needle))
    at=data.index(needle)+1
    assert any(h[0]==1 and h[1]==4 and h[2]<=at and at+len(old)<h[2]+h[5] for h in headers),'Version literal must be read-only, non-executable'
    assert len(new)<=len(old)
    data[at:at+len(old)]=new+b'\0'*(len(old)-len(new))
    patches.append({'offset':at,'length':len(old),'before':old.decode(),'after':new.decode()})
assert len(data)==len(original)
assert all(a==b or any(p['offset']<=i<p['offset']+p['length'] for p in patches) for i,(a,b) in enumerate(zip(original,data)))
for h in headers:
    if h[0]==1 and h[1]&1: assert data[h[2]:h[2]+h[5]]==original[h[2]:h[2]+h[5]],'Code changed'
(out/'eboot.elf').write_bytes(data)
sha=lambda b:hashlib.sha256(b).hexdigest()
(out/'label-proof.json').write_text(json.dumps({'display_version':'TEST 0.5.9','base_native_sha256':sha((w/'native/eboot.bin').read_bytes()),'base_elf_sha256':sha(original),'renamed_elf_sha256':sha(data),'patches':patches,'all_executable_segments_identical':True,'hardware_bully':'User confirmed successful loading on installed readonly-pool.1 candidate; renamed package not yet run on hardware'},indent=2))
print('PASS three read-only version literals updated; executable segments unchanged')
