#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <fcntl.h>
#include <limits>
#include <mutex>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_map>

// Read-only device files may have many guest handles. Keep at most 64
// native descriptors, independently of guest handle lifetime. Positioned
// reads do not share a cursor. Writable files retain the original backend.
class ReadOnlyFilePool {
 public:
  static ReadOnlyFilePool& Get() { static ReadOnlyFilePool pool; return pool; }
  bool Inspect(const std::filesystem::path& path, struct stat& identity) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto* item = Acquire(path);
    if (!item) return false;
    identity = item->identity;
    return true;
  }
  bool Read(const std::filesystem::path& path, const struct stat& identity,
            size_t offset, void* data, size_t length, size_t* count) {
    *count = 0;
    if (offset > static_cast<uint64_t>(std::numeric_limits<off_t>::max())) {
      errno = EINVAL; return false;
    }
    std::lock_guard<std::mutex> lock(mutex_);
    auto* item = Acquire(path);
    if (!item) return false;
    // Never silently read a replacement file after eviction/reopen.
    if (item->identity.st_dev != identity.st_dev ||
        item->identity.st_ino != identity.st_ino ||
        item->identity.st_size != identity.st_size) {
      errno = EIO; return false;
    }
    ssize_t result;
    do { result = pread(item->fd, data, length, static_cast<off_t>(offset)); }
    while (result < 0 && errno == EINTR);
    if (result < 0) return false;
    *count = static_cast<size_t>(result);
    return true;
  }
  ~ReadOnlyFilePool() { for (auto& pair : items_) close(pair.second.fd); }
 private:
  struct Item { int fd; struct stat identity; uint64_t used; };
  Item* Acquire(const std::filesystem::path& path) {
    const std::string key = path.string();
    auto found = items_.find(key);
    if (found != items_.end()) { found->second.used = ++clock_; return &found->second; }
    if (items_.size() >= 64) {
      auto oldest = std::min_element(items_.begin(), items_.end(),
          [](const auto& a, const auto& b) { return a.second.used < b.second.used; });
      close(oldest->second.fd);
      items_.erase(oldest);
    }
    int fd;
    do { fd = open(path.c_str(), O_RDONLY); } while (fd < 0 && errno == EINTR);
    if (fd < 0) return nullptr;
    struct stat identity{};
    if (fstat(fd, &identity) != 0 || !S_ISREG(identity.st_mode)) {
      const int error = errno; close(fd); errno = error ? error : EISDIR; return nullptr;
    }
    try {
      return &items_.emplace(key, Item{fd, identity, ++clock_}).first->second;
    } catch (...) { close(fd); throw; }
  }
  std::mutex mutex_;
  std::unordered_map<std::string, Item> items_;
  uint64_t clock_ = 0;
};

class PooledReadOnlyFileHandle final : public xe::filesystem::FileHandle {
 public:
  static std::unique_ptr<xe::filesystem::FileHandle> Open(const std::filesystem::path& path) {
    struct stat identity{};
    if (!ReadOnlyFilePool::Get().Inspect(path, identity)) return nullptr;
    return std::unique_ptr<xe::filesystem::FileHandle>(new PooledReadOnlyFileHandle(path, identity));
  }
  bool Read(size_t offset, void* data, size_t length, size_t* count) override {
    return ReadOnlyFilePool::Get().Read(path_, identity_, offset, data, length, count);
  }
  bool Write(size_t, const void*, size_t, size_t* count) override { *count = 0; errno = EBADF; return false; }
  bool SetLength(size_t) override { errno = EBADF; return false; }
  void Flush() override {}
 private:
  PooledReadOnlyFileHandle(const std::filesystem::path& path, const struct stat& identity)
      : FileHandle(path), identity_(identity) {}
  struct stat identity_;
};
