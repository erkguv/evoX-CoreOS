# Bounded read-only file pool (private candidate)

- General read-only mounted file backend keeps up to 64 native descriptors,
  regardless of the number of guest file handles. LRU eviction, positioned
  reads and serialized descriptor lifetime prevent close/read races.
- Verify file identity and size when reopening; reject replacement files.
- Writable save/content files keep their original backend.
- Persistent limit/open-failure trace retained. No graphics changes.

PS5 evidence: soft and hard limits both 13952, yet native opens report EMFILE.
Raising the advertised limit was ineffective. This candidate reduces native
descriptor pressure. Host stress tests and installation are separate from
pending PS5 gameplay validation. Previous executable preserved for rollback.
