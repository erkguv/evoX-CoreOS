from pathlib import Path
import subprocess,shutil
w=Path(__file__).resolve().parent
shutil.copy2(w.parent/'pool_test.cpp',w/'test.cpp')
subprocess.run(['clang++-18','-std=c++20','-Wall','-Wextra','-Werror','-pthread','-fsanitize=address,undefined',str(w/'test.cpp'),'-o',str(w/'test')],check=True)
p=subprocess.run([str(w/'test')],check=True,capture_output=True,text=True)
(w/'test-results.txt').write_text(p.stdout);print(p.stdout)
