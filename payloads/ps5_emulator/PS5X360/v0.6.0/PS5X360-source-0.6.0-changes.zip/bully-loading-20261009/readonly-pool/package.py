from pathlib import Path
import hashlib,json,zipfile,shutil
w=Path(__file__).resolve().parent;base=w.parent/'file-limit-trace';p=json.loads((w/'native/build.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
notes="""# Bounded read-only file pool (private candidate)

- General read-only mounted file backend keeps up to 64 native descriptors,
  regardless of the number of guest file handles. LRU eviction, positioned
  reads and serialized descriptor lifetime prevent close/read races.
- Verify file identity and size when reopening; reject replacement files.
- Writable save/content files keep their original backend.
- Persistent limit/open-failure trace retained. No graphics changes.

PS5 evidence: soft and hard limits both 13952, yet native opens report EMFILE.
Raising the advertised limit was ineffective. This candidate reduces native
descriptor pressure. Host stress tests and installation are separate from
pending PS5 gameplay validation. Previous executable preserved for rollback.
"""
with zipfile.ZipFile(base/'package/PPSA50011.zip') as z:files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
image=(w/'native/eboot.bin').read_bytes();assert sha(image)==p['native_sha256']
files.update({'PPSA50011/eboot.bin':image,'PPSA50011/VERSION':(p['version']+'\n').encode(),'PPSA50011/RELEASE.json':json.dumps(p,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()});files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for n,b in files.items()};files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=w/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
 assert z.testzip() is None
 for n,e in manifest.items():assert sha(z.read('PPSA50011/'+n))==e['sha256']
(out/'README.md').write_text(notes,encoding='utf-8')
(w/'INVESTIGATION.md').write_text(notes,encoding='utf-8')
mirror=Path.home()/'Desktop/Xbox360PS5-source/readonly-pool-20261009';mirror.mkdir(exist_ok=True)
for n in ('build.py','host_path_entry.cc','package.py','INVESTIGATION.md','prepare.py','readonly_file_pool.hpp','test.py','test.cpp','test-results.txt'):shutil.copy2(w/n,mirror/n)
shutil.copy2(w/'native/build.json',mirror/'build.json')
s=(base/'deploy.py').read_text().replace("root / 'build/bully-loading-20261009/return-trace/native'","root / 'build/bully-loading-20261009/return-trace/native'")
s=s.replace('eboot-before-eof-fix-','eboot-before-file-errors-').replace('eboot-eof-fix-','eboot-file-errors-')
(w/'deploy.py').write_text(s,encoding='utf-8');print('PASS package CRC and',len(manifest),'manifest entries')
