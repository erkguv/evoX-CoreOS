from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('/ws/Xbox360PS5');w=Path(__file__).resolve().parent;base=w.parent/'file-limit-trace/native';out=w/'native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
shutil.copytree(base/'obj',out/'obj',dirs_exist_ok=True)
cmd=list(json.loads((base/'build.json').read_text())['compile']);cmd[cmd.index('-o')+1]=str(w/'preimage.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
assert sha(w/'preimage.o')==sha(base/'obj/host_path_entry.cc.o'),'Host-entry preimage mismatch'
s=(w.parent/'file-limit-trace/host_path_entry.cc').read_text()
s=s.replace('namespace xe {', '#include "readonly_file_pool.hpp"\n\nnamespace xe {',1)
old="""  auto file_handle =
      xe::filesystem::FileHandle::OpenExisting(host_path_, desired_access);"""
new="""  const bool pooled = is_read_only() && !(attributes_ & kFileAttributeDirectory) &&
      !(desired_access & (FileAccess::kGenericWrite | FileAccess::kGenericAll |
                         FileAccess::kFileWriteData | FileAccess::kFileAppendData));
  auto file_handle = pooled ? PooledReadOnlyFileHandle::Open(host_path_) :
      xe::filesystem::FileHandle::OpenExisting(host_path_, desired_access);
  static std::once_flag pool_notice;
  if (pooled && file_handle) std::call_once(pool_notice, [] {
    const char* text = "READONLYPOOL active native-cap=64; writable files unchanged";
    xbox360ps5::Stage(text);
    if (budget_trace >= 0) { (void)!write(budget_trace, text, std::strlen(text));
      (void)!write(budget_trace, "\\n", 1); fsync(budget_trace); }
  });"""
assert s.count(old)==1
s=s.replace(old,new,1)
(w/'host_path_entry.cc').write_text(s)
cmd[cmd.index('-c')+1]=str(w/'host_path_entry.cc');cmd[cmd.index('-o')+1]=str(out/'obj/host_path_entry.cc.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
subprocess.run(['python3',str(w/'test.py')],check=True)
subprocess.run(['bash',str(r/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(r),str(out)],check=True)
kept={p.name:sha(p) for p in (base/'obj').glob('*.o') if p.name!='host_path_entry.cc.o'}
assert all(sha(out/'obj'/n)==h for n,h in kept.items())
p={'version':'0.5.9-readonly-pool.1-local','native_sha256':sha(out/'eboot.bin'),'baseline_sha256':sha(base/'eboot.bin'),'preimage_byte_identical':True,'compile':cmd,'unchanged_objects':kept,'scope':'Read-only device file descriptor cache capped at 64, positioned reads, unchanged writable backend','hardware_gameplay':'pending'}
(out/'build.json').write_text(json.dumps(p,indent=2));print('PASS general file-limit candidate',p['native_sha256'])
