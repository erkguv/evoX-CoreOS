from pathlib import Path
import hashlib,json,zipfile,shutil
w=Path(__file__).resolve().parent;native=w/'test-release'
out=Path.home()/'Desktop/PS5X360-TEST-0.5.9'
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
proof=json.loads((native/'label-proof.json').read_text())
with zipfile.ZipFile(w/'package/PPSA50011.zip') as z:
    assert z.testzip() is None
    files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
notes='''# PS5X360 TEST 0.5.9

- Improved file handling for games that keep many files open.
- Bully successfully passed the loading failure on the developer's PS5
  after this fix (user-confirmed). Please test loading, gameplay and audio.
- Previous loading/EOF and safe return-to-library fixes are retained.
- Other games still need testing; this is a tester build.

The menu, boot version and session version strings say TEST 0.5.9.
Only read-only version strings were changed after the successful PS5 test;
all executable code segments remain identical to the tested candidate.
The renamed package itself has not yet been launched on a console.
'''
release={'version':'TEST 0.5.9','channel':'test','native_sha256':sha((native/'eboot.bin').read_bytes()),'base_version':'0.5.9-readonly-pool.1-local','base_native_sha256':proof['base_native_sha256'],'executable_code_unchanged_from_tested_candidate':True,'hardware_validation':'Bully loading succeeded on base candidate, confirmed by user; renamed package pending console validation'}
files.update({'PPSA50011/eboot.bin':(native/'eboot.bin').read_bytes(),'PPSA50011/VERSION':b'TEST 0.5.9\n','PPSA50011/RELEASE.json':json.dumps(release,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()})
files.pop('PPSA50011/MANIFEST.json',None)
manifest={n.removeprefix('PPSA50011/'):{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
    for n,b in files.items():z.writestr(n,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
    assert z.testzip() is None
    for n,e in manifest.items(): assert sha(z.read('PPSA50011/'+n))==e['sha256']
    assert z.read('PPSA50011/VERSION')==b'TEST 0.5.9\n'
    assert all(not any('/'+part+'/' in n.lower() for part in ('saves','logs','profiles')) for n in z.namelist())
    assert all('/assets/roms/' not in n or n.endswith('/README.txt') for n in z.namelist())
    z.extractall(out)
previous=Path.home()/'Desktop/PS5X360-v0.5.9-fix1'
for name in ('PS5X360-AutoLog-v1.0.9-preview.elf','Kinect-Phone.zip'):
    source=previous/name
    assert source.is_file()
    shutil.copy2(source,out/name)
    assert sha(source.read_bytes())==sha((out/name).read_bytes())
(out/'README.md').write_text('''# PS5X360 TEST 0.5.9 — tester package

1. Close PS5X360 completely before updating.
2. Back up your current installation. Extract PPSA50011.zip and copy the
   PPSA50011 folder into /data/homebrew/ on the PS5, merging/replacing program
   files. Keep your existing games, saves and settings.
3. Open PS5X360 from your homebrew launcher. Keep detailed logs OFF for normal
   testing. Test Bully and other previously affected games.
4. For a failed test, report the game, firmware, patches, exact step and the
   session log from /data/homebrew/PPSA50011/logs/.

PPSA50011/ is also included unpacked. Share PPSA50011.zip with testers.
AutoLog ELF is optional and unchanged (v1.0.9). Kinect-Phone.zip is the
unchanged phone companion from the previous package, for existing Kinect tests.

'''+notes,encoding='utf-8')
(out/'TESTER-MESSAGE.txt').write_text('''PS5X360 TEST 0.5.9 is ready for testing!

This build improves file handling for games that open many files. Bully now
passes the loading issue on my PS5. Please test it and other affected games,
including audio, gameplay and returning to the library.

Keep detailed logs OFF during normal play. If something fails, send the game
name, firmware, enabled patches and the session log from PPSA50011/logs.
Compatibility with every game is not guaranteed. Thanks for testing!
''',encoding='utf-8')
receipt={'version':'TEST 0.5.9','archive_sha256':sha((out/'PPSA50011.zip').read_bytes()),'native_sha256':release['native_sha256'],'manifest_entries_verified':len(manifest),'zip_crc_passed':True,'no_game_or_user_data':True,'version_label_proof':proof}
(out/'PACKAGE-VERIFICATION.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
(out/'PPSA50011.zip.sha256').write_text(receipt['archive_sha256']+'  PPSA50011.zip\n')
mirror=Path.home()/'Desktop/Xbox360PS5-source/readonly-pool-20261009'
for name in ('prepare_test_release.py','package_test_release.py'):shutil.copy2(w/name,mirror/name)
shutil.copy2(native/'label-proof.json',mirror/'test-label-proof.json')
print(out);print(json.dumps({k:v for k,v in receipt.items() if k!='version_label_proof'},indent=2))
