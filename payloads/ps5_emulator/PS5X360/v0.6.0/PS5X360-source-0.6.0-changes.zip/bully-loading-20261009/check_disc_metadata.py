from pathlib import Path
import ftplib, io, struct, json, hashlib
out = Path(__file__).resolve().parent / 'lost-odyssey-headers'
out.mkdir(exist_ok=True)
result=[]
with ftplib.FTP() as ftp:
    ftp.connect('192.168.0.19',2121,timeout=30); ftp.login()
    for number in range(1,5):
        path='/data/homebrew/PPSA50011/assets/roms/LOST ODYSSEY/DISCO%d/default.xex'%number
        data=io.BytesIO(); ftp.retrbinary('RETR '+path,data.write,blocksize=1024*1024)
        b=data.getvalue(); (out/('disc%d.xex'%number)).write_bytes(b)
        assert b[:4]==b'XEX2'
        be=lambda off:struct.unpack_from('>I',b,off)[0]
        n=be(20); offsets=[be(28+8*i) for i in range(n) if be(24+8*i)==0x40006]
        assert len(offsets)==1
        p=offsets[0]
        result.append({'folder_disc':number,'title_id':'%08X'%be(p+12),
                       'media_id':'%08X'%be(p),'version':'%08X'%be(p+4),
                       'base_version':'%08X'%be(p+8),'platform':b[p+16],
                       'executable_table':b[p+17],'disc_number':b[p+18],
                       'disc_count':b[p+19],'savegame_id':'%08X'%be(p+20),
                       'region':'%08X'%be(be(16)+0x178),'sha256':hashlib.sha256(b).hexdigest()})
(out/'metadata.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
