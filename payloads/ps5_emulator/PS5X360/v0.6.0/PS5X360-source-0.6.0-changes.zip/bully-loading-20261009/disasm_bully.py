from pathlib import Path
from capstone import Cs, CS_ARCH_PPC, CS_MODE_32, CS_MODE_BIG_ENDIAN
w=Path(__file__).resolve().parent/'file-review';data=(w/'guest-image.bin').read_bytes()
md=Cs(CS_ARCH_PPC,CS_MODE_32|CS_MODE_BIG_ENDIAN)
for start,size in ((0x828BD820,0x180),(0x828CF3E0,0x140)):
 lines=[f'{i.address:08X} {i.mnemonic} {i.op_str}' for i in md.disasm(data[start-0x82000000:start-0x82000000+size],start)]
 (w/f'disasm-{start:08X}.txt').write_text('\n'.join(lines));print('\n'.join(lines))
