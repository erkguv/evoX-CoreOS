from pathlib import Path
import struct,sys
from capstone import Cs,CS_ARCH_PPC,CS_MODE_64,CS_MODE_BIG_ENDIAN
w=Path(__file__).resolve().parent/'file-review';d=(w/'guest-image.bin').read_bytes();base=0x82000000
m=Cs(CS_ARCH_PPC,CS_MODE_64|CS_MODE_BIG_ENDIAN);m.skipdata=True
calls=[]
for at in range(0,len(d)-4,4):
 v=struct.unpack_from('>I',d,at)[0]
 if v>>26!=18:continue
 disp=v&0x03fffffc
 if disp&0x02000000:disp-=0x04000000
 target=disp if v&2 else base+at+disp
 if target==int(sys.argv[1],16) if len(sys.argv)>1 else target==0x828bd900:calls.append(base+at)
lines=[]
for addr in calls:
 lines.append('CALLER '+hex(addr))
 start=addr-0x100
 lines.extend(f'{i.address:08X} {i.mnemonic} {i.op_str}' for i in m.disasm(d[start-base:start-base+0x140],start))
(w/'dirty-disc-callers.txt').write_text('\n'.join(lines));print('\n'.join(lines))
