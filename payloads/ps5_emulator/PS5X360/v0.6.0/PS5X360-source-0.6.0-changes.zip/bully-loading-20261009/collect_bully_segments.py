from pathlib import Path
import ftplib,io,json,datetime
w=Path(__file__).resolve().parent/('segments-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));w.mkdir()
base='/data/homebrew/PPSA50011/logs'
with ftplib.FTP() as f:
 f.connect('192.168.0.19',2121,timeout=20);f.login();rows=[];f.retrlines('LIST '+base,rows.append)
 names=[r.split(maxsplit=8)[8] for r in rows if len(r.split(maxsplit=8))==9]
 wanted=sorted(n for n in names if 'Bully' in n and '20261009-223143' in n)
 for n in wanted:
  b=io.BytesIO();f.retrbinary('RETR '+base+'/'+n,b.write,blocksize=1024*1024);(w/n).write_bytes(b.getvalue());print(n,len(b.getvalue()))
(w/'listing.json').write_text(json.dumps(rows,indent=2));print(w)
