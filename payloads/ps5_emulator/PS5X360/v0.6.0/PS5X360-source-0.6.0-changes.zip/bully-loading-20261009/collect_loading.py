"""Read-only collection of loading sessions and the Lost Odyssey disc layout."""
from pathlib import Path
import ftplib, io, json, re, datetime

work = Path(__file__).resolve().parent
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out = work / ('loading-' + stamp)
out.mkdir()
report = {'collected_utc': stamp, 'remote_writes': False}
with ftplib.FTP() as ftp:
    ftp.connect('192.168.0.19', 2121, timeout=20)
    ftp.login()
    base = '/data/homebrew/PPSA50011'
    def read(path):
        data = io.BytesIO()
        ftp.retrbinary('RETR ' + path, data.write, blocksize=1024*1024)
        return data.getvalue()
    def listing(path):
        lines = []
        ftp.retrlines('LIST ' + path, lines.append)
        entries = []
        for line in lines:
            parts = line.split(maxsplit=8)
            if len(parts) == 9 and parts[8] not in ('.', '..'):
                entries.append({'name': parts[8], 'directory': parts[0][0] == 'd', 'size': parts[4]})
        return entries
    for name in ('VERSION', 'RELEASE.json', 'framegen.conf', 'render-target-fsi.conf'):
        try:
            data = read(base + '/' + name)
            (out / name).write_bytes(data)
        except ftplib.error_perm as exc:
            report[name] = str(exc)
    names = [e['name'] for e in listing(base + '/logs') if not e['directory']]
    for term in ('bully', 'odyssey', 'disco'):
        matches = sorted(n for n in names if term in n.lower() and n.endswith('.log'))
        report[term + '_logs'] = matches
        for name in matches[-3:]:
            (out / name).write_bytes(read(base + '/logs/' + name))
    (out / 'boot.log').write_bytes(read(base + '/logs/boot.log'))
    roms = base + '/assets/roms'
    roots = [e for e in listing(roms) if 'odyssey' in e['name'].lower() or 'odisse' in e['name'].lower()]
    tree = {}
    def visit(path, depth):
        entries = listing(path)
        tree[path] = entries
        if depth:
            for e in entries:
                if e['directory']:
                    visit(path + '/' + e['name'], depth - 1)
    for e in roots:
        if e['directory']:
            visit(roms + '/' + e['name'], 2)
    report['disc_layout'] = tree
(out / 'collection.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(out)
print(json.dumps({k:v for k,v in report.items() if k != 'disc_layout'}, indent=2))
print('disc directories:', len(tree))
