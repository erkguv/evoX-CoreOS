from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[2]
w=Path(__file__).resolve().parent/'candidate'
w.mkdir(exist_ok=True)
menu=r/'build/menu-perf-20261009/launcher.cpp'
old=r/'build/multidisc-ui-20261008/agent-library'
s=menu.read_text(encoding='utf-8')
s=s.replace('#include "xbox360ps5/launcher.hpp"', '#include "xbox360ps5/launcher.hpp"\n#include "disc_library.hpp"',1)
previous=(old/'launcher.cpp').read_text(encoding='utf-8')
start=previous.index('    // Grouped entries retain')
end=previous.index('    // Cover:',start)
s=s.replace('    // Cover: a picture',previous[start:end]+'    // Cover: a picture',1)
start=previous.index('    if (grouped && game.cover < 0)')
end=previous.index('    // Downloaded',start)
s=s.replace('    // Downloaded by the title',previous[start:end]+'    // Downloaded by the title',1)
start=previous.index('    std::set<fs::path> grouped_directories;')
end=previous.index('    for (const auto& entry : entries)',start)
at=s.index('void Launcher::Scan()')
scan=s[at:]
scan=scan.replace('    for (const auto& entry : entries) {\n      const fs::path& path',previous[start:end]+'    for (const auto& entry : entries) {\n      const fs::path& path',1)
s=s[:at]+scan
s=s.replace('depth < 6 && extension != ".data") scan(', 'depth < 6 && extension != ".data" && !grouped_directories.count(path)) scan(',1)
# Reuse the existing size string; no GameEntry/Launcher layout changes.
s=s.replace('    std::set<fs::path> grouped_directories;', '    std::set<fs::path> grouped_directories;',1)
(w/'launcher.cpp').write_text(s,encoding='utf-8')
for n in ('disc_catalog.hpp','disc_catalog.cpp','disc_library.hpp','disc_library.cpp'):
    shutil.copy2(old/n,w/n)
ts=r/'.deps/xenia-canary/src/xenia/cpu/thread_state.cc'
s=ts.read_text(encoding='utf-8')
before='  memory::DeallocFixed(true_start_of_ctx, granularity + sizeof(ppc::PPCContext),\n                       memory::DeallocationType::kRelease);'
assert s.count(before)==1
s=s.replace(before,'''  // PS5 uses whole reservations. A nonzero release length is refused by
  // its memory backend and leaks every retired PPC context.
#if XE_PLATFORM_PS5
  const size_t release_size = 0;
#else
  const size_t release_size = granularity + sizeof(ppc::PPCContext);
#endif
  memory::DeallocFixed(true_start_of_ctx, release_size,
                       memory::DeallocationType::kRelease);''')
(w/'thread_state.cc').write_text(s,encoding='utf-8')
shutil.copy2(ts,w/'thread_state.preimage.cc')
print(w)
