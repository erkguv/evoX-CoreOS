from pathlib import Path
import ftplib,io,hashlib
w=Path(__file__).resolve().parent/'file-review';w.mkdir(exist_ok=True)
with ftplib.FTP() as f:
 f.connect('192.168.0.19',2121,timeout=20);f.login()
 b=io.BytesIO();f.retrbinary('RETR /data/homebrew/PPSA50011/assets/roms/BULLY SCHOLARSHIP EDITION PT-BR RGH/Default.xex',b.write,blocksize=1024*1024)
 (w/'Default.xex').write_bytes(b.getvalue());print(len(b.getvalue()),hashlib.sha256(b.getvalue()).hexdigest())
