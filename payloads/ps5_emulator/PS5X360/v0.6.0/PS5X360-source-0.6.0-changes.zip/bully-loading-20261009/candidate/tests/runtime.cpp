#include "mock.hpp"
#include "xbox360ps5/multi_disc.hpp"
#include <iostream>
namespace xbox360ps5 {bool accepted=true; unsigned prompts=0; bool ConfirmDiscSwap(xe::kernel::KernelState*,uint32_t,uint32_t,const std::string&){++prompts;return accepted;} void SetLaunchedGame(const std::filesystem::path&p){SetMultiDiscSource(p);}}
namespace xe::vfs {std::mutex retired_mutex;std::unordered_map<VirtualFileSystem*,std::vector<std::unique_ptr<Device>>>retired_devices;
bool VirtualFileSystem::ReplaceDeviceRetainingOld(std::unique_ptr<Device> device) {
  if (!device) return false;
  auto global_lock = global_critical_region_.Acquire();
  std::lock_guard lock(retired_mutex);
  auto it = std::find_if(devices_.begin(), devices_.end(), [&](const auto& old) {
    return xe::utf8::equal_case(old->mount_path(), device->mount_path());
  });
  if (it == devices_.end()) return false;
  auto& retained = retired_devices[this];
  if (retained.size() >= 16) return false;
  retained.reserve(retained.size() + 1); // Allocate before touching live mount.
  it->swap(device);
  retained.push_back(std::move(device));
  return true;
}

}
void Write(const std::filesystem::path&p,int disc,int title=0x12345678,int save=77,int count=2){std::filesystem::create_directories(p.parent_path());std::vector<uint8_t>b(80);auto put=[&](int off,uint32_t v){b[off]=v>>24;b[off+1]=v>>16;b[off+2]=v>>8;b[off+3]=v;};put(0,0x58455832);put(8,80);put(20,1);put(24,0x40006);put(28,48);put(48,1234+disc);put(60,title);b[66]=disc;b[67]=count;put(68,save);std::ofstream f(p,std::ios::binary);f.write(reinterpret_cast<const char*>(b.data()),b.size());}
int main(int argc,char**argv){if(argc!=2)return 2;std::filesystem::path root=argv[1];auto one=root/"Max Payne 3"/"Disc 1"/"default.xex",two=root/"Max Payne 3"/"Disc 2"/"default.xex";Write(one,1);Write(two,2);xe::kernel::KernelState state;auto d=state.emu.CreateVfsDevice(one,"disc");if(!d->Initialize())return 3;state.fs.devices_.push_back(std::move(d));auto*borrowed=state.fs.devices_[0]->root.get();xbox360ps5::SetMultiDiscSource(one);unsigned checks=0;auto check=[&](bool ok){if(!ok){std::cerr<<"FAIL "<<checks;std::exit(1);}++checks;};
check(xbox360ps5::SwapMultiDisc(&state,0)==87);check(xbox360ps5::SwapMultiDisc(&state,3)==87);check(state.fs.devices_[0]->root.get()==borrowed);Write(two,2,0x76543210);check(xbox360ps5::SwapMultiDisc(&state,2)==2);check(state.execution.disc_number==1);check(state.fs.devices_[0]->root.get()==borrowed);Write(two,2,0x12345678,99);check(xbox360ps5::SwapMultiDisc(&state,2)==2);check(state.execution.disc_number==1);Write(two,2);xbox360ps5::accepted=false;check(xbox360ps5::SwapMultiDisc(&state,2)==1223);check(state.execution.disc_number==1);check(state.fs.devices_[0]->root.get()==borrowed);check(xbox360ps5::prompts==1);xbox360ps5::accepted=true;check(xbox360ps5::SwapMultiDisc(&state,2)==0);check(state.execution.disc_number==2);check(state.execution.media_id==1236);check(state.execution.title_id==0x12345678);check(borrowed->device()!=state.fs.devices_[0].get());check(borrowed->size()==80);check(xbox360ps5::SwapMultiDisc(&state,2)==0);check(xbox360ps5::SwapMultiDisc(&state,1)==0);check(state.execution.disc_number==1);check(state.execution.media_id==1235);state.fs.devices_.clear();xe::vfs::retired_devices.erase(&state.fs);check(xe::vfs::Device::live==0);{
  xe::kernel::KernelState four;
  four.execution.disc_count=4;
  auto first=root/"Four Discs"/"DISCO1"/"default.xex";
  for(int n=1;n<=4;++n)Write(root/"Four Discs"/("DISCO"+std::to_string(n))/"default.xex",n,0x12345678,77,4);
  auto device=four.emu.CreateVfsDevice(first,"disc");check(device->Initialize());
  four.fs.devices_.push_back(std::move(device));
  xbox360ps5::SetMultiDiscSource(first);
  for(unsigned n : {2u,3u,4u,1u}) {
    check(xbox360ps5::SwapMultiDisc(&four,n)==0);
    check(four.execution.disc_number==n);
    check(four.execution.media_id==1234+n);
  }
  check(xbox360ps5::SwapMultiDisc(&four,5)==87);
  xbox360ps5::accepted=false;
  check(xbox360ps5::SwapMultiDisc(&four,4)==1223);
  check(four.execution.disc_number==1);
  xbox360ps5::accepted=true;
  four.fs.devices_.clear();xe::vfs::retired_devices.erase(&four.fs);
  check(xe::vfs::Device::live==0);
}
std::cout<<"PASS "<<checks<<" real runtime/catalog transaction checks with host VFS adapter\n";}
