#pragma once
#include <atomic>
namespace xbox360ps5::gpu_diag {inline std::atomic<bool> enabled{false};}
