#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <sys/mman.h>
#include <cerrno>
static unsigned direct_live=0;
extern "C" {
int64_t sceKernelGetDirectMemorySize(){return 0x300000000;}
int32_t sceKernelAllocateDirectMemory(int64_t,int64_t,size_t,size_t,int,int64_t*p){if(direct_live==64)return 12;++direct_live;*p=0;return 0;}
int32_t sceKernelReleaseDirectMemory(int64_t,size_t){--direct_live;return 0;}
int32_t sceKernelReserveVirtualRange(void**p,size_t n,int,size_t){void*v=mmap(*p,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);if(v==MAP_FAILED)return errno;*p=v;return 0;}
int32_t sceKernelMapDirectMemory(void**,size_t,int,int,int64_t,size_t){return 0;}
int32_t sceKernelMunmap(void*p,size_t n){return munmap(p,n);}
int32_t sceKernelMprotect(const void*p,size_t n,int prot){return mprotect(const_cast<void*>(p),n,prot);}
int32_t sceKernelVirtualQuery(const void*,int,void*,size_t){return 1;}
int sceKernelDebugOutText(int,const char*){return 0;}
}
#include "/ws/Xbox360PS5/platform/ps5/memory_ps5.cpp"
namespace xe::cpu {
namespace memory=xe::memory;
namespace ppc {struct PPCContext {unsigned char data[0xac0];};}
#define assert_always(message) throw std::runtime_error(message)
static void* AllocateContext() {
  size_t granularity = xe::memory::allocation_granularity();
  for (unsigned pos32 = 0x40; pos32 < 8192; ++pos32) {
    /*
        we want our register which points to the context to have 0xE0000000 in
       the low 32 bits, for checking for whether we need the 4k offset, but also
       if we allocate starting from the page before we allow backends to index
       negatively to get to their own backend specific data, which makes full
        use of int8 displacement


        the downside is we waste most of one granula and probably a fair bit of
       the one starting at 0xE0 by using a direct virtual memory allocation
       instead of malloc
    */
    uintptr_t context_pre =
        ((static_cast<uint64_t>(pos32) << 32) | 0xE0000000) - granularity;

    void* p = memory::AllocFixed(
        (void*)context_pre, granularity + sizeof(ppc::PPCContext),
        memory::AllocationType::kReserveCommit, memory::PageAccess::kReadWrite);
    if (p) {
      return reinterpret_cast<char*>(p) +
             granularity;  // now we have a ctx ptr with the e0 constant in low,
                           // and one page allocated before it
    }
  }

  assert_always("giving up on allocating context, likely leaking contexts");
  return nullptr;
}

static void FreeContext(void* ctx) {
  size_t granularity = xe::memory::allocation_granularity();
  char* true_start_of_ctx =
      &reinterpret_cast<char*>(ctx)[-static_cast<ptrdiff_t>(granularity)];
  // PS5 uses whole reservations. A nonzero release length is refused by
  // its memory backend and leaks every retired PPC context.
#if XE_PLATFORM_PS5
  const size_t release_size = 0;
#else
  const size_t release_size = granularity + sizeof(ppc::PPCContext);
#endif
  memory::DeallocFixed(true_start_of_ctx, release_size,
                       memory::DeallocationType::kRelease);
}


}
int main(){try {for(unsigned i=0;i<200;++i){void*p=xe::cpu::AllocateContext();if(!p)return 3;xe::cpu::FreeContext(p);}if(direct_live)return 4;std::cout<<"PASS 200 PPC context lifecycles; no direct-memory leak\n";return 0;}catch(const std::runtime_error&){std::cout<<"Allocation exhausted; live reservations="<<direct_live<<"\n";return 2;}}
