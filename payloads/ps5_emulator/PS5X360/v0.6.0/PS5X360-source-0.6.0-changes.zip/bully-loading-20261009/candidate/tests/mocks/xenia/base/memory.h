#pragma once
#include <filesystem>
#include <cstdint>
namespace xe::memory {
enum class PageAccess {kNoAccess=0,kReadOnly=1,kReadWrite=3,kExecuteReadOnly=5,kExecuteReadWrite=7};
enum class AllocationType {kReserve=1,kCommit=2,kReserveCommit=3};
enum class DeallocationType {kRelease=1,kDecommit=2};
using FileMappingHandle=int; constexpr int kFileMappingHandleInvalid=-1;
}
