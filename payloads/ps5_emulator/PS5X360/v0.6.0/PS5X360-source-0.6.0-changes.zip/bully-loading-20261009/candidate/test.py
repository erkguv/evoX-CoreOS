from pathlib import Path
import subprocess, shutil
r=Path('/ws/Xbox360PS5');w=Path(__file__).resolve().parent;t=w/'tests';t.mkdir(exist_ok=True)
for p in ('xenia/base','xbox360ps5'):(t/'mocks'/p).mkdir(parents=True,exist_ok=True)
(t/'mocks/xenia/base/memory.h').write_text('''#pragma once
#include <filesystem>
#include <cstdint>
namespace xe::memory {
enum class PageAccess {kNoAccess=0,kReadOnly=1,kReadWrite=3,kExecuteReadOnly=5,kExecuteReadWrite=7};
enum class AllocationType {kReserve=1,kCommit=2,kReserveCommit=3};
enum class DeallocationType {kRelease=1,kDecommit=2};
using FileMappingHandle=int; constexpr int kFileMappingHandleInvalid=-1;
}
''')
(t/'mocks/xbox360ps5/gpu_diagnostics.hpp').write_text('#pragma once\n#include <atomic>\nnamespace xbox360ps5::gpu_diag {inline std::atomic<bool> enabled{false};}\n')
prefix='''#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <sys/mman.h>
#include <cerrno>
static unsigned direct_live=0;
extern "C" {
int64_t sceKernelGetDirectMemorySize(){return 0x300000000;}
int32_t sceKernelAllocateDirectMemory(int64_t,int64_t,size_t,size_t,int,int64_t*p){if(direct_live==64)return 12;++direct_live;*p=0;return 0;}
int32_t sceKernelReleaseDirectMemory(int64_t,size_t){--direct_live;return 0;}
int32_t sceKernelReserveVirtualRange(void**p,size_t n,int,size_t){void*v=mmap(*p,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_FIXED_NOREPLACE,-1,0);if(v==MAP_FAILED)return errno;*p=v;return 0;}
int32_t sceKernelMapDirectMemory(void**,size_t,int,int,int64_t,size_t){return 0;}
int32_t sceKernelMunmap(void*p,size_t n){return munmap(p,n);}
int32_t sceKernelMprotect(const void*p,size_t n,int prot){return mprotect(const_cast<void*>(p),n,prot);}
int32_t sceKernelVirtualQuery(const void*,int,void*,size_t){return 1;}
int sceKernelDebugOutText(int,const char*){return 0;}
}
#include "/ws/Xbox360PS5/platform/ps5/memory_ps5.cpp"
namespace xe::cpu {
namespace memory=xe::memory;
namespace ppc {struct PPCContext {unsigned char data[0xac0];};}
#define assert_always(message) throw std::runtime_error(message)
'''
suffix='''
}
int main(){try {for(unsigned i=0;i<200;++i){void*p=xe::cpu::AllocateContext();if(!p)return 3;xe::cpu::FreeContext(p);}if(direct_live)return 4;std::cout<<"PASS 200 PPC context lifecycles; no direct-memory leak\\n";return 0;}catch(const std::runtime_error&){std::cout<<"Allocation exhausted; live reservations="<<direct_live<<"\\n";return 2;}}
'''
for n in ('thread_state.preimage.cc','thread_state.cc'):
    s=(w/n).read_text();s=s[s.index('static void* AllocateContext()'):s.index('ThreadState::ThreadState(')]
    test=t/(n+'.test.cpp');test.write_text(prefix+s+suffix)
    exe=t/(n+'.test')
    subprocess.run(['clang++-18','-std=c++20','-O1','-g','-fsanitize=undefined','-DXE_PLATFORM_PS5=1','-I'+str(t/'mocks'),str(test),'-o',str(exe)],check=True)
    p=subprocess.run([str(exe)],capture_output=True,text=True)
    print(n,p.returncode,p.stdout,p.stderr)
    assert p.returncode==(2 if 'preimage' in n else 0)
header_dir=w.parent/'lost-odyssey-headers'
fixture=t/'Lost Odyssey'
for n in range(1,5):
    d=fixture/('DISCO'+str(n));d.mkdir(parents=True,exist_ok=True);shutil.copy2(header_dir/('disc%d.xex'%n),d/'default.xex')
group=t/'real_discs.cpp';group.write_text('''#include "disc_library.hpp"
#include <iostream>
int main(int argc,char**argv){if(argc!=2)return 2;std::string error;auto g=xbox360ps5::multidisc::InspectExtractedDiscGroup(argv[1],error);if(!g){std::cerr<<error;return 1;}if(g->disc_count!=4||g->title_id!=0x4D5307FA||g->launch_path.parent_path().filename()!="DISCO1")return 3;for(unsigned n=1;n<=4;++n){auto set=ps5x360_disc::DiscoverDiscSet(g->launch_path.string(),n);if(!set||!set.complete||set.candidates[*set.requested_index].execution.disc_number!=n)return 4;}std::cout<<"PASS real four-disc headers grouped; disc 1 launches; targets 1-4 validated\\n";}
''')
exe=t/'real_discs'
subprocess.run(['clang++-18','-std=c++20','-O1','-g','-fsanitize=address,undefined','-I'+str(w),str(r/'build/multidisc-ui-20261008/agent-library/disc_catalog.cpp'),str(w/'disc_library.cpp'),str(group),'-o',str(exe)],check=True)
p=subprocess.run([str(exe),str(fixture)],capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0
old=r/'build/multidisc-ui-20261008'
shutil.copytree(old/'host-mocks',t/'host-mocks',dirs_exist_ok=True)
s=(old/'test-runtime.cpp').read_text()
s=s.replace('int save=77)', 'int save=77,int count=2)')
s=s.replace('b[67]=2;', 'b[67]=count;')
at=s.index('std::cout<<"PASS ')
s=s[:at]+'''{
  xe::kernel::KernelState four;
  four.execution.disc_count=4;
  auto first=root/"Four Discs"/"DISCO1"/"default.xex";
  for(int n=1;n<=4;++n)Write(root/"Four Discs"/("DISCO"+std::to_string(n))/"default.xex",n,0x12345678,77,4);
  auto device=four.emu.CreateVfsDevice(first,"disc");check(device->Initialize());
  four.fs.devices_.push_back(std::move(device));
  xbox360ps5::SetMultiDiscSource(first);
  for(unsigned n : {2u,3u,4u,1u}) {
    check(xbox360ps5::SwapMultiDisc(&four,n)==0);
    check(four.execution.disc_number==n);
    check(four.execution.media_id==1234+n);
  }
  check(xbox360ps5::SwapMultiDisc(&four,5)==87);
  xbox360ps5::accepted=false;
  check(xbox360ps5::SwapMultiDisc(&four,4)==1223);
  check(four.execution.disc_number==1);
  xbox360ps5::accepted=true;
  four.fs.devices_.clear();xe::vfs::retired_devices.erase(&four.fs);
  check(xe::vfs::Device::live==0);
}
''' + s[at:]
runtime=t/'runtime.cpp';runtime.write_text(s)
exe=t/'runtime'
subprocess.run(['clang++-18','-std=c++20','-O1','-g','-fsanitize=address,undefined','-I'+str(t/'host-mocks'),'-I'+str(old/'include'),'-I'+str(r/'build/dual-renderer-worktree/include'),'-I'+str(w),str(old/'multi_disc.cpp'),str(w/'disc_catalog.cpp'),str(runtime),'-o',str(exe)],check=True)
p=subprocess.run([str(exe),str(t/'runtime-fixture')],capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==0
(t/'results.txt').write_text('PASS: original context release exhausts the 64-reservation fixture; corrected release completes 200 cycles with zero live reservations.\nPASS: real Lost Odyssey four-disc header set validates launch and targets 1-4.\n'+p.stdout+'Hardware gameplay and actual disc transitions pending.\n')
