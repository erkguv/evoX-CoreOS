from pathlib import Path
r=Path(__file__).resolve().parents[3];w=Path(__file__).resolve().parent
s=(r/'build/menu-perf-20261009/package_deploy.py').read_text(encoding='utf-8')
s=s.replace('root = Path(__file__).resolve().parents[2]','root = Path(__file__).resolve().parents[3]')
s=s.replace("'eboot-before-perf-menu-'", "'eboot-before-loading-discs-'")
s=s.replace("'eboot-perf-menu-'", "'eboot-loading-discs-'")
s=s.replace("'eboot-rejected-perf-menu-'", "'eboot-rejected-loading-discs-'")
s=s.replace("installed = work / 'native-perf1'", "installed = root / 'build/menu-perf-20261009/native'")
# Remove the unrelated trace-marker mutation from this deployment.
a=s.index('        try:\n            f.rename(\'prince-io-trace.enable\'')
b=s.index('    receipt = dict(',a)
s=s[:a]+s[b:]
s=s[:s.rindex("{'package': package, 'deploy': deploy}")]+"deploy()\n"
(w/'deploy.py').write_text(s,encoding='utf-8')
