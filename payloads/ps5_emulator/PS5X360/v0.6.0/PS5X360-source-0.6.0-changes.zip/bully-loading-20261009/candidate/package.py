from pathlib import Path
import json, hashlib, zipfile, shutil
r=Path(__file__).resolve().parents[3];w=Path(__file__).resolve().parent
native=w/'native'; proof=json.loads((native/'build.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((r/'build/kinect-update-20261008/final-native/build.json').read_text())
for name,h in baseline['baseline_inputs'].items():
    if Path(name).suffix in ('.a','.o'):
        p=r/Path(name).relative_to('/ws/Xbox360PS5')
        assert sha(p.read_bytes())==h, 'baseline drift '+str(p)
image=(native/'eboot.bin').read_bytes();assert sha(image)==proof['native_sha256']
with zipfile.ZipFile(r/'build/menu-perf-20261009/package/PPSA50011.zip') as z:
    assert z.testzip() is None
    files={i.filename:z.read(i) for i in z.infolist() if not i.is_dir()}
notes='''# PS5X360 0.5.9-loading-discs.1 (private candidate)

Based on 0.5.9-perf-menu.2-local. Keep that package for rollback.

- Fix PS5 CPU context release: retired contexts used a nonzero release length
  that the PS5 memory backend rejected. This leaked direct-memory reservations.
- Restore validated multi-disc grouping in the current launcher: one entry,
  Disc 1 executable, advertised disc count and parent-folder cover art.
- Lost Odyssey's real Disc 1-4 headers passed title/version/region/count validation.
- Retain Vulkan, network, input and frame generation objects from the baseline.

Checks: original ThreadState and launcher objects reproduced byte for byte;
native link/image verification; original lifecycle test exhausts 64 reservations,
corrected code completes 200 cycles with zero reservations left; real four-disc
headers validate launch and all four targets; package manifest verification.

Not yet verified on PS5: Bully loading, Lost Odyssey gameplay and actual in-game
disc transitions. The captured Lost Odyssey crash was a null PPC context during
CPU thread creation, not a disc-swap failure. The leak is confirmed; whether it
alone explains that runtime allocation failure remains unconfirmed.

Only extracted disc folders are grouped. No GitHub release was published.
'''
files.update({'PPSA50011/eboot.bin':image,'PPSA50011/VERSION':(proof['version']+'\n').encode(),'PPSA50011/RELEASE.json':json.dumps(proof,indent=2).encode(),'PPSA50011/RELEASE_NOTES.md':notes.encode()})
files.pop('PPSA50011/MANIFEST.json',None)
manifest={name.removeprefix('PPSA50011/'):{'sha256':sha(b),'bytes':len(b)} for name,b in files.items()}
files['PPSA50011/MANIFEST.json']=json.dumps(manifest,indent=2).encode()
out=w/'package';out.mkdir(exist_ok=True)
with zipfile.ZipFile(out/'PPSA50011.zip','w',zipfile.ZIP_DEFLATED) as z:
    for name,b in files.items():z.writestr(name,b)
with zipfile.ZipFile(out/'PPSA50011.zip') as z:
    assert z.testzip() is None
    for name,expected in manifest.items():
        b=z.read('PPSA50011/'+name);assert sha(b)==expected['sha256'] and len(b)==expected['bytes']
(out/'README.md').write_text(notes,encoding='utf-8')
desktop=Path.home()/'Desktop/PS5X360-loading-discs-test-20261009';desktop.mkdir(exist_ok=True)
for name in ('PPSA50011.zip','README.md'):shutil.copy2(out/name,desktop/name)
mirror=Path.home()/'Desktop/Xbox360PS5-source/loading-discs-20261009';mirror.mkdir(exist_ok=True)
for name in ('launcher.cpp','thread_state.cc','disc_library.cpp','disc_library.hpp','disc_catalog.cpp','disc_catalog.hpp','build.py','test.py','package.py'):shutil.copy2(w/name,mirror/name)
shutil.copy2(native/'build.json',mirror/'build.json')
shutil.copy2(w/'tests/results.txt',mirror/'test-results.txt')
print('PASS package',len(manifest),'files:',desktop)
