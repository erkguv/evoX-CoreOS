from pathlib import Path
import json, hashlib, subprocess, shutil, shlex, tempfile
r=Path('/ws/Xbox360PS5'); w=Path(__file__).resolve().parent
base=r/'build/menu-perf-20261009/native'; out=w/'native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base/'eboot.bin')=='9d729e2494b30b876521af2e69b32c9f8ba7d8559313d441d61099d3f8dfcb6e'
receipt=json.loads((base/'build.json').read_text())
command=shlex.split(subprocess.check_output(['ninja','-C',str(r/'build/canary-ps5'),'-t','commands','core/src/xenia/cpu/CMakeFiles/xenia-cpu.dir/thread_state.cc.o'],text=True))
command=command[:command.index('-MD')]+['-o',str(w/'thread_state.proof.o'),'-c',str(r/'.deps/xenia-canary/src/xenia/cpu/thread_state.cc')]
frozen=r/'build/continuation-20261009/menu/frozen'
command[1:1]=['-I'+str(frozen/'src'),'-I'+str(frozen/'include')]
subprocess.run(command,cwd=r/'build/canary-ps5',check=True)
original=r/'build/canary-ps5/core/src/xenia/cpu/CMakeFiles/xenia-cpu.dir/thread_state.cc.o'
if sha(w/'thread_state.proof.o')!=sha(original):
    (w/'preimage-mismatch.json').write_text(json.dumps({'original':sha(original),'rebuilt':sha(w/'thread_state.proof.o')},indent=2))
    raise RuntimeError('ThreadState preimage drift: stop, do not link or deploy')
(out/'obj').mkdir(parents=True,exist_ok=True)
for p in (base/'obj').glob('*.o'): shutil.copy2(p,out/'obj'/p.name)
cmd=list(command); cmd[cmd.index('-c')+1]=str(w/'thread_state.cc');cmd[cmd.index('-o')+1]=str(out/'obj/thread_state.cc.o')
subprocess.run(cmd,cwd=r/'build/canary-ps5',check=True)
menu=list(receipt['compile'])
proof=list(menu); proof[proof.index('-o')+1]=str(w/'launcher.proof.o')
subprocess.run(proof,cwd=r,check=True)
assert sha(w/'launcher.proof.o')==receipt['launcher_object_sha256']
cmds=[cmd]
for name in ('launcher.cpp','disc_library.cpp','disc_catalog.cpp'):
    cmd=list(menu);cmd[1:1]=['-I'+str(w),'-I'+str(r/'build/multidisc-ui-20261008/agent-library')]
    cmd[cmd.index('-c')+1]=str(w/name);cmd[cmd.index('-o')+1]=str(out/'obj'/(name+'.o'))
    subprocess.run(cmd,cwd=r,check=True);cmds.append(cmd)
subprocess.run(['bash',str(r/'build/kinect-update-20261008/native/link_dual_renderer_game.sh'),str(r),str(out)],check=True)
unchanged={p.name:sha(p) for p in (base/'obj').glob('*.o') if p.name not in ('launcher.cpp.o','disc_catalog.cpp.o')}
assert all(sha(out/'obj'/n)==h for n,h in unchanged.items())
(out/'build.json').write_text(json.dumps({'version':'0.5.9-loading-discs.1-local','baseline_sha256':sha(base/'eboot.bin'),'native_sha256':sha(out/'eboot.bin'),'commands':cmds,'unchanged_objects':unchanged,'thread_state_preimage_sha256':sha(original),'hardware':'pending'},indent=2))
print('PASS isolated candidate',sha(out/'eboot.bin'))
