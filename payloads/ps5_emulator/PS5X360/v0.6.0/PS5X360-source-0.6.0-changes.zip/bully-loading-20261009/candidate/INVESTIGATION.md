# Bully loading and Lost Odyssey four-disc investigation

## Current outcome

Private candidate `0.5.9-loading-discs.1-local` installed with mapped ELF and
dynamic segment verification. SHA256 of the local signed native image:
`d6f81df24df51f653f6af572eed1c1e2ab5d2488db6ebe10e2cb1e029345ffe4`.
Prior `0.5.9-perf-menu.2-local` preserved on console and locally; see deployment.json.
No public release was published. Console gameplay validation is pending.

## Observations and interpretation

- User reports Bully no longer aborts on the current baseline but stays loading.
  Latest Bully session: `20261009-190752-UTC`, title 5454081A,
  executable hash 0B2030C3D550882B. Detailed logging was enabled.
  No new SIGABRT was established for this session. The older invalid-mutex
  SIGABRT belongs to the preserved perf-menu.1 executable.
- Lost Odyssey launch: `20261009-183204-UTC`, title 4D5307FA,
  executable hash C0A4515E25B5D74B, source DISCO1/default.xex.
  Current matching ELF identifies crash offset 0x4822ae as
  X64Backend::InitializeBackendContext: write to ctx-16 with ctx=null.
  ThreadState allocation exhausted all fixed-address attempts and passed null
  to backend initialization. No disc swap preceded this crash.
- ThreadState::FreeContext passes a nonzero release length. The PS5 memory
  backend rejects nonzero kRelease lengths. Retired contexts consequently
  retain mappings/direct-memory allocations. Candidate uses the documented
  whole-region zero-length release only on PS5. Other host paths are unchanged.
  The mismatch and leak are confirmed. Whether it alone caused the observed
  Lost Odyssey allocation exhaustion or Bully stall remains unconfirmed.
- Current launcher omitted the previously implemented disc-group inspection.
  Restored it without adding/changing Launcher or GameEntry fields.
- Real Lost Odyssey DISCO1-4 headers agree in title, version, base version,
  platform, executable table, savegame identity and region; each identifies
  its proper disc number and a four-disc count. Files were read only.

## Verification limits

- ThreadState and launcher unmodified sources reproduced their installed
  objects byte for byte before compiling the isolated changes.
- Lifecycle fixture runs actual PS5 memory-backend source and extracted
  allocation/free functions, using Linux-backed kernel stubs and a deliberately
  bounded 64-reservation budget. Original exhausts that budget; corrected code
  completes 200 cycles leaving zero reservations. This is not a measurement
  of the PS5's actual address-space or memory capacity.
- Real four-disc XEX headers validate grouping and targets 1-4 under sanitizers.
- 40 source-level runtime/catalog checks with a mocked VFS cover valid swaps,
  cancellation and return to disc 1. This is not proof of actual campaign
  transitions on PS5. Retained compiled multi_disc.cpp.o was not replaced.
- Package CRC and all 563 manifest members verified; retained native objects
  and shared archive inputs checked against the baseline receipts.
- GitHub open issues reviewed read-only; Discord forum content was unavailable
  through the web tool. No external messages or issue mutations.

## Next console test

Use Vulkan with detailed logs off. Lost Odyssey should be one library item with
four discs; launch its Disc 1 and check whether loading reaches gameplay.
Repeat Bully loading. If either stalls, collect that candidate's new game log
and boot.log; do not reuse the older ELF when interpreting addresses.
