// SPDX-License-Identifier: GPL-3.0-or-later
// The adapter of the installed build under another name, to compare decisions with (the modes'
// tests): its class is the only thing renamed.
#define Pacing PacingBefore
#include "../framegen-stutter-20261010/pacing_adapter.hpp"
#undef Pacing
#include "pacing_adapter.hpp"
#include <cassert>
#include <iostream>
#include <thread>
using namespace ps5x360::framegen;
static const void* owner = reinterpret_cast<void*>(0x1234);
struct Run {
  Pacing p;
  uint64_t serial = 0, tick = 0, ns = 1000000000;
  double display = 60, source = 60;
  bool next(uint64_t ticks = 2, uint64_t elapsed = 0, bool present = true) {
    tick += ticks;
    ns += elapsed ? elapsed : uint64_t(ticks * 1e9 / source);
    source_ticks.store(tick);
    { std::lock_guard<std::mutex> lock(stamps_mutex);
      stamps[next_stamp++ % stamps.size()] = {owner, ++serial, tick, ns, source}; }
    const bool result = p.Observe(ns + 1000000000, serial, 1280, 720,
                                 display, true, true, owner);
    const auto fit = ticks && std::isfinite(source) && source > 0 ?
        uint32_t(ticks * display / source + 0.03) : 0;
    if (ticks) assert(p.HoldNanoseconds() <= 1e9 * fit / display + 1);
    if (present) p.Presented(true);
    return result;
  }
  void warm(uint64_t ticks = 2) {
    for (int i = 0; i < 24; ++i) next(ticks);
  }
};
// Model the parent's new policy: an engaged but unadmitted arrival neither
// records a snapshot nor presents. The next admitted arrival seeds history,
// presents one real frame, and only its successor may show a midpoint.
struct PresenterRun : Run {
  bool history = false, interpolation_history = false;
  uint32_t copies = 0, skipped = 0, real_presents = 0, midpoints = 0;
  bool paint(uint64_t ticks = 2, uint64_t elapsed = 0) {
    const bool admitted = next(ticks, elapsed, false);
    const bool engaged = p.Engaged();
    if (!engaged || !admitted) {
      history = interpolation_history = false;
      if (engaged) { ++skipped; return false; }
    } else {
      ++copies;
      if (history && interpolation_history) ++midpoints;
      history = interpolation_history = true;
    }
    ++real_presents; p.Presented(true);
    return admitted;
  }
  void warm(uint64_t ticks = 2) { for (int i = 0; i < 24; ++i) paint(ticks); }
};
#include "test_modes.inc"
int main() {
  RunModeTests();
  Run thirty; thirty.warm(); assert(thirty.p.Engaged());
  // The baseline drops on the third non-identical interval in this window.
  for (int i = 0; i < 64; ++i) {
    const uint64_t ticks[] = {2, 1, 3, 2, 2, 1, 3, 2};
    thirty.next(ticks[i % 8]);
    assert(thirty.p.Engaged());
    if (ticks[i % 8] == 1) assert(thirty.p.HoldNanoseconds() == 0);
  }
  Run duplicate; duplicate.warm();
  assert(!duplicate.next(0, 1000)); assert(duplicate.p.Engaged());
  assert(duplicate.p.HoldNanoseconds() == 0);
  assert(!duplicate.p.Observe(0, duplicate.serial, 1280, 720, 60, true, true, owner));
  assert(duplicate.p.Engaged());
  Run equal_stamp; equal_stamp.warm();
  assert(!equal_stamp.next(0)); assert(equal_stamp.p.Engaged());
  assert(equal_stamp.p.HoldNanoseconds() == 0);
  // Both successful repeat paints still spend this interval's refreshes.
  assert(!duplicate.next()); assert(duplicate.p.HoldNanoseconds() == 0);
  assert(duplicate.next());
  Run sixty;
  for (int i = 0; i < 80; ++i) assert(!sixty.next(1));
  Run high; high.display = 120; high.warm(1); assert(high.p.Engaged());
  Run unstable;
  for (int i = 0; i < 80; ++i) assert(!unstable.next(1 + i % 2));
  Run gap; gap.warm(); assert(!gap.next(9)); assert(!gap.p.Engaged());
  for (int i = 0; i < 7; ++i) assert(!gap.next());
  assert(gap.next());
  Run zero; zero.warm();
  assert(!zero.next(0, 200000000)); assert(!zero.p.Engaged());
  Run stopped; stopped.warm(); source_ticks.store(stopped.tick + 9);
  assert(!stopped.p.Engaged());
  Run irregular; irregular.warm();
  irregular.next(3); assert(!irregular.next(3)); assert(!irregular.p.Engaged());
  Run dense; dense.warm();
  for (int i = 0; i < 16; ++i) dense.next(i % 2 ? 3 : 1);
  assert(!dense.p.Engaged());
  Run transition; transition.warm();
  for (int i = 0; i < 32; ++i) transition.next(1);
  assert(!transition.p.Engaged());
  for (int i = 0; i < 32; ++i) transition.next(2);
  assert(transition.p.Engaged());
  assert(!transition.p.Observe(0, 999999, 1280, 720, 60, true, true, owner));
  Run cost; cost.warm();
  assert(cost.p.ProducerReferenceReady());
  for (int i = 0; i < 100 && !cost.p.SafetyPaused(); ++i) cost.next(2, 66666666);
  assert(cost.p.SafetyPaused()); assert(!cost.p.Engaged());
  assert(cost.p.ProducerRatePercent() > 49 && cost.p.ProducerRatePercent() < 51);
  // A gap must not erase the 10-second safety pause or relearn the slow rate.
  assert(!cost.next(9)); assert(cost.p.SafetyPaused());
  for (int i = 0; i < 400 && cost.p.SafetyPaused(); ++i) {
    if (cost.next()) assert(!cost.p.SafetyPaused());
  }
  assert(!cost.p.SafetyPaused());
  assert(cost.p.NextSafetyPauseSeconds() == 20);
  assert(cost.p.SafetyRecoveryRatePercent() >= 97);
  cost.warm(); assert(cost.p.Engaged());
  for (int i = 0; i < 100 && !cost.p.SafetyPaused(); ++i) cost.next(2, 66666666);
  assert(cost.p.SafetyPaused());
  for (int i = 0; i < 150; ++i) assert(!cost.next());
  assert(cost.p.SafetyPaused()); // The second pause really lasts longer.
  const double pause_rate = cost.p.ProducerRatePercent();
  assert(!cost.p.Observe(cost.ns, 999999, 1280, 720, 60, true, true, owner));
  assert(cost.p.SafetyPaused()); assert(cost.p.NextSafetyPauseSeconds() == 20);
  assert(cost.p.ProducerReferenceReady());
  assert(cost.p.ProducerRatePercent() == pause_rate);
  cost.p.Suspend(); cost.p.InvalidateCadence();
  assert(cost.p.SafetyPaused()); assert(!cost.p.Engaged());
  assert(cost.p.NextSafetyPauseSeconds() == 20);
  assert(!cost.next()); // Same-owner resume must not Reset the safety state.
  for (int i = 0; i < 8; ++i) assert(!cost.next());
  assert(cost.p.SafetyPaused()); assert(cost.p.NextSafetyPauseSeconds() == 20);
  for (int i = 0; i < 650 && cost.p.SafetyPaused(); ++i) cost.next();
  assert(!cost.p.SafetyPaused()); assert(cost.p.NextSafetyPauseSeconds() == 40);
  // Clock slowdown cannot be promoted to a new 100% producer reference.
  Run feedback; feedback.warm(1);
  for (int i = 0; i < 150; ++i) assert(!feedback.next(2, 66666666));
  assert(!feedback.p.Engaged());
  assert(feedback.p.ProducerRatePercent() < 51);
  PresenterRun menu; menu.warm(1);
  for (int i = 0; i < 15; ++i) assert(!menu.paint(2));
  assert(menu.paint(2)); assert(menu.history);
  assert(menu.midpoints == 0); assert(menu.paint(2)); assert(menu.midpoints == 1);
  assert(menu.p.ProducerRatePercent() > 99);
  PresenterRun retry; retry.warm();
  const auto copies = retry.copies, presents = retry.real_presents;
  const auto midpoints = retry.midpoints;
  assert(!retry.paint(0, 1000)); assert(retry.p.Engaged());
  assert(!retry.history && !retry.interpolation_history);
  assert(retry.copies == copies && retry.real_presents == presents);
  assert(retry.paint()); assert(retry.copies == copies + 1);
  assert(retry.midpoints == midpoints); // Seed after no-admission; no stale midpoint.
  assert(retry.paint()); assert(retry.midpoints == midpoints + 1);
  PresenterRun short_tick; short_tick.warm();
  assert(!short_tick.paint(1)); assert(short_tick.p.Engaged());
  assert(short_tick.paint(3)); assert(short_tick.paint(2));
  PresenterRun mode_shift; mode_shift.warm();
  assert(!mode_shift.paint(4)); // Active cost cannot immediately promote cadence.
  for (int i = 0; i < 15; ++i) assert(!mode_shift.paint(4));
  assert(mode_shift.paint(4));
  PresenterRun transient; transient.warm();
  assert(!transient.paint(4));
  for (int i = 0; i < 6; ++i) assert(!transient.paint(4));
  // Once generator waits stop, the old cadence recovers: no slower promotion.
  for (int i = 0; i < 16; ++i) transient.paint(2);
  assert(transient.p.Engaged());
  PresenterRun interrupted_menu; interrupted_menu.warm(1);
  for (int i = 0; i < 4; ++i) assert(!interrupted_menu.paint(2));
  interrupted_menu.p.Suspend();
  assert(interrupted_menu.p.ProducerReferenceReady());
  assert(!interrupted_menu.paint(2)); // First stamp only reseeds the anchor.
  for (int i = 0; i < 15; ++i) assert(!interrupted_menu.paint(2));
  assert(interrupted_menu.paint(2));
  PresenterRun lost; lost.warm();
  assert(!lost.p.Observe(lost.ns, 999999, 1280, 720, 60, true, true, owner));
  assert(!lost.p.Engaged()); assert(lost.p.ProducerReferenceReady());
  lost.history = lost.interpolation_history = false;
  assert(!lost.paint());
  for (int i = 0; i < 7; ++i) assert(!lost.paint());
  assert(lost.paint()); assert(lost.paint());
  Run reference; reference.warm(); reference.p.Suspend();
  assert(!reference.next(2, 66666666));
  for (int i = 0; i < 8; ++i) reference.next(2, 66666666);
  assert(reference.p.ProducerRatePercent() < 51);
  reference.p.InvalidateCadence();
  assert(!reference.p.Observe(reference.ns, 999999, 1280, 720, 60, true, true, owner));
  assert(reference.p.ProducerReferenceReady());
  assert(!reference.next(2, 66666666));
  for (int i = 0; i < 8; ++i) reference.next(2, 66666666);
  assert(reference.p.ProducerRatePercent() < 51);
  Run jitter_start;
  for (int i = 0; i < 64; ++i) {
    const uint64_t ticks[] = {2, 1, 3, 2, 2, 1, 3, 2};
    assert(!jitter_start.next(ticks[i % 8]));
  }
  Run budget; budget.display = 120; budget.warm();
  budget.p.Presented(true); budget.p.Presented(true); budget.p.Presented(true);
  assert(!budget.next()); assert(budget.p.HoldNanoseconds() == 0);
  assert(budget.next());
  Run failed; failed.warm(); failed.p.Presented(false); assert(failed.next());
  Run no_ticks;
  for (int i = 0; i < 128; ++i) assert(!no_ticks.next(0, 1000000));
  assert(!no_ticks.p.Engaged()); assert(!no_ticks.p.ProducerReferenceReady());
  Run initially_slow;
  for (int i = 0; i < 100 && !initially_slow.p.SafetyPaused(); ++i)
    initially_slow.next(2, 66666666);
  assert(initially_slow.p.SafetyPaused());
  assert(initially_slow.p.ProducerRatePercent() < 51);
  Run rollback; rollback.warm(); rollback.tick = 0;
  assert(!rollback.next()); assert(!rollback.p.Engaged());
  Run backwards_time; backwards_time.warm(); backwards_time.ns = 1;
  assert(!backwards_time.next()); assert(!backwards_time.p.Engaged());
  Run mode; mode.warm(); mode.display = 120;
  assert(!mode.next()); mode.warm(); assert(mode.p.Engaged());
  Run disabled; disabled.warm();
  assert(!disabled.p.Observe(0, disabled.serial, 1280, 720, 60, false, true, owner));
  assert(!disabled.p.Engaged());
  Run fifty; fifty.source = 50; fifty.display = 100; fifty.warm();
  assert(fifty.p.Engaged());
  Run bad; bad.warm(); bad.source = 0; assert(!bad.next(0, 1));
  assert(!bad.p.Engaged());
  Run frozen; frozen.warm();
  std::this_thread::sleep_for(std::chrono::milliseconds(150));
  assert(!frozen.p.Engaged()); assert(frozen.p.HoldNanoseconds() == 0);
  std::cout << "PASS: bounded jitter, strict start, zero/repeated tick, actual budget, failed presents, 30->60, 60->60, 60->120, 25->100, irregular, gaps, two-window dormant menu/mode transitions, missing stamps, Suspend/InvalidateCadence, frozen producer reference, 10/20/40s backoff, no-admission/reengage history, self-feeding rejection\n";
}
