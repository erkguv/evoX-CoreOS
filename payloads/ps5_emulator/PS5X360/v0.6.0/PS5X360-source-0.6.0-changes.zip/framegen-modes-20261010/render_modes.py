"""Host test of the launcher's frame generation rows: key presses in, settings file out.

Builds the launcher preview (software raster of the real ImGui draw list) with the launcher.cpp
of this folder, opens Settings > Performance, presses keys and checks what is then in
/app0/framegen.conf of the container. Screenshots go to preview/. Modelled on
build/title-updates-20261010/render_updates.py.
In xbox360ps5-canary with the repository's parent at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-canary:latest python3 -u /ws/Xbox360PS5/build/framegen-modes-20261010/render_modes.py
"""
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import zipfile

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
candidate = root / 'build/bully-loading-20261009/candidate'
menu = root / 'build/continuation-20261009/menu'
build = root / 'build/canary-runner'
out = here / 'preview'
objs = out / 'obj'
objs.mkdir(parents=True, exist_ok=True)

z = zipfile.ZipFile(root / 'build/release-v059/input/PS5X360-source-0.5.8-fix1.zip')
s = z.read('source/tools/preview-launcher.cpp').decode()
old = '    } else if (argc == 3) {'
assert s.count(old) == 1
s = s.replace(old, '''    } else if (argc == 3 && std::string(argv[2]).rfind("modes:", 0) == 0) {
      // modes:<language>:<keys>  Settings > Performance, then the keys, in that language.
      const std::string spec = std::string(argv[2]).substr(6);
      const int language = std::stoi(spec.substr(0, spec.find(':')));
      launcher.Press(xbox360ps5::Key::square);
      for (int i = 0; i < 3; ++i) launcher.Press(xbox360ps5::Key::down);
      launcher.Press(xbox360ps5::Key::cross);
      std::string list = spec.substr(spec.find(':') + 1) + ",";
      for (size_t at = 0; at < list.size();) {
        const size_t end = list.find(',', at);
        std::string token = list.substr(at, end - at);
        at = end + 1;
        if (token.empty()) continue;
        int count = 1;
        if (std::isdigit(static_cast<unsigned char>(token[0]))) { count = token[0] - '0'; token = token.substr(1); }
        const xbox360ps5::Key key = token == "sq" ? xbox360ps5::Key::square : token == "x" ? xbox360ps5::Key::cross :
          token == "o" ? xbox360ps5::Key::circle : token == "up" ? xbox360ps5::Key::up :
          token == "down" ? xbox360ps5::Key::down : token == "left" ? xbox360ps5::Key::left : xbox360ps5::Key::right;
        for (int n = 0; n < count; ++n) { launcher.Press(key); usleep(150000); }
      }
      xbox360ps5::ui_language.store(language);
    } else if (argc == 3) {''')
assert s.count('#include <algorithm>') == 1
s = s.replace('#include <algorithm>', '#include <algorithm>\n#include <unistd.h>\n#include "xbox360ps5/i18n.hpp"')
(out / 'preview-launcher.cpp').write_text(s)

ninja = (build / 'build.ninja').read_text()
target = next(line.split(': ', 1)[0][6:] for line in ninja.splitlines()
              if line.startswith('build CMakeFiles/xbox360ps5-launcher-preview.dir') and line.split(': ', 1)[0].endswith('/launcher.cpp.o'))
template = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', target], text=True).splitlines()[-1])
includes = ['-I' + str(here), '-I' + str(root / 'build/title-updates-20261010'),
            '-I' + str(root / 'build/kinect-native-20261009'), '-I' + str(candidate),
            '-I' + str(root / 'build/multidisc-ui-20261008/agent-library'),
            '-I' + str(menu / 'frozen/include'), '-I' + str(menu / 'frozen/src'),
            '-I' + str(root / 'build/dual-renderer-worktree/include'),
            '-I' + str(root / 'build/dual-renderer-worktree/.deps/xenia-canary/src')]
sources = {'launcher.cpp': here / 'launcher.cpp', 'preview-launcher.cpp': out / 'preview-launcher.cpp',
           'disc_library.cpp': candidate / 'disc_library.cpp', 'disc_catalog.cpp': candidate / 'disc_catalog.cpp'}
for name, source in sources.items():
    cmd = list(template)
    cmd[1:1] = includes
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(objs / (name + '.o'))
    if '-MF' in cmd:  # the dependency file too stays in this folder, not in build/canary-runner
        cmd[cmd.index('-MF') + 1] = str(objs / (name + '.o.d'))
    for i, a in enumerate(cmd):
        if a.startswith('-DXBOX360PS5_VERSION='):
            cmd[i] = '-DXBOX360PS5_VERSION="TEST updates.2"'
    subprocess.run(cmd, cwd=build, check=True)
line = subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', 'xbox360ps5-launcher-preview'], text=True).splitlines()[-1]
cmd = shlex.split(next(part for part in line.split(' && ') if ' -o xbox360ps5-launcher-preview ' in part))
replaced = set()
for i, a in enumerate(cmd):
    for n in sources:
        if a.endswith('/' + n + '.o'):
            cmd[i] = str(objs / (n + '.o'))
            replaced.add(n)
extra = [str(objs / (n + '.o')) for n in sources if n not in replaced]
cmd[cmd.index('-o') + 1] = str(objs / 'launcher-preview')
cmd[cmd.index('-o'):cmd.index('-o')] = extra
subprocess.run(cmd, cwd=build, check=True)

fonts = Path('/app0/assets/fonts')
fonts.mkdir(parents=True, exist_ok=True)
for p in (root / 'dist/PPSA50011/assets/fonts').glob('*.ttf'):
    shutil.copy2(p, fonts / p.name)

ON, OFF = 'ps5_frame_interpolation=true\n', 'ps5_frame_interpolation=false\n'
M, H = 'ps5_frame_multiplier=', 'ps5_frame_output_hz='
MODE, OUTPUT = '3up', '2up'  # from the page's first row: up wraps to FSI, then the output, then the mode
EN, ES, PT = 1, 5, 9
# name, language, the file before (None: no file), keys, the file after (None: no file)
cases = [
    ('first-use-automatic', EN, None, MODE + ',x', ON + M + 'auto\n' + H + '60\n'),
    ('untouched-no-file', EN, None, MODE, None),
    ('untouched-old-file', EN, ON, MODE, ON),
    ('old-on-is-2x-then-3x', PT, ON, MODE + ',x', ON + M + '3\n' + H + '60\n'),
    ('old-on-left-automatic', EN, ON, MODE + ',left', ON + M + 'auto\n' + H + '60\n'),
    ('old-off-left-4x', ES, OFF, MODE + ',left', ON + M + '4\n' + H + '60\n'),
    ('4x-right-off-keeps-lines', EN, ON + M + '4\n' + H + 'auto\n', MODE + ',right', OFF + M + '4\n' + H + 'auto\n'),
    ('4x-off-automatic', EN, ON + M + '4\n' + H + 'auto\n', MODE + ',2x', ON + M + 'auto\n' + H + 'auto\n'),
    ('whole-cycle-back-to-2x', EN, ON, MODE + ',5x', ON + M + '2\n' + H + '60\n'),
    ('off-first-press-automatic', EN, OFF + M + '3\n', MODE + ',x', ON + M + 'auto\n' + H + '60\n'),
    ('cycle-through-to-off-keeps-last-on', EN, OFF + M + '3\n', MODE + ',5x', OFF + M + '4\n' + H + '60\n'),
    ('output-to-120', PT, ON + M + '3\n', OUTPUT + ',x', ON + M + '3\n' + H + '120\n'),
    ('output-auto-to-60', ES, ON + M + 'auto\n' + H + 'auto\n', OUTPUT + ',right', ON + M + 'auto\n' + H + '60\n'),
    ('output-toggle-twice', EN, ON + M + 'auto\n' + H + 'auto\n', OUTPUT + ',2x', ON + M + 'auto\n' + H + '120\n'),
    ('unknown-output-kept', EN, ON + M + '3\n' + H + '144\n', MODE + ',right', ON + M + '4\n' + H + '144\n'),
    ('crlf-file-read', EN, 'ps5_frame_interpolation=true\r\nps5_frame_multiplier=3\r\nps5_frame_output_hz=120\r\n',
     MODE + ',x', ON + M + '4\n' + H + '120\n'),
    ('bad-first-line-is-off', EN, 'frame=yes\n' + M + '4\n' + H + '120\n', MODE + ',x', ON + M + 'auto\n' + H + '60\n'),
    ('screen-automatic-en', EN, ON + M + 'auto\n' + H + '120\n', MODE, ON + M + 'auto\n' + H + '120\n'),
    ('screen-4x-pt', PT, ON + M + '4\n' + H + '120\n', MODE, ON + M + '4\n' + H + '120\n'),
    ('screen-output-es', ES, ON + M + '3\n' + H + '60\n', OUTPUT, ON + M + '3\n' + H + '60\n'),
    ('screen-off-pt', PT, OFF, MODE, OFF),
]
conf = Path('/app0/framegen.conf')
failed = 0
for name, language, before, keys, after in cases:
    shutil.rmtree('/download0/xbox360ps5', ignore_errors=True)
    conf.unlink(missing_ok=True)
    Path('/app0/framegen.conf.new').unlink(missing_ok=True)
    if before is not None:
        conf.write_bytes(before.encode())
    run = subprocess.run([str(objs / 'launcher-preview'), str(out / (name + '.png')), f'modes:{language}:{keys}'],
                         cwd=objs, capture_output=True, text=True)
    got = conf.read_bytes().decode() if conf.exists() else None
    ok = run.returncode == 0 and got == after and not Path('/app0/framegen.conf.new').exists()
    failed += not ok
    print('PASS' if ok else 'FAIL', name, repr(keys), '->', repr(got))
    if not ok:
        print('   expected', repr(after), '| exit', run.returncode, (run.stdout + run.stderr).strip()[-300:])
print(f'{"PASS" if not failed else "FAIL"} launcher rows: {len(cases) - failed} of {len(cases)} cases')
sys.exit(1 if failed else 0)
