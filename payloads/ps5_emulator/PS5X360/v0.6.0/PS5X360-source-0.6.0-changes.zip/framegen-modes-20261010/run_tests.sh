#!/usr/bin/env bash
# Host tests of the frame generation modes. In xbox360ps5-canary with the repository's parent
# mounted at /ws:  bash /ws/Xbox360PS5/build/framegen-modes-20261010/run_tests.sh
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
base="$here/../framegen-stutter-20261010"   # source_clock.hpp and vendor/, unchanged
out=$(mktemp -d)
flags=(-std=gnu++20 -Wall -Wextra -Werror -I"$here" -I"$base")
clang++-18 "${flags[@]}" -O2 "$here/test_adapter.cpp" -o "$out/test_adapter"
"$out/test_adapter"
clang++-18 "${flags[@]}" -O1 -g -fsanitize=address,undefined -fno-sanitize-recover=all \
  "$here/test_adapter.cpp" -o "$out/test_adapter_san"
"$out/test_adapter_san"
# The upstream pacer is used unchanged: its own test still passes against the vendored copy.
clang++-18 -std=c++17 -Wall -Wextra -I"$base/vendor" \
  "$here/../ps5-framegen-upstream-20261010/tests/test_pacing.cpp" -o "$out/test_pacing"
"$out/test_pacing" | tail -1
echo "PASS host tests (clang++-18 -Wall -Wextra -Werror, then ASan/UBSan)"
