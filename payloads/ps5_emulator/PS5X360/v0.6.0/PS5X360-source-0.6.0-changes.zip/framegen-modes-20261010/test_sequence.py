"""The interpolator called in the order the presenter calls it for 3x and 4x, on a CPU Vulkan driver.

The presenter records a frame, advances the interpolator at once, and only then (after the
paint of each picture) asks for the next picture between the same two frames, with its own
barrier in front. Upstream's test tool advances last. This builds that tool twice from the
module as it is linked into the candidate (private dispatch, 10-bit frames): once in upstream's
order and once in the presenter's, and checks that every picture of the x3 and x4 scenes is
the same file in both, and within upstream's limits.
In xbox360ps5-canary with the repository's parent at /ws:
  python3 /ws/Xbox360PS5/build/framegen-modes-20261010/test_sequence.py
"""
from pathlib import Path
import hashlib
import os
import subprocess
import sys
import tempfile

root = Path('/ws/Xbox360PS5')
vendor = root / 'build/framegen-stutter-20261010/vendor'
upstream = root / 'build/ps5-framegen-upstream-20261010'
work = Path(tempfile.mkdtemp())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def swap(text, old, new):
    assert text.count(old) == 1, (old[:60], text.count(old))
    return text.replace(old, new)


# The tool on the candidate's module: its private dispatch bound, frames in the 10-bit format.
s = (upstream / 'tools/fg-test.cpp').read_text()
s = '#include "sword_loader.hpp"\n' + s
s = swap(s, '\tif (!fg.create(g.physical, g.device,',
         '\tif (!ps5x360::sword_dispatch::Bind(g.instance,g.device,vkGetInstanceProcAddr)) return 2;\n'
         '\tif (!fg.create(g.physical, g.device,')
s = swap(s, 'error, bgra ? VK_FORMAT_B8G8R8A8_UNORM', 'error, true ? VK_FORMAT_A2B10G10R10_UNORM_PACK32 : bgra ? VK_FORMAT_B8G8R8A8_UNORM')
s = swap(s, '\t\tif (bgra)\n\t\t{', '''\t\tif (true) {
      auto* packed = static_cast<uint32_t*>(map);
      for (size_t pixel=0;pixel<bytes/4;++pixel) {
        const auto* p=cur.rgba.data()+pixel*4;
        packed[pixel]=uint32_t((p[0]*1023+127)/255) |
                      (uint32_t((p[1]*1023+127)/255)<<10) |
                      (uint32_t((p[2]*1023+127)/255)<<20) | 0xc0000000u;
      }
    } else if (bgra)
    {''')
(work / 'upstream_order.cpp').write_text(s)

# The same, in the presenter's order (presenter_sidecar.hpp: Record, then RecordNext).
p = swap(s, '\t\tconst bool made = fg.record(cmd, frame == 0);\n',
         '\t\tconst bool made = fg.record(cmd, frame == 0);\n\t\tfg.advance();  // the presenter advances here\n')
p = swap(p, '\t\tfg.advance();\n\t}\n', '\t}\n')
p = swap(p, '\t\t\t\tif (!fg.interpolate_next(cmd2, static_cast<uint32_t>(i))) die("interpolate_next");\n', '''\t\t\t\t{
\t\t\t\t\tVkMemoryBarrier reuse{}; reuse.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
\t\t\t\t\treuse.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
\t\t\t\t\treuse.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
\t\t\t\t\tvkCmdPipelineBarrier(cmd2, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1, &reuse, 0, nullptr, 0, nullptr);
\t\t\t\t}
\t\t\t\tif (!fg.interpolate_next(cmd2, static_cast<uint32_t>(i))) die("interpolate_next");
''')
(work / 'presenter_order.cpp').write_text(p)

base = ['clang++-18', '-std=c++17', '-O2', '-Wno-missing-field-initializers', '-I' + str(vendor), '-I' + str(upstream / 'tools/stb')]
subprocess.run(base + ['-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"', str(vendor / 'ps5_framegen.cpp'), '-c', '-o', str(work / 'module.o')], check=True)
for name in ('upstream_order', 'presenter_order'):
    subprocess.run(base + [str(work / (name + '.cpp')), str(work / 'module.o'), '-lvulkan', '-ldl', '-o', str(work / name)], check=True)

# Every picture of x2, x3 and x4 is the same in both orders.
compared = 0
for scene, gen in (('all', 1), ('all', 2), ('all', 3), ('head', 3), ('hud', 2)):
    files = {}
    for name in ('upstream_order', 'presenter_order'):
        out = work / f'{name}-{scene}-{gen}.png'
        extra = ['--head-move', '6'] if scene == 'head' else []
        run = subprocess.run([str(work / name), '--scene', scene, str(out)] + extra + ['--gen', str(gen)], capture_output=True, text=True)
        if run.returncode != 0:
            print(run.stdout[-2000:], run.stderr[-2000:])
            sys.exit(f'FAIL {name} {scene} x{gen + 1}: exit {run.returncode}')
        files[name] = [out] + [Path(f'{out}.{i}.png') for i in range(1, gen)]
    for a, b in zip(files['upstream_order'], files['presenter_order']):
        assert a.exists() and b.exists(), (a, b)
        if sha(a) != sha(b):
            sys.exit(f'FAIL {scene} x{gen + 1}: {b.name} differs from upstream order')
        compared += 1
    print(f'same   {scene} x{gen + 1}: {gen} picture(s) identical in both orders')

# And the presenter's order within upstream's limits for every scene.
check = subprocess.run([sys.executable, str(upstream / 'tools/check-scenes.py'), str(work / 'presenter_order'), str(work / 'scenes')],
                       capture_output=True, text=True, env=dict(os.environ))
print(check.stdout + check.stderr)
if check.returncode != 0:
    sys.exit('FAIL scene limits in the presenter order')
print(f'PASS sequence: {compared} pictures identical in upstream order and presenter order (10-bit frames, private dispatch)')
