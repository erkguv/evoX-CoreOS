#!/usr/bin/env bash
# Shows that the modes' tests notice a wrong adapter: two deliberate faults must each fail.
# In xbox360ps5-canary:  bash /ws/Xbox360PS5/build/framegen-modes-20261010/mutation_check.sh
set -uo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
base=$(cd -- "$here/../framegen-stutter-20261010" && pwd)
work=$(mktemp -d)
cp "$here/test_adapter.cpp" "$here/test_modes.inc" "$here/framegen_config.hpp" "$work/"
sed -i "s#../framegen-stutter-20261010/pacing_adapter.hpp#$base/pacing_adapter.hpp#" "$work/test_adapter.cpp"
fault() {  # name, sed expression on the adapter
  sed "$2" "$here/pacing_adapter.hpp" > "$work/pacing_adapter.hpp"
  cmp -s "$here/pacing_adapter.hpp" "$work/pacing_adapter.hpp" && { echo "FAIL $1: the fault did not apply"; exit 1; }
  clang++-18 -std=gnu++20 -O2 -Wall -Wextra -Werror -I"$work" -I"$base" "$work/test_adapter.cpp" -o "$work/t" || exit 1
  if "$work/t" > /dev/null 2> "$work/err"; then echo "FAIL $1: the tests passed with the fault"; exit 1; fi
  echo "caught $1: $(head -1 "$work/err" | sed 's#.*/##')"
}
fault 'a picture held one refresh too long' 's/const Pictures one{presents ? 1u : 0u, presents};/const Pictures one{presents ? 1u : 0u, presents + (fit == 4)};/'
fault 'a 120 Hz guest clock given to the pacer as it is' 's/return source_hz > 100 ? 0.5 : 1.0;/return source_hz > 1000 ? 0.5 : 1.0;/'
fault 'automatic never above 2x' 's/fit % 4 == 0 ? 4 : fit % 3 == 0 ? 3 : 2;/2;/'
fault 'more pictures than the interval has refreshes' 's/const uint32_t pictures = std::min(times - 1, left);/const uint32_t pictures = times - 1;/'
echo "PASS mutation check: 4 faults, 4 caught"
