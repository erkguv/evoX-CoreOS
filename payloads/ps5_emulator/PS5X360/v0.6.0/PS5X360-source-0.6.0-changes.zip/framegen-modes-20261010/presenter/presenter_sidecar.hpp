// SPDX-License-Identifier: GPL-3.0-or-later
// Included in exactly one presenter translation unit. No frozen class members.
#pragma once
#include <chrono>
#include <cstdio>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include "framegen_config.hpp"
#include "pacing_adapter.hpp"
#include "vendor/ps5_framegen.h"
#include "vendor/sword_loader.hpp"

namespace xe::ui::vulkan {
namespace {
bool FramegenDrawUI(bool requested, bool) { return requested; }
void ReleaseInactiveFramegenConsumer(std::unique_lock<std::mutex>& lock, bool active) {
  if (!active && lock.owns_lock()) lock.unlock();
}
// The settings file as read at the start: the switch, the multiplier and the output rate.
ps5x360::framegen::Config& FramegenConfig() {
  static ps5x360::framegen::Config config;
  return config;
}
// The refresh to ask of the display, in millihertz, given the surface's own request.
uint32_t FramegenRequestedRefresh(uint32_t surface_request) {
  return ps5x360::framegen::RequestedRefreshMillihertz(FramegenConfig(), surface_request);
}
void FramegenNoteDisplay(uint32_t requested, uint32_t surface_request, uint32_t selected) {
  static bool logged = false;
  if (logged || requested == surface_request) return;
  logged = true;
  // Accepted: selected_hz is 119.88. Otherwise the driver listed no such mode.
  XELOGW("Framegen output: asked for {} Hz, selected_hz={}{}", requested / 1000,
         double(selected) / 1000.0,
         selected >= 100000 ? " (120 Hz output accepted)"
                            : " (no 120 Hz mode offered: the title's param.json attribute3, the "
                              "console's 120 Hz setting or the display; staying at 60 Hz)");
}
void LoadFramegenPrivateConfig() {
  // No launcher Settings field. Read once per process, before swapchain setup.
  static bool loaded = false;
  if (loaded) return;
  loaded = true;
  const char* path = "/app0/framegen.conf";
  std::FILE* file = std::fopen(path, "rb");
  if (!file) {
    path = "/data/homebrew/PPSA50011/framegen.conf";
    file = std::fopen(path, "rb");
  }
  if (!file) {
    XELOGW("Framegen config unavailable in /app0 or installation root; disabled");
    return;
  }
  char text[1024]{};
  const size_t length = std::fread(text, 1, sizeof(text) - 1, file);
  std::fclose(file);
  auto& config = FramegenConfig();
  config = ps5x360::framegen::ParseConfig(std::string(text, length));
  const bool valid = config.valid;
  // Line 1 decides alone whether the file counts, as before modes; a file it rejects gives
  // nothing else either.
  if (!valid) config = {};
  cvars::ps5_frame_interpolation = valid && config.enabled;
  XELOGW("Framegen private config: {} enabled={} valid={} (restart required)",
         path, bool(cvars::ps5_frame_interpolation), valid);
  if (config.has_multiplier || config.has_output || config.unknown_value)
    XELOGW("Framegen private config: multiplier={}{} output_hz={}{}{}",
           ps5x360::framegen::MultiplierText(config.multiplier),
           config.has_multiplier ? "" : " (default)",
           ps5x360::framegen::OutputText(config.output_hz), config.has_output ? "" : " (default)",
           config.unknown_value ? "; a line with an unknown value was ignored" : "");
}
struct FramegenSidecar {
  struct Image { VkImage image{}; VkImageView view{}; VkDeviceMemory memory{}; };
  VulkanDevice* device = nullptr;
  Image images[3]{};  // Two private snapshots and one private midpoint.
  ps5::framegen::interpolator interpolation;
  ps5x360::framegen::Pacing pacing;
  VkDescriptorPool pool{};
  VkDescriptorSet sampled[3]{};
  PFN_vkCmdCopyImage copy_image = nullptr;
  VkExtent2D extent{};
  uint32_t current = 0;
  bool interpolation_history = false;
  bool history = false, initialized = false, failed = false;
  uint64_t serial = 0;
  std::shared_ptr<void> source_keepalive;
  uint64_t source_copy_submission = 0;
  // Independently of effect_count, every snapshot has an owning GPU lease.
  bool RetireSource(uint64_t completed_submission) {
    if (source_keepalive && source_copy_submission > completed_submission) return false;
    source_keepalive.reset(); source_copy_submission = 0; return true;
  }
  bool RetainSnapshotSource(std::shared_ptr<void> source, uint64_t submission) {
    if (source_keepalive || !source) return false;
    source_keepalive = std::move(source); source_copy_submission = submission;
    return true;
  }
  double display_hz = 0;
  uint64_t paints = 0, new_frames = 0, admitted = 0;
  uint64_t dormant_frames = 0, snapshot_waits = 0, snapshot_wait_ns = 0;
  uint64_t snapshot_wait_max_ns = 0;
  uint64_t deferred_frames = 0;
  // Modes: the generated pictures of the frame recorded last (0: none; 1 to 3), and what the
  // log last said about the multiplier in effect.
  uint32_t pictures = 0, plan_logged = 0, plan_logs = 0;
  // Diagnostics of the presentation queue, reported with the presentation cost: source frames
  // never painted while generating, generated presents that waited for a free swapchain image
  // (a full queue), and cadence losses.
  uint64_t skipped_sources = 0, slow_acquires = 0;
  uint32_t cadence_breaks_reported = 0;
  bool acquire_pending = false;
  // A new source serial: the ones between it and the last painted were never shown.
  void NoteSerial(uint64_t next) {
    if (history && pictures && serial && next > serial + 1) skipped_sources += next - serial - 1;
  }
  // The wait of the first acquire of a frame's generated pictures. Over 2 ms, no image was
  // free before a refresh: every image was queued or on screen.
  void NoteAcquire(std::chrono::steady_clock::duration wait) {
    if (!acquire_pending) return;
    acquire_pending = false;
    if (wait > std::chrono::milliseconds(2)) ++slow_acquires;
  }
  // The multiplier in effect, logged when it changes (a few times, not per frame). Nothing is
  // logged for the plain 2x of the builds before modes.
  void NotePlan() {
    const uint32_t times = pacing.Generated() + 1;
    if (pacing.Multiplier() == 2 || times == plan_logged || !pacing.Generated()) return;
    if (plan_logs < 24) {
      XELOGW("Framegen {}: {}x in effect ({} generated, each shown {} refresh(es); a game frame "
             "lasts {} refreshes at selected_hz={}){}",
             pacing.Multiplier() ? "multiplier" : "automatic", times, pacing.Generated(),
             pacing.HoldRefreshes(), pacing.IntervalRefreshes(), display_hz,
             ++plan_logs == 24 ? "; further changes are not logged" : "");
    }
    plan_logged = times;
  }
  void ReportPresentationCost() {
    if (new_frames % 600 != 0) return;
    const uint32_t breaks = pacing.CadenceBreaks();
    if (skipped_sources || slow_acquires || breaks != cadence_breaks_reported)
      XELOGW("Framegen queue: skipped_source={} slow_acquire={} cadence_breaks={} in the last 600 "
             "source frames", skipped_sources, slow_acquires, breaks - cadence_breaks_reported);
    cadence_breaks_reported = breaks;
    skipped_sources = slow_acquires = 0;
    XELOGW("Framegen presentation cost: source={} dormant={} deferred={} waits={} mean={}ms max={}ms",
           new_frames, dormant_frames, deferred_frames, snapshot_waits,
           snapshot_waits ? double(snapshot_wait_ns) / double(snapshot_waits) / 1e6 : 0.0,
           double(snapshot_wait_max_ns) / 1e6);
    dormant_frames = deferred_frames = snapshot_waits = snapshot_wait_ns = snapshot_wait_max_ns = 0;
  }
  uint64_t midpoint_present_ok = 0, ordinary_present_ok = 0;
  uint64_t fallback_paints = 0, ui_skips = 0, failures = 0;
  uint32_t fallback_log_mask = 0;
  bool enabled_logged = false, admission_logged = false;
  void LogEnabled() {
    if (enabled_logged) return;
    enabled_logged = true;
    XELOGW("Framegen enabled (Sword FSR3 optical flow): selected_hz={}, FIFO required", display_hz);
    const auto& config = FramegenConfig();
    const char* const in_effect = config.multiplier == 0 ? "2x to 4x by the game's cadence"
        : config.multiplier == 3 ? "up to 3x" : config.multiplier == 4 ? "up to 4x" : "2x";
    XELOGW("Framegen mode: {}, multiplier {}, output asked {} Hz, selected_hz={}",
           config.multiplier == 0 ? "automatic" : config.multiplier == 3 ? "3x"
               : config.multiplier == 4 ? "4x" : "2x",
           in_effect, FramegenRequestedRefresh(60000) / 1000, display_hz);
  }
  void Fallback(uint32_t reason, const char* text) {
    ++fallback_paints;
    if (!(fallback_log_mask & reason)) {
      fallback_log_mask |= reason;
      XELOGW("Framegen fallback: {}", text);
    }
  }
  // Called only after ALL referencing paint submissions have completed.
  void DestroyImages(bool reset_pacing = true) {
    // Entry points that release GPU resources MUST first retire paint work.
    source_keepalive.reset(); source_copy_submission = 0;
    if (reset_pacing) pacing.Reset();
    if (!device) return;
    const auto& f = device->functions(); auto d = device->device();
    interpolation.destroy();
    if (pool) f.vkDestroyDescriptorPool(d, pool, nullptr);
    pool = {}; for (auto& set : sampled) set = {};
    for (auto& i : images) i = {}; // Owned by the interpolator.
    interpolation_history = initialized = history = false; serial = 0; current = 0;
    pictures = 0; acquire_pending = false;
    extent = {};
  }
  ~FramegenSidecar() {
    if (paints || enabled_logged) {
      XELOGW("Framegen summary: paints={} new_frames={} admitted={} "
             "midpoint_present_ok={} ordinary_present_ok={} "
             "fallback_paints={} ui_skips={} failures={} (present acceptance, not scanout FPS)",
             paints,new_frames,admitted,midpoint_present_ok,ordinary_present_ok,
             fallback_paints,ui_skips,failures);
    }
    DestroyImages();
  }
  bool Prepare(VulkanDevice* dev, VkExtent2D size, VkFormat source_format,
               VkDescriptorSetLayout sampled_layout) {
    if (failed) return false;
    if (initialized && size.width == extent.width && size.height == extent.height) return true;
    // Observe already qualified the new extent. Recreate visual history without
    // discarding that producer cadence. Failure/teardown still resets pacing.
    DestroyImages(false); device = dev; extent = size;
    auto fail = [&] { DestroyImages(); failed = true; return false; };
    // Copy requires identical source/snapshot formats; no reinterpretation.
    if (source_format != VK_FORMAT_A2B10G10R10_UNORM_PACK32) return fail();
    VkFormatProperties properties{};
    dev->vulkan_instance()->functions().vkGetPhysicalDeviceFormatProperties(
        dev->physical_device(), source_format, &properties);
    const auto required = VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT |
        VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT |
        VK_FORMAT_FEATURE_TRANSFER_SRC_BIT | VK_FORMAT_FEATURE_TRANSFER_DST_BIT;
    if ((properties.optimalTilingFeatures & required) != required) return fail();
    dev->vulkan_instance()->functions().vkGetPhysicalDeviceFormatProperties(
        dev->physical_device(), ps5::framegen::interpolator::k_format, &properties);
    const auto output_required = VK_FORMAT_FEATURE_STORAGE_IMAGE_BIT |
        VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT |
        VK_FORMAT_FEATURE_TRANSFER_SRC_BIT;
    if ((properties.optimalTilingFeatures & output_required) != output_required) return fail();
    auto d = dev->device(); const auto& f = dev->functions();
    const auto& ifn = dev->vulkan_instance()->functions();
    auto instance = dev->vulkan_instance()->instance();
    auto loader = reinterpret_cast<PFN_vkGetDeviceProcAddr>(ifn.vkGetInstanceProcAddr(instance,"vkGetDeviceProcAddr"));
    if (!loader || !ps5x360::sword_dispatch::Bind(instance,d,ifn.vkGetInstanceProcAddr)) return fail();
    copy_image = reinterpret_cast<PFN_vkCmdCopyImage>(loader(d,"vkCmdCopyImage"));
    if (!copy_image) return fail();
    std::string error;
    if (!interpolation.create(dev->physical_device(),d,size.width,size.height,error,source_format)) {
      XELOGE("Framegen: Sword interpolator setup failed: {}",error);
      return fail();
    }
    for (unsigned i=0;i<2;++i) { images[i].image=interpolation.snapshot_image(i); images[i].view=interpolation.snapshot_view(i); }
    images[2].image=interpolation.output_image(); images[2].view=interpolation.output_view();
    XELOGW("Framegen: Sword FSR3 ready for {}x{} (6436210, {})",size.width,size.height,
           ps5x360::framegen::ModeText(pacing.Multiplier()));
    VkDescriptorPoolSize counts[] = {{VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE, 3},
                                    {VK_DESCRIPTOR_TYPE_SAMPLER, 3}};
    VkDescriptorPoolCreateInfo p{}; p.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO;
    p.maxSets = 3; p.poolSizeCount = 2; p.pPoolSizes = counts;
    if (f.vkCreateDescriptorPool(d, &p, nullptr, &pool) != VK_SUCCESS) return fail();
    VkDescriptorSetAllocateInfo a{}; a.sType = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO;
    VkDescriptorSetLayout layouts[] = {sampled_layout,sampled_layout,sampled_layout};
    a.descriptorPool = pool; a.descriptorSetCount = 3; a.pSetLayouts = layouts;
    if (f.vkAllocateDescriptorSets(d, &a, sampled) != VK_SUCCESS) return fail();
    VkDescriptorImageInfo info[3]{}; VkWriteDescriptorSet writes[3]{};
    for (uint32_t n=0;n<3;++n) {
      info[n].imageView = images[n].view; info[n].imageLayout = VK_IMAGE_LAYOUT_GENERAL;
      auto& w=writes[n];w.sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
      w.dstSet = sampled[n]; w.dstBinding = 0; w.descriptorCount = 1;
      w.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE; w.pImageInfo = &info[n];
    }
    f.vkUpdateDescriptorSets(d, 3, writes, 0, nullptr);
    initialized = true; return true;
  }
  // Source is pinned by the presenter shared_ptr; the existing queue owns it.
  // The caller retires paint submissions before changing this serial sidecar.
  bool Record(VkCommandBuffer command, VkImage source, bool generate) {
    const auto& f = device->functions();
    interpolation.prepare(command);
    uint32_t next = interpolation.frame_image() == images[0].image ? 0u : 1u;
    VkImageMemoryBarrier b{}; b.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    b.oldLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    b.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    b.image = source; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT,0,1,0,1};
    b.srcAccessMask = VK_ACCESS_MEMORY_WRITE_BIT | VK_ACCESS_MEMORY_READ_BIT;
    b.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    f.vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
                          VK_PIPELINE_STAGE_TRANSFER_BIT,0,0,nullptr,0,nullptr,1,&b);
    // Retired prior submissions still need an execution/memory dependency.
    VkMemoryBarrier reuse{}; reuse.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    reuse.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
    reuse.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT | VK_ACCESS_SHADER_READ_BIT |
                          VK_ACCESS_SHADER_WRITE_BIT;
    f.vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        VK_PIPELINE_STAGE_TRANSFER_BIT|VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        0,1,&reuse,0,nullptr,0,nullptr);
    VkImageCopy copy{}; copy.srcSubresource = copy.dstSubresource =
        {VK_IMAGE_ASPECT_COLOR_BIT,0,0,1};
    copy.extent = {extent.width,extent.height,1};
    copy_image(command,source,VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                    images[next].image,VK_IMAGE_LAYOUT_GENERAL,1,&copy);
    b.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    b.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    b.srcAccessMask = VK_ACCESS_TRANSFER_READ_BIT; b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    f.vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,
        VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,0,0,nullptr,0,nullptr,1,&b);
    VkMemoryBarrier uploaded{}; uploaded.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    uploaded.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    uploaded.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    f.vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_TRANSFER_BIT,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT|VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
        0,1,&uploaded,0,nullptr,0,nullptr);
    // Maintain luma/scene history, but don't interpolate unless pacing permits.
    bool made = false;
    if (pacing.Engaged()) {
      // Modes: the pictures planned for this frame, set before the first is recorded (it is
      // made a 1 / (pictures + 1) of the way). One, at the middle, unless 3x or 4x applies.
      interpolation.set_generated(generate ? std::clamp<uint32_t>(pacing.Generated(), 1, 3) : 1);
      made = interpolation.record(command, !interpolation_history);
      interpolation_history = true;
    } else { interpolation_history = false; }
    const bool generated = generate && history && made;
    pictures = generated ? interpolation.generated() : 0;
    acquire_pending = generated;
    current = next; history = true;
    interpolation.advance();
    if ((new_frames % 120) == 0) {
      double mean=0,max=0,flow_mean=0; uint32_t count=0;
      if (interpolation.take_gpu_time(mean,max,count,flow_mean))
        XELOGW("Framegen GPU cost: mean={}ms max={}ms flow={}ms samples={}",mean,max,flow_mean,count);
    }
    return generated;
  }
  // 3x and 4x: the next picture between the same two frames (1 to pictures - 1), into the
  // interpolator's one output image. The paint that samples the picture before it is already
  // queued ahead of this on the same queue, and the barrier orders the write after it.
  bool RecordNext(VkCommandBuffer command, uint32_t picture) {
    VkMemoryBarrier reuse{}; reuse.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    reuse.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
    reuse.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
    device->functions().vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,1,&reuse,0,nullptr,0,nullptr);
    return interpolation.interpolate_next(command, picture);
  }
};
std::mutex framegen_sidecars_mutex;
std::unordered_map<const void*, std::unique_ptr<FramegenSidecar>> framegen_sidecars;
FramegenSidecar& GetFramegenSidecar(const void* presenter) {
  std::lock_guard<std::mutex> lock(framegen_sidecars_mutex);
  auto& entry = framegen_sidecars[presenter];
  if (!entry) entry = std::make_unique<FramegenSidecar>();
  return *entry;
}
void EraseFramegenSidecar(const void* presenter) {
  std::lock_guard<std::mutex> lock(framegen_sidecars_mutex);
  framegen_sidecars.erase(presenter);
}
void DisableFramegenSidecar(const void* presenter) {
  std::lock_guard<std::mutex> lock(framegen_sidecars_mutex);
  auto it = framegen_sidecars.find(presenter);
  if (it != framegen_sidecars.end()) {
    it->second->display_hz = 0;
    it->second->pacing.Reset();
  }
}
}  // namespace
}  // namespace xe::ui::vulkan
