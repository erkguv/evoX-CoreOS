"""Frame generation modes, presenter side: writes the three edited sources of this folder.

Reads the sources of the installed presenter object (build/framegen-stutter-20261010, whose
compile reproduces that object byte for byte: build.py checks it) and writes, next to this
script, pacing_adapter.hpp, presenter/presenter_sidecar.hpp and presenter/vulkan_presenter.cc.
Every anchor must match exactly once. Line endings are kept as each source has them.
usage: python apply_presenter.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
base = here.parent / 'framegen-stutter-20261010'


class Source:
    def __init__(self, name):
        self.name = name
        raw = (base / name).read_bytes()
        self.crlf = raw.count(b'\r\n') * 2 > raw.count(b'\n')
        self.text = raw.decode('utf-8').replace('\r\n', '\n')

    def swap(self, old, new):
        assert self.text.count(old) == 1, (self.name, old[:70], self.text.count(old))
        self.text = self.text.replace(old, new)

    def write(self):
        text = self.text.replace('\n', '\r\n') if self.crlf else self.text
        target = here / self.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(text.encode('utf-8'))


# ---------------------------------------------------------------------------------------------
# pacing_adapter.hpp: the plan of a frame (pictures, refreshes each) and a 120 Hz guest clock.
a = Source('pacing_adapter.hpp')
a.swap('''  uint32_t width_ = 0, height_ = 0, already_ = 0, presents_ = 0;
  bool engaged_ = false;
''', '''  uint32_t width_ = 0, height_ = 0, already_ = 0, presents_ = 0;
  // Modes: the multiplier asked for (0: automatic; 2, 3, 4) and this frame's plan. With 2, the
  // plan is the one of the builds before modes: one picture held presents_ refreshes.
  uint32_t multiplier_ = 2, generated_ = 0, hold_ = 0, fit_ = 0, cadence_breaks_ = 0;
  bool engaged_ = false;
''')
a.swap('''    phase_ = 0; engaged_ = false; presents_ = already_ = 0;
''', '''    phase_ = 0; engaged_ = false; presents_ = already_ = 0;
    generated_ = hold_ = fit_ = 0;
''')
a.swap('''  void Gap(const Stamp& s) {
    ClearCadence();
    pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, s.hz,
                 display_, double(s.ns) * 1e-9, rate_, false);
    previous_ = s;
  }
''', '''  // The upstream pacer takes a source clock of 20 to 100 Hz and uses the two rates only as
  // their ratio. A 120 Hz guest clock (the launcher's video clock option) is given to it with
  // both rates halved: the same ratio, inside its range. 1 for the usual 60 Hz clock.
  static double PacerScale(double source_hz) { return source_hz > 100 ? 0.5 : 1.0; }
  void Gap(const Stamp& s) {
    ClearCadence();
    pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, s.hz * PacerScale(s.hz),
                 display_ * PacerScale(s.hz), double(s.ns) * 1e-9, rate_, false);
    previous_ = s;
  }
  void Plan(uint32_t fit, uint32_t left) {
    const Pictures plan = PlanPictures(multiplier_, presents_, fit, left);
    fit_ = fit;
    generated_ = plan.generated;
    hold_ = plan.hold;
  }
''')
a.swap('''    presents_ = 0;
    if (!permit || !enabled''', '''    presents_ = 0;
    generated_ = hold_ = 0;
    if (!permit || !enabled''')
a.swap(''' public:
  bool Observe(uint64_t, uint64_t serial, uint32_t w, uint32_t h, double display,
''', ''' public:
  // The pictures generated for a frame and the refreshes each is shown before the next
  // picture. `multiplier`: 0 automatic, or 2, 3, 4. `presents`: the refreshes the upstream
  // pacer gives one generated picture (0: none this frame). `fit`: the refreshes the frame's
  // interval is worth. `left`: those not spent by presents already made in it.
  struct Pictures { uint32_t generated, hold; };
  static Pictures PlanPictures(uint32_t multiplier, uint32_t presents, uint32_t fit,
                               uint32_t left) {
    // One picture held as the pacer says: all there is with 2, and the fallback of the others.
    const Pictures one{presents ? 1u : 0u, presents};
    if (!presents || multiplier == 2) return one;
    // Automatic: the most pictures (up to 3) that divide the interval into equal parts, so the
    // game's own frame and the generated ones are all shown for the same time.
    const uint32_t times = multiplier ? multiplier : fit % 4 == 0 ? 4 : fit % 3 == 0 ? 3 : 2;
    // The multiplier is a most: never more pictures than the interval has refreshes to spare.
    const uint32_t pictures = std::min(times - 1, left);
    if (pictures < 2) return one;
    uint32_t hold = fit % times == 0 ? fit / times : 1;
    if (pictures * hold > left) hold = 1;
    return {pictures, hold};
  }
  bool Observe(uint64_t, uint64_t serial, uint32_t w, uint32_t h, double display,
''')
a.swap('''    if (!Lookup(owner, serial, s) || !std::isfinite(s.hz) ||
        s.hz < 20 || s.hz > 100 || !s.ns) {
      Suspend(); return false;
    }
''', '''    if (!Lookup(owner, serial, s) || !std::isfinite(s.hz) ||
        s.hz < 20 || s.hz > 200 || !s.ns || display * PacerScale(s.hz) < 20) {
      Suspend(); return false;
    }
''')
a.swap('''      if (std::abs(error) > 1 || std::abs(phase_) > 1 || exact < 4) {
        cadence_ = 0; phase_ = 0; nominal = false;
      }
''', '''      if (std::abs(error) > 1 || std::abs(phase_) > 1 || exact < 4) {
        cadence_ = 0; phase_ = 0; nominal = false;
        if (engaged_ && cadence_breaks_ != std::numeric_limits<uint32_t>::max()) ++cadence_breaks_;
      }
''')
a.swap('''    const auto d = pacer_.frame(admission_ticks,
        left ? already_ : std::max(already_, admission_fit), s.hz, display,
        double(s.ns) * 1e-9, rate_, nominal);
    already_ = 0;
    engaged_ = d.engaged;
    presents_ = engaged_ ? std::min(d.presents, left) : 0;
    return engaged_ && presents_ != 0;
  }
''', '''    const auto d = pacer_.frame(admission_ticks,
        left ? already_ : std::max(already_, admission_fit), s.hz * PacerScale(s.hz),
        display * PacerScale(s.hz), double(s.ns) * 1e-9, rate_, nominal);
    already_ = 0;
    engaged_ = d.engaged;
    presents_ = engaged_ ? std::min(d.presents, left) : 0;
    Plan(fit, left);
    return engaged_ && presents_ != 0;
  }
  // 0: automatic; 2, 3 or 4 (anything else: 2). Kept across Reset(): it is a setting.
  void SetMultiplier(uint32_t multiplier) {
    multiplier_ = multiplier == 0 || multiplier == 3 || multiplier == 4 ? multiplier : 2;
  }
  uint32_t Multiplier() const { return multiplier_; }
  // This frame's plan, valid after an Observe() that returned true: the generated pictures
  // (1 to 3), the refreshes each is shown, and the refreshes the frame's interval is worth.
  uint32_t Generated() const { return generated_; }
  uint32_t HoldRefreshes() const { return hold_; }
  uint32_t IntervalRefreshes() const { return fit_; }
  // Times an acquired cadence was lost while generating, since the start (a diagnostic).
  uint32_t CadenceBreaks() const { return cadence_breaks_; }
''')
a.swap('''  double HoldNanoseconds() const { return display_ > 0 ? 1e9 * presents_ / display_ : 0; }
''', '''  // How long one generated picture is shown before the next picture is queued.
  double HoldNanoseconds() const { return display_ > 0 ? 1e9 * hold_ / display_ : 0; }
''')
a.swap('''      pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, source_rate_,
                   display_, double(previous_.ns) * 1e-9, rate_, false);
''', '''      pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, source_rate_ * PacerScale(source_rate_),
                   display_ * PacerScale(source_rate_), double(previous_.ns) * 1e-9, rate_, false);
''')
a.write()

# ---------------------------------------------------------------------------------------------
# presenter/presenter_sidecar.hpp: the settings file's two new lines, the pictures of a frame.
s = Source('presenter/presenter_sidecar.hpp')
s.swap('''#include "pacing_adapter.hpp"
''', '''#include "framegen_config.hpp"
#include "pacing_adapter.hpp"
''')
s.swap('''void LoadFramegenPrivateConfig() {
  // No launcher Settings field. Read once per process, before swapchain setup.
  static bool loaded = false;
  if (loaded) return;
  loaded = true;
''', '''// The settings file as read at the start: the switch, the multiplier and the output rate.
ps5x360::framegen::Config& FramegenConfig() {
  static ps5x360::framegen::Config config;
  return config;
}
// The refresh to ask of the display, in millihertz, given the surface's own request.
uint32_t FramegenRequestedRefresh(uint32_t surface_request) {
  return ps5x360::framegen::RequestedRefreshMillihertz(FramegenConfig(), surface_request);
}
void FramegenNoteDisplay(uint32_t requested, uint32_t surface_request, uint32_t selected) {
  static bool logged = false;
  if (logged || requested == surface_request) return;
  logged = true;
  // Accepted: selected_hz is 119.88. Otherwise the driver listed no such mode.
  XELOGW("Framegen output: asked for {} Hz, selected_hz={}{}", requested / 1000,
         double(selected) / 1000.0,
         selected >= 100000 ? " (120 Hz output accepted)"
                            : " (no 120 Hz mode offered: the title's param.json attribute3, the "
                              "console's 120 Hz setting or the display; staying at 60 Hz)");
}
void LoadFramegenPrivateConfig() {
  // No launcher Settings field. Read once per process, before swapchain setup.
  static bool loaded = false;
  if (loaded) return;
  loaded = true;
''')
s.swap('''  char line[96]{};
  bool read = std::fgets(line, sizeof(line), file) != nullptr;
  std::fclose(file);
  size_t length = std::strlen(line);
  while (length && (line[length-1] == '\\r' || line[length-1] == '\\n')) line[--length] = 0;
  bool valid = read && (std::strcmp(line,"ps5_frame_interpolation=true") == 0 ||
                       std::strcmp(line,"ps5_frame_interpolation=false") == 0);
  cvars::ps5_frame_interpolation = valid && std::strcmp(line,"ps5_frame_interpolation=true") == 0;
  XELOGW("Framegen private config: {} enabled={} valid={} (restart required)",
         path, bool(cvars::ps5_frame_interpolation), valid);
}
''', '''  char text[1024]{};
  const size_t length = std::fread(text, 1, sizeof(text) - 1, file);
  std::fclose(file);
  auto& config = FramegenConfig();
  config = ps5x360::framegen::ParseConfig(std::string(text, length));
  const bool valid = config.valid;
  // Line 1 decides alone whether the file counts, as before modes; a file it rejects gives
  // nothing else either.
  if (!valid) config = {};
  cvars::ps5_frame_interpolation = valid && config.enabled;
  XELOGW("Framegen private config: {} enabled={} valid={} (restart required)",
         path, bool(cvars::ps5_frame_interpolation), valid);
  if (config.has_multiplier || config.has_output || config.unknown_value)
    XELOGW("Framegen private config: multiplier={}{} output_hz={}{}{}",
           ps5x360::framegen::MultiplierText(config.multiplier),
           config.has_multiplier ? "" : " (default)",
           ps5x360::framegen::OutputText(config.output_hz), config.has_output ? "" : " (default)",
           config.unknown_value ? "; a line with an unknown value was ignored" : "");
}
''')
s.swap('''  uint64_t deferred_frames = 0;
  void ReportPresentationCost() {
    if (new_frames % 600 != 0) return;
''', '''  uint64_t deferred_frames = 0;
  // Modes: the generated pictures of the frame recorded last (0: none; 1 to 3), and what the
  // log last said about the multiplier in effect.
  uint32_t pictures = 0, plan_logged = 0, plan_logs = 0;
  // Diagnostics of the presentation queue, reported with the presentation cost: source frames
  // never painted while generating, generated presents that waited for a free swapchain image
  // (a full queue), and cadence losses.
  uint64_t skipped_sources = 0, slow_acquires = 0;
  uint32_t cadence_breaks_reported = 0;
  bool acquire_pending = false;
  // A new source serial: the ones between it and the last painted were never shown.
  void NoteSerial(uint64_t next) {
    if (history && pictures && serial && next > serial + 1) skipped_sources += next - serial - 1;
  }
  // The wait of the first acquire of a frame's generated pictures. Over 2 ms, no image was
  // free before a refresh: every image was queued or on screen.
  void NoteAcquire(std::chrono::steady_clock::duration wait) {
    if (!acquire_pending) return;
    acquire_pending = false;
    if (wait > std::chrono::milliseconds(2)) ++slow_acquires;
  }
  // The multiplier in effect, logged when it changes (a few times, not per frame). Nothing is
  // logged for the plain 2x of the builds before modes.
  void NotePlan() {
    const uint32_t times = pacing.Generated() + 1;
    if (pacing.Multiplier() == 2 || times == plan_logged || !pacing.Generated()) return;
    if (plan_logs < 24) {
      XELOGW("Framegen {}: {}x in effect ({} generated, each shown {} refresh(es); a game frame "
             "lasts {} refreshes at selected_hz={}){}",
             pacing.Multiplier() ? "multiplier" : "automatic", times, pacing.Generated(),
             pacing.HoldRefreshes(), pacing.IntervalRefreshes(), display_hz,
             ++plan_logs == 24 ? "; further changes are not logged" : "");
    }
    plan_logged = times;
  }
  void ReportPresentationCost() {
    if (new_frames % 600 != 0) return;
    const uint32_t breaks = pacing.CadenceBreaks();
    if (skipped_sources || slow_acquires || breaks != cadence_breaks_reported)
      XELOGW("Framegen queue: skipped_source={} slow_acquire={} cadence_breaks={} in the last 600 "
             "source frames", skipped_sources, slow_acquires, breaks - cadence_breaks_reported);
    cadence_breaks_reported = breaks;
    skipped_sources = slow_acquires = 0;
''')
s.swap('''    XELOGW("Framegen enabled (Sword FSR3 optical flow): selected_hz={}, FIFO required", display_hz);
  }
''', '''    XELOGW("Framegen enabled (Sword FSR3 optical flow): selected_hz={}, FIFO required", display_hz);
    const auto& config = FramegenConfig();
    const char* const in_effect = config.multiplier == 0 ? "2x to 4x by the game's cadence"
        : config.multiplier == 3 ? "up to 3x" : config.multiplier == 4 ? "up to 4x" : "2x";
    XELOGW("Framegen mode: {}, multiplier {}, output asked {} Hz, selected_hz={}",
           config.multiplier == 0 ? "automatic" : config.multiplier == 3 ? "3x"
               : config.multiplier == 4 ? "4x" : "2x",
           in_effect, FramegenRequestedRefresh(60000) / 1000, display_hz);
  }
''')
s.swap('''    interpolation_history = initialized = history = false; serial = 0; current = 0;
''', '''    interpolation_history = initialized = history = false; serial = 0; current = 0;
    pictures = 0; acquire_pending = false;
''')
s.swap('''    XELOGW("Framegen: Sword FSR3 ready for {}x{} (6436210, x2)",size.width,size.height);
''', '''    XELOGW("Framegen: Sword FSR3 ready for {}x{} (6436210, {})",size.width,size.height,
           ps5x360::framegen::ModeText(pacing.Multiplier()));
''')
s.swap('''    if (pacing.Engaged()) {
      made = interpolation.record(command, !interpolation_history);
      interpolation_history = true;
    } else { interpolation_history = false; }
    const bool generated = generate && history && made;
''', '''    if (pacing.Engaged()) {
      // Modes: the pictures planned for this frame, set before the first is recorded (it is
      // made a 1 / (pictures + 1) of the way). One, at the middle, unless 3x or 4x applies.
      interpolation.set_generated(generate ? std::clamp<uint32_t>(pacing.Generated(), 1, 3) : 1);
      made = interpolation.record(command, !interpolation_history);
      interpolation_history = true;
    } else { interpolation_history = false; }
    const bool generated = generate && history && made;
    pictures = generated ? interpolation.generated() : 0;
    acquire_pending = generated;
''')
s.swap('''    return generated;
  }
};
''', '''    return generated;
  }
  // 3x and 4x: the next picture between the same two frames (1 to pictures - 1), into the
  // interpolator's one output image. The paint that samples the picture before it is already
  // queued ahead of this on the same queue, and the barrier orders the write after it.
  bool RecordNext(VkCommandBuffer command, uint32_t picture) {
    VkMemoryBarrier reuse{}; reuse.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    reuse.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
    reuse.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
    device->functions().vkCmdPipelineBarrier(command,VK_PIPELINE_STAGE_ALL_COMMANDS_BIT,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,0,1,&reuse,0,nullptr,0,nullptr);
    return interpolation.interpolate_next(command, picture);
  }
};
''')
s.write()

# ---------------------------------------------------------------------------------------------
# presenter/vulkan_presenter.cc: the display request and the pictures' loop.
p = Source('presenter/vulkan_presenter.cc')
p.swap('''        VkExtent2D selected_extent{};
        uint32_t selected_refresh = 0;
        std::string error;
        if (!xbox360ps5::CreateDisplaySurface(
                ifn.vkGetInstanceProcAddr, instance,
                vulkan_device_->physical_device(), new_surface_width,
                new_surface_height, display_surface.refresh(),
                paint_context_.vulkan_surface, selected_extent,
                selected_refresh, error)) {
          XELOGE("PS5 KHR_display: {}", error);
          return SurfacePaintConnectResult::kFailure;
        }
        if (cvars::ps5_frame_interpolation) {
          paint_context_.completion_timeline.AwaitAllSubmissions();
          auto& sidecar = GetFramegenSidecar(this);
          sidecar.DestroyImages();
          sidecar.failed = false;
          sidecar.display_hz = double(selected_refresh) / 1000.0;
          sidecar.LogEnabled();
        }
''', '''        VkExtent2D selected_extent{};
        uint32_t selected_refresh = 0;
        std::string error;
        // Modes: the settings file may ask for the 120 Hz output. The mode nearest to the
        // request among those the driver lists is taken, so 59.94 Hz remains the fallback.
        const uint32_t requested_refresh =
            FramegenRequestedRefresh(display_surface.refresh());
        if (!xbox360ps5::CreateDisplaySurface(
                ifn.vkGetInstanceProcAddr, instance,
                vulkan_device_->physical_device(), new_surface_width,
                new_surface_height, requested_refresh,
                paint_context_.vulkan_surface, selected_extent,
                selected_refresh, error)) {
          XELOGE("PS5 KHR_display: {}", error);
          return SurfacePaintConnectResult::kFailure;
        }
        FramegenNoteDisplay(requested_refresh, display_surface.refresh(),
                            selected_refresh);
        if (cvars::ps5_frame_interpolation) {
          paint_context_.completion_timeline.AwaitAllSubmissions();
          auto& sidecar = GetFramegenSidecar(this);
          sidecar.DestroyImages();
          sidecar.failed = false;
          sidecar.display_hz = double(selected_refresh) / 1000.0;
          sidecar.pacing.SetMultiplier(FramegenConfig().multiplier);
          sidecar.LogEnabled();
        }
''')
p.swap('''    if (pinned && serial != fg->serial) {
      ++fg->new_frames;
''', '''    if (pinned && serial != fg->serial) {
      fg->NoteSerial(serial);
      ++fg->new_frames;
''')
p.swap('''          generate = fg->history && admitted;
          if (generate) {
            ++fg->admitted;
''', '''          generate = fg->history && admitted;
          if (generate) {
            ++fg->admitted;
            fg->NotePlan();
''')
p.swap('''  uint32_t swapchain_image_index;
  VkResult acquire_result = dfn.vkAcquireNextImageKHR(
      device, paint_context_.swapchain, UINT64_MAX, acquire_semaphore,
      VK_NULL_HANDLE, &swapchain_image_index);
''', '''  uint32_t swapchain_image_index;
  const auto acquire_start = std::chrono::steady_clock::now();
  VkResult acquire_result = dfn.vkAcquireNextImageKHR(
      device, paint_context_.swapchain, UINT64_MAX, acquire_semaphore,
      VK_NULL_HANDLE, &swapchain_image_index);
  // A diagnostic only: whether the first generated picture found a free image at once.
  if (fg && midpoint) fg->NoteAcquire(std::chrono::steady_clock::now() - acquire_start);
''')
p.swap('''    const double hold = fg->pacing.HoldNanoseconds();
    const auto deadline = midpoint_start + std::chrono::nanoseconds(
        int64_t(hold > 0 ? hold : 1000000000.0 / fg->display_hz));
    if (midpoint) std::this_thread::sleep_until(deadline);
    midpoint = false;
''', '''    const double hold = fg->pacing.HoldNanoseconds();
    const auto step = std::chrono::nanoseconds(
        int64_t(hold > 0 ? hold : 1000000000.0 / fg->display_hz));
    auto deadline = midpoint_start + step;
    if (midpoint) std::this_thread::sleep_until(deadline);
    // Modes (3x, 4x): the further pictures between the same two frames. Each is made into
    // the interpolator's one output image after the paint of the one before it is queued,
    // and queued one hold after it. With one picture a frame this loop does nothing.
    for (uint32_t picture = 1; midpoint && picture < fg->pictures; ++picture) {
      if (!framegen_next_picture(picture)) {
        fg->Fallback(256, "a further generated picture could not be recorded; the frame's "
                          "remaining pictures are left out");
        break;
      }
      result = paint_one();
      ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, true);
      if (!succeeded(result)) {
        fg->failed = true;
        ++fg->failures;
        fg->Fallback(16, "record/submit/present failed");
        return result;
      }
      ++fg->midpoint_present_ok;
      if (execute_ui_drawers) ++fg->ui_skips;
      deadline += step;
      std::this_thread::sleep_until(deadline);
    }
    midpoint = false;
''')
p.swap('''  auto succeeded = [](PaintResult r) {
    return r == PaintResult::kPresented || r == PaintResult::kPresentedSuboptimal;
  };
''', '''  auto succeeded = [](PaintResult r) {
    return r == PaintResult::kPresented || r == PaintResult::kPresentedSuboptimal;
  };
  // Modes (3x, 4x): records and submits the next generated picture of this frame, on the
  // queue the paints use, in a paint submission's command buffer as the snapshot does.
  auto framegen_next_picture = [&](uint32_t picture) -> bool {
    const auto& dfn = vulkan_device_->functions();
    const auto device = vulkan_device_->device();
    const uint64_t count = uint64_t(paint_context_.submissions.size());
    const uint64_t index = paint_context_.completion_timeline.GetUpcomingSubmission();
    // The submission that used this command buffer last has to be done with it.
    paint_context_.completion_timeline.AwaitMaxSubmissionsPendingAndUpdateCompleted(count);
    const auto& submission = *paint_context_.submissions[index % count];
    const auto command = submission.draw_command_buffer();
    VkCommandBufferBeginInfo begin{};
    begin.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO;
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if (dfn.vkResetCommandPool(device, submission.draw_command_pool(), 0) != VK_SUCCESS ||
        dfn.vkBeginCommandBuffer(command, &begin) != VK_SUCCESS) {
      return false;
    }
    const bool made = fg->RecordNext(command, picture);
    if (dfn.vkEndCommandBuffer(command) != VK_SUCCESS || !made) return false;
    VkSubmitInfo submit{};
    submit.sType = VK_STRUCTURE_TYPE_SUBMIT_INFO;
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &command;
    return paint_context_.completion_timeline.AcquireFenceAndSubmit(
               vulkan_device_->queue_family_graphics_compute(), 0, 1, &submit) == VK_SUCCESS;
  };
''')
p.write()
print('PASS presenter sources written')
