// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include "source_clock.hpp"
#include "vendor/ps5_framegen_pacing.h"
namespace ps5x360::framegen {
class Pacing {
  static constexpr uint32_t kModeIntervals = 2 * ps5::framegen::pacer::kWindow;
  ps5::framegen::pacer pacer_;
  Stamp previous_{};
  std::array<uint32_t, 8> intervals_{};
  std::array<double, 8> elapsed_{};
  uint32_t next_ = 0, count_ = 0, cadence_ = 0, native_ticks_ = 0;
  uint32_t dormant_ticks_ = 0, dormant_count_ = 0;
  int phase_ = 0;
  double reference_ns_per_tick_ = 0, rate_ = 100, display_ = 0;
  double source_rate_ = 0;
  const void* owner_ = nullptr;
  uint32_t width_ = 0, height_ = 0, already_ = 0, presents_ = 0;
  // Modes: the multiplier asked for (0: automatic; 2, 3, 4) and this frame's plan. With 2, the
  // plan is the one of the builds before modes: one picture held presents_ refreshes.
  uint32_t multiplier_ = 2, generated_ = 0, hold_ = 0, fit_ = 0, cadence_breaks_ = 0;
  bool engaged_ = false;
  std::chrono::steady_clock::time_point last_progress_{};

  void ClearCadence() {
    intervals_ = {}; elapsed_ = {}; next_ = count_ = cadence_ = 0;
    phase_ = 0; engaged_ = false; presents_ = already_ = 0;
    generated_ = hold_ = fit_ = 0;
    dormant_ticks_ = dormant_count_ = 0;
    last_progress_ = {};
    // Keep the producer reference, native cadence ceiling and upstream backoff.
    // A load/wait must not train a slower reference or forgive a costly pause.
  }
  // The upstream pacer takes a source clock of 20 to 100 Hz and uses the two rates only as
  // their ratio. A 120 Hz guest clock (the launcher's video clock option) is given to it with
  // both rates halved: the same ratio, inside its range. 1 for the usual 60 Hz clock.
  static double PacerScale(double source_hz) { return source_hz > 100 ? 0.5 : 1.0; }
  void Gap(const Stamp& s) {
    ClearCadence();
    pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, s.hz * PacerScale(s.hz),
                 display_ * PacerScale(s.hz), double(s.ns) * 1e-9, rate_, false);
    previous_ = s;
  }
  void Plan(uint32_t fit, uint32_t left) {
    const Pictures plan = PlanPictures(multiplier_, presents_, fit, left);
    fit_ = fit;
    generated_ = plan.generated;
    hold_ = plan.hold;
  }
 public:
  // The pictures generated for a frame and the refreshes each is shown before the next
  // picture. `multiplier`: 0 automatic, or 2, 3, 4. `presents`: the refreshes the upstream
  // pacer gives one generated picture (0: none this frame). `fit`: the refreshes the frame's
  // interval is worth. `left`: those not spent by presents already made in it.
  struct Pictures { uint32_t generated, hold; };
  static Pictures PlanPictures(uint32_t multiplier, uint32_t presents, uint32_t fit,
                               uint32_t left) {
    // One picture held as the pacer says: all there is with 2, and the fallback of the others.
    const Pictures one{presents ? 1u : 0u, presents};
    if (!presents || multiplier == 2) return one;
    // Automatic: the most pictures (up to 3) that divide the interval into equal parts, so the
    // game's own frame and the generated ones are all shown for the same time.
    const uint32_t times = multiplier ? multiplier : fit % 4 == 0 ? 4 : fit % 3 == 0 ? 3 : 2;
    // The multiplier is a most: never more pictures than the interval has refreshes to spare.
    const uint32_t pictures = std::min(times - 1, left);
    if (pictures < 2) return one;
    uint32_t hold = fit % times == 0 ? fit / times : 1;
    if (pictures * hold > left) hold = 1;
    return {pictures, hold};
  }
  bool Observe(uint64_t, uint64_t serial, uint32_t w, uint32_t h, double display,
               bool permit, bool enabled, const void* owner) {
    Stamp s;
    presents_ = 0;
    generated_ = hold_ = 0;
    if (!permit || !enabled || !w || !h || !std::isfinite(display) ||
        display < 30 || display > 250) {
      Reset(); return false;
    }
    // Missing telemetry is a suspension, not proof that generation became cheap.
    // Discard the timing anchor so the next stamp cannot bridge unknown frames.
    if (!Lookup(owner, serial, s) || !std::isfinite(s.hz) ||
        s.hz < 20 || s.hz > 200 || !s.ns || display * PacerScale(s.hz) < 20) {
      Suspend(); return false;
    }
    if (w != width_ || h != height_ || display != display_ ||
        s.hz != source_rate_ || s.owner != owner_) {
      Reset(); width_ = w; height_ = h; display_ = display;
      source_rate_ = s.hz; owner_ = s.owner;
    }
    if (!previous_.ns) { previous_ = s; return false; }
    // Reobserving the same tick/time (even another serial) neither warms nor
    // spends ticks. Clock equality alone is not a clock rollback.
    if (s.ns == previous_.ns && s.ticks == previous_.ticks) return false;
    if (s.ns <= previous_.ns || s.ticks < previous_.ticks) {
      Gap(s); return false;
    }
    const uint64_t ticks = s.ticks - previous_.ticks;
    const double dt = double(s.ns - previous_.ns);
    if (ticks > ps5::framegen::pacer::kGapTicks ||
        dt > 1e9 * ps5::framegen::pacer::kGapTicks / s.hz) {
      Gap(s); return false;
    }
    // A new mailbox submission can land within the same source tick. Do not
    // insert a fictitious tick, move the timing anchor, or discard presents.
    if (!ticks) return false;
    previous_ = s;
    last_progress_ = std::chrono::steady_clock::now();
    intervals_[next_] = uint32_t(ticks); elapsed_[next_] = dt;
    next_ = (next_ + 1) % intervals_.size();
    count_ = std::min<uint32_t>(count_ + 1, intervals_.size());
    uint32_t usual = 0, same = 0;
    double total_ticks = 0, total_ns = 0;
    for (uint32_t i = 0; i < count_; ++i) {
      total_ticks += intervals_[i]; total_ns += elapsed_[i];
      uint32_t n = 0;
      for (uint32_t j = 0; j < count_; ++j) n += intervals_[j] == intervals_[i];
      if (n > same) { same = n; usual = intervals_[i]; }
    }
    // This is relative producer throughput, NOT CPU/emulation speed telemetry.
    // Aggregate ns/tick removes short/long scheduling pairs. Freeze the first
    // full-window reference (capped at the declared source tick rate) even
    // while waiting or in the safety pause; otherwise
    // generated-frame cost could gradually become the new "100 percent".
    if (count_ == intervals_.size() && !reference_ns_per_tick_)
      reference_ns_per_tick_ = std::min(total_ns / total_ticks, 1e9 / s.hz);
    rate_ = reference_ns_per_tick_ ?
        std::min(100.0, 100.0 * reference_ns_per_tick_ * total_ticks / total_ns) : 100;

    // A slower *game-frame* mode needs two windows (16) of real intervals while
    // generation is dormant and the producer clock meets the frozen reference.
    // Active generation, safety pauses, zero ticks, gaps and missing stamps
    // cannot train this transition. A generated-frame wait must first disappear
    // for two complete new windows, rather than promoting its own slower cadence.
    if (!engaged_ && !pacer_.paused() && native_ticks_ &&
        ticks > native_ticks_ && rate_ >= ps5::framegen::pacer::kFullSpeed) {
      if (dormant_ticks_ != ticks) { dormant_ticks_ = uint32_t(ticks); dormant_count_ = 0; }
      dormant_count_ = std::min(dormant_count_ + 1, kModeIntervals);
    } else dormant_ticks_ = dormant_count_ = 0;

    bool nominal = true;
    if (cadence_) {
      uint32_t exact = 0;
      for (uint32_t i = 0; i < count_; ++i) exact += intervals_[i] == cadence_;
      const int error = int(ticks) - int(cadence_);
      phase_ += error;
      // Only sustain sparse, compensated one-tick jitter around an acquired
      // cadence. Four exact intervals and bounded phase reject dense 1/3,
      // alternating 1/2, drifting 2/3 and larger excursions.
      if (std::abs(error) > 1 || std::abs(phase_) > 1 || exact < 4) {
        cadence_ = 0; phase_ = 0; nominal = false;
        if (engaged_ && cadence_breaks_ != std::numeric_limits<uint32_t>::max()) ++cadence_breaks_;
      }
    } else if (count_ == intervals_.size() && same >= 7) {
      // Normal acquisition stays strict (7/8). Promotion to a slower mode
      // requires a full unmixed window and the dormant evidence above.
      if (!native_ticks_) native_ticks_ = usual;
      if (usual > native_ticks_ && same == intervals_.size() &&
          dormant_ticks_ == usual && dormant_count_ == kModeIntervals)
        native_ticks_ = usual;
      if (usual <= native_ticks_) { cadence_ = usual; phase_ = 0; }
      else nominal = false;
    } else nominal = false;

    // The upstream pacer handles warmup, refresh hysteresis and the unchanged
    // 3s / 10..160s safety backoff. Its cadence input is a classification only;
    // source stamps/ticks are never rewritten. ALL spending uses the current
    // raw interval, including short jitter intervals, with no borrowed credit.
    const uint32_t admission_ticks = cadence_ ? cadence_ : uint32_t(ticks);
    const uint32_t fit = uint32_t(ticks * display / s.hz + 0.03);
    const uint32_t left = fit > already_ ? fit - already_ : 0;
    const uint32_t admission_fit = uint32_t(admission_ticks * display / s.hz + 0.03);
    const auto d = pacer_.frame(admission_ticks,
        left ? already_ : std::max(already_, admission_fit), s.hz * PacerScale(s.hz),
        display * PacerScale(s.hz), double(s.ns) * 1e-9, rate_, nominal);
    already_ = 0;
    engaged_ = d.engaged;
    presents_ = engaged_ ? std::min(d.presents, left) : 0;
    Plan(fit, left);
    return engaged_ && presents_ != 0;
  }
  // 0: automatic; 2, 3 or 4 (anything else: 2). Kept across Reset(): it is a setting.
  void SetMultiplier(uint32_t multiplier) {
    multiplier_ = multiplier == 0 || multiplier == 3 || multiplier == 4 ? multiplier : 2;
  }
  uint32_t Multiplier() const { return multiplier_; }
  // This frame's plan, valid after an Observe() that returned true: the generated pictures
  // (1 to 3), the refreshes each is shown, and the refreshes the frame's interval is worth.
  uint32_t Generated() const { return generated_; }
  uint32_t HoldRefreshes() const { return hold_; }
  uint32_t IntervalRefreshes() const { return fit_; }
  // Times an acquired cadence was lost while generating, since the start (a diagnostic).
  uint32_t CadenceBreaks() const { return cadence_breaks_; }
  void Presented(bool success) {
    if (success && already_ != std::numeric_limits<uint32_t>::max()) ++already_;
  }
  bool Engaged() {
    const uint64_t tick = source_ticks.load(std::memory_order_relaxed);
    // Wall time is a liveness timeout only, never admission or refresh credit.
    // It also releases UI paints if BOTH producer frames and source ticks stop.
    const bool stale = engaged_ &&
        std::chrono::duration<double>(std::chrono::steady_clock::now() -
                                      last_progress_).count() >
            ps5::framegen::pacer::kGapTicks / previous_.hz;
    if (engaged_ && (stale || tick < previous_.ticks ||
        tick - previous_.ticks > ps5::framegen::pacer::kGapTicks)) {
      // Invalidate history without erasing an ongoing safety pause.
      Stamp s = previous_; s.ticks = tick;
      Gap(s);
    }
    return engaged_;
  }
  // How long one generated picture is shown before the next picture is queued.
  double HoldNanoseconds() const { return display_ > 0 ? 1e9 * hold_ / display_ : 0; }
  // Optional diagnostics: relative producer throughput and upstream safety
  // state, never a claim of measured CPU speed. Existing methods are unchanged.
  double ProducerRatePercent() const { return rate_; }
  bool ProducerReferenceReady() const { return reference_ns_per_tick_ > 0; }
  bool SafetyPaused() const { return pacer_.paused(); }
  double NextSafetyPauseSeconds() const { return pacer_.next_pause(); }
  double SafetyProducerRatePercent() const { return pacer_.slow_speed(); }
  double SafetyRecoveryRatePercent() const { return pacer_.no_fg_speed(); }
  // For an inactive mailbox / lost telemetry: invalidate admission and history
  // anchors while preserving producer reference and all upstream safety state.
  // Configuration is separate from previous_, so resuming the same owner/extent
  // does not accidentally Reset() when its first new stamp seeds the anchor.
  void Suspend() {
    if (previous_.ns)
      pacer_.frame(ps5::framegen::pacer::kGapTicks + 1, 0, source_rate_ * PacerScale(source_rate_),
                   display_ * PacerScale(source_rate_), double(previous_.ns) * 1e-9, rate_, false);
    ClearCadence(); previous_ = {};
  }
  void InvalidateCadence() { Suspend(); }
  void Reset() {
    pacer_ = {}; previous_ = {}; ClearCadence(); native_ticks_ = 0;
    reference_ns_per_tick_ = display_ = 0; rate_ = 100; width_ = height_ = 0;
    source_rate_ = 0; owner_ = nullptr;
  }
};
}
