"""Frame generation modes in the launcher: Off, Automatic, 2x, 3x, 4x, and the output rate.

Reads build/title-updates-20261010/launcher.cpp (the source whose object is in the
0.5.9-updates.1 candidate, byte for byte: build.py checks it) and writes launcher.cpp next to
this script. Every anchor must match exactly once. The Launcher class and the Settings are not
touched: the state stays in file-scope statics, as the frame generation switch already was.
usage: python apply_modes.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
source = here.parent / 'title-updates-20261010/launcher.cpp'
text = source.read_text(encoding='utf-8')


def swap(old, new):
    global text
    assert text.count(old) == 1, (old[:70], text.count(old))
    text = text.replace(old, new)


# The settings file's format, shared with the presenter and the host test.
swap('#include "update_manager.hpp"\n', '#include "update_manager.hpp"\n#include "framegen_config.hpp"\n')

# The switch becomes a mode, and the file gets its two other lines.
swap('''bool& FramegenChoice() {
  static bool requested = [] {
  std::ifstream input("/app0/framegen.conf");
  std::string line;
  if (!std::getline(input, line)) return false;
  if (!line.empty() && line.back() == '\\r') line.pop_back();
  return line == "ps5_frame_interpolation=true";
  }();
  return requested;
}
bool FramegenRequested() { return FramegenChoice(); }
// What the presenter of this process read: a different choice restarts on close.
bool FramegenAtStart() {
  static const bool at_start = FramegenChoice();
  return at_start;
}
// The Performance page shows this sentinel row after the table's own options.
constexpr int kFramegenRow = -1;
constexpr int kFsiRow = -2;
bool SetFramegenRequested(bool enabled) {
  FramegenAtStart();
  const char* temporary = "/app0/framegen.conf.new";
  std::ofstream output(temporary, std::ios::trunc);
  output << "ps5_frame_interpolation=" << (enabled ? "true" : "false") << "\\n";
  output.close();
  if (!output) { std::remove(temporary); return false; }
  if (std::rename(temporary, "/app0/framegen.conf") != 0) {
    std::remove(temporary); return false;
  }
  XELOGW("Frame generation requested={} (restart required)", enabled);
  FramegenChoice() = enabled;
  return true;
}
''', '''// Frame generation as the menu shows it, read from /app0/framegen.conf (framegen_config.hpp
// has the file's three lines). Kept here, not in the class or the Settings.
struct FramegenChoiceState {
  int mode = 0;        // 0 off, 1 automatic, 2 2x, 3 3x, 4 4x
  int last_on = 2;     // the multiplier written while off: the mode it had when last on
  std::string output;  // the output rate line's value as the file has it ("": no such line)
};
FramegenChoiceState& FramegenChoice() {
  static FramegenChoiceState choice = [] {
    FramegenChoiceState state;
    std::ifstream input("/app0/framegen.conf", std::ios::binary);
    std::string file((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    if (file.size() > 1023) file.resize(1023);  // as much as the presenter reads
    const ps5x360::framegen::Config config = ps5x360::framegen::ParseConfig(file);
    if (!config.valid) return state;  // a first line the presenter rejects: off, nothing kept
    state.last_on = config.multiplier == 0 ? 1 : int(config.multiplier);
    state.mode = config.enabled ? state.last_on : 0;
    state.output = config.output_text;
    return state;
  }();
  return choice;
}
int FramegenMode() { return FramegenChoice().mode; }
// The output asked for: the 120 Hz mode when the display and the installation have it.
bool FramegenHighOutput(const FramegenChoiceState& choice) {
  return choice.output == "auto" || choice.output == "120";
}
bool FramegenHighOutput() { return FramegenHighOutput(FramegenChoice()); }
// What the presenter of this process read: a different choice restarts on close.
const FramegenChoiceState& FramegenAtStart() {
  static const FramegenChoiceState at_start = FramegenChoice();
  return at_start;
}
bool FramegenChanged() {
  return FramegenMode() != FramegenAtStart().mode ||
         FramegenHighOutput() != FramegenHighOutput(FramegenAtStart());
}
const char* FramegenModeName(int mode) {
  return mode == 0 ? FramegenText("Desligada", "Off", "Desactivada")
       : mode == 1 ? FramegenText("Automática", "Automatic", "Automática")
       : mode == 3 ? "3x" : mode == 4 ? "4x" : "2x";
}
// The Performance page shows these sentinel rows after the table's own options.
constexpr int kFramegenRow = -1;
constexpr int kFsiRow = -2;
constexpr int kFramegenOutputRow = -3;
// Writes the three lines. Line 1 stays the switch the builds before modes read; the output
// rate line is written back as it was unless `output` is a new choice.
bool WriteFramegen(int mode, const std::string& output) {
  FramegenAtStart();
  auto& choice = FramegenChoice();
  const int multiplier = mode ? mode : choice.last_on;  // 1 automatic, 2 to 4
  const std::string file = ps5x360::framegen::FormatConfig(
      mode != 0, multiplier == 1 ? 0u : uint32_t(multiplier), output);
  const char* temporary = "/app0/framegen.conf.new";
  std::ofstream stream(temporary, std::ios::trunc | std::ios::binary);
  stream << file;
  stream.close();
  if (!stream) { std::remove(temporary); return false; }
  if (std::rename(temporary, "/app0/framegen.conf") != 0) {
    std::remove(temporary); return false;
  }
  XELOGW("Frame generation requested={} multiplier={} output_hz={} (restart required)", mode != 0,
         ps5x360::framegen::MultiplierText(multiplier == 1 ? 0u : uint32_t(multiplier)),
         output.empty() ? "60" : output);
  choice.mode = mode;
  if (mode) choice.last_on = mode;
  choice.output = output;
  return true;
}
bool SetFramegenMode(int mode) { return WriteFramegen(mode, FramegenChoice().output); }
bool SetFramegenHighOutput(bool high) { return WriteFramegen(FramegenMode(), high ? "120" : "60"); }
''')

swap('''  if (StartOptionsDiffer(settings_, started_) || FramegenRequested() != FramegenAtStart() ||
      FsiChoice() != FsiAtStart()) restart_ = true;
''', '''  if (StartOptionsDiffer(settings_, started_) || FramegenChanged() ||
      FsiChoice() != FsiAtStart()) restart_ = true;
''')

swap('''            if (category_ == 1) { category_rows_.push_back(kFramegenRow); category_rows_.push_back(kFsiRow); }
''', '''            if (category_ == 1) {
              category_rows_.push_back(kFramegenRow);
              category_rows_.push_back(kFramegenOutputRow);
              category_rows_.push_back(kFsiRow);
            }
''')

# Cross and right go to the next mode, left to the one before.
swap('''        } else if (category_rows_[size_t(option_row_)] == kFramegenRow) {
          if (!SetFramegenRequested(!FramegenRequested()))
            SetMessage(FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.",
                                    "No se pudo guardar la configuración."));
        } else {
''', '''        } else if (category_rows_[size_t(option_row_)] == kFramegenRow) {
          if (!SetFramegenMode((FramegenMode() + (key == Key::left ? 4 : 1)) % 5))
            SetMessage(FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.",
                                    "No se pudo guardar la configuración."));
        } else if (category_rows_[size_t(option_row_)] == kFramegenOutputRow) {
          if (!SetFramegenHighOutput(!FramegenHighOutput()))
            SetMessage(FramegenText("Não foi possível gravar a configuração.", "Could not save the setting.",
                                    "No se pudo guardar la configuración."));
        } else {
''')

swap('''      const bool on = FramegenRequested();
      c.Text(on ? FramegenText("Ligada", "On", "Activada") : FramegenText("Desligada", "Off", "Desactivada"),
             x + 796, y + 10, 22, focused ? kAccent : on ? kWarning : kMuted, 1.0f, 2, 320);
      continue;
    }
''', '''      const int mode = FramegenMode();
      c.Text(FramegenModeName(mode), x + 796, y + 10, 22, focused ? kAccent : mode ? kWarning : kMuted, 1.0f, 2, 320);
      continue;
    }
    if (category_rows_[size_t(n)] == kFramegenOutputRow) {
      c.Fill(x + 40, y, 780, 44, focused ? kSurfaceHigh : kSurface, focused ? 1.0f : 0.6f, 10);
      if (focused) c.Edge(x + 40, y, 780, 44, kAccent, 0.9f, 10, 2.0f);
      c.Text(FramegenText("Saída de vídeo da geração (teste)", "Frame generation output (test)",
                          "Salida de vídeo de la generación (prueba)"),
             x + 64, y + 10, 22, focused ? kText : kBody, 1.0f, 0, 440);
      const bool high = FramegenHighOutput();
      c.Text(high ? FramegenText("Até 120 Hz", "Up to 120 Hz", "Hasta 120 Hz") : "60 Hz",
             x + 796, y + 10, 22, focused ? kAccent : high ? kWarning : kMuted, 1.0f, 2, 320);
      continue;
    }
''')

swap('''    c.Wrapped(FramegenText(
        "Cria um quadro intermediário entre dois quadros do jogo: um jogo estável a 30 FPS aparece a 60 numa tela de 60 Hz. Não acelera o jogo, acrescenta cerca de um quadro de atraso e pode borrar o HUD e movimentos rápidos. O contador de FPS mostra Game, Output e FG.",
        "Creates an in-between frame from two game frames: a steady 30 FPS game is shown at 60 on a 60 Hz display. It does not speed up the game, adds about one frame of latency and can blur the HUD and fast motion. The FPS counter shows Game, Output and FG.",
        "Crea un fotograma intermedio entre dos fotogramas del juego: un juego estable a 30 FPS se muestra a 60 en una pantalla de 60 Hz. No acelera el juego, añade cerca de un fotograma de latencia y puede difuminar el HUD y los movimientos rápidos. El contador de FPS muestra Game, Output y FG."),
        x + 56, 632, 20, kBody, 750);
    c.Text(std::string(Tr("Recomendado: ")) + FramegenText("Desligada", "Off", "Desactivada"), x + 56, 860, 20, kAccent, 1.0f, 0, 750);
    c.Text(Tr("O emulador reinicia para aplicar, ao fechar as configurações."), x + 56, 892, 20, kMuted, 1.0f, 0, 750);
    float hint = c.Hint('x', Tr("Alterar"), x + 56, 1004);
    hint = c.Hint('o', Tr("Voltar"), hint, 1004);
    c.Hint('v', Tr("Mover"), hint, 1004);
    return;
  }
''', '''    c.Wrapped(FramegenText(
        "Cria quadros intermediários entre dois quadros do jogo. 2x: um quadro (30 FPS aparece a 60). 3x e 4x: dois ou três quadros, para telas de 120 Hz (30 FPS aparece a 120 em 4x); cada quadro a mais acrescenta atraso. Automática escolhe pelo ritmo do jogo e pela tela. Não acelera o jogo e pode borrar o HUD e movimentos rápidos. O contador de FPS mostra Game, Output e FG.",
        "Creates in-between frames from two game frames. 2x: one frame (30 FPS is shown at 60). 3x and 4x: two or three frames, for 120 Hz displays (30 FPS is shown at 120 with 4x); each extra frame adds latency. Automatic picks from the game's pace and the display. It does not speed up the game and can blur the HUD and fast motion. The FPS counter shows Game, Output and FG.",
        "Crea fotogramas intermedios entre dos fotogramas del juego. 2x: un fotograma (30 FPS se muestra a 60). 3x y 4x: dos o tres fotogramas, para pantallas de 120 Hz (30 FPS se muestra a 120 con 4x); cada fotograma extra añade latencia. Automática elige según el ritmo del juego y la pantalla. No acelera el juego y puede difuminar el HUD y los movimientos rápidos. El contador de FPS muestra Game, Output y FG."),
        x + 56, 632, 20, kBody, 750);
    c.Text(std::string(Tr("Recomendado: ")) + FramegenText("Desligada", "Off", "Desactivada"), x + 56, 860, 20, kAccent, 1.0f, 0, 750);
    c.Text(Tr("O emulador reinicia para aplicar, ao fechar as configurações."), x + 56, 892, 20, kMuted, 1.0f, 0, 750);
    float hint = c.Hint('x', Tr("Alterar"), x + 56, 1004);
    hint = c.Hint('o', Tr("Voltar"), hint, 1004);
    c.Hint('v', Tr("Mover"), hint, 1004);
    return;
  }
  if (category_rows_[size_t(option_row_)] == kFramegenOutputRow) {
    c.Fill(x + 40, 612, 780, 1, kWhite, 0.10f);
    c.Wrapped(FramegenText(
        "A taxa pedida ao vídeo do PS5. Até 120 Hz deixa 3x e 4x mostrarem um quadro por atualização numa tela de 120 Hz, e um jogo a 60 FPS aparecer a 120. Só funciona se esta instalação declarar 120 Hz (param.json) e a tela aceitar; senão a saída continua a 60 Hz sozinha.",
        "The rate asked of the PS5 video output. Up to 120 Hz lets 3x and 4x show one frame per refresh on a 120 Hz display, and a 60 FPS game be shown at 120. It only works if this installation declares 120 Hz (param.json) and the display accepts it; otherwise the output stays at 60 Hz by itself.",
        "La frecuencia pedida a la salida de vídeo de la PS5. Hasta 120 Hz permite que 3x y 4x muestren un fotograma por actualización en una pantalla de 120 Hz, y que un juego a 60 FPS se muestre a 120. Solo funciona si esta instalación declara 120 Hz (param.json) y la pantalla lo acepta; si no, la salida sigue a 60 Hz por sí sola."),
        x + 56, 632, 20, kBody, 750);
    c.Text(std::string(Tr("Recomendado: ")) + "60 Hz", x + 56, 860, 20, kAccent, 1.0f, 0, 750);
    c.Text(Tr("O emulador reinicia para aplicar, ao fechar as configurações."), x + 56, 892, 20, kMuted, 1.0f, 0, 750);
    float hint = c.Hint('x', Tr("Alterar"), x + 56, 1004);
    hint = c.Hint('o', Tr("Voltar"), hint, 1004);
    c.Hint('v', Tr("Mover"), hint, 1004);
    return;
  }
''')

(here / 'launcher.cpp').write_text(text, encoding='utf-8', newline='\n')
print('PASS launcher.cpp written')
