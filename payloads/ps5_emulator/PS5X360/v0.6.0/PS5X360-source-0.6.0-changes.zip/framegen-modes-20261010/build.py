"""Builds the frame generation modes candidate on the 0.5.9-updates.1 executable.

Two objects change: the presenter (modes, the output rate request, the pictures' loop) and the
launcher (the mode and output rate rows). Every other object is the one of
build/title-updates-20261010/native, checked by hash. The edited sources are written again from
the base's by apply_presenter.py and apply_modes.py before anything is compiled.
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/framegen-modes-20261010/build.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct  # used by the validation step taken from the framegen.3 recipe
import subprocess
import sys

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/title-updates-20261010/native'
stutter = root / 'build/framegen-stutter-20261010'
updates = root / 'build/title-updates-20261010'
out = here / 'native'
record = json.loads((base / 'build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base / 'eboot.bin') == record['native_sha256'] == '35962ce9e485f3151c233c26656f58e33848819744c8931769f9bad781c8261c'
VERSION = '0.5.9-updates.2-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')

# The edited sources, from the base's sources and this folder's scripts.
for script in ('apply_presenter.py', 'apply_modes.py'):
    subprocess.run([sys.executable, str(here / script)], check=True)
# Headers shared with objects that are not rebuilt stay the base's: the one copy this folder
# needs is identical, and the others are not here at all, so they are found in the base.
assert sha(here / 'shared/output_metrics.hpp') == sha(stutter / 'shared/output_metrics.hpp')
assert not (here / 'vendor').exists() and not (here / 'source_clock.hpp').exists()
assert sha(stutter / 'vendor/ps5_framegen.h') == sha(root / 'build/framegen-sword-20261010/vendor/ps5_framegen.h')
assert sha(stutter / 'source_clock.hpp') == sha(root / 'build/framegen-sword-20261010/source_clock.hpp')

(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    c = list(command)
    c[1:1] = extra
    c[c.index('-c') + 1] = str(source)
    c[c.index('-o') + 1] = str(obj)
    subprocess.run(c, cwd=root, check=True)
    return c


# The unchanged sources still give the base's objects, byte for byte.
for key, source, name in (('presenter', stutter / 'presenter/vulkan_presenter.cc', 'vulkan_presenter.cc.o'),
                          ('launcher', updates / 'launcher.cpp', 'launcher.cpp.o')):
    compile_with(record['commands'][key], source, here / (key + '.proof.o'))
    assert sha(here / (key + '.proof.o')) == sha(base / 'obj' / name), key + ' preimage drift'

presenter_build = compile_with(record['commands']['presenter'], here / 'presenter/vulkan_presenter.cc',
                               out / 'obj/vulkan_presenter.cc.o', ['-I' + str(here)])
launcher_cmd = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a
                for a in record['commands']['launcher']]
launcher_build = compile_with(launcher_cmd, here / 'launcher.cpp', out / 'obj/launcher.cpp.o',
                              ['-I' + str(updates)])
changed = {'vulkan_presenter.cc.o', 'launcher.cpp.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / name) == value for name, value in retained.items())
assert all(sha(out / 'obj' / name) != sha(base / 'obj' / name) for name in changed)
assert {p.name for p in (out / 'obj').glob('*.o')} == set(record['objects'])
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)

# Display version, image verification and signing: the reviewed step of the framegen.3 recipe.
s = (root / 'build/framegen-sword-20261010/build.py').read_text()
validation = s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation, 'framegen-sword build.py', 'exec'), globals())
image = (out / 'llvm-pie.elf').read_bytes()
for needle in (b'PPSA50011/updates', b'000B0000-off', b'Framegen: Sword FSR3 ready', b'shader-trace.conf',
               b'Framegen mode: ', b'Framegen output: asked for', b'ps5_frame_multiplier=', b'ps5_frame_output_hz=',
               b'ps5_frame_interpolation=true'):
    assert needle in image, needle
commands = dict(record['commands'])
commands.update(presenter=presenter_build, launcher=launcher_build)
(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'presenter_preimage_identical': True, 'launcher_preimage_identical': True, 'unchanged_objects': retained,
    'objects': {p.name: sha(p) for p in (out / 'obj').glob('*.o')}, 'commands': commands,
    'source_sha256': {str(p.relative_to(here)): sha(p) for p in sorted(here.rglob('*'))
                      if p.is_file() and p.suffix in ('.py', '.hpp', '.cc', '.cpp', '.inc', '.sh')
                      and 'preview' not in p.parts and 'native' not in p.parts},
    'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
