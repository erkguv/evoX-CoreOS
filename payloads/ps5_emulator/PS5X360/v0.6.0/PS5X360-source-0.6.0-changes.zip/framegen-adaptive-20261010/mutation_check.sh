#!/usr/bin/env bash
# Shows that the tests notice a wrong adapter or a wrong adaptive scheduler: each deliberate
# fault must make them fail.
# In xbox360ps5-canary:  bash /ws/Xbox360PS5/build/framegen-adaptive-20261010/mutation_check.sh
set -uo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
base=$(cd -- "$here/../framegen-stutter-20261010" && pwd)
work=$(mktemp -d)
cp "$here"/test_adapter.cpp "$here"/test_modes.inc "$here"/test_adaptive.inc "$here"/framegen_config.hpp \
   "$here"/pacing_adapter.hpp "$here"/adaptive_pacing.hpp "$work/"
sed -i "s#../framegen-stutter-20261010/pacing_adapter.hpp#$base/pacing_adapter.hpp#" "$work/test_adapter.cpp"
caught=0
fault() {  # file, name, sed expression
  cp "$here/$1" "$work/$1"
  sed -i "$3" "$work/$1"
  cmp -s "$here/$1" "$work/$1" && { echo "FAIL $2: the fault did not apply"; exit 1; }
  clang++-18 -std=gnu++20 -O2 -Wall -Wextra -Werror -I"$work" -I"$base" "$work/test_adapter.cpp" -o "$work/t" \
    || { echo "FAIL $2: the faulty source does not compile"; exit 1; }
  if "$work/t" > /dev/null 2> "$work/err"; then echo "FAIL $2: the tests passed with the fault"; exit 1; fi
  echo "caught $2: $(head -1 "$work/err" | sed 's#.*/##')"
  cp "$here/$1" "$work/$1"
  caught=$((caught + 1))
}
# The strict adapter (the modes' faults).
fault pacing_adapter.hpp 'a picture held one refresh too long' 's/const Pictures one{presents ? 1u : 0u, presents};/const Pictures one{presents ? 1u : 0u, presents + (fit == 4)};/'
fault pacing_adapter.hpp 'a 120 Hz guest clock given to the pacer as it is' 's/return source_hz > 100 ? 0.5 : 1.0;/return source_hz > 1000 ? 0.5 : 1.0;/'
fault pacing_adapter.hpp 'automatic never above 2x' 's/fit % 4 == 0 ? 4 : fit % 3 == 0 ? 3 : 2;/2;/'
fault pacing_adapter.hpp 'more pictures than the interval has refreshes' 's/const uint32_t pictures = std::min(times - 1, left);/const uint32_t pictures = times - 1;/'
# The adaptive scheduler.
fault adaptive_pacing.hpp 'no backlog guard' 's/kBacklogRefreshes = 1.25;/kBacklogRefreshes = 1e9; /'
fault adaptive_pacing.hpp 'an output near the frame is not the frame' 's/kSnap = 0.125;/kSnap = 0.0;  /'
fault adaptive_pacing.hpp 'generation at the display rate' 's/if (rate > display_hz - kHeadroomFps + slack)/if (rate > 1e9 + display_hz - kHeadroomFps + slack)/'
fault adaptive_pacing.hpp 'always the middle picture' 's/        best = pictures;/        best = 1;/'
fault adaptive_pacing.hpp 'the content clock starts each span at the frame' 's/    content_ -= 1.0;/    content_ = 0.0;/'
fault adaptive_pacing.hpp 'pictures without a previous frame' 's/    if (!history) {/    if (!history \&\& display_hz < 0) {/'
fault adaptive_pacing.hpp 'adaptive while strict pacing is engaged' 's/if (!allowed) return Off(plan, AdaptiveReason::NotAllowed);/(void)allowed;/'
fault adaptive_pacing.hpp 'nothing shown between frames for ever' 's/kGapIntervals \* interval_ns_) return true;/kGapIntervals * interval_ns_ * 1e6) return true;/'
fault adaptive_pacing.hpp 'a pause is not a gap' 's/if (step > 2 || span > kGapNs || (interval_ns_ > 0 \&\& span > kGapIntervals \* interval_ns_)) {/if (step > 2) {/'
fault adaptive_pacing.hpp 'no margin under the display rate' 's/kMargin = 0.002;/kMargin = -0.02; /'
fault framegen_config.hpp 'pacing=strict ignored' 's/config.adaptive_pacing = value == "auto";/config.adaptive_pacing = true;/'
echo "PASS mutation check: $caught faults, $caught caught"
