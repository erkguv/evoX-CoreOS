"""The launcher source of this candidate: launcher.cpp next to this script.

It is build/updates-integration-20261010/launcher-updates.cpp (the Updates tab and its log
line), then the modes folder's apply_modes.py run on it unchanged (the frame generation mode and
output rate rows), then two changes of this folder, every anchor matching exactly once:
  - a ps5_frame_pacing line in the settings file is written back as it was (the launcher has no
    row for it);
  - the help text of the mode row says that Automatic also works at uneven frame rates.
The Launcher class and the Settings are not touched.
usage: python apply_launcher.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
modes = here.parent / 'framegen-modes-20261010'
source = here.parent / 'updates-integration-20261010/launcher-updates.cpp'
target = here / 'launcher.cpp'

# The modes script, unchanged but for where it reads and writes.
script = (modes / 'apply_modes.py').read_text(encoding='utf-8')
reads = "source = here.parent / 'title-updates-20261010/launcher.cpp'\n"
writes = "(here / 'launcher.cpp').write_text(text, encoding='utf-8', newline='\\n')\n"
assert script.count(reads) == 1 and script.count(writes) == 1
script = script.replace(reads, 'source = LAUNCHER_SOURCE\n').replace(
    writes, "LAUNCHER_TARGET.write_text(text, encoding='utf-8', newline='\\n')\n")
exec(compile(script, str(modes / 'apply_modes.py'), 'exec'),
     {'__file__': str(modes / 'apply_modes.py'), '__name__': 'apply_modes',
      'LAUNCHER_SOURCE': source, 'LAUNCHER_TARGET': target})

text = target.read_text(encoding='utf-8')
assert 'LAUNCHER title update for' in text and 'framegen_config.hpp' in text


def swap(old, new):
    global text
    assert text.count(old) == 1, (old[:70], text.count(old))
    text = text.replace(old, new)


# The pacing line is kept as the file has it.
swap('''  std::string output;  // the output rate line's value as the file has it ("": no such line)
};
''', '''  std::string output;  // the output rate line's value as the file has it ("": no such line)
  std::string pacing;  // the pacing line's value, written back as it is ("": no such line)
};
''')
swap('''    state.output = config.output_text;
''', '''    state.output = config.output_text;
    state.pacing = config.pacing_text;
''')
swap('''      mode != 0, multiplier == 1 ? 0u : uint32_t(multiplier), output);
''', '''      mode != 0, multiplier == 1 ? 0u : uint32_t(multiplier), output, choice.pacing);
''')

# Automatic also paces games whose frame rate is uneven.
swap('''        "Cria quadros intermediários entre dois quadros do jogo. 2x: um quadro (30 FPS aparece a 60). 3x e 4x: dois ou três quadros, para telas de 120 Hz (30 FPS aparece a 120 em 4x); cada quadro a mais acrescenta atraso. Automática escolhe pelo ritmo do jogo e pela tela. Não acelera o jogo e pode borrar o HUD e movimentos rápidos. O contador de FPS mostra Game, Output e FG.",
        "Creates in-between frames from two game frames. 2x: one frame (30 FPS is shown at 60). 3x and 4x: two or three frames, for 120 Hz displays (30 FPS is shown at 120 with 4x); each extra frame adds latency. Automatic picks from the game's pace and the display. It does not speed up the game and can blur the HUD and fast motion. The FPS counter shows Game, Output and FG.",
        "Crea fotogramas intermedios entre dos fotogramas del juego. 2x: un fotograma (30 FPS se muestra a 60). 3x y 4x: dos o tres fotogramas, para pantallas de 120 Hz (30 FPS se muestra a 120 con 4x); cada fotograma extra añade latencia. Automática elige según el ritmo del juego y la pantalla. No acelera el juego y puede difuminar el HUD y los movimientos rápidos. El contador de FPS muestra Game, Output y FG."),
''', '''        "Cria quadros intermediários entre dois quadros do jogo. 2x: um quadro (30 FPS aparece a 60). 3x e 4x: dois ou três quadros, para telas de 120 Hz; cada quadro a mais acrescenta atraso. Automática escolhe pelo ritmo do jogo e pela tela, e também funciona quando a taxa do jogo varia (40 FPS, de 31 a 47). Não acelera o jogo e pode borrar o HUD e movimentos rápidos. O contador de FPS mostra Game, Output e FG.",
        "Creates in-between frames from two game frames. 2x: one frame (30 FPS is shown at 60). 3x and 4x: two or three frames, for 120 Hz displays; each extra frame adds latency. Automatic picks from the game's pace and the display, and also works when the game's rate is uneven (40 FPS, 31 to 47). It does not speed up the game and can blur the HUD and fast motion. The FPS counter shows Game, Output and FG.",
        "Crea fotogramas intermedios entre dos fotogramas del juego. 2x: un fotograma (30 FPS se muestra a 60). 3x y 4x: dos o tres fotogramas, para pantallas de 120 Hz; cada fotograma extra añade latencia. Automática elige según el ritmo del juego y la pantalla, y también funciona cuando la tasa del juego varía (40 FPS, de 31 a 47). No acelera el juego y puede difuminar el HUD y los movimientos rápidos. El contador de FPS muestra Game, Output y FG."),
''')

target.write_text(text, encoding='utf-8', newline='\n')
print('PASS launcher.cpp written (updates, modes, pacing line kept, help text)')
