"""Adaptive frame generation pacing: writes this folder's sources from the modes folder's.

Reads build/framegen-modes-20261010 (the accepted modes work, not edited) and writes, next to
this script: framegen_config.hpp, pacing_adapter.hpp, presenter/presenter_sidecar.hpp,
presenter/vulkan_presenter.cc, shared/output_metrics.hpp, test_adapter.cpp and test_modes.inc.
Every anchor must match exactly once. adaptive_pacing.hpp and test_adaptive.inc are new files
of this folder. Line endings are kept as each source has them.
usage: python apply_adaptive.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
base = here.parent / 'framegen-modes-20261010'


class Source:
    def __init__(self, name):
        self.name = name
        raw = (base / name).read_bytes()
        self.crlf = raw.count(b'\r\n') * 2 > raw.count(b'\n')
        self.text = raw.decode('utf-8').replace('\r\n', '\n')

    def swap(self, old, new):
        assert self.text.count(old) == 1, (self.name, old[:70], self.text.count(old))
        self.text = self.text.replace(old, new)

    def write(self):
        text = self.text.replace('\n', '\r\n') if self.crlf else self.text
        target = here / self.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(text.encode('utf-8'))


# Unchanged: the header shared with objects that are not rebuilt, and the modes' tests.
for name in ('shared/output_metrics.hpp', 'test_modes.inc'):
    Source(name).write()

# ---------------------------------------------------------------------------------------------
# framegen_config.hpp: the fourth line, ps5_frame_pacing=auto|strict.
c = Source('framegen_config.hpp')
c.swap('''//   ps5_frame_output_hz=60           optional: auto, 60 or 120. Missing or unknown: 60
''', '''//   ps5_frame_output_hz=60           optional: auto, 60 or 120. Missing or unknown: 60
//   ps5_frame_pacing=auto            optional: auto or strict. Missing or unknown: auto.
//                                    auto: in the Automatic mode, pictures are also generated
//                                    when the game's frames are not of one length (adaptive
//                                    pacing). strict: only the pacing of the builds before it.
''')
c.swap('''  std::string output_text;   // the output line's value as written: a writer that did not set it keeps it
''', '''  std::string output_text;   // the output line's value as written: a writer that did not set it keeps it
  bool adaptive_pacing = true;  // ps5_frame_pacing is not "strict"
  bool has_pacing = false;      // the line was there, with a known value
  std::string pacing_text;      // its value as written, kept by a writer the same way
''')
c.swap('''constexpr const char* kOutputKey = "ps5_frame_output_hz=";
''', '''constexpr const char* kOutputKey = "ps5_frame_output_hz=";
constexpr const char* kPacingKey = "ps5_frame_pacing=";
''')
c.swap('''        config.has_output = true;
      } else {
        config.unknown_value = true;
      }
    }
''', '''        config.has_output = true;
      } else {
        config.unknown_value = true;
      }
    } else if (line.rfind(kPacingKey, 0) == 0) {
      const std::string value = line.substr(std::strlen(kPacingKey));
      config.pacing_text = value;
      if (value == "auto" || value == "strict") {
        config.adaptive_pacing = value == "auto";
        config.has_pacing = true;
      } else {
        config.unknown_value = true;
      }
    }
''')
c.swap('''// What the launcher writes: always the three lines, line 1 first for the builds before modes.
// `output_text` is written as it is when not empty (a value the launcher did not set).
inline std::string FormatConfig(bool enabled, uint32_t multiplier, const std::string& output_text) {
''', '''// What the launcher writes: always the three lines, line 1 first for the builds before modes.
// `output_text` is written as it is when not empty (a value the launcher did not set). The
// pacing line is written only when the file had one (`pacing_text` not empty), as it was.
inline std::string FormatConfig(bool enabled, uint32_t multiplier, const std::string& output_text,
                                const std::string& pacing_text = std::string()) {
''')
c.swap('''  text += output_text.empty() ? "60" : output_text;
  text += "\\n";
  return text;
''', '''  text += output_text.empty() ? "60" : output_text;
  text += "\\n";
  if (!pacing_text.empty()) {
    text += kPacingKey;
    text += pacing_text;
    text += "\\n";
  }
  return text;
''')
c.swap('''}  // namespace ps5x360::framegen
''', '''
// Whether adaptive pacing may be used at all: frame generation on, the Automatic mode, and the
// pacing line not "strict". The fixed 2x, 3x and 4x modes are paced strictly, as before.
inline bool AdaptivePacingEnabled(const Config& config) {
  return config.valid && config.enabled && config.multiplier == 0 && config.adaptive_pacing;
}
}  // namespace ps5x360::framegen
''')
c.write()

# ---------------------------------------------------------------------------------------------
# pacing_adapter.hpp: nothing about its decisions changes. One accessor, for the log.
a = Source('pacing_adapter.hpp')
a.swap('''  bool SafetyPaused() const { return pacer_.paused(); }
''', '''  bool SafetyPaused() const { return pacer_.paused(); }
  // Where strict pacing is, in words for the log (the upstream pacer's state).
  const char* StrictStateText() const {
    switch (pacer_.state()) {
      case ps5::framegen::pacer_state::Warming: return "warming up";
      case ps5::framegen::pacer_state::NoRoom: return "no room, under two refreshes a frame";
      case ps5::framegen::pacer_state::Unsteady: return "frames of uneven length";
      case ps5::framegen::pacer_state::NotNominal: return "cadence lost";
      case ps5::framegen::pacer_state::Paused: return "safety pause";
      case ps5::framegen::pacer_state::Generating: return "generating";
    }
    return "unknown";
  }
''')
a.write()

# ---------------------------------------------------------------------------------------------
# presenter/presenter_sidecar.hpp: the adaptive scheduler's state, its logs and the summary.
s = Source('presenter/presenter_sidecar.hpp')
s.swap('''#include "framegen_config.hpp"
''', '''#include "adaptive_pacing.hpp"
#include "framegen_config.hpp"
''')
s.swap('''  if (config.has_multiplier || config.has_output || config.unknown_value)
    XELOGW("Framegen private config: multiplier={}{} output_hz={}{}{}",
           ps5x360::framegen::MultiplierText(config.multiplier),
           config.has_multiplier ? "" : " (default)",
           ps5x360::framegen::OutputText(config.output_hz), config.has_output ? "" : " (default)",
           config.unknown_value ? "; a line with an unknown value was ignored" : "");
''', '''  if (config.has_multiplier || config.has_output || config.has_pacing || config.unknown_value)
    XELOGW("Framegen private config: multiplier={}{} output_hz={}{} pacing={}{}{}",
           ps5x360::framegen::MultiplierText(config.multiplier),
           config.has_multiplier ? "" : " (default)",
           ps5x360::framegen::OutputText(config.output_hz), config.has_output ? "" : " (default)",
           config.adaptive_pacing ? "auto" : "strict", config.has_pacing ? "" : " (default)",
           config.unknown_value ? "; a line with an unknown value was ignored" : "");
''')
s.swap('''  bool acquire_pending = false;
''', '''  bool acquire_pending = false;
  // Adaptive pacing (adaptive_pacing.hpp): pictures for a game whose frames are not of one
  // length, used only while strict pacing is not engaged, in the Automatic mode.
  ps5x360::framegen::AdaptivePacing adaptive;
  ps5x360::framegen::AdaptivePlan plan;  // of the frame being presented
  bool adaptive_backlog = false;         // this span's first acquire found the queue full
  bool adaptive_announced = false;
  uint32_t adaptive_run = 0, adaptive_logs = 0;
  double adaptive_fps = 0;
  // The 600-frame summary: frames paced by each path, and the presents made for them.
  uint64_t strict_frames = 0, adaptive_frames = 0, outputs_reported = 0, backlogs_reported = 0;
  static constexpr uint32_t kAdaptiveAnnounce = 8;  // game frames in a row before "started" is logged
  static constexpr uint32_t kAdaptiveLogs = 48;     // start and stop lines per process
  static bool AdaptiveEnabled() { return ps5x360::framegen::AdaptivePacingEnabled(FramegenConfig()); }
  static uint64_t NowNanoseconds() {
    return uint64_t(std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count());
  }
  // The path stops pacing: said once in the log if its start was.
  void AdaptiveEnd(const char* why) {
    if (adaptive_announced && adaptive_logs < kAdaptiveLogs) {
      XELOGW("Framegen adaptive: stopped after {} game frames ({}; game at {:.1f} FPS){}",
             adaptive_run, why, adaptive_fps,
             ++adaptive_logs == kAdaptiveLogs ? "; further starts and stops are not logged" : "");
    }
    adaptive_announced = false;
    adaptive_run = 0;
  }
  void AdaptiveStop(const char* why) {
    if (adaptive.active() || adaptive_run) AdaptiveEnd(why);
    adaptive.Stop();
  }
  // A new frame of the game, after strict pacing has looked at it. True when this span is
  // paced by the adaptive path: `plan` then holds its outputs.
  bool AdaptiveArrive(const void* owner, uint64_t next_serial, uint64_t now_ns, bool strict) {
    plan = {};
    adaptive_backlog = false;
    if (!AdaptiveEnabled()) return false;
    ps5x360::framegen::Stamp stamp;
    if (!ps5x360::framegen::Lookup(owner, next_serial, stamp) || !stamp.ns) {
      AdaptiveStop("no time stamp for the game's frame");
      adaptive.Reset();
      return false;
    }
    const uint64_t step = serial && next_serial > serial ? next_serial - serial : 0;
    plan = adaptive.Arrive(stamp.ns, now_ns, step, display_hz, !strict && !pacing.SafetyPaused(),
                           history && interpolation_history);
    if (!plan.active) {
      using Reason = ps5x360::framegen::AdaptiveReason;
      if (adaptive_run) {
        AdaptiveEnd(plan.reason == Reason::NotAllowed ? (strict ? "strict pacing engaged" : "safety pause")
                    : plan.reason == Reason::Gap ? "a gap in the game's frames"
                    : plan.reason == Reason::TooSlow ? "game below 18 FPS"
                    : plan.reason == Reason::TooFast ? "game at the display's rate"
                    : "the game's rate is being measured");
      }
      return false;
    }
    ++adaptive_frames;
    adaptive_fps = adaptive.fps();
    if (++adaptive_run == kAdaptiveAnnounce && adaptive_logs < kAdaptiveLogs) {
      ++adaptive_logs;
      adaptive_announced = true;
      XELOGW("Framegen adaptive: started (game at {:.1f} FPS on selected_hz={}; strict pacing: {})",
             adaptive_fps, display_hz, pacing.StrictStateText());
    }
    return true;
  }
  // The plan cannot be carried out from output `from` on (no picture was made, or the queue is
  // full): the game's frame takes that place and ends the span.
  void AdaptiveCut(uint32_t from) {
    plan.outputs[from] = {int8_t(-1), 1};
    plan.count = from + 1;
    adaptive.ShownAlone(NowNanoseconds());
  }
  // Between two frames of the game nothing else is presented while the path paces.
  bool AdaptiveHolding() {
    if (!adaptive.active()) return false;
    if (adaptive.Holding(NowNanoseconds())) return true;
    AdaptiveEnd("no new frame from the game");
    return false;
  }
''')
s.swap('''    if (wait > std::chrono::milliseconds(2)) ++slow_acquires;
''', '''    if (wait > std::chrono::milliseconds(2)) {
      ++slow_acquires;
      adaptive_backlog = true;
    }
''')
s.swap('''    if (skipped_sources || slow_acquires || breaks != cadence_breaks_reported)
      XELOGW("Framegen queue: skipped_source={} slow_acquire={} cadence_breaks={} in the last 600 "
             "source frames", skipped_sources, slow_acquires, breaks - cadence_breaks_reported);
    cadence_breaks_reported = breaks;
    skipped_sources = slow_acquires = 0;
    XELOGW("Framegen presentation cost: source={} dormant={} deferred={} waits={} mean={}ms max={}ms",
           new_frames, dormant_frames, deferred_frames, snapshot_waits,
           snapshot_waits ? double(snapshot_wait_ns) / double(snapshot_waits) / 1e6 : 0.0,
           double(snapshot_wait_max_ns) / 1e6);
''', '''    const uint64_t backlogs = adaptive.backlogs();
    if (skipped_sources || slow_acquires || breaks != cadence_breaks_reported || backlogs != backlogs_reported)
      XELOGW("Framegen queue: skipped_source={} slow_acquire={} cadence_breaks={} adaptive_backlog={} "
             "in the last 600 source frames", skipped_sources, slow_acquires,
             breaks - cadence_breaks_reported, backlogs - backlogs_reported);
    cadence_breaks_reported = breaks;
    backlogs_reported = backlogs;
    skipped_sources = slow_acquires = 0;
    // strict and adaptive: frames paced by each path; dormant: frames shown without generation.
    const uint64_t outputs = midpoint_present_ok + ordinary_present_ok;
    XELOGW("Framegen presentation cost: source={} dormant={} deferred={} waits={} mean={}ms max={}ms "
           "strict={} adaptive={} outputs_per_source={:.2f}",
           new_frames, dormant_frames, deferred_frames, snapshot_waits,
           snapshot_waits ? double(snapshot_wait_ns) / double(snapshot_waits) / 1e6 : 0.0,
           double(snapshot_wait_max_ns) / 1e6, strict_frames, adaptive_frames,
           double(outputs - outputs_reported) / 600.0);
    outputs_reported = outputs;
    strict_frames = adaptive_frames = 0;
''')
s.swap('''    XELOGW("Framegen mode: {}, multiplier {}, output asked {} Hz, selected_hz={}",
           config.multiplier == 0 ? "automatic" : config.multiplier == 3 ? "3x"
               : config.multiplier == 4 ? "4x" : "2x",
           in_effect, FramegenRequestedRefresh(60000) / 1000, display_hz);
''', '''    XELOGW("Framegen mode: {}, multiplier {}, output asked {} Hz, selected_hz={}, pacing {}",
           config.multiplier == 0 ? "automatic" : config.multiplier == 3 ? "3x"
               : config.multiplier == 4 ? "4x" : "2x",
           in_effect, FramegenRequestedRefresh(60000) / 1000, display_hz,
           AdaptiveEnabled() ? "strict, adaptive when the game's frames are uneven" : "strict only");
''')
s.swap('''    source_keepalive.reset(); source_copy_submission = 0;
    if (reset_pacing) pacing.Reset();
''', '''    source_keepalive.reset(); source_copy_submission = 0;
    if (reset_pacing) pacing.Reset();
    if (reset_pacing) AdaptiveStop("the display was set up again");
    if (reset_pacing) adaptive.Reset();
''')
s.swap('''  bool Record(VkCommandBuffer command, VkImage source, bool generate) {
''', '''  bool Record(VkCommandBuffer command, VkImage source, bool generate, bool adaptive_span = false) {
''')
s.swap('''    if (pacing.Engaged()) {
      // Modes: the pictures planned for this frame, set before the first is recorded (it is
      // made a 1 / (pictures + 1) of the way). One, at the middle, unless 3x or 4x applies.
      interpolation.set_generated(generate ? std::clamp<uint32_t>(pacing.Generated(), 1, 3) : 1);
''', '''    if (adaptive_span || pacing.Engaged()) {
      // Modes: the pictures planned for this frame, set before the first is recorded (it is
      // made a 1 / (pictures + 1) of the way). One, at the middle, unless 3x or 4x applies.
      // Adaptive pacing sets the count whose fractions its outputs need.
      interpolation.set_generated(adaptive_span ? std::clamp<uint32_t>(plan.generated, 1, 3)
                                  : generate ? std::clamp<uint32_t>(pacing.Generated(), 1, 3) : 1);
''')
s.swap('''    acquire_pending = generated;
''', '''    acquire_pending = generated || adaptive_span;
''')
s.write()

# ---------------------------------------------------------------------------------------------
# presenter/vulkan_presenter.cc: the adaptive span beside the strict and the dormant ones.
p = Source('presenter/vulkan_presenter.cc')
p.swap('''  bool new_frame = false, generate = false, snapshot_ready = false;
''', '''  bool new_frame = false, generate = false, snapshot_ready = false;
  // Adaptive pacing: this new frame's span is paced by the adaptive path (strict not engaged).
  bool adaptive_span = false;
''')
p.swap('''      if (!pinned) {
        fg->pacing.Suspend();
        fg->Fallback(32, "inactive guest mailbox");
      }
''', '''      if (!pinned) {
        fg->pacing.Suspend();
        fg->AdaptiveStop("inactive guest mailbox");
        fg->Fallback(32, "inactive guest mailbox");
      }
''')
p.swap('''      if (fg->pacing.Engaged() && !admitted) {
        ++fg->deferred_frames;
''', '''      // Adaptive pacing sees every arrival and takes the span only when strict pacing is not
      // engaged for it (and the mode and the settings file allow it).
      adaptive_span = fg->AdaptiveArrive(this, serial, now, fg->pacing.Engaged());
      if (fg->pacing.Engaged() && !admitted) {
        ++fg->deferred_frames;
        ++fg->strict_frames;
''')
p.swap('''      if (!fg->pacing.Engaged()) {
        ++fg->dormant_frames;
''', '''      if (!fg->pacing.Engaged() && !adaptive_span) {
        ++fg->dormant_frames;
''')
p.swap('''          generate = fg->history && admitted;
          if (generate) {
            ++fg->admitted;
''', '''          generate = adaptive_span ? fg->history && fg->plan.pictures() != 0
                                   : fg->history && admitted;
          if (!adaptive_span) ++fg->strict_frames;
          if (generate && !adaptive_span) {
            ++fg->admitted;
''')
p.swap('''  if (fg && pinned && !fg->failed && !new_frame && fg->pacing.Engaged()) {
    if (fg_consumer_lock.owns_lock()) fg_consumer_lock.unlock();
    return PaintResult::kNotPresented;
  }
''', '''  if (fg && pinned && !fg->failed && !new_frame &&
      (fg->pacing.Engaged() || fg->AdaptiveHolding())) {
    if (fg_consumer_lock.owns_lock()) fg_consumer_lock.unlock();
    return PaintResult::kNotPresented;
  }
''')
p.swap('''  if (fg && pinned && (!fg->pacing.Engaged() || fg->failed)) {
    pinned.reset();
''', '''  if (fg && pinned && ((!fg->pacing.Engaged() && !adaptive_span) || fg->failed)) {
    pinned.reset();
''')
p.swap('''        midpoint = fg->Record(command, pinned->image(), generate);
''', '''        midpoint = fg->Record(command, pinned->image(), generate, adaptive_span);
''')
p.swap('''  if (fg && midpoint) fg->NoteAcquire(std::chrono::steady_clock::now() - acquire_start);
''', '''  if (fg) fg->NoteAcquire(std::chrono::steady_clock::now() - acquire_start);
''')
p.swap('''  const auto midpoint_start = std::chrono::steady_clock::now();
  const bool deferred_ui = execute_ui_drawers && midpoint;
''', '''  if (fg && adaptive_span && new_frame && pinned && !fg->failed) {
    // Adaptive pacing: this span's outputs in order, the first at once and each of the others
    // when the output before it has had its refreshes. An output is a generated picture (the
    // one Record made, or a further one of the same two frames) or the game's frame itself.
    // `midpoint` here says whether Record made pictures at all.
    if (!midpoint && fg->plan.pictures()) fg->AdaptiveCut(0);
    const auto refresh = std::chrono::nanoseconds(int64_t(1000000000.0 / fg->display_hz));
    auto deadline = std::chrono::steady_clock::now();
    PaintResult result = PaintResult::kNotPresented;
    for (uint32_t k = 0; k < fg->plan.count; ++k) {
      if (k) std::this_thread::sleep_until(deadline);
      // The first acquire waited for a refresh: every image was queued or on screen. The
      // pictures still to come are left out so that the queue, and the latency, cannot grow.
      if (k == 1 && fg->adaptive_backlog) fg->AdaptiveCut(k);
      ps5x360::framegen::AdaptiveOutput output = fg->plan.outputs[k];
      if (output.picture > 0 && !framegen_next_picture(uint32_t(output.picture))) {
        fg->Fallback(256, "a further generated picture could not be recorded; the frame's "
                          "remaining pictures are left out");
        fg->AdaptiveCut(k);
        output = fg->plan.outputs[k];
      }
      midpoint = output.picture >= 0;
      guest_picture_drawn = false;
      result = paint_one();
      ps5x360::output_metrics::Present(succeeded(result), guest_picture_drawn, midpoint);
      fg->pacing.Presented(succeeded(result) && guest_picture_drawn && !midpoint);
      if (!succeeded(result)) {
        fg->failed = true;
        ++fg->failures;
        fg->Fallback(16, "record/submit/present failed");
        fg->AdaptiveStop("a present failed");
        midpoint = false;
        return result;
      }
      if (midpoint) ++fg->midpoint_present_ok; else ++fg->ordinary_present_ok;
      if (!guest_picture_drawn) {
        fg->AdaptiveStop("the game's picture could not be drawn");
        break;
      }
      deadline += refresh * output.refreshes;
    }
    midpoint = false;
    return result;
  }
  const auto midpoint_start = std::chrono::steady_clock::now();
  const bool deferred_ui = execute_ui_drawers && midpoint;
''')
p.write()

# ---------------------------------------------------------------------------------------------
# test_adapter.cpp: the installed adapter's test and the modes' tests as they are, then this
# folder's.
t = Source('test_adapter.cpp')
t.swap('''#include "test_modes.inc"
int main() {
  RunModeTests();
''', '''#include "test_modes.inc"
#include "test_adaptive.inc"
int main() {
  RunModeTests();
  RunAdaptiveTests();
''')
t.write()
print('PASS adaptive sources written')
