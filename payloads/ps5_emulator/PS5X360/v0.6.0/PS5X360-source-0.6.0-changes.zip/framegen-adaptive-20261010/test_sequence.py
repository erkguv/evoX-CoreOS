"""The interpolator used the way adaptive pacing uses it, on a CPU Vulkan driver.

Adaptive pacing asks the interpolator for another number of pictures on every span (1, 2 or 3,
whichever has the fraction it needs) and often for one picture only, not the first: it records
the frame (which always makes the first picture), advances, and then asks for picture 1 or 2
directly. This builds upstream's test tool on the module as it is linked into the candidate
(private dispatch, 10-bit frames), in the presenter's call order, three ways:
  reference   the same number of pictures on every frame, every picture in order
  skipping    the last frame's further pictures asked for last first (so each is made without
              the ones before it): every file must be the same as the reference's
  varying     another number of pictures on each earlier frame: every scene must stay within
              upstream's limits
In xbox360ps5-canary with the repository's parent at /ws:
  python3 /ws/Xbox360PS5/build/framegen-adaptive-20261010/test_sequence.py
"""
from pathlib import Path
import hashlib
import os
import subprocess
import sys
import tempfile

root = Path('/ws/Xbox360PS5')
vendor = root / 'build/framegen-stutter-20261010/vendor'
upstream = root / 'build/ps5-framegen-upstream-20261010'
work = Path(tempfile.mkdtemp())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def swap(text, old, new):
    assert text.count(old) == 1, (old[:60], text.count(old))
    return text.replace(old, new)


# The tool on the candidate's module: its private dispatch bound, frames in the 10-bit format,
# and the presenter's order (advance right after record, its barrier before a further picture).
s = (upstream / 'tools/fg-test.cpp').read_text()
s = '#include "sword_loader.hpp"\n' + s
s = swap(s, '\tif (!fg.create(g.physical, g.device,',
         '\tif (!ps5x360::sword_dispatch::Bind(g.instance,g.device,vkGetInstanceProcAddr)) return 2;\n'
         '\tif (!fg.create(g.physical, g.device,')
s = swap(s, 'error, bgra ? VK_FORMAT_B8G8R8A8_UNORM', 'error, true ? VK_FORMAT_A2B10G10R10_UNORM_PACK32 : bgra ? VK_FORMAT_B8G8R8A8_UNORM')
s = swap(s, '\t\tif (bgra)\n\t\t{', '''\t\tif (true) {
      auto* packed = static_cast<uint32_t*>(map);
      for (size_t pixel=0;pixel<bytes/4;++pixel) {
        const auto* p=cur.rgba.data()+pixel*4;
        packed[pixel]=uint32_t((p[0]*1023+127)/255) |
                      (uint32_t((p[1]*1023+127)/255)<<10) |
                      (uint32_t((p[2]*1023+127)/255)<<20) | 0xc0000000u;
      }
    } else if (bgra)
    {''')
s = swap(s, '\t\tconst bool made = fg.record(cmd, frame == 0);\n',
         '\t\tconst bool made = fg.record(cmd, frame == 0);\n\t\tfg.advance();  // the presenter advances here\n')
s = swap(s, '\t\tfg.advance();\n\t}\n', '\t}\n')
barrier = '''\t\t\t\t{
\t\t\t\t\tVkMemoryBarrier reuse{}; reuse.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
\t\t\t\t\treuse.srcAccessMask = VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT;
\t\t\t\t\treuse.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
\t\t\t\t\tvkCmdPipelineBarrier(cmd2, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1, &reuse, 0, nullptr, 0, nullptr);
\t\t\t\t}
'''
s = swap(s, '\t\t\t\tif (!fg.interpolate_next(cmd2, static_cast<uint32_t>(i))) die("interpolate_next");\n',
         barrier + '\t\t\t\tif (!fg.interpolate_next(cmd2, static_cast<uint32_t>(i))) die("interpolate_next");\n')
(work / 'reference.cpp').write_text(s)

# Skipping: the further pictures of the last frame last first, each straight after the record.
loop = '\t\t\tfor (int i = 1; i < gen; i++)\n'
(work / 'skipping.cpp').write_text(swap(s, loop, '\t\t\tfor (int i = gen - 1; i >= 1; i--)\n'))

# Varying: 1, 2 or 3 pictures on the frames before the last, in turn.
(work / 'varying.cpp').write_text(swap(s, '\t\tfg.prepare(cmd);\n',
    '\t\tfg.set_generated(frame == frames - 1 ? static_cast<uint32_t>(gen) : static_cast<uint32_t>(1 + (frame + gen) % 3));\n'
    '\t\tfg.prepare(cmd);\n'))

base = ['clang++-18', '-std=c++17', '-O2', '-Wno-missing-field-initializers', '-I' + str(vendor), '-I' + str(upstream / 'tools/stb')]
subprocess.run(base + ['-DPS5_FRAMEGEN_VULKAN_HEADER="sword_dispatch.hpp"', str(vendor / 'ps5_framegen.cpp'), '-c', '-o', str(work / 'module.o')], check=True)
for name in ('reference', 'skipping', 'varying'):
    subprocess.run(base + [str(work / (name + '.cpp')), str(work / 'module.o'), '-lvulkan', '-ldl', '-o', str(work / name)], check=True)


def pictures(tool, scene, gen):
    out = work / f'{tool}-{scene}-{gen}.png'
    extra = ['--head-move', '6'] if scene == 'head' else []
    run = subprocess.run([str(work / tool), '--scene', scene, str(out)] + extra + ['--gen', str(gen)], capture_output=True, text=True)
    if run.returncode != 0:
        print(run.stdout[-2000:], run.stderr[-2000:])
        sys.exit(f'FAIL {tool} {scene} with {gen} pictures: exit {run.returncode}')
    return [out] + [Path(f'{out}.{i}.png') for i in range(1, gen)]


# A picture asked for without the ones before it is the picture made in order.
compared = 0
for scene, gen in (('all', 2), ('all', 3), ('head', 3), ('hud', 3)):
    for a, b in zip(pictures('reference', scene, gen), pictures('skipping', scene, gen)):
        assert a.exists() and b.exists(), (a, b)
        if sha(a) != sha(b):
            sys.exit(f'FAIL {scene} with {gen} pictures: {b.name} differs when asked for out of order')
        compared += 1
    print(f'same   {scene}, {gen} pictures: each is the same file asked for last first')

# Another number of pictures on every frame: still within upstream's limits, every scene.
for tool in ('reference', 'varying'):
    check = subprocess.run([sys.executable, str(upstream / 'tools/check-scenes.py'), str(work / tool), str(work / ('scenes-' + tool))],
                           capture_output=True, text=True, env=dict(os.environ))
    print(f'--- {tool}')
    print(check.stdout + check.stderr)
    if check.returncode != 0:
        sys.exit(f'FAIL scene limits, {tool}')
print(f'PASS sequence: {compared} pictures identical when asked for out of order; scenes within upstream\'s limits '
      'with a number of pictures that changes on every frame (10-bit frames, private dispatch, presenter order)')
