"""Host test of this candidate's launcher rows: key presses in, settings file out.

Runs the modes folder's render_modes.py (the launcher preview built with a launcher source,
keys pressed on Settings > Performance, /app0/framegen.conf checked) on this folder's
launcher.cpp, with its cases and these more: a ps5_frame_pacing line is written back as it was,
and the Automatic mode's help text fits its panel in the three languages. Screenshots go to
preview/ here.
In xbox360ps5-canary with the repository's parent at /ws:
  python3 -u /ws/Xbox360PS5/build/framegen-adaptive-20261010/render_adaptive.py
"""
from pathlib import Path

here = Path(__file__).resolve().parent
modes = here.parent / 'framegen-modes-20261010'
script = (modes / 'render_modes.py').read_text(encoding='utf-8')


def swap(old, new):
    global script
    assert script.count(old) == 1, (old[:60], script.count(old))
    script = script.replace(old, new)


swap("here = Path(__file__).resolve().parent\n", "here = HERE\n")
swap("conf = Path('/app0/framegen.conf')\n", '''P = 'ps5_frame_pacing='
cases += [
    ('pacing-strict-kept-on-mode-change', EN, ON + M + 'auto\\n' + H + '60\\n' + P + 'strict\\n', MODE + ',x',
     ON + M + '2\\n' + H + '60\\n' + P + 'strict\\n'),
    ('pacing-auto-kept-on-output-change', PT, ON + M + 'auto\\n' + P + 'auto\\n', OUTPUT + ',x',
     ON + M + 'auto\\n' + H + '120\\n' + P + 'auto\\n'),
    ('pacing-kept-through-off', EN, ON + M + '4\\n' + H + '120\\n' + P + 'strict\\n', MODE + ',2x',
     ON + M + 'auto\\n' + H + '120\\n' + P + 'strict\\n'),
    ('pacing-unknown-value-kept', ES, ON + M + '3\\n' + H + '120\\n' + P + 'loose\\n', MODE + ',left',
     ON + M + '2\\n' + H + '120\\n' + P + 'loose\\n'),
    ('no-pacing-line-none-written', EN, ON + M + 'auto\\n' + H + '60\\n', MODE + ',x', ON + M + '2\\n' + H + '60\\n'),
    ('screen-help-automatic-pt', PT, ON + M + 'auto\\n' + H + '60\\n', MODE, ON + M + 'auto\\n' + H + '60\\n'),
    ('screen-help-automatic-es', ES, ON + M + 'auto\\n' + H + '60\\n', MODE, ON + M + 'auto\\n' + H + '60\\n'),
    ('screen-help-automatic-en', EN, ON + M + 'auto\\n' + H + '60\\n', MODE, ON + M + 'auto\\n' + H + '60\\n'),
]
conf = Path('/app0/framegen.conf')
''')
exec(compile(script, str(modes / 'render_modes.py'), 'exec'),
     {'__file__': str(modes / 'render_modes.py'), '__name__': '__main__', 'HERE': here})
