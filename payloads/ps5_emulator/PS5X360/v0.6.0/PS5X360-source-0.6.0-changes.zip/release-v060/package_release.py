"""Assembles the v0.6.0 release assets in build/release-v060/artifacts:
  PPSA50011.zip                          the complete application folder
  PS5X360-AutoLog-v1.0.9-preview.elf     unchanged, copied from the v0.5.9 assets
  PS5X360-source-0.6.0-changes.zip       sources and recipes of what changed since v0.5.9
  SHA256SUMS.txt
Support files are those of the tester package made on 2026-10-10 (its staging folder); the
executable, VERSION, RELEASE.json, RELEASE_NOTES.md and MANIFEST.json are written here.
No games, saves, logs, settings, certificates or keys.
usage: python package_release.py
"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

here = Path(__file__).resolve().parent
root = here.parents[1]
checkout = root / 'build/release-v059-checkout'
record = json.loads((here / 'native/build.json').read_text())
assert record['version'] == '0.6.0'
sha = lambda data: hashlib.sha256(data).hexdigest()
# A key with its body, or a webhook address with its number: never in a package or a source archive.
SECRET = re.compile(rb'-----BEGIN [A-Z ]*PRIVATE KEY-----\s*[A-Za-z0-9+/=\s]{60,}|discord(?:app)?\.com/api/webhooks/\d{6,}')
MAIL = re.compile(rb'[A-Za-z0-9._%+-]+@(?:gmail|outlook|hotmail|ccr)\.[a-z.]+', re.I)

stage = here / 'stage'
shutil.rmtree(stage, ignore_errors=True)
title = stage / 'PPSA50011'
shutil.copytree(root / 'dist/local/0.5.9-updates.3-safe-local/tester/PPSA50011', title)
image = (here / 'native/eboot.bin').read_bytes()
assert sha(image) == record['native_sha256']
(title / 'eboot.bin').write_bytes(image)
(title / 'VERSION').write_text('0.6.0\n', encoding='utf-8', newline='\n')
(title / 'RELEASE.json').write_text(json.dumps({
    'version': '0.6.0', 'channel': 'release', 'native_sha256': record['native_sha256'],
    'tested_candidate': record['tested_candidate'],
    'hardware_validation': 'The tested candidate 0.5.9-updates.5 ran on the developer PS5 (firmware 13.60) on 2026-10-11 '
                           '(GTA IV, Bully: frame generation active at uneven frame rates). The 0.6.0 executable differs '
                           'only in the launcher object compiled with the version text and was not opened on a console '
                           'before publication.',
}, indent=2) + '\n', encoding='utf-8', newline='\n')
shutil.copyfile(checkout / 'docs/releases/v0.6.0.md', title / 'RELEASE_NOTES.md')
assert (title / 'framegen.conf').read_text().strip() == 'ps5_frame_interpolation=false'  # off until switched on
for needed in ('assets/kinect/index.html', 'updates/README.md', 'licenses/PS5-FRAMEGEN-GPL-3.txt',
               'licenses/AMD-FIDELITYFX-SDK-MIT.txt', 'sce_sys/param.json', 'sce_module/libc.prx'):
    assert (title / needed).is_file(), needed
assert 'ps5-framegen' in (title / 'CREDITS.md').read_text(encoding='utf-8')
allowed_top = {'AUTOLOG.md', 'CREDITS.md', 'INSTALLATION.md', 'LICENSE', 'MANIFEST.json', 'MULTI-DISC.md', 'RELEASE.json',
               'RELEASE_NOTES.md', 'VERSION', 'assets', 'dlc', 'eboot.bin', 'framegen.conf', 'licenses', 'sce_module',
               'sce_sys', 'updates'}
assert {p.name for p in title.iterdir()} <= allowed_top, {p.name for p in title.iterdir()} - allowed_top
files = sorted(p for p in title.rglob('*') if p.is_file())
forbidden = ('.key', '.pem', '.crt', '.der', '.p12', '.log', '.bak', '.iso', '.xex')
assert not [p for p in files if p.suffix.lower() in forbidden]
assert [p.name for p in (title / 'assets/roms').rglob('*')] == ['README.txt']  # the games folder ships empty
for p in files:
    if p.suffix.lower() in {'.md', '.txt', '.json', '.toml', '.html', '.mjs', '.conf'}:
        assert not SECRET.search(p.read_bytes()), p
manifest = {p.relative_to(title).as_posix(): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in files if p.name != 'MANIFEST.json'}
(title / 'MANIFEST.json').write_text(json.dumps(manifest, indent=1) + '\n', encoding='utf-8', newline='\n')

out = here / 'artifacts'
shutil.rmtree(out, ignore_errors=True)
out.mkdir()
package = out / 'PPSA50011.zip'
with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(title.rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(stage).as_posix())
with zipfile.ZipFile(package) as z:
    assert z.testzip() is None and sha(z.read('PPSA50011/eboot.bin')) == record['native_sha256']
    packed = json.loads(z.read('PPSA50011/MANIFEST.json'))
    assert all(sha(z.read('PPSA50011/' + name)) == entry['sha256'] for name, entry in packed.items())
    assert z.read('PPSA50011/VERSION') == b'0.6.0\n'
    entries = len(z.namelist())

autolog = out / 'PS5X360-AutoLog-v1.0.9-preview.elf'
shutil.copyfile(root / 'build/release-v059/artifacts/PS5X360-AutoLog-v1.0.9-preview.elf', autolog)
assert sha(autolog.read_bytes()).startswith('5da64c23263e6868'), 'not the published AutoLog 1.0.9'

# Sources and recipes of what changed since v0.5.9 (whose own source archive stays in its release).
KEEP = {'.py', '.cpp', '.hpp', '.h', '.cc', '.inc', '.comp', '.hlsl', '.glsl', '.md', '.toml', '.sh', '.mjs', '.html'}
SKIP = re.compile(r'^(native.*|obj|proofs|console.*|logs?|__pycache__|preview|video|tester|scenes.*|host.*|package|stage|'
                  r'artifacts|crash-analysis|memory-review|loading-2.*|segments-.*|.*trace.*|.*-review|retest-.*|'
                  r'lost-odyssey-headers|reference.*|research|\.git|node_modules|backups?|old-kit|kit|captures)$')
FOLDERS = ['dist/local/0.5.9-framegen.3-local/SOURCE', 'dist/local/0.5.9-framegen.4-local/SOURCE',
           'build/loading-fix-20261009', 'build/net-fix-20261009', 'build/prince-fix-20261009',
           'build/menu-perf-20261009', 'build/framegen-counter-20261009', 'build/bully-loading-20261009',
           'build/kinect-native-20261009', 'build/title-updates-20261010', 'build/stutter-wait-20261010',
           'build/updates-integration-20261010', 'build/framegen-modes-20261010', 'build/framegen-adaptive-20261010',
           'build/framegen-always-20261010', 'build/release-v060', 'tools/kinect-phone']
picked = {}
for folder in FOLDERS:
    base = root / folder
    assert base.is_dir(), folder
    label = folder.split('/')[-2] + '-SOURCE' if folder.endswith('SOURCE') else folder.split('/')[-1]
    for p in base.rglob('*'):
        relative = p.relative_to(base)
        if not p.is_file() or any(SKIP.match(part) for part in relative.parts[:-1]):
            continue
        if not (p.name in ('COPYING', 'PROVENANCE.json') or p.suffix.lower() in KEEP) or p.stat().st_size > 1_500_000:
            continue
        if p.name.startswith(('deployment', 'agent-', 'DISCORD-')):
            continue  # local paths and the console address, research notes, chat texts
        data = p.read_bytes()
        assert not SECRET.search(data), p
        assert not MAIL.search(data), (p, MAIL.search(data).group(0))
        picked[f'{label}/{relative.as_posix()}'] = data
picked['README.md'] = (here / 'SOURCE-README.md').read_bytes()
sources = out / 'PS5X360-source-0.6.0-changes.zip'
with zipfile.ZipFile(sources, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(picked):
        z.writestr(name, picked[name])
with zipfile.ZipFile(sources) as z:
    assert z.testzip() is None

sums = ''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in (package, autolog, sources))
(out / 'SHA256SUMS.txt').write_text(sums, encoding='utf-8', newline='\n')
print(sums.strip())
print('package entries:', entries, '| bytes:', package.stat().st_size, '| source files:', len(picked), 'bytes:', sources.stat().st_size)
by_folder = {}
for name in picked:
    by_folder[name.split('/')[0]] = by_folder.get(name.split('/')[0], 0) + 1
print(by_folder)
