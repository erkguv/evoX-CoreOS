"""Builds the v0.6.0 executable: the recipe of build/framegen-always-20261010 (0.5.9-updates.5, the
build run on the developer's PS5) with the version text 0.6.0 and nothing else changed.

The recipe is run as it is, with two lines replaced: the version and the output folder. Afterwards
every object is compared with the updates.5 build: only launcher.cpp.o may differ (it is compiled
with the version text).
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/release-v060/build_release.py
"""
from pathlib import Path
import hashlib
import json

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
recipe = root / 'build/framegen-always-20261010/build.py'
tested = root / 'build/framegen-always-20261010/native'
text = recipe.read_text(encoding='utf-8')
for old, new in (("VERSION = '0.5.9-updates.5-local'\n", "VERSION = '0.6.0'\n"),
                 ("out = here / 'native'\n", "out = root / 'build/release-v060/native'\n"),
                 ("proofs = here / 'proofs'\n", "proofs = root / 'build/release-v060/proofs'\n")):
    assert text.count(old) == 1, old
    text = text.replace(old, new)
exec(compile(text, str(recipe), 'exec'), {'__file__': str(recipe), '__name__': 'release_build'})

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
out = here / 'native'
record = json.loads((out / 'build.json').read_text())
before = json.loads((tested / 'build.json').read_text())
assert before['version'] == '0.5.9-updates.5-local' and before['native_sha256'].startswith('fffc5a015bedc8d1')
different = sorted(name for name, value in record['objects'].items() if before['objects'][name] != value)
assert different == ['launcher.cpp.o'], different
record['tested_candidate'] = {'version': before['version'], 'native_sha256': before['native_sha256'],
                              'objects_that_differ': different,
                              'difference': 'the launcher is compiled with the version text 0.6.0; read-only version strings'}
(out / 'build.json').write_text(json.dumps(record, indent=2))
print('RELEASE BUILD', record['version'], sha(out / 'eboot.bin'), '| objects differing from updates.5:', different)
