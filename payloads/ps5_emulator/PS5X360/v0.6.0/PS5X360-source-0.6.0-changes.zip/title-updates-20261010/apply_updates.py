"""Adds the Updates tab (title updates) to the launcher source of the installed build.

Reads build/kinect-native-20261009/launcher.cpp (the source whose object is in framegen.4,
byte for byte) and writes launcher.cpp next to this script. Every anchor must match once.
The Launcher class is not touched: its layout is shared with objects that are not rebuilt.
usage: python apply_updates.py [output file]
Without an output file it rewrites launcher.cpp beside this script, which
build/framegen-modes-20261010 reads: give an output file instead.
"""
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
source = here.parent / 'kinect-native-20261009/launcher.cpp'
text = source.read_text(encoding='utf-8')


def swap(old, new):
    global text
    assert text.count(old) == 1, (old[:70], text.count(old))
    text = text.replace(old, new)


swap('#include "dlc_manager.hpp"\n', '#include "dlc_manager.hpp"\n#include "update_manager.hpp"\n')

# State and helpers of the Updates tab, ahead of the launch code that uses them.
swap('''dlc2::Found& DlcPage();  // the DLCs tab's list, defined with RefreshDlcs
''', r'''dlc2::Found& DlcPage();  // the DLCs tab's list, defined with RefreshDlcs
const char* FramegenText(const char* pt, const char* en, const char* es);
namespace {
// The Updates tab (title updates) and what it shows. Kept here, not in the class: the class
// layout is shared with objects that are not rebuilt.
struct UpdateSheet {
  tu::Found page;
  std::vector<tu::Inbox> inboxes;
  std::filesystem::path root;
  uint32_t title = 0, media = 0;
  int row = 0;
  std::string result;
};
UpdateSheet& Updates() {
  static UpdateSheet sheet;
  return sheet;
}
// Updates are looked for in the updates folders and, since that is where people put them, in
// the dlc folders too.
template <class Roots>
std::vector<tu::Inbox> UpdateInboxes(const std::filesystem::path& game, const Roots& roots) {
  std::vector<tu::Inbox> inboxes = {{"/app0/updates", true}, {game.parent_path() / "updates", true},
                                    {"/app0/dlc", false}, {game.parent_path() / "dlc", false}};
  for (const auto& root : roots) {
    inboxes.push_back({std::filesystem::path(root) / "updates", true});
    inboxes.push_back({std::filesystem::path(root) / "dlc", false});
  }
  return inboxes;
}
void RefreshUpdates() {
  auto& sheet = Updates();
  if (tu::copier().Busy()) return;
  sheet.page = sheet.title ? tu::Find(sheet.title, sheet.root, sheet.inboxes) : tu::Found{};
  sheet.row = std::clamp(sheet.row, 0, std::max(0, int(sheet.page.items.size()) - 1));
}
template <class Roots>
void OpenUpdates(const std::filesystem::path* game, uint32_t title, const std::filesystem::path& root,
                 const Roots& roots) {
  auto& sheet = Updates();
  if (tu::copier().Busy()) return;
  std::error_code error;
  std::filesystem::create_directories("/app0/updates", error);  // where a new update is copied to
  sheet.result.clear();
  sheet.title = game && !root.empty() ? title : 0;
  sheet.root = root;
  sheet.inboxes = sheet.title ? UpdateInboxes(*game, roots) : std::vector<tu::Inbox>{};
  sheet.media = sheet.title ? tu::GameMedia(*game, title) : 0;
  RefreshUpdates();
}
template <class Surface>
void DrawUpdates(Surface& c, float x);
}  // namespace
''')

# Play installs a waiting update first, then the DLCs.
swap('''  auto& copier = dlc2::copier();
  if (copier.Busy()) {
    if (!label.empty()) loading_ = label + "  " + std::to_string(int(copier.Progress() * 100)) + "%";
    return false;
  }
''', '''  auto& copier = dlc2::copier();
  if (copier.Busy()) {
    if (!label.empty()) loading_ = label + "  " + std::to_string(int(copier.Progress() * 100)) + "%";
    return false;
  }
  static std::vector<tu::Item> update;  // its update not installed yet: none or one
  static std::string update_note;       // the update this launch runs with, for the log
  auto& updater = tu::copier();
  if (updater.Busy()) {
    if (!label.empty()) loading_ = label + "  " + std::to_string(int(updater.Progress() * 100)) + "%";
    return false;
  }
''')
swap('''    checked = current;
    waiting.clear();
    found = 0;
''', '''    checked = current;
    waiting.clear();
    update.clear();
    update_note.clear();
    found = 0;
''')
swap('''        if (item.state == dlc2::State::available) waiting.push_back(item);
      found = waiting.size();
''', '''        if (item.state == dlc2::State::available) waiting.push_back(item);
      found = waiting.size();
      const tu::Found updates = tu::Find(title, save_root_, UpdateInboxes(launch_.path, settings_.game_paths));
      if (const tu::Item* pending = tu::Pending(updates, tu::GameMedia(launch_.path, title))) update.push_back(*pending);
      for (const auto& item : updates.items)
        if (item.state == tu::State::active) update_note = "v" + tu::VersionText(item.version) + " " + item.file + " (active)";
      if (!update.empty()) update_note = "v" + tu::VersionText(update.front().version) + " " + update.front().file + " (installed at this launch)";
''')
swap('''  copier.TakeResult();
  while (!waiting.empty()) {
''', r'''  copier.TakeResult();
  updater.TakeResult();
  if (!update.empty()) {
    const tu::Item next = update.front();
    update.clear();
    label = launch_.name + "  ·  " + FramegenText("Atualização ", "Update ", "Actualización ") + tu::VersionText(next.version);
    loading_ = label;
    if (updater.Start(next, save_root_, title)) return false;  // copying; asked again next frame
  }
  while (!waiting.empty()) {
''')

swap('''  checked.clear();
  label.clear();
  loading_ = launch_.name;
''', '''  XELOGW("LAUNCHER title update for {} ({}): {}", launch_.name, launch_.title_id, update_note.empty() ? "none" : update_note);
  checked.clear();
  label.clear();
  loading_ = launch_.name;
''')

# Six tabs; the sixth opens the Updates page.
swap('''game_tab_ = (game_tab_ + (key == Key::r1 ? 1 : 4)) % 5; if (game_tab_ == 3) RefreshAchievements(); if (game_tab_ == 4) RefreshDlcs(); break; }''',
     '''game_tab_ = (game_tab_ + (key == Key::r1 ? 1 : 5)) % 6; if (game_tab_ == 3) RefreshAchievements(); if (game_tab_ == 4) RefreshDlcs(); if (game_tab_ == 5) OpenUpdates(Selected() ? &Selected()->path : nullptr, SelectedTitleId(), save_root_, settings_.game_paths); break; }''')
swap('''          if ((dlc_hooks_.status && dlc_hooks_.status().busy) || dlc2::copier().Busy()) { message_ = Tr("Aguarde a instalação do DLC terminar."); break; }
''', '''          if ((dlc_hooks_.status && dlc_hooks_.status().busy) || dlc2::copier().Busy()) { message_ = Tr("Aguarde a instalação do DLC terminar."); break; }
          if (tu::copier().Busy()) { message_ = FramegenText("Aguarde a instalação da atualização terminar.", "Wait for the update to finish installing.", "Espera a que termine la instalación de la actualización."); break; }
''')
swap('''      if (game_tab_ == 4) {
        const bool busy = dlc2::copier().Busy();
''', '''      if (game_tab_ == 5) {
        auto& sheet = Updates();
        const bool busy = tu::copier().Busy();
        const int rows = int(sheet.page.items.size());
        if (key == Key::up && rows) sheet.row = (sheet.row + rows - 1) % rows;
        if (key == Key::down && rows) sheet.row = (sheet.row + 1) % rows;
        if (!busy && key == Key::square) { sheet.result.clear(); RefreshUpdates(); }
        if (!busy && key == Key::cross && rows && !save_root_.empty()) {
          const tu::Item item = sheet.page.items[size_t(sheet.row)];
          if (item.state == tu::State::available) {
            sheet.result = tu::copier().Start(item, save_root_, sheet.title) ? "" : "start-failed";
          } else {
            const bool enable = item.state == tu::State::disabled;
            const bool moved = enable ? tu::Activate(item, save_root_, sheet.title)
                                      : tu::Disable(item.path, save_root_, sheet.title);
            RefreshUpdates();
            sheet.result = !moved ? "move-failed" : enable ? "enabled" : "disabled";
          }
        }
        if (key == Key::circle) close();
        break;
      }
      if (game_tab_ == 4) {
        const bool busy = dlc2::copier().Busy();
''')
swap('''    const char* const tabs[] = {"Jogar", "Patches", "Configurações", "Conquistas", "DLCs"};
    float tab_x = x + 56;
    for (int n = 0; n < int(std::size(tabs)); ++n) {
      const float width = c.Width(Tr(tabs[n]), 28);
      c.Text(Tr(tabs[n]), tab_x, 272, 28, n == game_tab_ ? kText : kFaint);
      if (n == game_tab_) c.Fill(tab_x, 310, width, 3, kAccent, 0.9f, 2);
      tab_x += width + 26;
    }
''', '''    const char* const tabs[] = {Tr("Jogar"), Tr("Patches"), Tr("Configurações"), Tr("Conquistas"), Tr("DLCs"),
                                FramegenText("Atualizações", "Updates", "Actualizaciones")};
    // Six names do not fit the sheet at full size in every language: they shrink together.
    float names = 0;
    for (const char* tab : tabs) names += c.Width(tab, 28);
    const float fit = std::min(1.0f, (748 - c.Width("L1 / R1", 20)) / (names + 26 * float(std::size(tabs))));
    const float size = 28 * fit, gap = 26 * fit;
    float tab_x = x + 56;
    for (int n = 0; n < int(std::size(tabs)); ++n) {
      const float width = c.Width(tabs[n], size);
      c.Text(tabs[n], tab_x, 272 + (28 - size) * 0.6f, size, n == game_tab_ ? kText : kFaint);
      if (n == game_tab_) c.Fill(tab_x, 310, width, 3, kAccent, 0.9f, 2);
      tab_x += width + gap;
    }
''')
swap('''  if (game_tab_ == 4) { DrawDlcs(c, x); return; }
''', '''  if (game_tab_ == 4) { DrawDlcs(c, x); return; }
  if (game_tab_ == 5) { DrawUpdates(c, x); return; }
''')

# The page itself, after the DLC page it is modelled on.
swap('''  c.Hint('o', Tr("Voltar"), hint, 1004);
}

template <class Surface>  // Launcher::Canvas is private to the class
void DrawQrCard(''', r'''  c.Hint('o', Tr("Voltar"), hint, 1004);
}

namespace {
template <class Surface>  // Launcher::Canvas is private to the class
void DrawUpdates(Surface& c, float x) {
  auto& sheet = Updates();
  auto& copier = tu::copier();
  const bool busy = copier.Busy();
  if (!busy) {
    if (const int result = copier.TakeResult()) {
      RefreshUpdates();
      sheet.result = result > 0 ? "installed" : "copy-failed:" + std::to_string(-result);
    }
  }
  c.Wrapped(FramegenText(
      "Uma atualização fica ativa por vez. Copie o arquivo para PPSA50011/updates ou para a pasta updates do jogo: a mais nova é instalada sozinha ao apertar Jogar (ou aqui, com X). Patches feitos para o jogo sem atualização não valem com ela ativa.",
      "One update is active at a time. Copy the file to PPSA50011/updates or to the game's updates folder: the newest installs by itself when you press Play (or here, with X). Patches made for the game without an update do not apply while one is active.",
      "Solo una actualización está activa a la vez. Copia el archivo en PPSA50011/updates o en la carpeta updates del juego: la más nueva se instala sola al pulsar Jugar (o aquí, con X). Los parches hechos para el juego sin actualización no se aplican con ella activa."),
    x + 56, 330, 21, kMuted, 740);
  const auto& page = sheet.page;
  const int rows = int(page.items.size());
  const int first = std::clamp(sheet.row - 2, 0, std::max(0, rows - 5));
  for (int n = first; n < std::min(rows, first + 5); ++n) {
    const auto& item = page.items[size_t(n)];
    const float y = 470 + (n - first) * 56.0f;
    const bool selected = n == sheet.row;
    if (selected) c.Fill(x + 48, y, 768, 50, kSurfaceHigh, 1, 8);
    c.Text("v" + tu::VersionText(item.version) + "  ·  " + item.file, x + 64, y + 10, 22, selected ? kText : kBody, 1, 0, 520);
    const bool on = item.state == tu::State::active, off = item.state == tu::State::disabled;
    // An installed update keeps showing its state; the note below says when it does not fit.
    const bool other = !on && !off && !tu::Fits(item, sheet.media);
    c.Text(on ? FramegenText("Ativa", "On", "Activa") : off ? FramegenText("Desativada", "Off", "Desactivada")
              : other ? FramegenText("Outra edição do jogo", "Another edition", "Otra edición")
                      : FramegenText("Não instalada", "Not installed", "No instalada"),
           x + 796, y + 12, 20, on ? kAccent : off || other ? kMuted : kBody, 1, 2);
  }
  if (!rows)
    c.Wrapped(sheet.title ? FramegenText("Nenhuma atualização deste jogo encontrada.", "No update for this game found.", "No se encontró ninguna actualización de este juego.")
                          : Tr("Abra o jogo uma vez para identificar o título."),
              x + 56, 470, 24, kMuted, 730);
  if (rows && !tu::Fits(page.items[size_t(std::clamp(sheet.row, 0, rows - 1))], sheet.media)) {
    char other[360];
    std::snprintf(other, sizeof(other),
                  FramegenText("Esta atualização é de outra edição do jogo (mídia %08X; a sua é %08X). O emulador provavelmente não vai aplicá-la.",
                               "This update is for another edition of the game (media %08X; yours is %08X). The emulator will probably not apply it.",
                               "Esta actualización es de otra edición del juego (medio %08X; el tuyo es %08X). El emulador probablemente no la aplicará."),
                  page.items[size_t(std::clamp(sheet.row, 0, rows - 1))].media, sheet.media);
    c.Wrapped(other, x + 56, 762, 19, kBody, 740);
  } else if (page.other_game || page.not_update || page.not_package) {
    char ignored[320];
    std::snprintf(ignored, sizeof(ignored),
                  FramegenText("Ignorados nas pastas updates: %d de outro jogo (outro ID), %d que não são atualização (ex.: DLC), %d que não são pacotes do Xbox 360.",
                               "Ignored in the updates folders: %d of another game (other ID), %d not updates (e.g. DLC), %d not Xbox 360 packages.",
                               "Ignorados en las carpetas updates: %d de otro juego (otro ID), %d que no son actualizaciones (p. ej. DLC), %d que no son paquetes de Xbox 360."),
                  page.other_game, page.not_update, page.not_package);
    c.Wrapped(ignored, x + 56, 762, 19, kFaint, 740);
  }
  if (busy) {
    const float progress = float(std::clamp(copier.Progress(), 0.0, 1.0));
    c.Text(std::string(FramegenText("Instalando atualização  ", "Installing update  ", "Instalando actualización  ")) +
               std::to_string(int(progress * 100)) + "%", x + 56, 840, 22, kAccent, 1, 0, 740);
    c.Fill(x + 56, 876, 740, 5, kSurfaceHigh); c.Fill(x + 56, 876, 740 * progress, 5, kAccent);
  } else if (!sheet.result.empty()) {
    const std::string& r = sheet.result;
    const char* message = r == "enabled" ? FramegenText("Atualização ativada: o jogo abre com ela.", "Update on: the game starts with it.", "Actualización activada: el juego arranca con ella.")
      : r == "disabled" ? FramegenText("Atualização desativada: o jogo abre sem ela, e o arquivo continua guardado.", "Update off: the game starts without it; the file is kept.", "Actualización desactivada: el juego arranca sin ella; el archivo se conserva.")
      : r == "installed" ? FramegenText("Atualização instalada e ativada.", "Update installed and on.", "Actualización instalada y activada.")
      : r == "move-failed" ? FramegenText("Não foi possível mover o arquivo da atualização.", "Could not move the update file.", "No se pudo mover el archivo de la actualización.")
      : FramegenText("A instalação falhou: confira o espaço livre e o arquivo.", "Installing failed: check free space and the file.", "La instalación falló: revisa el espacio libre y el archivo.");
    c.Wrapped(std::string(message) + (r.rfind("copy-failed", 0) == 0 ? " (" + r.substr(12) + ")" : ""), x + 56, 840, 22, kBody, 740);
  }
  c.Text(Tr("Destino: ") + sheet.root.string(), x + 56, 928, 20, kFaint, 1, 0, 740);
  float hint = x + 56;
  if (!busy && rows) {
    const auto state = page.items[size_t(std::clamp(sheet.row, 0, rows - 1))].state;
    hint = c.Hint('x', state == tu::State::active ? FramegenText("Desativar", "Turn off", "Desactivar")
                     : state == tu::State::disabled ? FramegenText("Ativar", "Turn on", "Activar") : Tr("Instalar"), hint, 1004);
  }
  if (!busy) hint = c.Hint('s', Tr("Recarregar lista"), hint, 1004);
  c.Hint('o', Tr("Voltar"), hint, 1004);
}
}  // namespace

template <class Surface>  // Launcher::Canvas is private to the class
void DrawQrCard(''')

target = Path(sys.argv[1]) if len(sys.argv) > 1 else here / 'launcher.cpp'
target.write_text(text, encoding='utf-8', newline='\n')
print(target, 'written:', len(text), 'characters')
