# Title updates in the launcher (0.5.9-updates.1-local)

Local candidate on the installed `0.5.9-framegen.4-local` executable. Not a public release.
Only `launcher.cpp.o` is rebuilt; every other object is that build's, checked by hash.

## What it adds

The emulator core already applies a title update at launch: it lists
`saves/0000000000000000/<TITLE>/000B0000/`, mounts the first package it finds as `update:` and
applies its `.xexp` to the executable. What was missing is a way to get a package there and to
choose which one is used.

- **Updates tab** on the game sheet (sixth tab, after DLCs). It lists the game's updates as
  *On* (in `000B0000`), *Off* (in `000B0000-off`, kept but not applied) or *Not installed*
  (found in a folder), with version and file name. Cross installs, turns on or turns off;
  Square reloads the list.
- **One update is active at a time.** The core takes the first package of the folder, whichever
  it is, so activating one moves the others to the off folder.
- **Where to copy a new update:** `PPSA50011/updates`, the game's own `updates` folder, or an
  `updates` folder in a library root. The `dlc` folders are searched too, because that is where
  people put them. The `PPSA50011/updates` folder is created when the tab is first opened and
  by `deploy.py`.
- **Play installs it by itself:** the newest waiting update that fits the game and is newer than
  every installed one is copied (progress on the loading screen) and made active before the game
  starts. An update the player turned off is not put back.
- **Edition check.** An update is made for one edition of a game. The media ID in the update's
  header is compared with the game's (executable execution information, or package header).
  When both are known and differ the update is labelled "another edition", a note gives both
  IDs, and Play does not install it by itself. Disc images are not inspected: nothing is
  concluded for them.
- **Log.** Each launch writes `LAUNCHER title update for <game> (<title>): ...` with the update
  in use, or `none`.

Patches and fixes keyed to an executable hash (the patch files, the Dragon Ball Z for Kinect
skeleton source) are made for one version of a game's code. The hash is taken after the update
is applied, so with an update active they stop applying. The tab says so, and turning the
update off brings them back.

## Evidence

- `update_test.py` (host, ASan/UBSan): listing, ignored-file counts, version order, the pending
  rule, install with replacement of the active update, on/off, refusal of a non-update package,
  clean-up of a folder with two packages, media ID from an executable and from a package. PASS.
- `render_updates.py`: software render of the tab (`preview/list.png`, `preview/installed.png`).
- `build.py`: the unchanged launcher source reproduces the installed object byte for byte; the
  new image passes the native image verification and is signed.
- **Not tested:** a real title update with a real game, on the host or on the console. Whether a
  given update applies is decided by the core's signature check; a refusal is logged as
  `Skipping incompatible title update`.

## Files

`update_manager.hpp` (the logic), `apply_updates.py` (launcher changes, generated into
`launcher.cpp`), `update_test.cpp/.py`, `render_updates.py`, `build.py`, `deploy.py`.
