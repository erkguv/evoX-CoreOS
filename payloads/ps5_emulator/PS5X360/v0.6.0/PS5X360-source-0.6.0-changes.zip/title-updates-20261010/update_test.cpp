// Host check of update_manager.hpp against package files prepared by update_test.py.
// usage: update_test <saves root> <updates inbox> <dlc inbox> <game.xex> <game package> <disc image>
#include "update_manager.hpp"
#include <chrono>
#include <cstdlib>
#include <iostream>

using namespace xbox360ps5;
namespace fs = std::filesystem;

static int failures = 0;
#define CHECK(condition) \
  do { if (!(condition)) { ++failures; std::cerr << "FAIL line " << __LINE__ << ": " #condition "\n"; } } while (0)

static size_t Files(const fs::path& folder) {
  size_t n = 0;
  std::error_code ec;
  for (fs::directory_iterator it(folder, ec), end; !ec && it != end; it.increment(ec)) n += it->is_regular_file(ec);
  return n;
}
static int Install(const tu::Item& item, const fs::path& root, uint32_t title) {
  auto& copier = tu::copier();
  if (!copier.Start(item, root, title)) return -100;
  for (int n = 0; n < 2000 && copier.Busy(); ++n) std::this_thread::sleep_for(std::chrono::milliseconds(5));
  return copier.TakeResult();
}
static const tu::Item* Named(const tu::Found& found, const std::string& file) {
  for (const auto& item : found.items) if (item.file == file) return &item;
  return nullptr;
}

int main(int argc, char** argv) {
  if (argc != 7) return 2;
  const fs::path root = argv[1];
  const std::vector<tu::Inbox> inboxes = {{argv[2], true}, {argv[3], false}};
  const uint32_t title = 0x4E4D0860, media = 0x11112222;

  CHECK(tu::VersionText(0x00000500) == "0.0.5.0");
  CHECK(tu::VersionText(0x12003407) == "1.2.52.7");
  CHECK(tu::GameMedia(argv[4], title) == media);       // executable: execution information
  CHECK(tu::GameMedia(argv[4], 0x12345678) == 0);      // not that title's executable
  CHECK(tu::GameMedia(argv[5], title) == media);       // package header
  CHECK(tu::GameMedia(argv[6], title) == 0);           // disc image: nothing concluded
  CHECK(tu::GameMedia(root / "missing", title) == 0);

  // Nothing installed: three updates wait (two fit, the newest of all is for another edition),
  // one of them in the dlc folder; a DLC, another game's update and a text file are not used.
  tu::Found found = tu::Find(title, root, inboxes);
  CHECK(found.items.size() == 3);
  CHECK(found.other_game == 1 && found.not_update == 1 && found.not_package == 1);
  CHECK(found.items.size() == 3 && found.items[0].version == 0x00000900 && found.items[2].version == 0x00000200);
  const tu::Item* pending = tu::Pending(found, media);
  CHECK(pending && pending->version == 0x00000500 && pending->file == "tu-5");
  CHECK(tu::Pending(found, 0) && tu::Pending(found, 0)->version == 0x00000900);  // edition unknown: newest
  const tu::Item* other = Named(found, "tu-9-other-edition");
  CHECK(other && !tu::Fits(*other, media) && tu::Fits(*other, 0));

  // Play installs the pending one; it is then the only active package and nothing is pending.
  CHECK(pending && Install(*pending, root, title) == 1);
  CHECK(Files(tu::ActiveFolder(root, title)) == 1 && Files(tu::DisabledFolder(root, title)) == 0);
  found = tu::Find(title, root, inboxes);
  CHECK(Named(found, "tu-5") && Named(found, "tu-5")->state == tu::State::active);
  CHECK(found.items.size() == 3 && found.items[0].state == tu::State::active);
  CHECK(tu::Pending(found, media) == nullptr);

  // Installing the older one by hand replaces it: the newer goes to the disabled folder.
  const tu::Item* older = Named(found, "tu-2");
  CHECK(older && older->state == tu::State::available && Install(*older, root, title) == 1);
  CHECK(Files(tu::ActiveFolder(root, title)) == 1 && Files(tu::DisabledFolder(root, title)) == 1);
  found = tu::Find(title, root, inboxes);
  CHECK(Named(found, "tu-2") && Named(found, "tu-2")->state == tu::State::active);
  CHECK(Named(found, "tu-5") && Named(found, "tu-5")->state == tu::State::disabled);
  CHECK(tu::Pending(found, media) == nullptr);  // the newer one was put aside, not asked for again

  // Turning the newer one back on swaps them.
  CHECK(tu::Activate(*Named(found, "tu-5"), root, title));
  found = tu::Find(title, root, inboxes);
  CHECK(Named(found, "tu-5")->state == tu::State::active && Named(found, "tu-2")->state == tu::State::disabled);
  CHECK(Files(tu::ActiveFolder(root, title)) == 1 && Files(tu::DisabledFolder(root, title)) == 1);

  // Turning it off leaves the game without an update; both files are kept.
  CHECK(tu::Disable(Named(found, "tu-5")->path, root, title));
  CHECK(Files(tu::ActiveFolder(root, title)) == 0 && Files(tu::DisabledFolder(root, title)) == 2);
  found = tu::Find(title, root, inboxes);
  CHECK(tu::Pending(found, media) == nullptr);

  // A package that is not this title's update is refused by the installer and leaves nothing.
  tu::Item wrong = *Named(found, "tu-9-other-edition");
  wrong.path = fs::path(argv[2]) / "dlc-not-update";
  std::error_code ec;
  wrong.bytes = fs::file_size(wrong.path, ec);
  wrong.file = "dlc-not-update";
  CHECK(Install(wrong, root, title) == -4);
  CHECK(Files(tu::ActiveFolder(root, title)) == 0 && Files(dlc2::Folder(root, title, tu::kStagingLeaf)) == 0);

  // Two packages left in the active folder by hand: activating one leaves it alone there.
  fs::copy_file(fs::path(argv[2]) / "nested" / "tu-9-other-edition", tu::ActiveFolder(root, title) / "tu-9-other-edition", ec);
  fs::copy_file(fs::path(argv[3]) / "tu-2", tu::ActiveFolder(root, title) / "tu-2-copy", ec);
  CHECK(Files(tu::ActiveFolder(root, title)) == 2);
  found = tu::Find(title, root, inboxes);
  CHECK(tu::Activate(*Named(found, "tu-5"), root, title));
  CHECK(Files(tu::ActiveFolder(root, title)) == 1 && fs::exists(tu::ActiveFolder(root, title) / "tu-5"));

  std::cout << (failures ? "FAILED " : "PASS ") << failures << " failures\n";
  return failures ? 1 : 0;
}
