"""Builds the title-updates local candidate on the installed framegen.4 executable.

Only the launcher object changes (Updates tab, update installed on Play). Every other object
is the one of build/framegen-stutter-20261010/native, checked by hash.
In xbox360ps5-radv-buildenv with the repository's parent mounted at /ws:
  python3 /ws/Xbox360PS5/build/title-updates-20261010/build.py
"""
from pathlib import Path
import hashlib
import json
import shutil
import struct  # used by the validation step taken from the framegen.3 recipe
import subprocess

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
base = root / 'build/framegen-stutter-20261010/native'
out = here / 'native'
record = json.loads((base / 'build.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(base / 'eboot.bin') == record['native_sha256'] == '09224f0f1f06224d6acf21f9bc6d39f95c8bb8fe5d35d785fd065f96e11f2914'
VERSION = '0.5.9-updates.1-local'
LABEL = VERSION.removesuffix('-local')
SHORT = LABEL.removeprefix('0.5.9-')

(out / 'obj').mkdir(parents=True, exist_ok=True)
for p in (base / 'obj').glob('*.o'):
    shutil.copy2(p, out / 'obj' / p.name)


def compile_with(command, source, obj, extra=()):
    c = list(command)
    c[1:1] = extra
    c[c.index('-c') + 1] = str(source)
    c[c.index('-o') + 1] = str(obj)
    subprocess.run(c, cwd=root, check=True)
    return c


# The unchanged launcher source still gives the installed object, byte for byte.
original = root / 'build/kinect-native-20261009/launcher.cpp'
compile_with(record['commands']['launcher'], original, here / 'launcher.proof.o')
assert sha(here / 'launcher.proof.o') == sha(base / 'obj/launcher.cpp.o'), 'launcher preimage drift'

launcher_cmd = [f'-DXBOX360PS5_VERSION="{LABEL}"' if a.startswith('-DXBOX360PS5_VERSION=') else a
                for a in record['commands']['launcher']]
launcher_build = compile_with(launcher_cmd, here / 'launcher.cpp', out / 'obj/launcher.cpp.o',
                              ['-I' + str(original.parent)])
changed = {'launcher.cpp.o'}
retained = {p.name: sha(p) for p in (base / 'obj').glob('*.o') if p.name not in changed}
assert all(sha(out / 'obj' / name) == value for name, value in retained.items())
assert {p.name for p in (out / 'obj').glob('*.o')} == set(record['objects'])
subprocess.run(['bash', str(root / 'build/kinect-update-20261008/native/link_dual_renderer_game.sh'), str(root), str(out)], check=True)

# Display version, image verification and signing: the reviewed step of the framegen.3 recipe.
s = (root / 'build/framegen-sword-20261010/build.py').read_text()
validation = s[s.index('# Display version'):s.index("(out / 'build.json').write_text")]
exec(compile(validation, 'framegen-sword build.py', 'exec'), globals())
image = (out / 'llvm-pie.elf').read_bytes()
for needle in (b'PPSA50011/updates', b'000B0000-off', b'Framegen: Sword FSR3 ready', b'shader-trace.conf'):
    assert needle in image, needle
commands = dict(record['commands'])
commands['launcher'] = launcher_build
(out / 'build.json').write_text(json.dumps({
    'version': VERSION, 'baseline_native_sha256': sha(base / 'eboot.bin'), 'native_sha256': sha(out / 'eboot.bin'),
    'launcher_preimage_identical': True, 'unchanged_objects': retained,
    'objects': {p.name: sha(p) for p in (out / 'obj').glob('*.o')}, 'commands': commands, 'hardware': 'pending'}, indent=2))
print('PASS', VERSION, sha(out / 'eboot.bin'))
