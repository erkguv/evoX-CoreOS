"""Render the game sheet's Updates tab with the launcher source of this folder (software raster).

Run in xbox360ps5-canary with the parent folder at /ws:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-canary:latest python3 -u /ws/Xbox360PS5/build/title-updates-20261010/render_updates.py name=keys ...
keys: comma-separated sq, x, o, tri, up, down, left, right, l1, r1 (prefix a count: 5r1). The first
sample game is given title 4E4D0860 and made-up update packages (see update_test.py).
"""
from pathlib import Path
import shlex
import shutil
import struct
import subprocess
import sys
import zipfile

root = Path('/ws/Xbox360PS5')
here = Path(__file__).resolve().parent
candidate = root / 'build/bully-loading-20261009/candidate'
menu = root / 'build/continuation-20261009/menu'
build = root / 'build/canary-runner'
out = here / 'preview'
objs = out / 'obj'
objs.mkdir(parents=True, exist_ok=True)

z = zipfile.ZipFile(root / 'build/release-v059/input/PS5X360-source-0.5.8-fix1.zip')
s = z.read('source/tools/preview-launcher.cpp').decode()
old = '    } else if (argc == 3) {'
assert s.count(old) == 1
s = s.replace(old, '''    } else if (argc == 3 && std::string(argv[2]).rfind("updates:", 0) == 0) {
      const auto paths = launcher.GamePaths();
      fs::copy_file("/app0/fixture-default.xex", paths[0], fs::copy_options::overwrite_existing);
      launcher.RecordLaunch({"Visual sample 1", paths[0], "XEX", paths[0].parent_path().string()}, 0x4E4D0860, "Visual sample 1", {}, 0);
      launcher.Scan();
      launcher.SetSaveRoot("/app0/saves");
      for (int i = 0; i < 3; ++i) launcher.Press(xbox360ps5::Key::left);
      std::string list = std::string(argv[2]).substr(8) + ",";
      for (size_t at = 0; at < list.size();) {
        const size_t end = list.find(',', at);
        std::string token = list.substr(at, end - at);
        at = end + 1;
        int count = 1;
        if (!token.empty() && std::isdigit(static_cast<unsigned char>(token[0]))) { count = token[0] - '0'; token = token.substr(1); }
        const xbox360ps5::Key key = token == "sq" ? xbox360ps5::Key::square : token == "x" ? xbox360ps5::Key::cross :
          token == "o" ? xbox360ps5::Key::circle : token == "tri" ? xbox360ps5::Key::triangle : token == "up" ? xbox360ps5::Key::up :
          token == "down" ? xbox360ps5::Key::down : token == "left" ? xbox360ps5::Key::left : token == "right" ? xbox360ps5::Key::right :
          token == "l1" ? xbox360ps5::Key::l1 : xbox360ps5::Key::r1;
        for (int n = 0; n < count; ++n) { launcher.Press(key); usleep(150000); }
      }
    } else if (argc == 3) {''')
s = s.replace('#include <algorithm>\n', '#include <algorithm>\n#include <unistd.h>\n', 1)
(out / 'preview-launcher.cpp').write_text(s)

ninja = (build / 'build.ninja').read_text()
target = next(line.split(': ', 1)[0][6:] for line in ninja.splitlines()
              if line.startswith('build CMakeFiles/xbox360ps5-launcher-preview.dir') and line.split(': ', 1)[0].endswith('/launcher.cpp.o'))
template = shlex.split(subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', target], text=True).splitlines()[-1])
includes = ['-I' + str(here), '-I' + str(root / 'build/kinect-native-20261009'), '-I' + str(candidate),
            '-I' + str(root / 'build/multidisc-ui-20261008/agent-library'),
            '-I' + str(menu / 'frozen/include'), '-I' + str(menu / 'frozen/src'),
            '-I' + str(root / 'build/dual-renderer-worktree/include'),
            '-I' + str(root / 'build/dual-renderer-worktree/.deps/xenia-canary/src')]
sources = {'launcher.cpp': here / 'launcher.cpp', 'preview-launcher.cpp': out / 'preview-launcher.cpp',
           'disc_library.cpp': candidate / 'disc_library.cpp', 'disc_catalog.cpp': candidate / 'disc_catalog.cpp'}
for name, source in sources.items():
    cmd = list(template)
    cmd[1:1] = includes
    cmd[cmd.index('-c') + 1] = str(source)
    cmd[cmd.index('-o') + 1] = str(objs / (name + '.o'))
    for i, a in enumerate(cmd):
        if a.startswith('-DXBOX360PS5_VERSION='):
            cmd[i] = '-DXBOX360PS5_VERSION="TEST updates.1"'
    subprocess.run(cmd, cwd=build, check=True)
line = subprocess.check_output(['ninja', '-C', str(build), '-t', 'commands', 'xbox360ps5-launcher-preview'], text=True).splitlines()[-1]
cmd = shlex.split(next(part for part in line.split(' && ') if ' -o xbox360ps5-launcher-preview ' in part))
replaced = set()
for i, a in enumerate(cmd):
    for n in sources:
        if a.endswith('/' + n + '.o'):
            cmd[i] = str(objs / (n + '.o'))
            replaced.add(n)
extra = [str(objs / (n + '.o')) for n in sources if n not in replaced]
cmd[cmd.index('-o') + 1] = str(objs / 'launcher-preview')
cmd[cmd.index('-o'):cmd.index('-o')] = extra
subprocess.run(cmd, cwd=build, check=True)

fonts = Path('/app0/assets/fonts')
fonts.mkdir(parents=True, exist_ok=True)
for p in (root / 'dist/PPSA50011/assets/fonts').glob('*.ttf'):
    shutil.copy2(p, fonts / p.name)

TITLE, MEDIA = 0x4E4D0860, 0x11112222
base = sorted((root / 'build/dlc-battlez-20261009/packages').iterdir())[0].read_bytes()[:0x20000]


def package(version, media=MEDIA, kind=0x000B0000, title=TITLE):
    data = bytearray(base)
    struct.pack_into('>I', data, 0x344, kind)
    struct.pack_into('>I', data, 0x354, media)
    struct.pack_into('>I', data, 0x358, version)
    struct.pack_into('>I', data, 0x360, title)
    return bytes(data)


xex = bytearray(b'XEX2' + b'\0' * 0x400)
struct.pack_into('>I', xex, 0x14, 1)
struct.pack_into('>II', xex, 0x18, 0x00040006, 0x300)
struct.pack_into('>IIII', xex, 0x300, MEDIA, 0x00000100, 0, TITLE)
for arg in sys.argv[1:]:
    name, keys = arg.split('=', 1)
    shutil.rmtree('/download0/xbox360ps5', ignore_errors=True)
    for folder in ('/app0/updates', '/app0/dlc', '/app0/saves'):
        shutil.rmtree(folder, ignore_errors=True)
        Path(folder).mkdir(parents=True)
    Path('/app0/fixture-default.xex').write_bytes(xex)
    Path('/app0/updates/tu00000005_00000000').write_bytes(package(0x00000500))
    Path('/app0/updates/tu00000009_other_disc').write_bytes(package(0x00000900, media=0x99990000))
    Path('/app0/updates/some-dlc').write_bytes(package(0x00000100, kind=2))
    Path('/app0/updates/notes.txt').write_text('not a package')
    Path('/app0/dlc/tu00000002_00000000').write_bytes(package(0x00000200))
    run = subprocess.run([str(objs / 'launcher-preview'), str(out / (name + '.png')), 'updates:' + keys], cwd=objs,
                         capture_output=True, text=True)
    print(name, run.returncode, (run.stdout + run.stderr).strip()[-200:])
