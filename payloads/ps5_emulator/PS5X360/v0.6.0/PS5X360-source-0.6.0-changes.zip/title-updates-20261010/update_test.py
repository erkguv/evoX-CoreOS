"""Build and run update_test.cpp, in xbox360ps5-canary:
  docker run --rm -v "C:/Users/bruno/Documents/PS5,:/ws" xbox360ps5-canary:latest python3 -u /ws/Xbox360PS5/build/title-updates-20261010/update_test.py
Update packages are made from a real package header (a Battle of Z DLC) with the content type,
version and media ID fields rewritten; no real title update is needed or shipped.
"""
from pathlib import Path
import shutil
import struct
import subprocess

here = Path(__file__).resolve().parent
packages = sorted((here.parent / 'dlc-battlez-20261009/packages').iterdir())
work = Path('/tmp/update-test')
shutil.rmtree(work, ignore_errors=True)
root, inbox, dlc = work / 'saves', work / 'updates', work / 'dlc'
for folder in (root, inbox / 'nested', dlc):
    folder.mkdir(parents=True)
base = packages[0].read_bytes()[:0x20000]  # header and a little data are enough
TITLE, MEDIA = 0x4E4D0860, 0x11112222


def package(version, media=MEDIA, kind=0x000B0000, title=TITLE, tail=b''):
    data = bytearray(base)
    struct.pack_into('>I', data, 0x344, kind)
    struct.pack_into('>I', data, 0x354, media)
    struct.pack_into('>I', data, 0x358, version)
    struct.pack_into('>I', data, 0x360, title)
    return bytes(data) + tail


(inbox / 'tu-5').write_bytes(package(0x00000500, tail=b'five'))
(dlc / 'tu-2').write_bytes(package(0x00000200))                      # dropped in the dlc folder
(inbox / 'nested' / 'tu-9-other-edition').write_bytes(package(0x00000900, media=0x99990000))
(inbox / 'dlc-not-update').write_bytes(package(0x00000100, kind=0x00000002))
(inbox / 'other-game').write_bytes(package(0x00000700, title=0x4D530000))
(inbox / 'readme.txt').write_text('not a package')
(inbox / '.hidden').mkdir()
(inbox / '.hidden' / 'tu-hidden').write_bytes(package(0x00000F00))

# A game as an executable (XEX2 with execution information), as a package, and as a disc image.
xex = bytearray(b'XEX2' + b'\0' * 0x400)
struct.pack_into('>I', xex, 0x14, 3)
for n, (key, value) in enumerate(((0x000002FF, 0x200), (0x00040006, 0x300), (0x00010100, 0))):
    struct.pack_into('>II', xex, 0x18 + n * 8, key, value)
struct.pack_into('>IIII', xex, 0x300, MEDIA, 0x00000100, 0, TITLE)
(work / 'default.xex').write_bytes(xex)
(work / 'game-package').write_bytes(package(0x00000100, kind=0x00007000))
(work / 'game.iso').write_bytes(b'\0' * 0x10000 + b'MICROSOFT*XBOX*MEDIA' + b'\0' * 0x400)

binary = work / 'update_test'
subprocess.run(['clang++-18', '-std=gnu++20', '-O1', '-g', '-fsanitize=address,undefined', '-pthread',
                f'-I{here}', f'-I{here.parent / "kinect-native-20261009"}',
                str(here / 'update_test.cpp'), '-o', str(binary)], check=True)
subprocess.run([str(binary), str(root), str(inbox), str(dlc), str(work / 'default.xex'),
                str(work / 'game-package'), str(work / 'game.iso')], check=True)
