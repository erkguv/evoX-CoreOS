# PS5X360 v0.1.0-preview — 2026-10-03

Experimental Xbox 360 emulation on PlayStation 5, based on Xenia Canary.

## Included in this preview

- Game library with cover flow, profiles and version-matched community patches.
- Touchpad guide that reveals from the center outward.
- Noto Sans fonts and English, Portuguese and Spanish interface translations.
- Automatic PS5 system-language detection, with English as the interface fallback.
- GPU upload and thread stack recommit fixes for the PS5 memory layout.
- Native DualSense input, audio output and RADV Vulkan rendering.

## Installation

Download **PS5X360-v0.1.0-preview.zip** below, extract it and copy the complete
`PPSA50011` folder to `/data/homebrew/PPSA50011` using FTP. Open PS5X360
through the homebrew title registered by ShadowMountPlus.

The development setup is PS5 firmware **13.60**, etaHEN, ShadowMountPlus and
kstuff. Other configurations have not been verified. This application requires
an already working homebrew environment.

Place each game in its own folder under `PPSA50011/assets/roms/`.
See [Installation and usage](https://github.com/BrinooTk/PS5X360/blob/main/docs/INSTALLATION.md)
for formats, controls, covers, profiles, language settings and updates.

The GitHub “Source code” archives are not the installable build.

## Verification and known issues

Games have run on the development PS5. This exact executable was compiled,
its mapped image was validated, and it was installed on that console.
The most recent fonts and language changes passed local tests; their appearance
and automatic language detection still need confirmation after reopening on PS5.

Sonic and Budokai regressions improved in host reproductions. This is not a claim
that every scene works on the console. Black screens during fights in
**Dragon Ball Z Burst Limit** and **Ultimate Tenkaichi** remain unresolved.
Read the [compatibility notes](https://github.com/BrinooTk/PS5X360/blob/main/docs/COMPATIBILITY.md).

Community patches ship disabled. Compatibility and performance vary by game.
No games, BIOS or keys are included. Credits and license notices accompany the ZIP.

## Download verification

A separate `.sha256` file verifies the release ZIP. `MANIFEST.json` inside the
archive records the size and SHA-256 digest of each application file.

## Support

If you would like to support PS5X360 and my other projects, visit [Ko-fi](https://ko-fi.com/brinoblitz). Contributions are optional and appreciated.
