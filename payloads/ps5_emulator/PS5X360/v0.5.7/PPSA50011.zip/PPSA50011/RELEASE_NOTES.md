# PS5X360 v0.5.7

This release fixes several games that stopped or showed broken pictures, gives every game its own settings, lets you change settings from a phone or a computer, and makes the game library keep itself up to date. Compatibility continues to improve, but results depend on the game, firmware and homebrew setup.

## What's new

### Games

- **Left 4 Dead 2** starts, shows its menu text and loads a match. Three separate causes: network addresses handed to the PS5 in the wrong layout ("Guest Kernel Crash (KeBugCheck)" at start), a picture the game reads back from the GPU being returned before it was finished (menu text shown as dots), and the visibility-query mode (the match stayed on its loading screen). The game now selects the settings it needs by itself. The first fix may help other games that open a network port at start; the second affects every game that needs "Image readback by the game".
- **Forza Horizon** no longer closes when START is pressed. Games that switch stacks (fibers) ended the emulator at the first switch; other games that closed by themselves at a fixed point may be the same.
- **Arcade / LIVE packages (STFS)** that crashed when started as a game, and games that keep data in a package inside another package or use the console's LZX decompression service.
- **Games that worked on v0.5.5 and stopped on v0.5.6:** the two speed-ups introduced in v0.5.6, "Fast locks" and "Optimized video memory", are now options and are **off by default**. Without them this release takes the same paths as v0.5.5. Grand Theft Auto IV, where they were measured, turns them on by itself.

### Settings

- **Every game has its own settings.** X on a game opens its sheet: **Play**, **Patches**, **Settings** and **Achievements** (L1/R1). The game's settings are grouped by subject (Graphics, Performance, Audio, Controls, System). What a game does not change follows the general settings. Triangle on the shelf goes straight to the game's settings; Square resets them to the recommended values.
- **Settings has two pages:** General, and Per game.
- **New options**, all at their usual value unless you choose otherwise: picture proportions (keep or stretch), emulated console resolution (480p, 540p, 720p, 1080p), emulated video rate 120 Hz (a test), console gamma, depth precision, decal fix, geometry rounding, shader preparation threads, fast dot product, conservative recompiler, access to address zero, audio decoder version, interface sound volume, and per-game vibration and stick dead zones.
- **Settings from a phone or a computer.** The address and key are on the bottom line of the library; Settings shows a QR code. Open it on the same network as the PS5. Options change while a game runs, and the Logs tab downloads every log, or one game's, as a ZIP.

### Library

- **New games appear by themselves** a few seconds after the copy to the console ends, and their covers are fetched. An extracted game can appear a little before a long copy finishes; wait for the copy before starting it.
- **OPTIONS reloads the list**, and "Refresh game list" in Settings now keeps the selected game and shows what it found.
- **Cover downloads are announced** on the library screen.

### Players and achievements

- **Up to four local players.** Controllers of different signed-in PS5 users take player slots 2 to 4; Settings > Profiles assigns a profile to each. The game itself must support local multiplayer.
- **Xbox 360 achievements** are announced with a PS5 notification and listed per game and per player. These are local Xbox achievement data, not PSN trophies.

### Diagnostics

- **Crash records are complete.** `boot.log` used to keep only the first line of a crash.
- **A game that stops says what it was waiting for.** When a game stops showing frames, or sits at one low frame rate for two minutes, its log lists what each of its threads waits for and the code that led there.

### Research, off by default

- **Camera motion (research)** receives an estimated body pose from a camera page and hands it to a Kinect game as its skeleton. It is not Kinect support: it has been seen working on a development PC only, depth and colour pictures, voice and identity are not emulated, and the body does not move across the room. Turn it on in the settings of a Kinect game only; a game with optional Kinect can wait forever with it on.

## Development testing

Seen on the development console (firmware 13.60): Left 4 Dead 2 starting, showing its text and loading a match; Forza Horizon passing START and continuing to load; complete crash records; per-game settings taking effect.

Not seen on a console yet: four physical controllers, a real achievement unlock, the Arcade package fix, the self-updating library and the new library footer in every language, and the camera motion research with a real game.

Host checks cover the readback ordering, the memory watch limits, the settings page and its ZIP export, the motion receiver, the skeleton frame layout and the package and decompression code. Host checks are not console gameplay results. This release does **not** promise locked 30/60 FPS or full-library compatibility.

## Known limits

- Rendering above the game's resolution (2x, 3x) is not offered: it closed every game when tried.
- "Emulated video rate 120 Hz" takes some 30 FPS games to 60 and makes others run too fast. Try it game by game.
- With "Shaders in the background" on (the default), an object or an effect can be missing for a moment while it is prepared. If something stays missing in a game, turn it off for that game.
- No Kinect support and no frame generation.

## Reporting a problem

Say which game, your firmware, what happened and where, and send the logs. The easiest way is the settings page, Logs tab, the button with the game's name; that ZIP already holds `boot.log`. By FTP the logs are in `/data/homebrew/PPSA50011/logs`. If a game worked on v0.5.5 and not since, open its Settings, subject Performance, and say whether "Fast locks" or "Optimized video memory" changes it.

## Downloads and installation

1. Download **PPSA50011.zip** and extract it.
2. Copy the complete `PPSA50011` folder to `/data/homebrew/` using your console's FTP service. Update the existing folder without deleting games, saves or logs.
3. Open PS5X360 through your already working homebrew environment.
4. Keep each game in its own folder under `PPSA50011/assets/roms`, or add other accessible folders in Settings.

The optional **PS5X360-AutoLog-v1.0.9-preview.elf** is unchanged from v0.5.6. It is a separate logger; read `PPSA50011/AUTOLOG.md` or the [AutoLog instructions](https://github.com/BrinooTk/PS5X360/blob/main/native/autolog/README.md) before loading it once after console boot. It does not install the emulator or a boot service. Games, BIOS and keys are not included.

Development setup: firmware 13.60, etaHEN, ShadowMountPlus and kstuff. Other setups require their own validation.

Support current and future projects: https://ko-fi.com/brinoblitz
