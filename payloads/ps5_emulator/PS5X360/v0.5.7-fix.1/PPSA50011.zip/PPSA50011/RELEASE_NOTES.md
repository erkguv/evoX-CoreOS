# PS5X360 v0.5.7-fix.1

This fix release builds on v0.5.7 and improves thread synchronization and local
player management.

## Fixes and improvements

- **Left 4 Dead 2:** the owner confirmed that the loading problem was resolved
  on the development PS5 after installing this build.
- **Thread synchronization:** nested suspensions and resumes now balance the
  guest and host counts. Initial suspension state is published atomically with
  its count, preventing a resume during thread startup from being lost. These
  are shared core fixes rather than a game-specific bypass.
- **Local players:** extra accounts sign in only when their controllers are
  connected and sign out when disconnected. Reconnecting reuses the preferred
  account. Old extra sign-ins are cleared before launching a game.
- **Profile removal:** in Settings > Profiles, press Square twice to confirm
  removal. Saves and account data are retained in `saves/removed-profiles`.
  The primary profile cannot be removed, and removal is blocked during gameplay.
- **Diagnostics:** logs distinguish stored accounts from signed-in players.

## Validation

The owner reported success on the development PS5 after the update. Host
regressions verified nested suspension/resumption and profile removal with save
preservation. Native image layout, release ZIP contents and manifest hashes
were checked. Four physical controllers and other firmware versions still
require separate validation. No locked frame rate or universal compatibility
is promised.

## Installation

1. Download **PPSA50011.zip** and extract it.
2. Close PS5X360, then copy the `PPSA50011` folder over the existing folder in
   `/data/homebrew/` using FTP. Keep your games, saves, settings and logs.
3. Open the emulator through your existing homebrew setup.

The optional **PS5X360-AutoLog-v1.0.9-preview.elf** is unchanged. Read the
included `PPSA50011/AUTOLOG.md` before loading it. Games, BIOS and keys are not
included.

Development console: firmware 13.60, etaHEN, ShadowMountPlus and kstuff.
Please report the game, firmware, build version and session logs when testing.

Support current and future projects: https://ko-fi.com/brinoblitz
