/* Castation - Homebrew Launcher entry.
 * Copyright (C) 2026 BlackBearReloaded
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * The launcher sweeps /data/homebrew for a file called homebrew.js or
 * eboot.elf and lists whatever it finds. A bare eboot.elf is listed under that
 * name, which tells nobody what it is; this says what the entry is called and
 * which picture goes with it, and hands back the same executable to run.
 *
 * The launcher runs this in a sandboxed frame with a five second budget, so it
 * does the least it can: no requests, no waiting, one object returned. If it
 * were deleted the launcher would fall back to listing eboot.elf directly, and
 * the emulator would still start.
 */

// @ts-nocheck

async function main() {
    // The launcher sets workingDir to the folder this file came from, which is
    // also where the executable and the icon are.
    const directory =
        typeof window.workingDir === "string" && window.workingDir.length > 0
            ? window.workingDir
            : "/data/homebrew/Castation";

    const entry = {
        mainText: "Castation",
        secondaryText: "Dreamcast emulator",
        onclick: () => ({ path: directory + "/eboot.elf" }),
        options: [
            {
                // The disc it last played, without going through the library.
                text: "Resume last disc",
                onclick: () => ({ path: directory + "/eboot.elf", args: "--auto" })
            }
        ]
    };

    // baseURL comes from the launcher's own client, which is injected here too.
    // Without it the entry simply has no picture, which is not worth failing on.
    if (typeof baseURL === "string") {
        entry.imgPath = baseURL + "/fs" + directory + "/sce_sys/icon0.png";
    }
    return entry;
}
