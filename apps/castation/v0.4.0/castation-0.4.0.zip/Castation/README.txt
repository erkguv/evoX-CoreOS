Castation 0.4.0 - a Dreamcast emulator for a jailbroken PlayStation 5

Extract this archive into /data/homebrew/ on the console, so that the files
land as:

    /data/homebrew/Castation/eboot.elf
    /data/homebrew/Castation/homebrew.js
    /data/homebrew/Castation/sce_sys/icon0.png

Then put your own disc images (.chd, .gdi, .cdi, .cue, .m3u, .zip) in:

    /data/homebrew/Castation/games/

A Dreamcast BIOS is optional. If you have one, put it in:

    /data/homebrew/Castation/bios/

Without one, turn on HLE BIOS on the settings screen before choosing a game;
that setting only takes effect when a disc is loaded.

Open the Homebrew Launcher and start Castation. Saves and logs are written to
/data/Castation/.

Known problems in this release: emulation runs at about 96% of full speed, so
sound is about 4% flat in pitch; single frames stall for 50 to 100 ms while the
recompiler translates new code; heavy 3D scenes hold around 57 frames a second
rather than 60. The README in the repository explains why.

No BIOS and no game data is included in this archive. Supply your own, from
discs you own.

Castation is free software under the GNU General Public License, version 3 or
later. It is built on Flycast (https://github.com/flyinghead/flycast). The
complete corresponding source is at:

    https://github.com/BrinooTk/castation

Dreamcast is a trademark of Sega. This project is not affiliated with or
endorsed by Sega or Sony.
